; Auto-generated. Do not edit!


(cl:in-package pgm_learner-srv)


;//! \htmlinclude DiscreteStructureEstimation-request.msg.html

(cl:defclass <DiscreteStructureEstimation-request> (roslisp-msg-protocol:ros-message)
  ((states
    :reader states
    :initarg :states
    :type (cl:vector pgm_learner-msg:DiscreteGraphState)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:DiscreteGraphState :initial-element (cl:make-instance 'pgm_learner-msg:DiscreteGraphState)))
   (pvalparam
    :reader pvalparam
    :initarg :pvalparam
    :type cl:float
    :initform 0.0)
   (indegree
    :reader indegree
    :initarg :indegree
    :type cl:fixnum
    :initform 0))
)

(cl:defclass DiscreteStructureEstimation-request (<DiscreteStructureEstimation-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DiscreteStructureEstimation-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DiscreteStructureEstimation-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<DiscreteStructureEstimation-request> is deprecated: use pgm_learner-srv:DiscreteStructureEstimation-request instead.")))

(cl:ensure-generic-function 'states-val :lambda-list '(m))
(cl:defmethod states-val ((m <DiscreteStructureEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:states-val is deprecated.  Use pgm_learner-srv:states instead.")
  (states m))

(cl:ensure-generic-function 'pvalparam-val :lambda-list '(m))
(cl:defmethod pvalparam-val ((m <DiscreteStructureEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:pvalparam-val is deprecated.  Use pgm_learner-srv:pvalparam instead.")
  (pvalparam m))

(cl:ensure-generic-function 'indegree-val :lambda-list '(m))
(cl:defmethod indegree-val ((m <DiscreteStructureEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:indegree-val is deprecated.  Use pgm_learner-srv:indegree instead.")
  (indegree m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DiscreteStructureEstimation-request>) ostream)
  "Serializes a message object of type '<DiscreteStructureEstimation-request>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'states))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'states))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'pvalparam))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'indegree)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'indegree)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DiscreteStructureEstimation-request>) istream)
  "Deserializes a message object of type '<DiscreteStructureEstimation-request>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'states) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'states)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:DiscreteGraphState))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'pvalparam) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'indegree)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'indegree)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DiscreteStructureEstimation-request>)))
  "Returns string type for a service object of type '<DiscreteStructureEstimation-request>"
  "pgm_learner/DiscreteStructureEstimationRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteStructureEstimation-request)))
  "Returns string type for a service object of type 'DiscreteStructureEstimation-request"
  "pgm_learner/DiscreteStructureEstimationRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DiscreteStructureEstimation-request>)))
  "Returns md5sum for a message object of type '<DiscreteStructureEstimation-request>"
  "d5c235f713e8f4b23d3bb3e7113a4066")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DiscreteStructureEstimation-request)))
  "Returns md5sum for a message object of type 'DiscreteStructureEstimation-request"
  "d5c235f713e8f4b23d3bb3e7113a4066")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DiscreteStructureEstimation-request>)))
  "Returns full string definition for message of type '<DiscreteStructureEstimation-request>"
  (cl:format cl:nil "pgm_learner/DiscreteGraphState[] states # trial data~%float64 pvalparam # optional~%uint16 indegree # optional~%~%================================================================================~%MSG: pgm_learner/DiscreteGraphState~%pgm_learner/DiscreteNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/DiscreteNodeState~%string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DiscreteStructureEstimation-request)))
  "Returns full string definition for message of type 'DiscreteStructureEstimation-request"
  (cl:format cl:nil "pgm_learner/DiscreteGraphState[] states # trial data~%float64 pvalparam # optional~%uint16 indegree # optional~%~%================================================================================~%MSG: pgm_learner/DiscreteGraphState~%pgm_learner/DiscreteNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/DiscreteNodeState~%string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DiscreteStructureEstimation-request>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'states) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     8
     2
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DiscreteStructureEstimation-request>))
  "Converts a ROS message object to a list"
  (cl:list 'DiscreteStructureEstimation-request
    (cl:cons ':states (states msg))
    (cl:cons ':pvalparam (pvalparam msg))
    (cl:cons ':indegree (indegree msg))
))
;//! \htmlinclude DiscreteStructureEstimation-response.msg.html

(cl:defclass <DiscreteStructureEstimation-response> (roslisp-msg-protocol:ros-message)
  ((graph
    :reader graph
    :initarg :graph
    :type pgm_learner-msg:GraphStructure
    :initform (cl:make-instance 'pgm_learner-msg:GraphStructure)))
)

(cl:defclass DiscreteStructureEstimation-response (<DiscreteStructureEstimation-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DiscreteStructureEstimation-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DiscreteStructureEstimation-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<DiscreteStructureEstimation-response> is deprecated: use pgm_learner-srv:DiscreteStructureEstimation-response instead.")))

(cl:ensure-generic-function 'graph-val :lambda-list '(m))
(cl:defmethod graph-val ((m <DiscreteStructureEstimation-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:graph-val is deprecated.  Use pgm_learner-srv:graph instead.")
  (graph m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DiscreteStructureEstimation-response>) ostream)
  "Serializes a message object of type '<DiscreteStructureEstimation-response>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'graph) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DiscreteStructureEstimation-response>) istream)
  "Deserializes a message object of type '<DiscreteStructureEstimation-response>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'graph) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DiscreteStructureEstimation-response>)))
  "Returns string type for a service object of type '<DiscreteStructureEstimation-response>"
  "pgm_learner/DiscreteStructureEstimationResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteStructureEstimation-response)))
  "Returns string type for a service object of type 'DiscreteStructureEstimation-response"
  "pgm_learner/DiscreteStructureEstimationResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DiscreteStructureEstimation-response>)))
  "Returns md5sum for a message object of type '<DiscreteStructureEstimation-response>"
  "d5c235f713e8f4b23d3bb3e7113a4066")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DiscreteStructureEstimation-response)))
  "Returns md5sum for a message object of type 'DiscreteStructureEstimation-response"
  "d5c235f713e8f4b23d3bb3e7113a4066")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DiscreteStructureEstimation-response>)))
  "Returns full string definition for message of type '<DiscreteStructureEstimation-response>"
  (cl:format cl:nil "pgm_learner/GraphStructure graph # structure of network~%~%~%================================================================================~%MSG: pgm_learner/GraphStructure~%string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DiscreteStructureEstimation-response)))
  "Returns full string definition for message of type 'DiscreteStructureEstimation-response"
  (cl:format cl:nil "pgm_learner/GraphStructure graph # structure of network~%~%~%================================================================================~%MSG: pgm_learner/GraphStructure~%string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DiscreteStructureEstimation-response>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'graph))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DiscreteStructureEstimation-response>))
  "Converts a ROS message object to a list"
  (cl:list 'DiscreteStructureEstimation-response
    (cl:cons ':graph (graph msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'DiscreteStructureEstimation)))
  'DiscreteStructureEstimation-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'DiscreteStructureEstimation)))
  'DiscreteStructureEstimation-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteStructureEstimation)))
  "Returns string type for a service object of type '<DiscreteStructureEstimation>"
  "pgm_learner/DiscreteStructureEstimation")
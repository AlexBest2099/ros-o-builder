; Auto-generated. Do not edit!


(cl:in-package pgm_learner-srv)


;//! \htmlinclude DiscreteParameterEstimation-request.msg.html

(cl:defclass <DiscreteParameterEstimation-request> (roslisp-msg-protocol:ros-message)
  ((graph
    :reader graph
    :initarg :graph
    :type pgm_learner-msg:GraphStructure
    :initform (cl:make-instance 'pgm_learner-msg:GraphStructure))
   (states
    :reader states
    :initarg :states
    :type (cl:vector pgm_learner-msg:DiscreteGraphState)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:DiscreteGraphState :initial-element (cl:make-instance 'pgm_learner-msg:DiscreteGraphState))))
)

(cl:defclass DiscreteParameterEstimation-request (<DiscreteParameterEstimation-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DiscreteParameterEstimation-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DiscreteParameterEstimation-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<DiscreteParameterEstimation-request> is deprecated: use pgm_learner-srv:DiscreteParameterEstimation-request instead.")))

(cl:ensure-generic-function 'graph-val :lambda-list '(m))
(cl:defmethod graph-val ((m <DiscreteParameterEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:graph-val is deprecated.  Use pgm_learner-srv:graph instead.")
  (graph m))

(cl:ensure-generic-function 'states-val :lambda-list '(m))
(cl:defmethod states-val ((m <DiscreteParameterEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:states-val is deprecated.  Use pgm_learner-srv:states instead.")
  (states m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DiscreteParameterEstimation-request>) ostream)
  "Serializes a message object of type '<DiscreteParameterEstimation-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'graph) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'states))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'states))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DiscreteParameterEstimation-request>) istream)
  "Deserializes a message object of type '<DiscreteParameterEstimation-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'graph) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'states) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'states)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:DiscreteGraphState))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DiscreteParameterEstimation-request>)))
  "Returns string type for a service object of type '<DiscreteParameterEstimation-request>"
  "pgm_learner/DiscreteParameterEstimationRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteParameterEstimation-request)))
  "Returns string type for a service object of type 'DiscreteParameterEstimation-request"
  "pgm_learner/DiscreteParameterEstimationRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DiscreteParameterEstimation-request>)))
  "Returns md5sum for a message object of type '<DiscreteParameterEstimation-request>"
  "bf4a94ba6c903228425606a8b08d8ab9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DiscreteParameterEstimation-request)))
  "Returns md5sum for a message object of type 'DiscreteParameterEstimation-request"
  "bf4a94ba6c903228425606a8b08d8ab9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DiscreteParameterEstimation-request>)))
  "Returns full string definition for message of type '<DiscreteParameterEstimation-request>"
  (cl:format cl:nil "pgm_learner/GraphStructure graph # graph skeleton~%pgm_learner/DiscreteGraphState[] states # trial data~%~%================================================================================~%MSG: pgm_learner/GraphStructure~%string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%================================================================================~%MSG: pgm_learner/DiscreteGraphState~%pgm_learner/DiscreteNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/DiscreteNodeState~%string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DiscreteParameterEstimation-request)))
  "Returns full string definition for message of type 'DiscreteParameterEstimation-request"
  (cl:format cl:nil "pgm_learner/GraphStructure graph # graph skeleton~%pgm_learner/DiscreteGraphState[] states # trial data~%~%================================================================================~%MSG: pgm_learner/GraphStructure~%string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%================================================================================~%MSG: pgm_learner/DiscreteGraphState~%pgm_learner/DiscreteNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/DiscreteNodeState~%string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DiscreteParameterEstimation-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'graph))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'states) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DiscreteParameterEstimation-request>))
  "Converts a ROS message object to a list"
  (cl:list 'DiscreteParameterEstimation-request
    (cl:cons ':graph (graph msg))
    (cl:cons ':states (states msg))
))
;//! \htmlinclude DiscreteParameterEstimation-response.msg.html

(cl:defclass <DiscreteParameterEstimation-response> (roslisp-msg-protocol:ros-message)
  ((nodes
    :reader nodes
    :initarg :nodes
    :type (cl:vector pgm_learner-msg:DiscreteNode)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:DiscreteNode :initial-element (cl:make-instance 'pgm_learner-msg:DiscreteNode))))
)

(cl:defclass DiscreteParameterEstimation-response (<DiscreteParameterEstimation-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DiscreteParameterEstimation-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DiscreteParameterEstimation-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<DiscreteParameterEstimation-response> is deprecated: use pgm_learner-srv:DiscreteParameterEstimation-response instead.")))

(cl:ensure-generic-function 'nodes-val :lambda-list '(m))
(cl:defmethod nodes-val ((m <DiscreteParameterEstimation-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:nodes-val is deprecated.  Use pgm_learner-srv:nodes instead.")
  (nodes m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DiscreteParameterEstimation-response>) ostream)
  "Serializes a message object of type '<DiscreteParameterEstimation-response>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'nodes))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'nodes))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DiscreteParameterEstimation-response>) istream)
  "Deserializes a message object of type '<DiscreteParameterEstimation-response>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'nodes) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'nodes)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:DiscreteNode))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DiscreteParameterEstimation-response>)))
  "Returns string type for a service object of type '<DiscreteParameterEstimation-response>"
  "pgm_learner/DiscreteParameterEstimationResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteParameterEstimation-response)))
  "Returns string type for a service object of type 'DiscreteParameterEstimation-response"
  "pgm_learner/DiscreteParameterEstimationResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DiscreteParameterEstimation-response>)))
  "Returns md5sum for a message object of type '<DiscreteParameterEstimation-response>"
  "bf4a94ba6c903228425606a8b08d8ab9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DiscreteParameterEstimation-response)))
  "Returns md5sum for a message object of type 'DiscreteParameterEstimation-response"
  "bf4a94ba6c903228425606a8b08d8ab9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DiscreteParameterEstimation-response>)))
  "Returns full string definition for message of type '<DiscreteParameterEstimation-response>"
  (cl:format cl:nil "pgm_learner/DiscreteNode[] nodes # information of each nodes~%~%~%================================================================================~%MSG: pgm_learner/DiscreteNode~%string name~%string[] outcomes~%string[] parents~%string[] children~%pgm_learner/ConditionalProbability[] CPT~%~%================================================================================~%MSG: pgm_learner/ConditionalProbability~%string[]  values~%float32[] probabilities~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DiscreteParameterEstimation-response)))
  "Returns full string definition for message of type 'DiscreteParameterEstimation-response"
  (cl:format cl:nil "pgm_learner/DiscreteNode[] nodes # information of each nodes~%~%~%================================================================================~%MSG: pgm_learner/DiscreteNode~%string name~%string[] outcomes~%string[] parents~%string[] children~%pgm_learner/ConditionalProbability[] CPT~%~%================================================================================~%MSG: pgm_learner/ConditionalProbability~%string[]  values~%float32[] probabilities~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DiscreteParameterEstimation-response>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'nodes) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DiscreteParameterEstimation-response>))
  "Converts a ROS message object to a list"
  (cl:list 'DiscreteParameterEstimation-response
    (cl:cons ':nodes (nodes msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'DiscreteParameterEstimation)))
  'DiscreteParameterEstimation-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'DiscreteParameterEstimation)))
  'DiscreteParameterEstimation-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteParameterEstimation)))
  "Returns string type for a service object of type '<DiscreteParameterEstimation>"
  "pgm_learner/DiscreteParameterEstimation")
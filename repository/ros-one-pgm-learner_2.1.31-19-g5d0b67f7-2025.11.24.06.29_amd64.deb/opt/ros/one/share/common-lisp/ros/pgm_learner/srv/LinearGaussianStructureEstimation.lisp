; Auto-generated. Do not edit!


(cl:in-package pgm_learner-srv)


;//! \htmlinclude LinearGaussianStructureEstimation-request.msg.html

(cl:defclass <LinearGaussianStructureEstimation-request> (roslisp-msg-protocol:ros-message)
  ((states
    :reader states
    :initarg :states
    :type (cl:vector pgm_learner-msg:LinearGaussianGraphState)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:LinearGaussianGraphState :initial-element (cl:make-instance 'pgm_learner-msg:LinearGaussianGraphState)))
   (pvalparam
    :reader pvalparam
    :initarg :pvalparam
    :type cl:float
    :initform 0.0)
   (bins
    :reader bins
    :initarg :bins
    :type cl:fixnum
    :initform 0)
   (indegree
    :reader indegree
    :initarg :indegree
    :type cl:fixnum
    :initform 0))
)

(cl:defclass LinearGaussianStructureEstimation-request (<LinearGaussianStructureEstimation-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LinearGaussianStructureEstimation-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LinearGaussianStructureEstimation-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<LinearGaussianStructureEstimation-request> is deprecated: use pgm_learner-srv:LinearGaussianStructureEstimation-request instead.")))

(cl:ensure-generic-function 'states-val :lambda-list '(m))
(cl:defmethod states-val ((m <LinearGaussianStructureEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:states-val is deprecated.  Use pgm_learner-srv:states instead.")
  (states m))

(cl:ensure-generic-function 'pvalparam-val :lambda-list '(m))
(cl:defmethod pvalparam-val ((m <LinearGaussianStructureEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:pvalparam-val is deprecated.  Use pgm_learner-srv:pvalparam instead.")
  (pvalparam m))

(cl:ensure-generic-function 'bins-val :lambda-list '(m))
(cl:defmethod bins-val ((m <LinearGaussianStructureEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:bins-val is deprecated.  Use pgm_learner-srv:bins instead.")
  (bins m))

(cl:ensure-generic-function 'indegree-val :lambda-list '(m))
(cl:defmethod indegree-val ((m <LinearGaussianStructureEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:indegree-val is deprecated.  Use pgm_learner-srv:indegree instead.")
  (indegree m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LinearGaussianStructureEstimation-request>) ostream)
  "Serializes a message object of type '<LinearGaussianStructureEstimation-request>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'states))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'states))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'pvalparam))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'bins)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'bins)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'indegree)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'indegree)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LinearGaussianStructureEstimation-request>) istream)
  "Deserializes a message object of type '<LinearGaussianStructureEstimation-request>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'states) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'states)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:LinearGaussianGraphState))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'pvalparam) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'bins)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'bins)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'indegree)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'indegree)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LinearGaussianStructureEstimation-request>)))
  "Returns string type for a service object of type '<LinearGaussianStructureEstimation-request>"
  "pgm_learner/LinearGaussianStructureEstimationRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinearGaussianStructureEstimation-request)))
  "Returns string type for a service object of type 'LinearGaussianStructureEstimation-request"
  "pgm_learner/LinearGaussianStructureEstimationRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LinearGaussianStructureEstimation-request>)))
  "Returns md5sum for a message object of type '<LinearGaussianStructureEstimation-request>"
  "1672c2df657722c2698213e54a484e74")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LinearGaussianStructureEstimation-request)))
  "Returns md5sum for a message object of type 'LinearGaussianStructureEstimation-request"
  "1672c2df657722c2698213e54a484e74")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LinearGaussianStructureEstimation-request>)))
  "Returns full string definition for message of type '<LinearGaussianStructureEstimation-request>"
  (cl:format cl:nil "pgm_learner/LinearGaussianGraphState[] states # trial data~%float64 pvalparam # optional~%uint16 bins # optional~%uint16 indegree # optional~%~%================================================================================~%MSG: pgm_learner/LinearGaussianGraphState~%pgm_learner/LinearGaussianNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/LinearGaussianNodeState~%string node~%float32 state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LinearGaussianStructureEstimation-request)))
  "Returns full string definition for message of type 'LinearGaussianStructureEstimation-request"
  (cl:format cl:nil "pgm_learner/LinearGaussianGraphState[] states # trial data~%float64 pvalparam # optional~%uint16 bins # optional~%uint16 indegree # optional~%~%================================================================================~%MSG: pgm_learner/LinearGaussianGraphState~%pgm_learner/LinearGaussianNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/LinearGaussianNodeState~%string node~%float32 state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LinearGaussianStructureEstimation-request>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'states) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     8
     2
     2
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LinearGaussianStructureEstimation-request>))
  "Converts a ROS message object to a list"
  (cl:list 'LinearGaussianStructureEstimation-request
    (cl:cons ':states (states msg))
    (cl:cons ':pvalparam (pvalparam msg))
    (cl:cons ':bins (bins msg))
    (cl:cons ':indegree (indegree msg))
))
;//! \htmlinclude LinearGaussianStructureEstimation-response.msg.html

(cl:defclass <LinearGaussianStructureEstimation-response> (roslisp-msg-protocol:ros-message)
  ((graph
    :reader graph
    :initarg :graph
    :type pgm_learner-msg:GraphStructure
    :initform (cl:make-instance 'pgm_learner-msg:GraphStructure)))
)

(cl:defclass LinearGaussianStructureEstimation-response (<LinearGaussianStructureEstimation-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LinearGaussianStructureEstimation-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LinearGaussianStructureEstimation-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<LinearGaussianStructureEstimation-response> is deprecated: use pgm_learner-srv:LinearGaussianStructureEstimation-response instead.")))

(cl:ensure-generic-function 'graph-val :lambda-list '(m))
(cl:defmethod graph-val ((m <LinearGaussianStructureEstimation-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:graph-val is deprecated.  Use pgm_learner-srv:graph instead.")
  (graph m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LinearGaussianStructureEstimation-response>) ostream)
  "Serializes a message object of type '<LinearGaussianStructureEstimation-response>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'graph) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LinearGaussianStructureEstimation-response>) istream)
  "Deserializes a message object of type '<LinearGaussianStructureEstimation-response>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'graph) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LinearGaussianStructureEstimation-response>)))
  "Returns string type for a service object of type '<LinearGaussianStructureEstimation-response>"
  "pgm_learner/LinearGaussianStructureEstimationResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinearGaussianStructureEstimation-response)))
  "Returns string type for a service object of type 'LinearGaussianStructureEstimation-response"
  "pgm_learner/LinearGaussianStructureEstimationResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LinearGaussianStructureEstimation-response>)))
  "Returns md5sum for a message object of type '<LinearGaussianStructureEstimation-response>"
  "1672c2df657722c2698213e54a484e74")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LinearGaussianStructureEstimation-response)))
  "Returns md5sum for a message object of type 'LinearGaussianStructureEstimation-response"
  "1672c2df657722c2698213e54a484e74")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LinearGaussianStructureEstimation-response>)))
  "Returns full string definition for message of type '<LinearGaussianStructureEstimation-response>"
  (cl:format cl:nil "pgm_learner/GraphStructure graph # structure of network~%~%~%================================================================================~%MSG: pgm_learner/GraphStructure~%string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LinearGaussianStructureEstimation-response)))
  "Returns full string definition for message of type 'LinearGaussianStructureEstimation-response"
  (cl:format cl:nil "pgm_learner/GraphStructure graph # structure of network~%~%~%================================================================================~%MSG: pgm_learner/GraphStructure~%string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LinearGaussianStructureEstimation-response>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'graph))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LinearGaussianStructureEstimation-response>))
  "Converts a ROS message object to a list"
  (cl:list 'LinearGaussianStructureEstimation-response
    (cl:cons ':graph (graph msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'LinearGaussianStructureEstimation)))
  'LinearGaussianStructureEstimation-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'LinearGaussianStructureEstimation)))
  'LinearGaussianStructureEstimation-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinearGaussianStructureEstimation)))
  "Returns string type for a service object of type '<LinearGaussianStructureEstimation>"
  "pgm_learner/LinearGaussianStructureEstimation")
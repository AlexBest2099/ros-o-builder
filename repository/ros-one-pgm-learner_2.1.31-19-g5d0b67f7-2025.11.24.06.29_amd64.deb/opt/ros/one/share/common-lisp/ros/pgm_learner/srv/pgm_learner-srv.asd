
(cl:in-package :asdf)

(defsystem "pgm_learner-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :pgm_learner-msg
)
  :components ((:file "_package")
    (:file "DiscreteParameterEstimation" :depends-on ("_package_DiscreteParameterEstimation"))
    (:file "_package_DiscreteParameterEstimation" :depends-on ("_package"))
    (:file "DiscreteQuery" :depends-on ("_package_DiscreteQuery"))
    (:file "_package_DiscreteQuery" :depends-on ("_package"))
    (:file "DiscreteStructureEstimation" :depends-on ("_package_DiscreteStructureEstimation"))
    (:file "_package_DiscreteStructureEstimation" :depends-on ("_package"))
    (:file "LinearGaussianParameterEstimation" :depends-on ("_package_LinearGaussianParameterEstimation"))
    (:file "_package_LinearGaussianParameterEstimation" :depends-on ("_package"))
    (:file "LinearGaussianStructureEstimation" :depends-on ("_package_LinearGaussianStructureEstimation"))
    (:file "_package_LinearGaussianStructureEstimation" :depends-on ("_package"))
  ))
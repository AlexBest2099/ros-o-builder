; Auto-generated. Do not edit!


(cl:in-package pgm_learner-msg)


;//! \htmlinclude GraphStructure.msg.html

(cl:defclass <GraphStructure> (roslisp-msg-protocol:ros-message)
  ((nodes
    :reader nodes
    :initarg :nodes
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (edges
    :reader edges
    :initarg :edges
    :type (cl:vector pgm_learner-msg:GraphEdge)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:GraphEdge :initial-element (cl:make-instance 'pgm_learner-msg:GraphEdge))))
)

(cl:defclass GraphStructure (<GraphStructure>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <GraphStructure>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'GraphStructure)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-msg:<GraphStructure> is deprecated: use pgm_learner-msg:GraphStructure instead.")))

(cl:ensure-generic-function 'nodes-val :lambda-list '(m))
(cl:defmethod nodes-val ((m <GraphStructure>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:nodes-val is deprecated.  Use pgm_learner-msg:nodes instead.")
  (nodes m))

(cl:ensure-generic-function 'edges-val :lambda-list '(m))
(cl:defmethod edges-val ((m <GraphStructure>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:edges-val is deprecated.  Use pgm_learner-msg:edges instead.")
  (edges m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <GraphStructure>) ostream)
  "Serializes a message object of type '<GraphStructure>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'nodes))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'nodes))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'edges))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'edges))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <GraphStructure>) istream)
  "Deserializes a message object of type '<GraphStructure>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'nodes) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'nodes)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'edges) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'edges)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:GraphEdge))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<GraphStructure>)))
  "Returns string type for a message object of type '<GraphStructure>"
  "pgm_learner/GraphStructure")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'GraphStructure)))
  "Returns string type for a message object of type 'GraphStructure"
  "pgm_learner/GraphStructure")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<GraphStructure>)))
  "Returns md5sum for a message object of type '<GraphStructure>"
  "304d6cd63065185c359cebaf1ff017e9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'GraphStructure)))
  "Returns md5sum for a message object of type 'GraphStructure"
  "304d6cd63065185c359cebaf1ff017e9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<GraphStructure>)))
  "Returns full string definition for message of type '<GraphStructure>"
  (cl:format cl:nil "string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'GraphStructure)))
  "Returns full string definition for message of type 'GraphStructure"
  (cl:format cl:nil "string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <GraphStructure>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'nodes) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'edges) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <GraphStructure>))
  "Converts a ROS message object to a list"
  (cl:list 'GraphStructure
    (cl:cons ':nodes (nodes msg))
    (cl:cons ':edges (edges msg))
))

; Auto-generated. Do not edit!


(cl:in-package pgm_learner-srv)


;//! \htmlinclude DiscreteQuery-request.msg.html

(cl:defclass <DiscreteQuery-request> (roslisp-msg-protocol:ros-message)
  ((nodes
    :reader nodes
    :initarg :nodes
    :type (cl:vector pgm_learner-msg:DiscreteNode)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:DiscreteNode :initial-element (cl:make-instance 'pgm_learner-msg:DiscreteNode)))
   (evidence
    :reader evidence
    :initarg :evidence
    :type (cl:vector pgm_learner-msg:DiscreteNodeState)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:DiscreteNodeState :initial-element (cl:make-instance 'pgm_learner-msg:DiscreteNodeState)))
   (query
    :reader query
    :initarg :query
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element "")))
)

(cl:defclass DiscreteQuery-request (<DiscreteQuery-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DiscreteQuery-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DiscreteQuery-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<DiscreteQuery-request> is deprecated: use pgm_learner-srv:DiscreteQuery-request instead.")))

(cl:ensure-generic-function 'nodes-val :lambda-list '(m))
(cl:defmethod nodes-val ((m <DiscreteQuery-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:nodes-val is deprecated.  Use pgm_learner-srv:nodes instead.")
  (nodes m))

(cl:ensure-generic-function 'evidence-val :lambda-list '(m))
(cl:defmethod evidence-val ((m <DiscreteQuery-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:evidence-val is deprecated.  Use pgm_learner-srv:evidence instead.")
  (evidence m))

(cl:ensure-generic-function 'query-val :lambda-list '(m))
(cl:defmethod query-val ((m <DiscreteQuery-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:query-val is deprecated.  Use pgm_learner-srv:query instead.")
  (query m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DiscreteQuery-request>) ostream)
  "Serializes a message object of type '<DiscreteQuery-request>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'nodes))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'nodes))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'evidence))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'evidence))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'query))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'query))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DiscreteQuery-request>) istream)
  "Deserializes a message object of type '<DiscreteQuery-request>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'nodes) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'nodes)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:DiscreteNode))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'evidence) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'evidence)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:DiscreteNodeState))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'query) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'query)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DiscreteQuery-request>)))
  "Returns string type for a service object of type '<DiscreteQuery-request>"
  "pgm_learner/DiscreteQueryRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteQuery-request)))
  "Returns string type for a service object of type 'DiscreteQuery-request"
  "pgm_learner/DiscreteQueryRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DiscreteQuery-request>)))
  "Returns md5sum for a message object of type '<DiscreteQuery-request>"
  "268044a2749deb7a93e17566a63deb21")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DiscreteQuery-request)))
  "Returns md5sum for a message object of type 'DiscreteQuery-request"
  "268044a2749deb7a93e17566a63deb21")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DiscreteQuery-request>)))
  "Returns full string definition for message of type '<DiscreteQuery-request>"
  (cl:format cl:nil "pgm_learner/DiscreteNode[] nodes # information of each nodes~%pgm_learner/DiscreteNodeState[] evidence # evidnce~%string[] query # query~%~%================================================================================~%MSG: pgm_learner/DiscreteNode~%string name~%string[] outcomes~%string[] parents~%string[] children~%pgm_learner/ConditionalProbability[] CPT~%~%================================================================================~%MSG: pgm_learner/ConditionalProbability~%string[]  values~%float32[] probabilities~%~%================================================================================~%MSG: pgm_learner/DiscreteNodeState~%string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DiscreteQuery-request)))
  "Returns full string definition for message of type 'DiscreteQuery-request"
  (cl:format cl:nil "pgm_learner/DiscreteNode[] nodes # information of each nodes~%pgm_learner/DiscreteNodeState[] evidence # evidnce~%string[] query # query~%~%================================================================================~%MSG: pgm_learner/DiscreteNode~%string name~%string[] outcomes~%string[] parents~%string[] children~%pgm_learner/ConditionalProbability[] CPT~%~%================================================================================~%MSG: pgm_learner/ConditionalProbability~%string[]  values~%float32[] probabilities~%~%================================================================================~%MSG: pgm_learner/DiscreteNodeState~%string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DiscreteQuery-request>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'nodes) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'evidence) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'query) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DiscreteQuery-request>))
  "Converts a ROS message object to a list"
  (cl:list 'DiscreteQuery-request
    (cl:cons ':nodes (nodes msg))
    (cl:cons ':evidence (evidence msg))
    (cl:cons ':query (query msg))
))
;//! \htmlinclude DiscreteQuery-response.msg.html

(cl:defclass <DiscreteQuery-response> (roslisp-msg-protocol:ros-message)
  ((nodes
    :reader nodes
    :initarg :nodes
    :type (cl:vector pgm_learner-msg:DiscreteNode)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:DiscreteNode :initial-element (cl:make-instance 'pgm_learner-msg:DiscreteNode))))
)

(cl:defclass DiscreteQuery-response (<DiscreteQuery-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DiscreteQuery-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DiscreteQuery-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<DiscreteQuery-response> is deprecated: use pgm_learner-srv:DiscreteQuery-response instead.")))

(cl:ensure-generic-function 'nodes-val :lambda-list '(m))
(cl:defmethod nodes-val ((m <DiscreteQuery-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:nodes-val is deprecated.  Use pgm_learner-srv:nodes instead.")
  (nodes m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DiscreteQuery-response>) ostream)
  "Serializes a message object of type '<DiscreteQuery-response>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'nodes))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'nodes))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DiscreteQuery-response>) istream)
  "Deserializes a message object of type '<DiscreteQuery-response>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'nodes) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'nodes)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:DiscreteNode))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DiscreteQuery-response>)))
  "Returns string type for a service object of type '<DiscreteQuery-response>"
  "pgm_learner/DiscreteQueryResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteQuery-response)))
  "Returns string type for a service object of type 'DiscreteQuery-response"
  "pgm_learner/DiscreteQueryResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DiscreteQuery-response>)))
  "Returns md5sum for a message object of type '<DiscreteQuery-response>"
  "268044a2749deb7a93e17566a63deb21")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DiscreteQuery-response)))
  "Returns md5sum for a message object of type 'DiscreteQuery-response"
  "268044a2749deb7a93e17566a63deb21")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DiscreteQuery-response>)))
  "Returns full string definition for message of type '<DiscreteQuery-response>"
  (cl:format cl:nil "pgm_learner/DiscreteNode[] nodes # information of each nodes~%~%~%================================================================================~%MSG: pgm_learner/DiscreteNode~%string name~%string[] outcomes~%string[] parents~%string[] children~%pgm_learner/ConditionalProbability[] CPT~%~%================================================================================~%MSG: pgm_learner/ConditionalProbability~%string[]  values~%float32[] probabilities~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DiscreteQuery-response)))
  "Returns full string definition for message of type 'DiscreteQuery-response"
  (cl:format cl:nil "pgm_learner/DiscreteNode[] nodes # information of each nodes~%~%~%================================================================================~%MSG: pgm_learner/DiscreteNode~%string name~%string[] outcomes~%string[] parents~%string[] children~%pgm_learner/ConditionalProbability[] CPT~%~%================================================================================~%MSG: pgm_learner/ConditionalProbability~%string[]  values~%float32[] probabilities~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DiscreteQuery-response>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'nodes) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DiscreteQuery-response>))
  "Converts a ROS message object to a list"
  (cl:list 'DiscreteQuery-response
    (cl:cons ':nodes (nodes msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'DiscreteQuery)))
  'DiscreteQuery-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'DiscreteQuery)))
  'DiscreteQuery-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteQuery)))
  "Returns string type for a service object of type '<DiscreteQuery>"
  "pgm_learner/DiscreteQuery")
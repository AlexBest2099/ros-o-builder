; Auto-generated. Do not edit!


(cl:in-package pgm_learner-msg)


;//! \htmlinclude DiscreteNodeState.msg.html

(cl:defclass <DiscreteNodeState> (roslisp-msg-protocol:ros-message)
  ((node
    :reader node
    :initarg :node
    :type cl:string
    :initform "")
   (state
    :reader state
    :initarg :state
    :type cl:string
    :initform ""))
)

(cl:defclass DiscreteNodeState (<DiscreteNodeState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DiscreteNodeState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DiscreteNodeState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-msg:<DiscreteNodeState> is deprecated: use pgm_learner-msg:DiscreteNodeState instead.")))

(cl:ensure-generic-function 'node-val :lambda-list '(m))
(cl:defmethod node-val ((m <DiscreteNodeState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:node-val is deprecated.  Use pgm_learner-msg:node instead.")
  (node m))

(cl:ensure-generic-function 'state-val :lambda-list '(m))
(cl:defmethod state-val ((m <DiscreteNodeState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:state-val is deprecated.  Use pgm_learner-msg:state instead.")
  (state m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DiscreteNodeState>) ostream)
  "Serializes a message object of type '<DiscreteNodeState>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'node))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'node))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'state))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'state))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DiscreteNodeState>) istream)
  "Deserializes a message object of type '<DiscreteNodeState>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'node) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'node) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'state) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'state) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DiscreteNodeState>)))
  "Returns string type for a message object of type '<DiscreteNodeState>"
  "pgm_learner/DiscreteNodeState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteNodeState)))
  "Returns string type for a message object of type 'DiscreteNodeState"
  "pgm_learner/DiscreteNodeState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DiscreteNodeState>)))
  "Returns md5sum for a message object of type '<DiscreteNodeState>"
  "2ba0c980b5d3b248cb37845690ab0808")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DiscreteNodeState)))
  "Returns md5sum for a message object of type 'DiscreteNodeState"
  "2ba0c980b5d3b248cb37845690ab0808")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DiscreteNodeState>)))
  "Returns full string definition for message of type '<DiscreteNodeState>"
  (cl:format cl:nil "string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DiscreteNodeState)))
  "Returns full string definition for message of type 'DiscreteNodeState"
  (cl:format cl:nil "string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DiscreteNodeState>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'node))
     4 (cl:length (cl:slot-value msg 'state))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DiscreteNodeState>))
  "Converts a ROS message object to a list"
  (cl:list 'DiscreteNodeState
    (cl:cons ':node (node msg))
    (cl:cons ':state (state msg))
))

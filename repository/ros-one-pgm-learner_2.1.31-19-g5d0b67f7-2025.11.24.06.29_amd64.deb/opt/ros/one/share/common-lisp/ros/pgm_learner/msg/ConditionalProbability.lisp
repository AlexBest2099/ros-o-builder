; Auto-generated. Do not edit!


(cl:in-package pgm_learner-msg)


;//! \htmlinclude ConditionalProbability.msg.html

(cl:defclass <ConditionalProbability> (roslisp-msg-protocol:ros-message)
  ((values
    :reader values
    :initarg :values
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (probabilities
    :reader probabilities
    :initarg :probabilities
    :type (cl:vector cl:float)
   :initform (cl:make-array 0 :element-type 'cl:float :initial-element 0.0)))
)

(cl:defclass ConditionalProbability (<ConditionalProbability>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ConditionalProbability>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ConditionalProbability)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-msg:<ConditionalProbability> is deprecated: use pgm_learner-msg:ConditionalProbability instead.")))

(cl:ensure-generic-function 'values-val :lambda-list '(m))
(cl:defmethod values-val ((m <ConditionalProbability>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:values-val is deprecated.  Use pgm_learner-msg:values instead.")
  (values m))

(cl:ensure-generic-function 'probabilities-val :lambda-list '(m))
(cl:defmethod probabilities-val ((m <ConditionalProbability>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:probabilities-val is deprecated.  Use pgm_learner-msg:probabilities instead.")
  (probabilities m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ConditionalProbability>) ostream)
  "Serializes a message object of type '<ConditionalProbability>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'values))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'values))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'probabilities))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-single-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)))
   (cl:slot-value msg 'probabilities))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ConditionalProbability>) istream)
  "Deserializes a message object of type '<ConditionalProbability>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'values) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'values)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'probabilities) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'probabilities)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-single-float-bits bits))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ConditionalProbability>)))
  "Returns string type for a message object of type '<ConditionalProbability>"
  "pgm_learner/ConditionalProbability")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ConditionalProbability)))
  "Returns string type for a message object of type 'ConditionalProbability"
  "pgm_learner/ConditionalProbability")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ConditionalProbability>)))
  "Returns md5sum for a message object of type '<ConditionalProbability>"
  "232892e3b161d3aa164b36b806c0c5f8")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ConditionalProbability)))
  "Returns md5sum for a message object of type 'ConditionalProbability"
  "232892e3b161d3aa164b36b806c0c5f8")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ConditionalProbability>)))
  "Returns full string definition for message of type '<ConditionalProbability>"
  (cl:format cl:nil "string[]  values~%float32[] probabilities~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ConditionalProbability)))
  "Returns full string definition for message of type 'ConditionalProbability"
  (cl:format cl:nil "string[]  values~%float32[] probabilities~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ConditionalProbability>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'values) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'probabilities) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ConditionalProbability>))
  "Converts a ROS message object to a list"
  (cl:list 'ConditionalProbability
    (cl:cons ':values (values msg))
    (cl:cons ':probabilities (probabilities msg))
))

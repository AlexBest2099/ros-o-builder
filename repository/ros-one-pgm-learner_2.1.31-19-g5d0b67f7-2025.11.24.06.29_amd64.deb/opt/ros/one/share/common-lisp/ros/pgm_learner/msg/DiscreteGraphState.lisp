; Auto-generated. Do not edit!


(cl:in-package pgm_learner-msg)


;//! \htmlinclude DiscreteGraphState.msg.html

(cl:defclass <DiscreteGraphState> (roslisp-msg-protocol:ros-message)
  ((node_states
    :reader node_states
    :initarg :node_states
    :type (cl:vector pgm_learner-msg:DiscreteNodeState)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:DiscreteNodeState :initial-element (cl:make-instance 'pgm_learner-msg:DiscreteNodeState))))
)

(cl:defclass DiscreteGraphState (<DiscreteGraphState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DiscreteGraphState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DiscreteGraphState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-msg:<DiscreteGraphState> is deprecated: use pgm_learner-msg:DiscreteGraphState instead.")))

(cl:ensure-generic-function 'node_states-val :lambda-list '(m))
(cl:defmethod node_states-val ((m <DiscreteGraphState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:node_states-val is deprecated.  Use pgm_learner-msg:node_states instead.")
  (node_states m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DiscreteGraphState>) ostream)
  "Serializes a message object of type '<DiscreteGraphState>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'node_states))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'node_states))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DiscreteGraphState>) istream)
  "Deserializes a message object of type '<DiscreteGraphState>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'node_states) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'node_states)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:DiscreteNodeState))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DiscreteGraphState>)))
  "Returns string type for a message object of type '<DiscreteGraphState>"
  "pgm_learner/DiscreteGraphState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DiscreteGraphState)))
  "Returns string type for a message object of type 'DiscreteGraphState"
  "pgm_learner/DiscreteGraphState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DiscreteGraphState>)))
  "Returns md5sum for a message object of type '<DiscreteGraphState>"
  "16b46dda4af848eb5f3fa69917944093")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DiscreteGraphState)))
  "Returns md5sum for a message object of type 'DiscreteGraphState"
  "16b46dda4af848eb5f3fa69917944093")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DiscreteGraphState>)))
  "Returns full string definition for message of type '<DiscreteGraphState>"
  (cl:format cl:nil "pgm_learner/DiscreteNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/DiscreteNodeState~%string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DiscreteGraphState)))
  "Returns full string definition for message of type 'DiscreteGraphState"
  (cl:format cl:nil "pgm_learner/DiscreteNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/DiscreteNodeState~%string node~%string state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DiscreteGraphState>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'node_states) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DiscreteGraphState>))
  "Converts a ROS message object to a list"
  (cl:list 'DiscreteGraphState
    (cl:cons ':node_states (node_states msg))
))

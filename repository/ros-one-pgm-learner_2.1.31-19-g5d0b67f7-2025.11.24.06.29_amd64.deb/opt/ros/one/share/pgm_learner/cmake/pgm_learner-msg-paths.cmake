# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${pgm_learner_DIR}/.." "msg" pgm_learner_MSG_INCLUDE_DIRS UNIQUE)
set(pgm_learner_MSG_DEPENDENCIES )

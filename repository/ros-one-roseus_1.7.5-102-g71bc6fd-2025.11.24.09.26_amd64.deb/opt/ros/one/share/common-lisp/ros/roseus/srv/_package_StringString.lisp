(cl:in-package roseus-srv)
(cl:export '(STR-VAL
          STR
          STR-VAL
          STR
))
(cl:in-package roseus-msg)
(cl:export '(NAME-VAL
          NAME
))
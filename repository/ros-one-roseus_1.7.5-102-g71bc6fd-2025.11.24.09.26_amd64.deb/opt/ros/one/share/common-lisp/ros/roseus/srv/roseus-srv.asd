
(cl:in-package :asdf)

(defsystem "roseus-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "AddTwoInts" :depends-on ("_package_AddTwoInts"))
    (:file "_package_AddTwoInts" :depends-on ("_package"))
    (:file "StringString" :depends-on ("_package_StringString"))
    (:file "_package_StringString" :depends-on ("_package"))
  ))
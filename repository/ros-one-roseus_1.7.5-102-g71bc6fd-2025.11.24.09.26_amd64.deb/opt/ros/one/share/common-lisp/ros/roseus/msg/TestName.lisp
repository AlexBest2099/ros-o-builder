; Auto-generated. Do not edit!


(cl:in-package roseus-msg)


;//! \htmlinclude TestName.msg.html

(cl:defclass <TestName> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type roseus-msg:StringStamped
    :initform (cl:make-instance 'roseus-msg:StringStamped)))
)

(cl:defclass TestName (<TestName>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TestName>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TestName)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name roseus-msg:<TestName> is deprecated: use roseus-msg:TestName instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <TestName>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader roseus-msg:name-val is deprecated.  Use roseus-msg:name instead.")
  (name m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TestName>) ostream)
  "Serializes a message object of type '<TestName>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'name) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TestName>) istream)
  "Deserializes a message object of type '<TestName>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'name) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TestName>)))
  "Returns string type for a message object of type '<TestName>"
  "roseus/TestName")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TestName)))
  "Returns string type for a message object of type 'TestName"
  "roseus/TestName")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TestName>)))
  "Returns md5sum for a message object of type '<TestName>"
  "70bc7fd92cd8428f6a02d7d0df4d9b80")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TestName)))
  "Returns md5sum for a message object of type 'TestName"
  "70bc7fd92cd8428f6a02d7d0df4d9b80")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TestName>)))
  "Returns full string definition for message of type '<TestName>"
  (cl:format cl:nil "roseus/StringStamped name~%~%================================================================================~%MSG: roseus/StringStamped~%Header header~%string data~%~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TestName)))
  "Returns full string definition for message of type 'TestName"
  (cl:format cl:nil "roseus/StringStamped name~%~%================================================================================~%MSG: roseus/StringStamped~%Header header~%string data~%~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TestName>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'name))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TestName>))
  "Converts a ROS message object to a list"
  (cl:list 'TestName
    (cl:cons ':name (name msg))
))

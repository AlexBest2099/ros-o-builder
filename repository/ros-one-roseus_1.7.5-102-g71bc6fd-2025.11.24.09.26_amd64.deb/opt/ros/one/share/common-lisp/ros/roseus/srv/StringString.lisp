; Auto-generated. Do not edit!


(cl:in-package roseus-srv)


;//! \htmlinclude StringString-request.msg.html

(cl:defclass <StringString-request> (roslisp-msg-protocol:ros-message)
  ((str
    :reader str
    :initarg :str
    :type cl:string
    :initform ""))
)

(cl:defclass StringString-request (<StringString-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <StringString-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'StringString-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name roseus-srv:<StringString-request> is deprecated: use roseus-srv:StringString-request instead.")))

(cl:ensure-generic-function 'str-val :lambda-list '(m))
(cl:defmethod str-val ((m <StringString-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader roseus-srv:str-val is deprecated.  Use roseus-srv:str instead.")
  (str m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <StringString-request>) ostream)
  "Serializes a message object of type '<StringString-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'str))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'str))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <StringString-request>) istream)
  "Deserializes a message object of type '<StringString-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'str) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'str) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<StringString-request>)))
  "Returns string type for a service object of type '<StringString-request>"
  "roseus/StringStringRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'StringString-request)))
  "Returns string type for a service object of type 'StringString-request"
  "roseus/StringStringRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<StringString-request>)))
  "Returns md5sum for a message object of type '<StringString-request>"
  "671f8e4998eaec79f1c47e339dfd527b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'StringString-request)))
  "Returns md5sum for a message object of type 'StringString-request"
  "671f8e4998eaec79f1c47e339dfd527b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<StringString-request>)))
  "Returns full string definition for message of type '<StringString-request>"
  (cl:format cl:nil "string str~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'StringString-request)))
  "Returns full string definition for message of type 'StringString-request"
  (cl:format cl:nil "string str~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <StringString-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'str))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <StringString-request>))
  "Converts a ROS message object to a list"
  (cl:list 'StringString-request
    (cl:cons ':str (str msg))
))
;//! \htmlinclude StringString-response.msg.html

(cl:defclass <StringString-response> (roslisp-msg-protocol:ros-message)
  ((str
    :reader str
    :initarg :str
    :type cl:string
    :initform ""))
)

(cl:defclass StringString-response (<StringString-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <StringString-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'StringString-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name roseus-srv:<StringString-response> is deprecated: use roseus-srv:StringString-response instead.")))

(cl:ensure-generic-function 'str-val :lambda-list '(m))
(cl:defmethod str-val ((m <StringString-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader roseus-srv:str-val is deprecated.  Use roseus-srv:str instead.")
  (str m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <StringString-response>) ostream)
  "Serializes a message object of type '<StringString-response>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'str))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'str))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <StringString-response>) istream)
  "Deserializes a message object of type '<StringString-response>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'str) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'str) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<StringString-response>)))
  "Returns string type for a service object of type '<StringString-response>"
  "roseus/StringStringResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'StringString-response)))
  "Returns string type for a service object of type 'StringString-response"
  "roseus/StringStringResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<StringString-response>)))
  "Returns md5sum for a message object of type '<StringString-response>"
  "671f8e4998eaec79f1c47e339dfd527b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'StringString-response)))
  "Returns md5sum for a message object of type 'StringString-response"
  "671f8e4998eaec79f1c47e339dfd527b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<StringString-response>)))
  "Returns full string definition for message of type '<StringString-response>"
  (cl:format cl:nil "string str~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'StringString-response)))
  "Returns full string definition for message of type 'StringString-response"
  (cl:format cl:nil "string str~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <StringString-response>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'str))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <StringString-response>))
  "Converts a ROS message object to a list"
  (cl:list 'StringString-response
    (cl:cons ':str (str msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'StringString)))
  'StringString-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'StringString)))
  'StringString-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'StringString)))
  "Returns string type for a service object of type '<StringString>"
  "roseus/StringString")
// Auto-generated. Do not edit!

// (in-package roseus.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let StringStamped = require('./StringStamped.js');

//-----------------------------------------------------------

class TestName {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = new StringStamped();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TestName
    // Serialize message field [name]
    bufferOffset = StringStamped.serialize(obj.name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TestName
    let len;
    let data = new TestName(null);
    // Deserialize message field [name]
    data.name = StringStamped.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += StringStamped.getMessageSize(object.name);
    return length;
  }

  static datatype() {
    // Returns string type for a message object
    return 'roseus/TestName';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '70bc7fd92cd8428f6a02d7d0df4d9b80';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    roseus/StringStamped name
    
    ================================================================================
    MSG: roseus/StringStamped
    Header header
    string data
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TestName(null);
    if (msg.name !== undefined) {
      resolved.name = StringStamped.Resolve(msg.name)
    }
    else {
      resolved.name = new StringStamped()
    }

    return resolved;
    }
};

module.exports = TestName;

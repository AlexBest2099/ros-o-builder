set(roseus_MESSAGE_FILES "msg/String.msg;msg/StringStamped.msg;msg/FixedArray.msg;msg/VariableArray.msg;msg/TestName.msg")
set(roseus_SERVICE_FILES "srv/AddTwoInts.srv;srv/StringString.srv")


"use strict";

let CameraTrajectory = require('./CameraTrajectory.js');
let CameraMovement = require('./CameraMovement.js');
let CameraPlacement = require('./CameraPlacement.js');

module.exports = {
  CameraTrajectory: CameraTrajectory,
  CameraMovement: CameraMovement,
  CameraPlacement: CameraPlacement,
};

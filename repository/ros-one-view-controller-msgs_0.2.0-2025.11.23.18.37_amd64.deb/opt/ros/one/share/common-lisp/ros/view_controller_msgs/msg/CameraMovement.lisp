; Auto-generated. Do not edit!


(cl:in-package view_controller_msgs-msg)


;//! \htmlinclude CameraMovement.msg.html

(cl:defclass <CameraMovement> (roslisp-msg-protocol:ros-message)
  ((eye
    :reader eye
    :initarg :eye
    :type geometry_msgs-msg:PointStamped
    :initform (cl:make-instance 'geometry_msgs-msg:PointStamped))
   (focus
    :reader focus
    :initarg :focus
    :type geometry_msgs-msg:PointStamped
    :initform (cl:make-instance 'geometry_msgs-msg:PointStamped))
   (up
    :reader up
    :initarg :up
    :type geometry_msgs-msg:Vector3Stamped
    :initform (cl:make-instance 'geometry_msgs-msg:Vector3Stamped))
   (transition_duration
    :reader transition_duration
    :initarg :transition_duration
    :type cl:real
    :initform 0)
   (interpolation_speed
    :reader interpolation_speed
    :initarg :interpolation_speed
    :type cl:fixnum
    :initform 0))
)

(cl:defclass CameraMovement (<CameraMovement>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CameraMovement>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CameraMovement)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name view_controller_msgs-msg:<CameraMovement> is deprecated: use view_controller_msgs-msg:CameraMovement instead.")))

(cl:ensure-generic-function 'eye-val :lambda-list '(m))
(cl:defmethod eye-val ((m <CameraMovement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:eye-val is deprecated.  Use view_controller_msgs-msg:eye instead.")
  (eye m))

(cl:ensure-generic-function 'focus-val :lambda-list '(m))
(cl:defmethod focus-val ((m <CameraMovement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:focus-val is deprecated.  Use view_controller_msgs-msg:focus instead.")
  (focus m))

(cl:ensure-generic-function 'up-val :lambda-list '(m))
(cl:defmethod up-val ((m <CameraMovement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:up-val is deprecated.  Use view_controller_msgs-msg:up instead.")
  (up m))

(cl:ensure-generic-function 'transition_duration-val :lambda-list '(m))
(cl:defmethod transition_duration-val ((m <CameraMovement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:transition_duration-val is deprecated.  Use view_controller_msgs-msg:transition_duration instead.")
  (transition_duration m))

(cl:ensure-generic-function 'interpolation_speed-val :lambda-list '(m))
(cl:defmethod interpolation_speed-val ((m <CameraMovement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:interpolation_speed-val is deprecated.  Use view_controller_msgs-msg:interpolation_speed instead.")
  (interpolation_speed m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<CameraMovement>)))
    "Constants for message type '<CameraMovement>"
  '((:RISING . 0)
    (:DECLINING . 1)
    (:FULL . 2)
    (:WAVE . 3))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'CameraMovement)))
    "Constants for message type 'CameraMovement"
  '((:RISING . 0)
    (:DECLINING . 1)
    (:FULL . 2)
    (:WAVE . 3))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CameraMovement>) ostream)
  "Serializes a message object of type '<CameraMovement>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'eye) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'focus) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'up) ostream)
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'transition_duration)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'transition_duration) (cl:floor (cl:slot-value msg 'transition_duration)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'interpolation_speed)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CameraMovement>) istream)
  "Deserializes a message object of type '<CameraMovement>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'eye) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'focus) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'up) istream)
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'transition_duration) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'interpolation_speed)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CameraMovement>)))
  "Returns string type for a message object of type '<CameraMovement>"
  "view_controller_msgs/CameraMovement")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CameraMovement)))
  "Returns string type for a message object of type 'CameraMovement"
  "view_controller_msgs/CameraMovement")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CameraMovement>)))
  "Returns md5sum for a message object of type '<CameraMovement>"
  "fc7aac4a39426fb5e8b2dbb6e85bfc66")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CameraMovement)))
  "Returns md5sum for a message object of type 'CameraMovement"
  "fc7aac4a39426fb5e8b2dbb6e85bfc66")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CameraMovement>)))
  "Returns full string definition for message of type '<CameraMovement>"
  (cl:format cl:nil "# This message defines where to move a camera to and at which speeds.  ~%~%# The target pose definition:~%~%# The frame-relative point to move the camera to.~%geometry_msgs/PointStamped eye~%~%# The frame-relative point for the focus (or pivot for an Orbit controller).~%# The camera points into the direction of the focus point at the end of the movement.~%geometry_msgs/PointStamped focus~%~%# The frame-relative vector that maps to \"up\" in the view plane.~%# In other words, a vector pointing to the top of the camera, in case you want to perform roll movements.~%geometry_msgs/Vector3Stamped up~%~%~%# Defines how long the transition from the current to the target camera pose should take.~%# Movements with a negative transition_duration will be ignored.~%duration transition_duration~%~%# The interpolation speed profile to use during this movement.~%uint8 interpolation_speed~%uint8 RISING    = 0 # Speed of the camera rises smoothly - resembles the first quarter of a sinus wave.~%uint8 DECLINING = 1 # Speed of the camera declines smoothly - resembles the second quarter of a sinus wave.~%uint8 FULL      = 2 # Camera is always at full speed - depending on transition_duration.~%uint8 WAVE      = 3 # RISING and DECLINING concatenated in one movement.~%~%================================================================================~%MSG: geometry_msgs/PointStamped~%# This represents a Point with reference coordinate frame and timestamp~%Header header~%Point point~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Vector3Stamped~%# This represents a Vector3 with reference coordinate frame and timestamp~%Header header~%Vector3 vector~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CameraMovement)))
  "Returns full string definition for message of type 'CameraMovement"
  (cl:format cl:nil "# This message defines where to move a camera to and at which speeds.  ~%~%# The target pose definition:~%~%# The frame-relative point to move the camera to.~%geometry_msgs/PointStamped eye~%~%# The frame-relative point for the focus (or pivot for an Orbit controller).~%# The camera points into the direction of the focus point at the end of the movement.~%geometry_msgs/PointStamped focus~%~%# The frame-relative vector that maps to \"up\" in the view plane.~%# In other words, a vector pointing to the top of the camera, in case you want to perform roll movements.~%geometry_msgs/Vector3Stamped up~%~%~%# Defines how long the transition from the current to the target camera pose should take.~%# Movements with a negative transition_duration will be ignored.~%duration transition_duration~%~%# The interpolation speed profile to use during this movement.~%uint8 interpolation_speed~%uint8 RISING    = 0 # Speed of the camera rises smoothly - resembles the first quarter of a sinus wave.~%uint8 DECLINING = 1 # Speed of the camera declines smoothly - resembles the second quarter of a sinus wave.~%uint8 FULL      = 2 # Camera is always at full speed - depending on transition_duration.~%uint8 WAVE      = 3 # RISING and DECLINING concatenated in one movement.~%~%================================================================================~%MSG: geometry_msgs/PointStamped~%# This represents a Point with reference coordinate frame and timestamp~%Header header~%Point point~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Vector3Stamped~%# This represents a Vector3 with reference coordinate frame and timestamp~%Header header~%Vector3 vector~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CameraMovement>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'eye))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'focus))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'up))
     8
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CameraMovement>))
  "Converts a ROS message object to a list"
  (cl:list 'CameraMovement
    (cl:cons ':eye (eye msg))
    (cl:cons ':focus (focus msg))
    (cl:cons ':up (up msg))
    (cl:cons ':transition_duration (transition_duration msg))
    (cl:cons ':interpolation_speed (interpolation_speed msg))
))

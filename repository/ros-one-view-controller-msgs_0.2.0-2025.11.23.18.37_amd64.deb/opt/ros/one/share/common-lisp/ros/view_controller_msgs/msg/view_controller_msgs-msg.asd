
(cl:in-package :asdf)

(defsystem "view_controller_msgs-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
)
  :components ((:file "_package")
    (:file "CameraMovement" :depends-on ("_package_CameraMovement"))
    (:file "_package_CameraMovement" :depends-on ("_package"))
    (:file "CameraPlacement" :depends-on ("_package_CameraPlacement"))
    (:file "_package_CameraPlacement" :depends-on ("_package"))
    (:file "CameraTrajectory" :depends-on ("_package_CameraTrajectory"))
    (:file "_package_CameraTrajectory" :depends-on ("_package"))
  ))
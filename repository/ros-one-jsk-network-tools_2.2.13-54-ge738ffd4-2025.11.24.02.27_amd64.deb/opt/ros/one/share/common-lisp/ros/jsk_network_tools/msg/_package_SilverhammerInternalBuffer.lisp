(cl:in-package jsk_network_tools-msg)
(cl:export '(HEADER-VAL
          HEADER
          SEQ_ID-VAL
          SEQ_ID
          DATA-VAL
          DATA
))
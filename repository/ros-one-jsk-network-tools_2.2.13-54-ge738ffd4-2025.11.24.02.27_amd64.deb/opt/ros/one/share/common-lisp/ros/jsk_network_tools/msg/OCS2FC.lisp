; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-msg)


;//! \htmlinclude OCS2FC.msg.html

(cl:defclass <OCS2FC> (roslisp-msg-protocol:ros-message)
  ((joint_angles
    :reader joint_angles
    :initarg :joint_angles
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 32 :element-type 'cl:fixnum :initial-element 0))
   (start_impedance
    :reader start_impedance
    :initarg :start_impedance
    :type cl:boolean
    :initform cl:nil)
   (stop
    :reader stop
    :initarg :stop
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass OCS2FC (<OCS2FC>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <OCS2FC>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'OCS2FC)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-msg:<OCS2FC> is deprecated: use jsk_network_tools-msg:OCS2FC instead.")))

(cl:ensure-generic-function 'joint_angles-val :lambda-list '(m))
(cl:defmethod joint_angles-val ((m <OCS2FC>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:joint_angles-val is deprecated.  Use jsk_network_tools-msg:joint_angles instead.")
  (joint_angles m))

(cl:ensure-generic-function 'start_impedance-val :lambda-list '(m))
(cl:defmethod start_impedance-val ((m <OCS2FC>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:start_impedance-val is deprecated.  Use jsk_network_tools-msg:start_impedance instead.")
  (start_impedance m))

(cl:ensure-generic-function 'stop-val :lambda-list '(m))
(cl:defmethod stop-val ((m <OCS2FC>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:stop-val is deprecated.  Use jsk_network_tools-msg:stop instead.")
  (stop m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <OCS2FC>) ostream)
  "Serializes a message object of type '<OCS2FC>"
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'joint_angles))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'start_impedance) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'stop) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <OCS2FC>) istream)
  "Deserializes a message object of type '<OCS2FC>"
  (cl:setf (cl:slot-value msg 'joint_angles) (cl:make-array 32))
  (cl:let ((vals (cl:slot-value msg 'joint_angles)))
    (cl:dotimes (i 32)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'start_impedance) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'stop) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<OCS2FC>)))
  "Returns string type for a message object of type '<OCS2FC>"
  "jsk_network_tools/OCS2FC")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'OCS2FC)))
  "Returns string type for a message object of type 'OCS2FC"
  "jsk_network_tools/OCS2FC")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<OCS2FC>)))
  "Returns md5sum for a message object of type '<OCS2FC>"
  "036058ee69589b4817d296161ea7f432")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'OCS2FC)))
  "Returns md5sum for a message object of type 'OCS2FC"
  "036058ee69589b4817d296161ea7f432")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<OCS2FC>)))
  "Returns full string definition for message of type '<OCS2FC>"
  (cl:format cl:nil "# A message from OSC to FC.~%# There is are several limitations~%# 1. no nested fields is allowed.~%# 2. no variable length array is allowed.~%# 3. string is not supported.~%# 4. duration and time are not supported.~%~%uint8[32] joint_angles~%bool start_impedance~%bool stop~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'OCS2FC)))
  "Returns full string definition for message of type 'OCS2FC"
  (cl:format cl:nil "# A message from OSC to FC.~%# There is are several limitations~%# 1. no nested fields is allowed.~%# 2. no variable length array is allowed.~%# 3. string is not supported.~%# 4. duration and time are not supported.~%~%uint8[32] joint_angles~%bool start_impedance~%bool stop~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <OCS2FC>))
  (cl:+ 0
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'joint_angles) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <OCS2FC>))
  "Converts a ROS message object to a list"
  (cl:list 'OCS2FC
    (cl:cons ':joint_angles (joint_angles msg))
    (cl:cons ':start_impedance (start_impedance msg))
    (cl:cons ':stop (stop msg))
))

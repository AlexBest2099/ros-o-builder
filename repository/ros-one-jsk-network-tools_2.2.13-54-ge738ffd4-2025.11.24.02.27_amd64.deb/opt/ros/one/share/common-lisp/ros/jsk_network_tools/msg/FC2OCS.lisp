; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-msg)


;//! \htmlinclude FC2OCS.msg.html

(cl:defclass <FC2OCS> (roslisp-msg-protocol:ros-message)
  ((joint_angles
    :reader joint_angles
    :initarg :joint_angles
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 32 :element-type 'cl:fixnum :initial-element 0))
   (lhand_force
    :reader lhand_force
    :initarg :lhand_force
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 6 :element-type 'cl:fixnum :initial-element 0))
   (rhand_force
    :reader rhand_force
    :initarg :rhand_force
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 6 :element-type 'cl:fixnum :initial-element 0))
   (lfoot_force
    :reader lfoot_force
    :initarg :lfoot_force
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 6 :element-type 'cl:fixnum :initial-element 0))
   (rfoot_force
    :reader rfoot_force
    :initarg :rfoot_force
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 6 :element-type 'cl:fixnum :initial-element 0))
   (servo_state
    :reader servo_state
    :initarg :servo_state
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass FC2OCS (<FC2OCS>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <FC2OCS>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'FC2OCS)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-msg:<FC2OCS> is deprecated: use jsk_network_tools-msg:FC2OCS instead.")))

(cl:ensure-generic-function 'joint_angles-val :lambda-list '(m))
(cl:defmethod joint_angles-val ((m <FC2OCS>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:joint_angles-val is deprecated.  Use jsk_network_tools-msg:joint_angles instead.")
  (joint_angles m))

(cl:ensure-generic-function 'lhand_force-val :lambda-list '(m))
(cl:defmethod lhand_force-val ((m <FC2OCS>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:lhand_force-val is deprecated.  Use jsk_network_tools-msg:lhand_force instead.")
  (lhand_force m))

(cl:ensure-generic-function 'rhand_force-val :lambda-list '(m))
(cl:defmethod rhand_force-val ((m <FC2OCS>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:rhand_force-val is deprecated.  Use jsk_network_tools-msg:rhand_force instead.")
  (rhand_force m))

(cl:ensure-generic-function 'lfoot_force-val :lambda-list '(m))
(cl:defmethod lfoot_force-val ((m <FC2OCS>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:lfoot_force-val is deprecated.  Use jsk_network_tools-msg:lfoot_force instead.")
  (lfoot_force m))

(cl:ensure-generic-function 'rfoot_force-val :lambda-list '(m))
(cl:defmethod rfoot_force-val ((m <FC2OCS>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:rfoot_force-val is deprecated.  Use jsk_network_tools-msg:rfoot_force instead.")
  (rfoot_force m))

(cl:ensure-generic-function 'servo_state-val :lambda-list '(m))
(cl:defmethod servo_state-val ((m <FC2OCS>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:servo_state-val is deprecated.  Use jsk_network_tools-msg:servo_state instead.")
  (servo_state m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <FC2OCS>) ostream)
  "Serializes a message object of type '<FC2OCS>"
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'joint_angles))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'lhand_force))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'rhand_force))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'lfoot_force))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'rfoot_force))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'servo_state) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <FC2OCS>) istream)
  "Deserializes a message object of type '<FC2OCS>"
  (cl:setf (cl:slot-value msg 'joint_angles) (cl:make-array 32))
  (cl:let ((vals (cl:slot-value msg 'joint_angles)))
    (cl:dotimes (i 32)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
  (cl:setf (cl:slot-value msg 'lhand_force) (cl:make-array 6))
  (cl:let ((vals (cl:slot-value msg 'lhand_force)))
    (cl:dotimes (i 6)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
  (cl:setf (cl:slot-value msg 'rhand_force) (cl:make-array 6))
  (cl:let ((vals (cl:slot-value msg 'rhand_force)))
    (cl:dotimes (i 6)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
  (cl:setf (cl:slot-value msg 'lfoot_force) (cl:make-array 6))
  (cl:let ((vals (cl:slot-value msg 'lfoot_force)))
    (cl:dotimes (i 6)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
  (cl:setf (cl:slot-value msg 'rfoot_force) (cl:make-array 6))
  (cl:let ((vals (cl:slot-value msg 'rfoot_force)))
    (cl:dotimes (i 6)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'servo_state) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<FC2OCS>)))
  "Returns string type for a message object of type '<FC2OCS>"
  "jsk_network_tools/FC2OCS")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'FC2OCS)))
  "Returns string type for a message object of type 'FC2OCS"
  "jsk_network_tools/FC2OCS")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<FC2OCS>)))
  "Returns md5sum for a message object of type '<FC2OCS>"
  "7a556e2b1084dcaa36eeac7b2f905853")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'FC2OCS)))
  "Returns md5sum for a message object of type 'FC2OCS"
  "7a556e2b1084dcaa36eeac7b2f905853")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<FC2OCS>)))
  "Returns full string definition for message of type '<FC2OCS>"
  (cl:format cl:nil "# A message from FC to OSC.~%# There is are several limitations~%# 1. no nested fields is allowed.~%# 2. no variable length array is allowed.~%# 3. string is not supported.~%# 4. duration and time are not supported.~%~%uint8[32] joint_angles~%uint8[6] lhand_force~%uint8[6] rhand_force~%uint8[6] lfoot_force~%uint8[6] rfoot_force~%bool servo_state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'FC2OCS)))
  "Returns full string definition for message of type 'FC2OCS"
  (cl:format cl:nil "# A message from FC to OSC.~%# There is are several limitations~%# 1. no nested fields is allowed.~%# 2. no variable length array is allowed.~%# 3. string is not supported.~%# 4. duration and time are not supported.~%~%uint8[32] joint_angles~%uint8[6] lhand_force~%uint8[6] rhand_force~%uint8[6] lfoot_force~%uint8[6] rfoot_force~%bool servo_state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <FC2OCS>))
  (cl:+ 0
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'joint_angles) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'lhand_force) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'rhand_force) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'lfoot_force) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'rfoot_force) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <FC2OCS>))
  "Converts a ROS message object to a list"
  (cl:list 'FC2OCS
    (cl:cons ':joint_angles (joint_angles msg))
    (cl:cons ':lhand_force (lhand_force msg))
    (cl:cons ':rhand_force (rhand_force msg))
    (cl:cons ':lfoot_force (lfoot_force msg))
    (cl:cons ':rfoot_force (rfoot_force msg))
    (cl:cons ':servo_state (servo_state msg))
))

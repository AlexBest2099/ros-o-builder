; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-msg)


;//! \htmlinclude WifiStatus.msg.html

(cl:defclass <WifiStatus> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (interface
    :reader interface
    :initarg :interface
    :type cl:string
    :initform "")
   (enabled
    :reader enabled
    :initarg :enabled
    :type cl:boolean
    :initform cl:nil)
   (connected
    :reader connected
    :initarg :connected
    :type cl:boolean
    :initform cl:nil)
   (ssid
    :reader ssid
    :initarg :ssid
    :type cl:string
    :initform "")
   (frequency
    :reader frequency
    :initarg :frequency
    :type cl:float
    :initform 0.0)
   (access_point
    :reader access_point
    :initarg :access_point
    :type cl:string
    :initform "")
   (bitrate
    :reader bitrate
    :initarg :bitrate
    :type cl:float
    :initform 0.0)
   (tx_power
    :reader tx_power
    :initarg :tx_power
    :type cl:fixnum
    :initform 0)
   (link_quality
    :reader link_quality
    :initarg :link_quality
    :type cl:float
    :initform 0.0)
   (signal_level
    :reader signal_level
    :initarg :signal_level
    :type cl:fixnum
    :initform 0))
)

(cl:defclass WifiStatus (<WifiStatus>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <WifiStatus>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'WifiStatus)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-msg:<WifiStatus> is deprecated: use jsk_network_tools-msg:WifiStatus instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:header-val is deprecated.  Use jsk_network_tools-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'interface-val :lambda-list '(m))
(cl:defmethod interface-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:interface-val is deprecated.  Use jsk_network_tools-msg:interface instead.")
  (interface m))

(cl:ensure-generic-function 'enabled-val :lambda-list '(m))
(cl:defmethod enabled-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:enabled-val is deprecated.  Use jsk_network_tools-msg:enabled instead.")
  (enabled m))

(cl:ensure-generic-function 'connected-val :lambda-list '(m))
(cl:defmethod connected-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:connected-val is deprecated.  Use jsk_network_tools-msg:connected instead.")
  (connected m))

(cl:ensure-generic-function 'ssid-val :lambda-list '(m))
(cl:defmethod ssid-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:ssid-val is deprecated.  Use jsk_network_tools-msg:ssid instead.")
  (ssid m))

(cl:ensure-generic-function 'frequency-val :lambda-list '(m))
(cl:defmethod frequency-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:frequency-val is deprecated.  Use jsk_network_tools-msg:frequency instead.")
  (frequency m))

(cl:ensure-generic-function 'access_point-val :lambda-list '(m))
(cl:defmethod access_point-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:access_point-val is deprecated.  Use jsk_network_tools-msg:access_point instead.")
  (access_point m))

(cl:ensure-generic-function 'bitrate-val :lambda-list '(m))
(cl:defmethod bitrate-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:bitrate-val is deprecated.  Use jsk_network_tools-msg:bitrate instead.")
  (bitrate m))

(cl:ensure-generic-function 'tx_power-val :lambda-list '(m))
(cl:defmethod tx_power-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:tx_power-val is deprecated.  Use jsk_network_tools-msg:tx_power instead.")
  (tx_power m))

(cl:ensure-generic-function 'link_quality-val :lambda-list '(m))
(cl:defmethod link_quality-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:link_quality-val is deprecated.  Use jsk_network_tools-msg:link_quality instead.")
  (link_quality m))

(cl:ensure-generic-function 'signal_level-val :lambda-list '(m))
(cl:defmethod signal_level-val ((m <WifiStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:signal_level-val is deprecated.  Use jsk_network_tools-msg:signal_level instead.")
  (signal_level m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <WifiStatus>) ostream)
  "Serializes a message object of type '<WifiStatus>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'interface))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'interface))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'enabled) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'connected) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'ssid))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'ssid))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'frequency))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'access_point))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'access_point))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'bitrate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'tx_power)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 65536) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'link_quality))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'signal_level)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 65536) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <WifiStatus>) istream)
  "Deserializes a message object of type '<WifiStatus>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'interface) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'interface) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'enabled) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'connected) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'ssid) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'ssid) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'frequency) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'access_point) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'access_point) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'bitrate) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'tx_power) (cl:if (cl:< unsigned 32768) unsigned (cl:- unsigned 65536))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'link_quality) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'signal_level) (cl:if (cl:< unsigned 32768) unsigned (cl:- unsigned 65536))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<WifiStatus>)))
  "Returns string type for a message object of type '<WifiStatus>"
  "jsk_network_tools/WifiStatus")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'WifiStatus)))
  "Returns string type for a message object of type 'WifiStatus"
  "jsk_network_tools/WifiStatus")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<WifiStatus>)))
  "Returns md5sum for a message object of type '<WifiStatus>"
  "94da4b64008d69473c62c62019a8c0f6")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'WifiStatus)))
  "Returns md5sum for a message object of type 'WifiStatus"
  "94da4b64008d69473c62c62019a8c0f6")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<WifiStatus>)))
  "Returns full string definition for message of type '<WifiStatus>"
  (cl:format cl:nil "Header header~%string interface~%bool enabled~%bool connected~%string ssid~%float32 frequency # GHz~%string access_point~%float32 bitrate # Mb/s~%int16 tx_power # dBm~%float32 link_quality~%int16 signal_level # dBm~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'WifiStatus)))
  "Returns full string definition for message of type 'WifiStatus"
  (cl:format cl:nil "Header header~%string interface~%bool enabled~%bool connected~%string ssid~%float32 frequency # GHz~%string access_point~%float32 bitrate # Mb/s~%int16 tx_power # dBm~%float32 link_quality~%int16 signal_level # dBm~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <WifiStatus>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'interface))
     1
     1
     4 (cl:length (cl:slot-value msg 'ssid))
     4
     4 (cl:length (cl:slot-value msg 'access_point))
     4
     2
     4
     2
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <WifiStatus>))
  "Converts a ROS message object to a list"
  (cl:list 'WifiStatus
    (cl:cons ':header (header msg))
    (cl:cons ':interface (interface msg))
    (cl:cons ':enabled (enabled msg))
    (cl:cons ':connected (connected msg))
    (cl:cons ':ssid (ssid msg))
    (cl:cons ':frequency (frequency msg))
    (cl:cons ':access_point (access_point msg))
    (cl:cons ':bitrate (bitrate msg))
    (cl:cons ':tx_power (tx_power msg))
    (cl:cons ':link_quality (link_quality msg))
    (cl:cons ':signal_level (signal_level msg))
))

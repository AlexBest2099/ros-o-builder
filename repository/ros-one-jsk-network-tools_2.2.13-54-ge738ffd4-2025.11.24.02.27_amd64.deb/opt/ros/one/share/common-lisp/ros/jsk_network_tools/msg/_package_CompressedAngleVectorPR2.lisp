(cl:in-package jsk_network_tools-msg)
(cl:export '(ANGLES-VAL
          ANGLES
))
(cl:in-package jsk_network_tools-msg)
(cl:export '(JOINT_ANGLES-VAL
          JOINT_ANGLES
          START_IMPEDANCE-VAL
          START_IMPEDANCE
          STOP-VAL
          STOP
))
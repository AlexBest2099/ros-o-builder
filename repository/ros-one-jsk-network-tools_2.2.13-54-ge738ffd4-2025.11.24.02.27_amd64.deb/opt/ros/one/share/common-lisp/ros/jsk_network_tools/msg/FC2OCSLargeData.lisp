; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-msg)


;//! \htmlinclude FC2OCSLargeData.msg.html

(cl:defclass <FC2OCSLargeData> (roslisp-msg-protocol:ros-message)
  ((camera__rgb__image_rect_color
    :reader camera__rgb__image_rect_color
    :initarg :camera__rgb__image_rect_color
    :type sensor_msgs-msg:Image
    :initform (cl:make-instance 'sensor_msgs-msg:Image))
   (joint_state
    :reader joint_state
    :initarg :joint_state
    :type sensor_msgs-msg:JointState
    :initform (cl:make-instance 'sensor_msgs-msg:JointState))
   (usb_cam__image_raw
    :reader usb_cam__image_raw
    :initarg :usb_cam__image_raw
    :type sensor_msgs-msg:Image
    :initform (cl:make-instance 'sensor_msgs-msg:Image)))
)

(cl:defclass FC2OCSLargeData (<FC2OCSLargeData>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <FC2OCSLargeData>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'FC2OCSLargeData)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-msg:<FC2OCSLargeData> is deprecated: use jsk_network_tools-msg:FC2OCSLargeData instead.")))

(cl:ensure-generic-function 'camera__rgb__image_rect_color-val :lambda-list '(m))
(cl:defmethod camera__rgb__image_rect_color-val ((m <FC2OCSLargeData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:camera__rgb__image_rect_color-val is deprecated.  Use jsk_network_tools-msg:camera__rgb__image_rect_color instead.")
  (camera__rgb__image_rect_color m))

(cl:ensure-generic-function 'joint_state-val :lambda-list '(m))
(cl:defmethod joint_state-val ((m <FC2OCSLargeData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:joint_state-val is deprecated.  Use jsk_network_tools-msg:joint_state instead.")
  (joint_state m))

(cl:ensure-generic-function 'usb_cam__image_raw-val :lambda-list '(m))
(cl:defmethod usb_cam__image_raw-val ((m <FC2OCSLargeData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:usb_cam__image_raw-val is deprecated.  Use jsk_network_tools-msg:usb_cam__image_raw instead.")
  (usb_cam__image_raw m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <FC2OCSLargeData>) ostream)
  "Serializes a message object of type '<FC2OCSLargeData>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'camera__rgb__image_rect_color) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'joint_state) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'usb_cam__image_raw) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <FC2OCSLargeData>) istream)
  "Deserializes a message object of type '<FC2OCSLargeData>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'camera__rgb__image_rect_color) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'joint_state) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'usb_cam__image_raw) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<FC2OCSLargeData>)))
  "Returns string type for a message object of type '<FC2OCSLargeData>"
  "jsk_network_tools/FC2OCSLargeData")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'FC2OCSLargeData)))
  "Returns string type for a message object of type 'FC2OCSLargeData"
  "jsk_network_tools/FC2OCSLargeData")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<FC2OCSLargeData>)))
  "Returns md5sum for a message object of type '<FC2OCSLargeData>"
  "51c7ca6e66514e69ddd1a156f6a0b404")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'FC2OCSLargeData)))
  "Returns md5sum for a message object of type 'FC2OCSLargeData"
  "51c7ca6e66514e69ddd1a156f6a0b404")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<FC2OCSLargeData>)))
  "Returns full string definition for message of type '<FC2OCSLargeData>"
  (cl:format cl:nil "# large message from FC to OSC~%# topic name will be automatically generated from~%# field names.~%# the rule is super simple, just replace '__' with '/'~%sensor_msgs/Image camera__rgb__image_rect_color~%sensor_msgs/JointState joint_state~%sensor_msgs/Image usb_cam__image_raw~%================================================================================~%MSG: sensor_msgs/Image~%# This message contains an uncompressed image~%# (0, 0) is at top-left corner of image~%#~%~%Header header        # Header timestamp should be acquisition time of image~%                     # Header frame_id should be optical frame of camera~%                     # origin of frame should be optical center of camera~%                     # +x should point to the right in the image~%                     # +y should point down in the image~%                     # +z should point into to plane of the image~%                     # If the frame_id here and the frame_id of the CameraInfo~%                     # message associated with the image conflict~%                     # the behavior is undefined~%~%uint32 height         # image height, that is, number of rows~%uint32 width          # image width, that is, number of columns~%~%# The legal values for encoding are in file src/image_encodings.cpp~%# If you want to standardize a new string format, join~%# ros-users@lists.sourceforge.net and send an email proposing a new encoding.~%~%string encoding       # Encoding of pixels -- channel meaning, ordering, size~%                      # taken from the list of strings in include/sensor_msgs/image_encodings.h~%~%uint8 is_bigendian    # is this data bigendian?~%uint32 step           # Full row length in bytes~%uint8[] data          # actual matrix data, size is (step * rows)~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: sensor_msgs/JointState~%# This is a message that holds data to describe the state of a set of torque controlled joints. ~%#~%# The state of each joint (revolute or prismatic) is defined by:~%#  * the position of the joint (rad or m),~%#  * the velocity of the joint (rad/s or m/s) and ~%#  * the effort that is applied in the joint (Nm or N).~%#~%# Each joint is uniquely identified by its name~%# The header specifies the time at which the joint states were recorded. All the joint states~%# in one message have to be recorded at the same time.~%#~%# This message consists of a multiple arrays, one for each part of the joint state. ~%# The goal is to make each of the fields optional. When e.g. your joints have no~%# effort associated with them, you can leave the effort array empty. ~%#~%# All arrays in this message should have the same size, or be empty.~%# This is the only way to uniquely associate the joint name with the correct~%# states.~%~%~%Header header~%~%string[] name~%float64[] position~%float64[] velocity~%float64[] effort~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'FC2OCSLargeData)))
  "Returns full string definition for message of type 'FC2OCSLargeData"
  (cl:format cl:nil "# large message from FC to OSC~%# topic name will be automatically generated from~%# field names.~%# the rule is super simple, just replace '__' with '/'~%sensor_msgs/Image camera__rgb__image_rect_color~%sensor_msgs/JointState joint_state~%sensor_msgs/Image usb_cam__image_raw~%================================================================================~%MSG: sensor_msgs/Image~%# This message contains an uncompressed image~%# (0, 0) is at top-left corner of image~%#~%~%Header header        # Header timestamp should be acquisition time of image~%                     # Header frame_id should be optical frame of camera~%                     # origin of frame should be optical center of camera~%                     # +x should point to the right in the image~%                     # +y should point down in the image~%                     # +z should point into to plane of the image~%                     # If the frame_id here and the frame_id of the CameraInfo~%                     # message associated with the image conflict~%                     # the behavior is undefined~%~%uint32 height         # image height, that is, number of rows~%uint32 width          # image width, that is, number of columns~%~%# The legal values for encoding are in file src/image_encodings.cpp~%# If you want to standardize a new string format, join~%# ros-users@lists.sourceforge.net and send an email proposing a new encoding.~%~%string encoding       # Encoding of pixels -- channel meaning, ordering, size~%                      # taken from the list of strings in include/sensor_msgs/image_encodings.h~%~%uint8 is_bigendian    # is this data bigendian?~%uint32 step           # Full row length in bytes~%uint8[] data          # actual matrix data, size is (step * rows)~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: sensor_msgs/JointState~%# This is a message that holds data to describe the state of a set of torque controlled joints. ~%#~%# The state of each joint (revolute or prismatic) is defined by:~%#  * the position of the joint (rad or m),~%#  * the velocity of the joint (rad/s or m/s) and ~%#  * the effort that is applied in the joint (Nm or N).~%#~%# Each joint is uniquely identified by its name~%# The header specifies the time at which the joint states were recorded. All the joint states~%# in one message have to be recorded at the same time.~%#~%# This message consists of a multiple arrays, one for each part of the joint state. ~%# The goal is to make each of the fields optional. When e.g. your joints have no~%# effort associated with them, you can leave the effort array empty. ~%#~%# All arrays in this message should have the same size, or be empty.~%# This is the only way to uniquely associate the joint name with the correct~%# states.~%~%~%Header header~%~%string[] name~%float64[] position~%float64[] velocity~%float64[] effort~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <FC2OCSLargeData>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'camera__rgb__image_rect_color))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'joint_state))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'usb_cam__image_raw))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <FC2OCSLargeData>))
  "Converts a ROS message object to a list"
  (cl:list 'FC2OCSLargeData
    (cl:cons ':camera__rgb__image_rect_color (camera__rgb__image_rect_color msg))
    (cl:cons ':joint_state (joint_state msg))
    (cl:cons ':usb_cam__image_raw (usb_cam__image_raw msg))
))

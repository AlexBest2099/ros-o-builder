; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-srv)


;//! \htmlinclude SetSendRate-request.msg.html

(cl:defclass <SetSendRate-request> (roslisp-msg-protocol:ros-message)
  ((rate
    :reader rate
    :initarg :rate
    :type cl:float
    :initform 0.0))
)

(cl:defclass SetSendRate-request (<SetSendRate-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetSendRate-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetSendRate-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-srv:<SetSendRate-request> is deprecated: use jsk_network_tools-srv:SetSendRate-request instead.")))

(cl:ensure-generic-function 'rate-val :lambda-list '(m))
(cl:defmethod rate-val ((m <SetSendRate-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-srv:rate-val is deprecated.  Use jsk_network_tools-srv:rate instead.")
  (rate m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetSendRate-request>) ostream)
  "Serializes a message object of type '<SetSendRate-request>"
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'rate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetSendRate-request>) istream)
  "Deserializes a message object of type '<SetSendRate-request>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'rate) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetSendRate-request>)))
  "Returns string type for a service object of type '<SetSendRate-request>"
  "jsk_network_tools/SetSendRateRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetSendRate-request)))
  "Returns string type for a service object of type 'SetSendRate-request"
  "jsk_network_tools/SetSendRateRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetSendRate-request>)))
  "Returns md5sum for a message object of type '<SetSendRate-request>"
  "cae629dc09fa1062b0edd407f27533e9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetSendRate-request)))
  "Returns md5sum for a message object of type 'SetSendRate-request"
  "cae629dc09fa1062b0edd407f27533e9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetSendRate-request>)))
  "Returns full string definition for message of type '<SetSendRate-request>"
  (cl:format cl:nil "float32 rate~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetSendRate-request)))
  "Returns full string definition for message of type 'SetSendRate-request"
  (cl:format cl:nil "float32 rate~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetSendRate-request>))
  (cl:+ 0
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetSendRate-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetSendRate-request
    (cl:cons ':rate (rate msg))
))
;//! \htmlinclude SetSendRate-response.msg.html

(cl:defclass <SetSendRate-response> (roslisp-msg-protocol:ros-message)
  ((ok
    :reader ok
    :initarg :ok
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass SetSendRate-response (<SetSendRate-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetSendRate-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetSendRate-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-srv:<SetSendRate-response> is deprecated: use jsk_network_tools-srv:SetSendRate-response instead.")))

(cl:ensure-generic-function 'ok-val :lambda-list '(m))
(cl:defmethod ok-val ((m <SetSendRate-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-srv:ok-val is deprecated.  Use jsk_network_tools-srv:ok instead.")
  (ok m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetSendRate-response>) ostream)
  "Serializes a message object of type '<SetSendRate-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'ok) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetSendRate-response>) istream)
  "Deserializes a message object of type '<SetSendRate-response>"
    (cl:setf (cl:slot-value msg 'ok) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetSendRate-response>)))
  "Returns string type for a service object of type '<SetSendRate-response>"
  "jsk_network_tools/SetSendRateResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetSendRate-response)))
  "Returns string type for a service object of type 'SetSendRate-response"
  "jsk_network_tools/SetSendRateResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetSendRate-response>)))
  "Returns md5sum for a message object of type '<SetSendRate-response>"
  "cae629dc09fa1062b0edd407f27533e9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetSendRate-response)))
  "Returns md5sum for a message object of type 'SetSendRate-response"
  "cae629dc09fa1062b0edd407f27533e9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetSendRate-response>)))
  "Returns full string definition for message of type '<SetSendRate-response>"
  (cl:format cl:nil "bool ok~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetSendRate-response)))
  "Returns full string definition for message of type 'SetSendRate-response"
  (cl:format cl:nil "bool ok~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetSendRate-response>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetSendRate-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetSendRate-response
    (cl:cons ':ok (ok msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetSendRate)))
  'SetSendRate-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetSendRate)))
  'SetSendRate-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetSendRate)))
  "Returns string type for a service object of type '<SetSendRate>"
  "jsk_network_tools/SetSendRate")
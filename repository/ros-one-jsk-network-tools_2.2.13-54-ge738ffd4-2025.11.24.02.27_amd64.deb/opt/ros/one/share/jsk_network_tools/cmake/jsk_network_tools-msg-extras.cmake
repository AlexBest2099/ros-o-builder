set(jsk_network_tools_MESSAGE_FILES "msg/CompressedAngleVectorPR2.msg;msg/Heartbeat.msg;msg/HeartbeatResponse.msg;msg/FC2OCS.msg;msg/OCS2FC.msg;msg/FC2OCSLargeData.msg;msg/OpenNISample.msg;msg/AllTypeTest.msg;msg/SilverhammerInternalBuffer.msg;msg/WifiStatus.msg")
set(jsk_network_tools_SERVICE_FILES "srv/SetSendRate.srv")

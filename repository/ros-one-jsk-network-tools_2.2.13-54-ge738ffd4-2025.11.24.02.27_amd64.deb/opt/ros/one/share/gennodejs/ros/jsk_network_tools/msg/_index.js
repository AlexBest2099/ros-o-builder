
"use strict";

let WifiStatus = require('./WifiStatus.js');
let AllTypeTest = require('./AllTypeTest.js');
let FC2OCS = require('./FC2OCS.js');
let CompressedAngleVectorPR2 = require('./CompressedAngleVectorPR2.js');
let SilverhammerInternalBuffer = require('./SilverhammerInternalBuffer.js');
let OpenNISample = require('./OpenNISample.js');
let FC2OCSLargeData = require('./FC2OCSLargeData.js');
let HeartbeatResponse = require('./HeartbeatResponse.js');
let Heartbeat = require('./Heartbeat.js');
let OCS2FC = require('./OCS2FC.js');

module.exports = {
  WifiStatus: WifiStatus,
  AllTypeTest: AllTypeTest,
  FC2OCS: FC2OCS,
  CompressedAngleVectorPR2: CompressedAngleVectorPR2,
  SilverhammerInternalBuffer: SilverhammerInternalBuffer,
  OpenNISample: OpenNISample,
  FC2OCSLargeData: FC2OCSLargeData,
  HeartbeatResponse: HeartbeatResponse,
  Heartbeat: Heartbeat,
  OCS2FC: OCS2FC,
};

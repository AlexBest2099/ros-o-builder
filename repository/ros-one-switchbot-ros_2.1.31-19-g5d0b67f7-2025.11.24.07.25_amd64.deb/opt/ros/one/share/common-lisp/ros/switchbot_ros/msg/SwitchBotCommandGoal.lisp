; Auto-generated. Do not edit!


(cl:in-package switchbot_ros-msg)


;//! \htmlinclude SwitchBotCommandGoal.msg.html

(cl:defclass <SwitchBotCommandGoal> (roslisp-msg-protocol:ros-message)
  ((device_name
    :reader device_name
    :initarg :device_name
    :type cl:string
    :initform "")
   (command
    :reader command
    :initarg :command
    :type cl:string
    :initform "")
   (parameter
    :reader parameter
    :initarg :parameter
    :type cl:string
    :initform "")
   (command_type
    :reader command_type
    :initarg :command_type
    :type cl:string
    :initform ""))
)

(cl:defclass SwitchBotCommandGoal (<SwitchBotCommandGoal>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SwitchBotCommandGoal>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SwitchBotCommandGoal)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name switchbot_ros-msg:<SwitchBotCommandGoal> is deprecated: use switchbot_ros-msg:SwitchBotCommandGoal instead.")))

(cl:ensure-generic-function 'device_name-val :lambda-list '(m))
(cl:defmethod device_name-val ((m <SwitchBotCommandGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:device_name-val is deprecated.  Use switchbot_ros-msg:device_name instead.")
  (device_name m))

(cl:ensure-generic-function 'command-val :lambda-list '(m))
(cl:defmethod command-val ((m <SwitchBotCommandGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:command-val is deprecated.  Use switchbot_ros-msg:command instead.")
  (command m))

(cl:ensure-generic-function 'parameter-val :lambda-list '(m))
(cl:defmethod parameter-val ((m <SwitchBotCommandGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:parameter-val is deprecated.  Use switchbot_ros-msg:parameter instead.")
  (parameter m))

(cl:ensure-generic-function 'command_type-val :lambda-list '(m))
(cl:defmethod command_type-val ((m <SwitchBotCommandGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:command_type-val is deprecated.  Use switchbot_ros-msg:command_type instead.")
  (command_type m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SwitchBotCommandGoal>) ostream)
  "Serializes a message object of type '<SwitchBotCommandGoal>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'device_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'device_name))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'command))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'command))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parameter))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parameter))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'command_type))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'command_type))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SwitchBotCommandGoal>) istream)
  "Deserializes a message object of type '<SwitchBotCommandGoal>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'device_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'device_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'command) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'command) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parameter) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parameter) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'command_type) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'command_type) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SwitchBotCommandGoal>)))
  "Returns string type for a message object of type '<SwitchBotCommandGoal>"
  "switchbot_ros/SwitchBotCommandGoal")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SwitchBotCommandGoal)))
  "Returns string type for a message object of type 'SwitchBotCommandGoal"
  "switchbot_ros/SwitchBotCommandGoal")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SwitchBotCommandGoal>)))
  "Returns md5sum for a message object of type '<SwitchBotCommandGoal>"
  "2c96c4dddec9221be5c5dc637b8e4f64")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SwitchBotCommandGoal)))
  "Returns md5sum for a message object of type 'SwitchBotCommandGoal"
  "2c96c4dddec9221be5c5dc637b8e4f64")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SwitchBotCommandGoal>)))
  "Returns full string definition for message of type '<SwitchBotCommandGoal>"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%# Define the goal~%string device_name~%string command~%string parameter~%string command_type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SwitchBotCommandGoal)))
  "Returns full string definition for message of type 'SwitchBotCommandGoal"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%# Define the goal~%string device_name~%string command~%string parameter~%string command_type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SwitchBotCommandGoal>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'device_name))
     4 (cl:length (cl:slot-value msg 'command))
     4 (cl:length (cl:slot-value msg 'parameter))
     4 (cl:length (cl:slot-value msg 'command_type))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SwitchBotCommandGoal>))
  "Converts a ROS message object to a list"
  (cl:list 'SwitchBotCommandGoal
    (cl:cons ':device_name (device_name msg))
    (cl:cons ':command (command msg))
    (cl:cons ':parameter (parameter msg))
    (cl:cons ':command_type (command_type msg))
))

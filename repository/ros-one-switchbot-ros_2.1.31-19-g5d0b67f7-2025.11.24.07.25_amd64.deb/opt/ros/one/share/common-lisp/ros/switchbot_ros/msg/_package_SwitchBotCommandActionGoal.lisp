(cl:in-package switchbot_ros-msg)
(cl:export '(HEADER-VAL
          HEADER
          GOAL_ID-VAL
          GOAL_ID
          GOAL-VAL
          GOAL
))
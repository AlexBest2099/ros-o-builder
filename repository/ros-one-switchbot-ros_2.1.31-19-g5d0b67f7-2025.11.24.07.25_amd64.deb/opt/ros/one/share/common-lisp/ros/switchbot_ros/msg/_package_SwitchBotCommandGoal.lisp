(cl:in-package switchbot_ros-msg)
(cl:export '(DEVICE_NAME-VAL
          DEVICE_NAME
          COMMAND-VAL
          COMMAND
          PARAMETER-VAL
          PARAMETER
          COMMAND_TYPE-VAL
          COMMAND_TYPE
))
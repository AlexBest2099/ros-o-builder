(cl:in-package switchbot_ros-msg)
(cl:export '(HEADER-VAL
          HEADER
          TEMPERATURE-VAL
          TEMPERATURE
          HUMIDITY-VAL
          HUMIDITY
          LIGHT_LEVEL-VAL
          LIGHT_LEVEL
))
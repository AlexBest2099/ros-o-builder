; Auto-generated. Do not edit!


(cl:in-package switchbot_ros-msg)


;//! \htmlinclude DeviceArray.msg.html

(cl:defclass <DeviceArray> (roslisp-msg-protocol:ros-message)
  ((devices
    :reader devices
    :initarg :devices
    :type (cl:vector switchbot_ros-msg:Device)
   :initform (cl:make-array 0 :element-type 'switchbot_ros-msg:Device :initial-element (cl:make-instance 'switchbot_ros-msg:Device))))
)

(cl:defclass DeviceArray (<DeviceArray>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DeviceArray>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DeviceArray)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name switchbot_ros-msg:<DeviceArray> is deprecated: use switchbot_ros-msg:DeviceArray instead.")))

(cl:ensure-generic-function 'devices-val :lambda-list '(m))
(cl:defmethod devices-val ((m <DeviceArray>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:devices-val is deprecated.  Use switchbot_ros-msg:devices instead.")
  (devices m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DeviceArray>) ostream)
  "Serializes a message object of type '<DeviceArray>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'devices))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'devices))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DeviceArray>) istream)
  "Deserializes a message object of type '<DeviceArray>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'devices) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'devices)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'switchbot_ros-msg:Device))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DeviceArray>)))
  "Returns string type for a message object of type '<DeviceArray>"
  "switchbot_ros/DeviceArray")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DeviceArray)))
  "Returns string type for a message object of type 'DeviceArray"
  "switchbot_ros/DeviceArray")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DeviceArray>)))
  "Returns md5sum for a message object of type '<DeviceArray>"
  "24b7884c0fb68c7417b906902c32b745")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DeviceArray)))
  "Returns md5sum for a message object of type 'DeviceArray"
  "24b7884c0fb68c7417b906902c32b745")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DeviceArray>)))
  "Returns full string definition for message of type '<DeviceArray>"
  (cl:format cl:nil "switchbot_ros/Device[] devices~%~%================================================================================~%MSG: switchbot_ros/Device~%string name~%string type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DeviceArray)))
  "Returns full string definition for message of type 'DeviceArray"
  (cl:format cl:nil "switchbot_ros/Device[] devices~%~%================================================================================~%MSG: switchbot_ros/Device~%string name~%string type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DeviceArray>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'devices) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DeviceArray>))
  "Converts a ROS message object to a list"
  (cl:list 'DeviceArray
    (cl:cons ':devices (devices msg))
))

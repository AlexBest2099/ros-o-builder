; Auto-generated. Do not edit!


(cl:in-package switchbot_ros-msg)


;//! \htmlinclude Bot.msg.html

(cl:defclass <Bot> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (battery
    :reader battery
    :initarg :battery
    :type cl:float
    :initform 0.0)
   (power
    :reader power
    :initarg :power
    :type cl:boolean
    :initform cl:nil)
   (device_mode
    :reader device_mode
    :initarg :device_mode
    :type cl:string
    :initform ""))
)

(cl:defclass Bot (<Bot>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Bot>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Bot)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name switchbot_ros-msg:<Bot> is deprecated: use switchbot_ros-msg:Bot instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <Bot>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:header-val is deprecated.  Use switchbot_ros-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'battery-val :lambda-list '(m))
(cl:defmethod battery-val ((m <Bot>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:battery-val is deprecated.  Use switchbot_ros-msg:battery instead.")
  (battery m))

(cl:ensure-generic-function 'power-val :lambda-list '(m))
(cl:defmethod power-val ((m <Bot>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:power-val is deprecated.  Use switchbot_ros-msg:power instead.")
  (power m))

(cl:ensure-generic-function 'device_mode-val :lambda-list '(m))
(cl:defmethod device_mode-val ((m <Bot>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader switchbot_ros-msg:device_mode-val is deprecated.  Use switchbot_ros-msg:device_mode instead.")
  (device_mode m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<Bot>)))
    "Constants for message type '<Bot>"
  '((:DEVICEMODE_PRESS . "\"pressMode\"")
    (:DEVICEMODE_SWITCH . "\"switchMode\"")
    (:DEVICEMODE_CUSTOMIZE . "\"customizeMode\""))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'Bot)))
    "Constants for message type 'Bot"
  '((:DEVICEMODE_PRESS . "\"pressMode\"")
    (:DEVICEMODE_SWITCH . "\"switchMode\"")
    (:DEVICEMODE_CUSTOMIZE . "\"customizeMode\""))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Bot>) ostream)
  "Serializes a message object of type '<Bot>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'battery))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'power) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'device_mode))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'device_mode))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Bot>) istream)
  "Deserializes a message object of type '<Bot>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'battery) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:slot-value msg 'power) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'device_mode) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'device_mode) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Bot>)))
  "Returns string type for a message object of type '<Bot>"
  "switchbot_ros/Bot")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Bot)))
  "Returns string type for a message object of type 'Bot"
  "switchbot_ros/Bot")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Bot>)))
  "Returns md5sum for a message object of type '<Bot>"
  "2b3c1d42dc6799ac69c485a7805ddf85")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Bot)))
  "Returns md5sum for a message object of type 'Bot"
  "2b3c1d42dc6799ac69c485a7805ddf85")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Bot>)))
  "Returns full string definition for message of type '<Bot>"
  (cl:format cl:nil "string DEVICEMODE_PRESS     = \"pressMode\"~%string DEVICEMODE_SWITCH    = \"switchMode\"~%string DEVICEMODE_CUSTOMIZE = \"customizeMode\"~%~%Header  header       # timestamp~%~%float64 battery      # the current battery level, 0-100~%~%bool    power        # ON/OFF state True/False~%string  device_mode  # pressMode, switchMode, or customizeMode~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Bot)))
  "Returns full string definition for message of type 'Bot"
  (cl:format cl:nil "string DEVICEMODE_PRESS     = \"pressMode\"~%string DEVICEMODE_SWITCH    = \"switchMode\"~%string DEVICEMODE_CUSTOMIZE = \"customizeMode\"~%~%Header  header       # timestamp~%~%float64 battery      # the current battery level, 0-100~%~%bool    power        # ON/OFF state True/False~%string  device_mode  # pressMode, switchMode, or customizeMode~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Bot>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     8
     1
     4 (cl:length (cl:slot-value msg 'device_mode))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Bot>))
  "Converts a ROS message object to a list"
  (cl:list 'Bot
    (cl:cons ':header (header msg))
    (cl:cons ':battery (battery msg))
    (cl:cons ':power (power msg))
    (cl:cons ':device_mode (device_mode msg))
))

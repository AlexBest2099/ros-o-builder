(cl:in-package switchbot_ros-msg)
(cl:export '(NAME-VAL
          NAME
          TYPE-VAL
          TYPE
))
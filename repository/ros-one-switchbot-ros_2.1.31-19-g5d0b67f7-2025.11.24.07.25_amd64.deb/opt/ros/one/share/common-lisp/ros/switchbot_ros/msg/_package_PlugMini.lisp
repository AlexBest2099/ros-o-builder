(cl:in-package switchbot_ros-msg)
(cl:export '(HEADER-VAL
          HEADER
          VOLTAGE-VAL
          VOLTAGE
          WEIGHT-VAL
          WEIGHT
          CURRENT-VAL
          CURRENT
          MINUTES_DAY-VAL
          MINUTES_DAY
))
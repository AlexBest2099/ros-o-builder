(cl:in-package switchbot_ros-msg)
(cl:export '(HEADER-VAL
          HEADER
          POWER-VAL
          POWER
          BRIGHTNESS-VAL
          BRIGHTNESS
          COLOR_R-VAL
          COLOR_R
          COLOR_G-VAL
          COLOR_G
          COLOR_B-VAL
          COLOR_B
))
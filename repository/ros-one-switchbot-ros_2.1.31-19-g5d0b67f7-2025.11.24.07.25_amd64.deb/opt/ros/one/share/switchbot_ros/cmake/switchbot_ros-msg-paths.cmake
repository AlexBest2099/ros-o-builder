# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${switchbot_ros_DIR}/.." "msg;msg" switchbot_ros_MSG_INCLUDE_DIRS UNIQUE)
set(switchbot_ros_MSG_DEPENDENCIES actionlib_msgs)


"use strict";

let Bot = require('./Bot.js');
let PlugMini = require('./PlugMini.js');
let Device = require('./Device.js');
let Meter = require('./Meter.js');
let MeterProCO2 = require('./MeterProCO2.js');
let Hub2 = require('./Hub2.js');
let StripLight = require('./StripLight.js');
let DeviceArray = require('./DeviceArray.js');
let SwitchBotCommandAction = require('./SwitchBotCommandAction.js');
let SwitchBotCommandGoal = require('./SwitchBotCommandGoal.js');
let SwitchBotCommandResult = require('./SwitchBotCommandResult.js');
let SwitchBotCommandFeedback = require('./SwitchBotCommandFeedback.js');
let SwitchBotCommandActionGoal = require('./SwitchBotCommandActionGoal.js');
let SwitchBotCommandActionFeedback = require('./SwitchBotCommandActionFeedback.js');
let SwitchBotCommandActionResult = require('./SwitchBotCommandActionResult.js');

module.exports = {
  Bot: Bot,
  PlugMini: PlugMini,
  Device: Device,
  Meter: Meter,
  MeterProCO2: MeterProCO2,
  Hub2: Hub2,
  StripLight: StripLight,
  DeviceArray: DeviceArray,
  SwitchBotCommandAction: SwitchBotCommandAction,
  SwitchBotCommandGoal: SwitchBotCommandGoal,
  SwitchBotCommandResult: SwitchBotCommandResult,
  SwitchBotCommandFeedback: SwitchBotCommandFeedback,
  SwitchBotCommandActionGoal: SwitchBotCommandActionGoal,
  SwitchBotCommandActionFeedback: SwitchBotCommandActionFeedback,
  SwitchBotCommandActionResult: SwitchBotCommandActionResult,
};

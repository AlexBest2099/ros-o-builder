
"use strict";

let Byte = require('./Byte.js');
let Int8MultiArray = require('./Int8MultiArray.js');
let Int8 = require('./Int8.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');
let UInt8MultiArray = require('./UInt8MultiArray.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let UInt32 = require('./UInt32.js');
let Float32 = require('./Float32.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let UInt8 = require('./UInt8.js');
let ColorRGBA = require('./ColorRGBA.js');
let UInt64 = require('./UInt64.js');
let Header = require('./Header.js');
let String = require('./String.js');
let Int32 = require('./Int32.js');
let Float32MultiArray = require('./Float32MultiArray.js');
let Float64MultiArray = require('./Float64MultiArray.js');
let Empty = require('./Empty.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let MultiArrayDimension = require('./MultiArrayDimension.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');
let Int64 = require('./Int64.js');
let Duration = require('./Duration.js');
let UInt16 = require('./UInt16.js');
let Int16 = require('./Int16.js');
let Char = require('./Char.js');
let Bool = require('./Bool.js');
let Float64 = require('./Float64.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let Time = require('./Time.js');

module.exports = {
  Byte: Byte,
  Int8MultiArray: Int8MultiArray,
  Int8: Int8,
  UInt64MultiArray: UInt64MultiArray,
  UInt8MultiArray: UInt8MultiArray,
  Int32MultiArray: Int32MultiArray,
  Int16MultiArray: Int16MultiArray,
  UInt32: UInt32,
  Float32: Float32,
  Int64MultiArray: Int64MultiArray,
  UInt8: UInt8,
  ColorRGBA: ColorRGBA,
  UInt64: UInt64,
  Header: Header,
  String: String,
  Int32: Int32,
  Float32MultiArray: Float32MultiArray,
  Float64MultiArray: Float64MultiArray,
  Empty: Empty,
  UInt16MultiArray: UInt16MultiArray,
  MultiArrayDimension: MultiArrayDimension,
  UInt32MultiArray: UInt32MultiArray,
  Int64: Int64,
  Duration: Duration,
  UInt16: UInt16,
  Int16: Int16,
  Char: Char,
  Bool: Bool,
  Float64: Float64,
  MultiArrayLayout: MultiArrayLayout,
  ByteMultiArray: ByteMultiArray,
  Time: Time,
};

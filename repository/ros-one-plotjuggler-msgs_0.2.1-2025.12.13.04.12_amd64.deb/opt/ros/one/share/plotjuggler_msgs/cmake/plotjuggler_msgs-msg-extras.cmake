set(plotjuggler_msgs_MESSAGE_FILES "msg/DataPoint.msg;msg/DataPoints.msg;msg/Dictionary.msg;msg/StatisticsNames.msg;msg/StatisticsValues.msg")
set(plotjuggler_msgs_SERVICE_FILES "")

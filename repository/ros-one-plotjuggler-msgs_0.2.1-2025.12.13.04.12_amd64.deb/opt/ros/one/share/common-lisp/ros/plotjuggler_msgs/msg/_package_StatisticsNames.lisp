(cl:in-package plotjuggler_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          NAMES-VAL
          NAMES
          NAMES_VERSION-VAL
          NAMES_VERSION
))
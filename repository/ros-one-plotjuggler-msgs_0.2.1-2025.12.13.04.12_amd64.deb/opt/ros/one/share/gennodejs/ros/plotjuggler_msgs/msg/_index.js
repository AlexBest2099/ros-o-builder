
"use strict";

let DataPoint = require('./DataPoint.js');
let DataPoints = require('./DataPoints.js');
let Dictionary = require('./Dictionary.js');
let StatisticsValues = require('./StatisticsValues.js');
let StatisticsNames = require('./StatisticsNames.js');

module.exports = {
  DataPoint: DataPoint,
  DataPoints: DataPoints,
  Dictionary: Dictionary,
  StatisticsValues: StatisticsValues,
  StatisticsNames: StatisticsNames,
};

set(robot_body_filter_MESSAGE_FILES "msg/OrientedBoundingBox.msg;msg/OrientedBoundingBoxStamped.msg;msg/Sphere.msg;msg/SphereStamped.msg")
set(robot_body_filter_SERVICE_FILES "")

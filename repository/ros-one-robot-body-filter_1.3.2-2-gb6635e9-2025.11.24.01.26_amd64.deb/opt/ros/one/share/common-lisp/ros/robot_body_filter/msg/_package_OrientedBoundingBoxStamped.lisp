(cl:in-package robot_body_filter-msg)
(cl:export '(HEADER-VAL
          HEADER
          OBB-VAL
          OBB
))

(cl:in-package :asdf)

(defsystem "robot_body_filter-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "OrientedBoundingBox" :depends-on ("_package_OrientedBoundingBox"))
    (:file "_package_OrientedBoundingBox" :depends-on ("_package"))
    (:file "OrientedBoundingBoxStamped" :depends-on ("_package_OrientedBoundingBoxStamped"))
    (:file "_package_OrientedBoundingBoxStamped" :depends-on ("_package"))
    (:file "Sphere" :depends-on ("_package_Sphere"))
    (:file "_package_Sphere" :depends-on ("_package"))
    (:file "SphereStamped" :depends-on ("_package_SphereStamped"))
    (:file "_package_SphereStamped" :depends-on ("_package"))
  ))
; Auto-generated. Do not edit!


(cl:in-package robot_body_filter-msg)


;//! \htmlinclude SphereStamped.msg.html

(cl:defclass <SphereStamped> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (sphere
    :reader sphere
    :initarg :sphere
    :type robot_body_filter-msg:Sphere
    :initform (cl:make-instance 'robot_body_filter-msg:Sphere)))
)

(cl:defclass SphereStamped (<SphereStamped>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SphereStamped>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SphereStamped)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name robot_body_filter-msg:<SphereStamped> is deprecated: use robot_body_filter-msg:SphereStamped instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <SphereStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robot_body_filter-msg:header-val is deprecated.  Use robot_body_filter-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'sphere-val :lambda-list '(m))
(cl:defmethod sphere-val ((m <SphereStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robot_body_filter-msg:sphere-val is deprecated.  Use robot_body_filter-msg:sphere instead.")
  (sphere m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SphereStamped>) ostream)
  "Serializes a message object of type '<SphereStamped>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'sphere) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SphereStamped>) istream)
  "Deserializes a message object of type '<SphereStamped>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'sphere) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SphereStamped>)))
  "Returns string type for a message object of type '<SphereStamped>"
  "robot_body_filter/SphereStamped")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SphereStamped)))
  "Returns string type for a message object of type 'SphereStamped"
  "robot_body_filter/SphereStamped")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SphereStamped>)))
  "Returns md5sum for a message object of type '<SphereStamped>"
  "b3bf80c24e3bf1e801648dc1419145c0")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SphereStamped)))
  "Returns md5sum for a message object of type 'SphereStamped"
  "b3bf80c24e3bf1e801648dc1419145c0")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SphereStamped>)))
  "Returns full string definition for message of type '<SphereStamped>"
  (cl:format cl:nil "Header header~%robot_body_filter/Sphere sphere~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: robot_body_filter/Sphere~%float32 radius~%geometry_msgs/Point center~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SphereStamped)))
  "Returns full string definition for message of type 'SphereStamped"
  (cl:format cl:nil "Header header~%robot_body_filter/Sphere sphere~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: robot_body_filter/Sphere~%float32 radius~%geometry_msgs/Point center~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SphereStamped>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'sphere))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SphereStamped>))
  "Converts a ROS message object to a list"
  (cl:list 'SphereStamped
    (cl:cons ':header (header msg))
    (cl:cons ':sphere (sphere msg))
))

(cl:in-package robot_body_filter-msg)
(cl:export '(EXTENTS-VAL
          EXTENTS
          POSE-VAL
          POSE
))
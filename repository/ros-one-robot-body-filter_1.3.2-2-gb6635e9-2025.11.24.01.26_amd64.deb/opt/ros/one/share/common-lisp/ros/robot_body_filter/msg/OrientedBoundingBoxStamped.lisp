; Auto-generated. Do not edit!


(cl:in-package robot_body_filter-msg)


;//! \htmlinclude OrientedBoundingBoxStamped.msg.html

(cl:defclass <OrientedBoundingBoxStamped> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (obb
    :reader obb
    :initarg :obb
    :type robot_body_filter-msg:OrientedBoundingBox
    :initform (cl:make-instance 'robot_body_filter-msg:OrientedBoundingBox)))
)

(cl:defclass OrientedBoundingBoxStamped (<OrientedBoundingBoxStamped>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <OrientedBoundingBoxStamped>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'OrientedBoundingBoxStamped)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name robot_body_filter-msg:<OrientedBoundingBoxStamped> is deprecated: use robot_body_filter-msg:OrientedBoundingBoxStamped instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <OrientedBoundingBoxStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robot_body_filter-msg:header-val is deprecated.  Use robot_body_filter-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'obb-val :lambda-list '(m))
(cl:defmethod obb-val ((m <OrientedBoundingBoxStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robot_body_filter-msg:obb-val is deprecated.  Use robot_body_filter-msg:obb instead.")
  (obb m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <OrientedBoundingBoxStamped>) ostream)
  "Serializes a message object of type '<OrientedBoundingBoxStamped>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'obb) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <OrientedBoundingBoxStamped>) istream)
  "Deserializes a message object of type '<OrientedBoundingBoxStamped>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'obb) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<OrientedBoundingBoxStamped>)))
  "Returns string type for a message object of type '<OrientedBoundingBoxStamped>"
  "robot_body_filter/OrientedBoundingBoxStamped")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'OrientedBoundingBoxStamped)))
  "Returns string type for a message object of type 'OrientedBoundingBoxStamped"
  "robot_body_filter/OrientedBoundingBoxStamped")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<OrientedBoundingBoxStamped>)))
  "Returns md5sum for a message object of type '<OrientedBoundingBoxStamped>"
  "9db71e3e8567a7e001e55f01b76b7128")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'OrientedBoundingBoxStamped)))
  "Returns md5sum for a message object of type 'OrientedBoundingBoxStamped"
  "9db71e3e8567a7e001e55f01b76b7128")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<OrientedBoundingBoxStamped>)))
  "Returns full string definition for message of type '<OrientedBoundingBoxStamped>"
  (cl:format cl:nil "Header header~%robot_body_filter/OrientedBoundingBox obb~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: robot_body_filter/OrientedBoundingBox~%geometry_msgs/Vector3 extents~%geometry_msgs/Transform pose~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: geometry_msgs/Transform~%# This represents the transform between two coordinate frames in free space.~%~%Vector3 translation~%Quaternion rotation~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'OrientedBoundingBoxStamped)))
  "Returns full string definition for message of type 'OrientedBoundingBoxStamped"
  (cl:format cl:nil "Header header~%robot_body_filter/OrientedBoundingBox obb~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: robot_body_filter/OrientedBoundingBox~%geometry_msgs/Vector3 extents~%geometry_msgs/Transform pose~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: geometry_msgs/Transform~%# This represents the transform between two coordinate frames in free space.~%~%Vector3 translation~%Quaternion rotation~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <OrientedBoundingBoxStamped>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'obb))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <OrientedBoundingBoxStamped>))
  "Converts a ROS message object to a list"
  (cl:list 'OrientedBoundingBoxStamped
    (cl:cons ':header (header msg))
    (cl:cons ':obb (obb msg))
))

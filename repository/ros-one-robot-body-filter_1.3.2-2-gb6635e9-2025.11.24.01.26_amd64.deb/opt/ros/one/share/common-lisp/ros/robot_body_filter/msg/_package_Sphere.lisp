(cl:in-package robot_body_filter-msg)
(cl:export '(RADIUS-VAL
          RADIUS
          CENTER-VAL
          CENTER
))
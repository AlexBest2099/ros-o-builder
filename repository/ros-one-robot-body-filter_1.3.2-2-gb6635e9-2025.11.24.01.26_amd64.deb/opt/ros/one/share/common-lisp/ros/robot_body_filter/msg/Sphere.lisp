; Auto-generated. Do not edit!


(cl:in-package robot_body_filter-msg)


;//! \htmlinclude Sphere.msg.html

(cl:defclass <Sphere> (roslisp-msg-protocol:ros-message)
  ((radius
    :reader radius
    :initarg :radius
    :type cl:float
    :initform 0.0)
   (center
    :reader center
    :initarg :center
    :type geometry_msgs-msg:Point
    :initform (cl:make-instance 'geometry_msgs-msg:Point)))
)

(cl:defclass Sphere (<Sphere>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Sphere>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Sphere)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name robot_body_filter-msg:<Sphere> is deprecated: use robot_body_filter-msg:Sphere instead.")))

(cl:ensure-generic-function 'radius-val :lambda-list '(m))
(cl:defmethod radius-val ((m <Sphere>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robot_body_filter-msg:radius-val is deprecated.  Use robot_body_filter-msg:radius instead.")
  (radius m))

(cl:ensure-generic-function 'center-val :lambda-list '(m))
(cl:defmethod center-val ((m <Sphere>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robot_body_filter-msg:center-val is deprecated.  Use robot_body_filter-msg:center instead.")
  (center m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Sphere>) ostream)
  "Serializes a message object of type '<Sphere>"
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'radius))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'center) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Sphere>) istream)
  "Deserializes a message object of type '<Sphere>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'radius) (roslisp-utils:decode-single-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'center) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Sphere>)))
  "Returns string type for a message object of type '<Sphere>"
  "robot_body_filter/Sphere")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Sphere)))
  "Returns string type for a message object of type 'Sphere"
  "robot_body_filter/Sphere")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Sphere>)))
  "Returns md5sum for a message object of type '<Sphere>"
  "f69efc940c7492b83b9e5956c3c0f28e")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Sphere)))
  "Returns md5sum for a message object of type 'Sphere"
  "f69efc940c7492b83b9e5956c3c0f28e")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Sphere>)))
  "Returns full string definition for message of type '<Sphere>"
  (cl:format cl:nil "float32 radius~%geometry_msgs/Point center~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Sphere)))
  "Returns full string definition for message of type 'Sphere"
  (cl:format cl:nil "float32 radius~%geometry_msgs/Point center~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Sphere>))
  (cl:+ 0
     4
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'center))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Sphere>))
  "Converts a ROS message object to a list"
  (cl:list 'Sphere
    (cl:cons ':radius (radius msg))
    (cl:cons ':center (center msg))
))

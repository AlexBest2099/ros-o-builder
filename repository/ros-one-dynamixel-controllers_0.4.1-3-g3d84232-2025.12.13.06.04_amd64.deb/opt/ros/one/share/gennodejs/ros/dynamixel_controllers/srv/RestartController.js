// Auto-generated. Do not edit!

// (in-package dynamixel_controllers.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class RestartControllerRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.port_name = null;
      this.package_path = null;
      this.module_name = null;
      this.class_name = null;
      this.controller_name = null;
      this.dependencies = null;
    }
    else {
      if (initObj.hasOwnProperty('port_name')) {
        this.port_name = initObj.port_name
      }
      else {
        this.port_name = '';
      }
      if (initObj.hasOwnProperty('package_path')) {
        this.package_path = initObj.package_path
      }
      else {
        this.package_path = '';
      }
      if (initObj.hasOwnProperty('module_name')) {
        this.module_name = initObj.module_name
      }
      else {
        this.module_name = '';
      }
      if (initObj.hasOwnProperty('class_name')) {
        this.class_name = initObj.class_name
      }
      else {
        this.class_name = '';
      }
      if (initObj.hasOwnProperty('controller_name')) {
        this.controller_name = initObj.controller_name
      }
      else {
        this.controller_name = '';
      }
      if (initObj.hasOwnProperty('dependencies')) {
        this.dependencies = initObj.dependencies
      }
      else {
        this.dependencies = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RestartControllerRequest
    // Serialize message field [port_name]
    bufferOffset = _serializer.string(obj.port_name, buffer, bufferOffset);
    // Serialize message field [package_path]
    bufferOffset = _serializer.string(obj.package_path, buffer, bufferOffset);
    // Serialize message field [module_name]
    bufferOffset = _serializer.string(obj.module_name, buffer, bufferOffset);
    // Serialize message field [class_name]
    bufferOffset = _serializer.string(obj.class_name, buffer, bufferOffset);
    // Serialize message field [controller_name]
    bufferOffset = _serializer.string(obj.controller_name, buffer, bufferOffset);
    // Serialize message field [dependencies]
    bufferOffset = _arraySerializer.string(obj.dependencies, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RestartControllerRequest
    let len;
    let data = new RestartControllerRequest(null);
    // Deserialize message field [port_name]
    data.port_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [package_path]
    data.package_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [module_name]
    data.module_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [class_name]
    data.class_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [controller_name]
    data.controller_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [dependencies]
    data.dependencies = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.port_name);
    length += _getByteLength(object.package_path);
    length += _getByteLength(object.module_name);
    length += _getByteLength(object.class_name);
    length += _getByteLength(object.controller_name);
    object.dependencies.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'dynamixel_controllers/RestartControllerRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7785d708c83a180befd2fe3450dd9d41';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string port_name            # serial port that this controller is connected to
    string package_path         # path to ROS package containing controller module
    string module_name          # name of the controller module within that package
    string class_name           # controller class name within that module
    string controller_name      # path to controller config parameters on param server
    string[] dependencies       # optional, list names of all controllers this controller depends on
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RestartControllerRequest(null);
    if (msg.port_name !== undefined) {
      resolved.port_name = msg.port_name;
    }
    else {
      resolved.port_name = ''
    }

    if (msg.package_path !== undefined) {
      resolved.package_path = msg.package_path;
    }
    else {
      resolved.package_path = ''
    }

    if (msg.module_name !== undefined) {
      resolved.module_name = msg.module_name;
    }
    else {
      resolved.module_name = ''
    }

    if (msg.class_name !== undefined) {
      resolved.class_name = msg.class_name;
    }
    else {
      resolved.class_name = ''
    }

    if (msg.controller_name !== undefined) {
      resolved.controller_name = msg.controller_name;
    }
    else {
      resolved.controller_name = ''
    }

    if (msg.dependencies !== undefined) {
      resolved.dependencies = msg.dependencies;
    }
    else {
      resolved.dependencies = []
    }

    return resolved;
    }
};

class RestartControllerResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.reason = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('reason')) {
        this.reason = initObj.reason
      }
      else {
        this.reason = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RestartControllerResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [reason]
    bufferOffset = _serializer.string(obj.reason, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RestartControllerResponse
    let len;
    let data = new RestartControllerResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [reason]
    data.reason = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.reason);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'dynamixel_controllers/RestartControllerResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a4d50a34d34f18de48e2436ff1472594';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string reason
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RestartControllerResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.reason !== undefined) {
      resolved.reason = msg.reason;
    }
    else {
      resolved.reason = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: RestartControllerRequest,
  Response: RestartControllerResponse,
  md5sum() { return '94c76c2df56346fcaa2611bdac54f434'; },
  datatype() { return 'dynamixel_controllers/RestartController'; }
};


"use strict";

let StartController = require('./StartController.js')
let SetCompliancePunch = require('./SetCompliancePunch.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let RestartController = require('./RestartController.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let SetSpeed = require('./SetSpeed.js')
let TorqueEnable = require('./TorqueEnable.js')
let StopController = require('./StopController.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')

module.exports = {
  StartController: StartController,
  SetCompliancePunch: SetCompliancePunch,
  SetComplianceMargin: SetComplianceMargin,
  RestartController: RestartController,
  SetComplianceSlope: SetComplianceSlope,
  SetSpeed: SetSpeed,
  TorqueEnable: TorqueEnable,
  StopController: StopController,
  SetTorqueLimit: SetTorqueLimit,
};

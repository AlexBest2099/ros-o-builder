#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rtabmap::utilite" for configuration "None"
set_property(TARGET rtabmap::utilite APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(rtabmap::utilite PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librtabmap_utilite.so.0.23.3"
  IMPORTED_SONAME_NONE "librtabmap_utilite.so.0.23"
  )

list(APPEND _cmake_import_check_targets rtabmap::utilite )
list(APPEND _cmake_import_check_files_for_rtabmap::utilite "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librtabmap_utilite.so.0.23.3" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

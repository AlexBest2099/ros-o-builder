/*
Copyright (c) 2010-2016, Mathieu Labbe - IntRoLab - Universite de Sherbrooke
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Universite de Sherbrooke nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "rtabmap/core/rtabmap_core_export.h" // DLL export/import defines

#include <opencv2/core/core.hpp>
#include <map>

namespace rtabmap
{

class RTABMAP_CORE_EXPORT VisualWord
{
public:
	VisualWord(int id, const cv::Mat & descriptor, int signatureId = 0);
	~VisualWord();

	void addRef(int signatureId);
	int removeAllRef(int signatureId);
	unsigned long getMemoryUsed() const;

	int getTotalReferences() const {return _totalReferences;}
	int id() const {return _id;}
	const cv::Mat & getDescriptor() const {return _descriptor;}
	const std::map<int, int> & getReferences() const {return _references;} // (signature id , occurrence in the signature)

	bool isSaved() const {return _saved;}
	void setSaved(bool saved) {_saved = saved;}

private:
	int _id;
	cv::Mat _descriptor;
	bool _saved; // If it's saved to db

	int _totalReferences;
	std::map<int, int> _references; // (signature id , occurrence in the signature)
	std::map<int, int> _oldReferences; // (signature id , occurrence in the signature)
};

} // namespace rtabmap

set(rostwitter_MESSAGE_FILES "msg/TweetAction.msg;msg/TweetActionGoal.msg;msg/TweetActionResult.msg;msg/TweetActionFeedback.msg;msg/TweetGoal.msg;msg/TweetResult.msg;msg/TweetFeedback.msg")
set(rostwitter_SERVICE_FILES "")

(cl:in-package rostwitter-msg)
(cl:export '(SUCCESS-VAL
          SUCCESS
))
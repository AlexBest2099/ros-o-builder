(cl:in-package rostwitter-msg)
(cl:export '(STAMP-VAL
          STAMP
))
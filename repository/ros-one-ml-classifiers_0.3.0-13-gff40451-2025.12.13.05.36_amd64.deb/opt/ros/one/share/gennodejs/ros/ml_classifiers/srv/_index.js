
"use strict";

let SaveClassifier = require('./SaveClassifier.js')
let ClassifyData = require('./ClassifyData.js')
let LoadClassifier = require('./LoadClassifier.js')
let CreateClassifier = require('./CreateClassifier.js')
let AddClassData = require('./AddClassData.js')
let ClearClassifier = require('./ClearClassifier.js')
let TrainClassifier = require('./TrainClassifier.js')

module.exports = {
  SaveClassifier: SaveClassifier,
  ClassifyData: ClassifyData,
  LoadClassifier: LoadClassifier,
  CreateClassifier: CreateClassifier,
  AddClassData: AddClassData,
  ClearClassifier: ClearClassifier,
  TrainClassifier: TrainClassifier,
};

; Auto-generated. Do not edit!


(cl:in-package ml_classifiers-msg)


;//! \htmlinclude ClassDataPoint.msg.html

(cl:defclass <ClassDataPoint> (roslisp-msg-protocol:ros-message)
  ((target_class
    :reader target_class
    :initarg :target_class
    :type cl:string
    :initform "")
   (point
    :reader point
    :initarg :point
    :type (cl:vector cl:float)
   :initform (cl:make-array 0 :element-type 'cl:float :initial-element 0.0)))
)

(cl:defclass ClassDataPoint (<ClassDataPoint>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ClassDataPoint>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ClassDataPoint)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-msg:<ClassDataPoint> is deprecated: use ml_classifiers-msg:ClassDataPoint instead.")))

(cl:ensure-generic-function 'target_class-val :lambda-list '(m))
(cl:defmethod target_class-val ((m <ClassDataPoint>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-msg:target_class-val is deprecated.  Use ml_classifiers-msg:target_class instead.")
  (target_class m))

(cl:ensure-generic-function 'point-val :lambda-list '(m))
(cl:defmethod point-val ((m <ClassDataPoint>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-msg:point-val is deprecated.  Use ml_classifiers-msg:point instead.")
  (point m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ClassDataPoint>) ostream)
  "Serializes a message object of type '<ClassDataPoint>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'target_class))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'target_class))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'point))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'point))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ClassDataPoint>) istream)
  "Deserializes a message object of type '<ClassDataPoint>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'target_class) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'target_class) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'point) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'point)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ClassDataPoint>)))
  "Returns string type for a message object of type '<ClassDataPoint>"
  "ml_classifiers/ClassDataPoint")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ClassDataPoint)))
  "Returns string type for a message object of type 'ClassDataPoint"
  "ml_classifiers/ClassDataPoint")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ClassDataPoint>)))
  "Returns md5sum for a message object of type '<ClassDataPoint>"
  "46bea2d2ef979a71ef0bfa470e5978ff")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ClassDataPoint)))
  "Returns md5sum for a message object of type 'ClassDataPoint"
  "46bea2d2ef979a71ef0bfa470e5978ff")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ClassDataPoint>)))
  "Returns full string definition for message of type '<ClassDataPoint>"
  (cl:format cl:nil "string target_class~%float64[] point~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ClassDataPoint)))
  "Returns full string definition for message of type 'ClassDataPoint"
  (cl:format cl:nil "string target_class~%float64[] point~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ClassDataPoint>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'target_class))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'point) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ClassDataPoint>))
  "Converts a ROS message object to a list"
  (cl:list 'ClassDataPoint
    (cl:cons ':target_class (target_class msg))
    (cl:cons ':point (point msg))
))

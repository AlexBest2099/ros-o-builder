(cl:in-package ml_classifiers-srv)
(cl:export '(IDENTIFIER-VAL
          IDENTIFIER
          FILENAME-VAL
          FILENAME
          SUCCESS-VAL
          SUCCESS
))
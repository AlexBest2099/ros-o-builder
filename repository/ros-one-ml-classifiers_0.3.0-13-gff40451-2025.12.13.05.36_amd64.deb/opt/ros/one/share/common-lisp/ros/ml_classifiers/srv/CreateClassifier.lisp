; Auto-generated. Do not edit!


(cl:in-package ml_classifiers-srv)


;//! \htmlinclude CreateClassifier-request.msg.html

(cl:defclass <CreateClassifier-request> (roslisp-msg-protocol:ros-message)
  ((identifier
    :reader identifier
    :initarg :identifier
    :type cl:string
    :initform "")
   (class_type
    :reader class_type
    :initarg :class_type
    :type cl:string
    :initform ""))
)

(cl:defclass CreateClassifier-request (<CreateClassifier-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CreateClassifier-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CreateClassifier-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<CreateClassifier-request> is deprecated: use ml_classifiers-srv:CreateClassifier-request instead.")))

(cl:ensure-generic-function 'identifier-val :lambda-list '(m))
(cl:defmethod identifier-val ((m <CreateClassifier-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:identifier-val is deprecated.  Use ml_classifiers-srv:identifier instead.")
  (identifier m))

(cl:ensure-generic-function 'class_type-val :lambda-list '(m))
(cl:defmethod class_type-val ((m <CreateClassifier-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:class_type-val is deprecated.  Use ml_classifiers-srv:class_type instead.")
  (class_type m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CreateClassifier-request>) ostream)
  "Serializes a message object of type '<CreateClassifier-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'identifier))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'identifier))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'class_type))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'class_type))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CreateClassifier-request>) istream)
  "Deserializes a message object of type '<CreateClassifier-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'identifier) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'identifier) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'class_type) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'class_type) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CreateClassifier-request>)))
  "Returns string type for a service object of type '<CreateClassifier-request>"
  "ml_classifiers/CreateClassifierRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CreateClassifier-request)))
  "Returns string type for a service object of type 'CreateClassifier-request"
  "ml_classifiers/CreateClassifierRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CreateClassifier-request>)))
  "Returns md5sum for a message object of type '<CreateClassifier-request>"
  "99a1fae9581fcf2bc80fd6e5aed6e8ee")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CreateClassifier-request)))
  "Returns md5sum for a message object of type 'CreateClassifier-request"
  "99a1fae9581fcf2bc80fd6e5aed6e8ee")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CreateClassifier-request>)))
  "Returns full string definition for message of type '<CreateClassifier-request>"
  (cl:format cl:nil "string identifier~%string class_type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CreateClassifier-request)))
  "Returns full string definition for message of type 'CreateClassifier-request"
  (cl:format cl:nil "string identifier~%string class_type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CreateClassifier-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'identifier))
     4 (cl:length (cl:slot-value msg 'class_type))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CreateClassifier-request>))
  "Converts a ROS message object to a list"
  (cl:list 'CreateClassifier-request
    (cl:cons ':identifier (identifier msg))
    (cl:cons ':class_type (class_type msg))
))
;//! \htmlinclude CreateClassifier-response.msg.html

(cl:defclass <CreateClassifier-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass CreateClassifier-response (<CreateClassifier-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CreateClassifier-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CreateClassifier-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<CreateClassifier-response> is deprecated: use ml_classifiers-srv:CreateClassifier-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <CreateClassifier-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:success-val is deprecated.  Use ml_classifiers-srv:success instead.")
  (success m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CreateClassifier-response>) ostream)
  "Serializes a message object of type '<CreateClassifier-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CreateClassifier-response>) istream)
  "Deserializes a message object of type '<CreateClassifier-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CreateClassifier-response>)))
  "Returns string type for a service object of type '<CreateClassifier-response>"
  "ml_classifiers/CreateClassifierResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CreateClassifier-response)))
  "Returns string type for a service object of type 'CreateClassifier-response"
  "ml_classifiers/CreateClassifierResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CreateClassifier-response>)))
  "Returns md5sum for a message object of type '<CreateClassifier-response>"
  "99a1fae9581fcf2bc80fd6e5aed6e8ee")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CreateClassifier-response)))
  "Returns md5sum for a message object of type 'CreateClassifier-response"
  "99a1fae9581fcf2bc80fd6e5aed6e8ee")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CreateClassifier-response>)))
  "Returns full string definition for message of type '<CreateClassifier-response>"
  (cl:format cl:nil "bool success~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CreateClassifier-response)))
  "Returns full string definition for message of type 'CreateClassifier-response"
  (cl:format cl:nil "bool success~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CreateClassifier-response>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CreateClassifier-response>))
  "Converts a ROS message object to a list"
  (cl:list 'CreateClassifier-response
    (cl:cons ':success (success msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'CreateClassifier)))
  'CreateClassifier-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'CreateClassifier)))
  'CreateClassifier-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CreateClassifier)))
  "Returns string type for a service object of type '<CreateClassifier>"
  "ml_classifiers/CreateClassifier")
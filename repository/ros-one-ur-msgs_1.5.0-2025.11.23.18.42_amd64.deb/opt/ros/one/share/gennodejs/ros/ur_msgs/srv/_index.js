
"use strict";

let SetIO = require('./SetIO.js')
let SetForceMode = require('./SetForceMode.js')
let GetRobotSoftwareVersion = require('./GetRobotSoftwareVersion.js')
let SetPayload = require('./SetPayload.js')
let SetAnalogOutput = require('./SetAnalogOutput.js')
let SetSpeedSliderFraction = require('./SetSpeedSliderFraction.js')

module.exports = {
  SetIO: SetIO,
  SetForceMode: SetForceMode,
  GetRobotSoftwareVersion: GetRobotSoftwareVersion,
  SetPayload: SetPayload,
  SetAnalogOutput: SetAnalogOutput,
  SetSpeedSliderFraction: SetSpeedSliderFraction,
};

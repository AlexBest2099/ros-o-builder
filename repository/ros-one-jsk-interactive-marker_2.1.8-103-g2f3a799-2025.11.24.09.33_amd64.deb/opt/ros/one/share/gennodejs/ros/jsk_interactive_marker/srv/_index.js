
"use strict";

let MarkerSetPose = require('./MarkerSetPose.js')
let GetJointState = require('./GetJointState.js')
let GetMarkerDimensions = require('./GetMarkerDimensions.js')
let IndexRequest = require('./IndexRequest.js')
let GetTransformableMarkerPose = require('./GetTransformableMarkerPose.js')
let SetTransformableMarkerFocus = require('./SetTransformableMarkerFocus.js')
let SnapFootPrint = require('./SnapFootPrint.js')
let SetTransformableMarkerPose = require('./SetTransformableMarkerPose.js')
let SetTransformableMarkerColor = require('./SetTransformableMarkerColor.js')
let GetTransformableMarkerExistence = require('./GetTransformableMarkerExistence.js')
let SetMarkerDimensions = require('./SetMarkerDimensions.js')
let GetTransformableMarkerColor = require('./GetTransformableMarkerColor.js')
let SetHeuristic = require('./SetHeuristic.js')
let SetParentMarker = require('./SetParentMarker.js')
let GetType = require('./GetType.js')
let SetPose = require('./SetPose.js')
let RemoveParentMarker = require('./RemoveParentMarker.js')
let GetTransformableMarkerFocus = require('./GetTransformableMarkerFocus.js')

module.exports = {
  MarkerSetPose: MarkerSetPose,
  GetJointState: GetJointState,
  GetMarkerDimensions: GetMarkerDimensions,
  IndexRequest: IndexRequest,
  GetTransformableMarkerPose: GetTransformableMarkerPose,
  SetTransformableMarkerFocus: SetTransformableMarkerFocus,
  SnapFootPrint: SnapFootPrint,
  SetTransformableMarkerPose: SetTransformableMarkerPose,
  SetTransformableMarkerColor: SetTransformableMarkerColor,
  GetTransformableMarkerExistence: GetTransformableMarkerExistence,
  SetMarkerDimensions: SetMarkerDimensions,
  GetTransformableMarkerColor: GetTransformableMarkerColor,
  SetHeuristic: SetHeuristic,
  SetParentMarker: SetParentMarker,
  GetType: GetType,
  SetPose: SetPose,
  RemoveParentMarker: RemoveParentMarker,
  GetTransformableMarkerFocus: GetTransformableMarkerFocus,
};

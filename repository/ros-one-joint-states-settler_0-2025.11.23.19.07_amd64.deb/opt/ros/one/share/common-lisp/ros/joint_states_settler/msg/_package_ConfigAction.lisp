(cl:in-package joint_states_settler-msg)
(cl:export '(ACTION_GOAL-VAL
          ACTION_GOAL
          ACTION_RESULT-VAL
          ACTION_RESULT
          ACTION_FEEDBACK-VAL
          ACTION_FEEDBACK
))
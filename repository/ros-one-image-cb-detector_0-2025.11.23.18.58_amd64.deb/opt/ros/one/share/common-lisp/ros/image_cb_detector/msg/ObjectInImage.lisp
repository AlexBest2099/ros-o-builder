; Auto-generated. Do not edit!


(cl:in-package image_cb_detector-msg)


;//! \htmlinclude ObjectInImage.msg.html

(cl:defclass <ObjectInImage> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (model_points
    :reader model_points
    :initarg :model_points
    :type (cl:vector geometry_msgs-msg:Point)
   :initform (cl:make-array 0 :element-type 'geometry_msgs-msg:Point :initial-element (cl:make-instance 'geometry_msgs-msg:Point)))
   (image_points
    :reader image_points
    :initarg :image_points
    :type (cl:vector image_cb_detector-msg:ImagePoint)
   :initform (cl:make-array 0 :element-type 'image_cb_detector-msg:ImagePoint :initial-element (cl:make-instance 'image_cb_detector-msg:ImagePoint))))
)

(cl:defclass ObjectInImage (<ObjectInImage>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ObjectInImage>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ObjectInImage)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name image_cb_detector-msg:<ObjectInImage> is deprecated: use image_cb_detector-msg:ObjectInImage instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <ObjectInImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_cb_detector-msg:header-val is deprecated.  Use image_cb_detector-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'model_points-val :lambda-list '(m))
(cl:defmethod model_points-val ((m <ObjectInImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_cb_detector-msg:model_points-val is deprecated.  Use image_cb_detector-msg:model_points instead.")
  (model_points m))

(cl:ensure-generic-function 'image_points-val :lambda-list '(m))
(cl:defmethod image_points-val ((m <ObjectInImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_cb_detector-msg:image_points-val is deprecated.  Use image_cb_detector-msg:image_points instead.")
  (image_points m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ObjectInImage>) ostream)
  "Serializes a message object of type '<ObjectInImage>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'model_points))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'model_points))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'image_points))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'image_points))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ObjectInImage>) istream)
  "Deserializes a message object of type '<ObjectInImage>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'model_points) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'model_points)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'geometry_msgs-msg:Point))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'image_points) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'image_points)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'image_cb_detector-msg:ImagePoint))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ObjectInImage>)))
  "Returns string type for a message object of type '<ObjectInImage>"
  "image_cb_detector/ObjectInImage")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ObjectInImage)))
  "Returns string type for a message object of type 'ObjectInImage"
  "image_cb_detector/ObjectInImage")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ObjectInImage>)))
  "Returns md5sum for a message object of type '<ObjectInImage>"
  "0996b0d8499882526b533fe6e96aa418")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ObjectInImage)))
  "Returns md5sum for a message object of type 'ObjectInImage"
  "0996b0d8499882526b533fe6e96aa418")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ObjectInImage>)))
  "Returns full string definition for message of type '<ObjectInImage>"
  (cl:format cl:nil "Header header~%geometry_msgs/Point[] model_points~%image_cb_detector/ImagePoint[] image_points~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: image_cb_detector/ImagePoint~%float32 x~%float32 y~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ObjectInImage)))
  "Returns full string definition for message of type 'ObjectInImage"
  (cl:format cl:nil "Header header~%geometry_msgs/Point[] model_points~%image_cb_detector/ImagePoint[] image_points~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: image_cb_detector/ImagePoint~%float32 x~%float32 y~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ObjectInImage>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'model_points) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'image_points) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ObjectInImage>))
  "Converts a ROS message object to a list"
  (cl:list 'ObjectInImage
    (cl:cons ':header (header msg))
    (cl:cons ':model_points (model_points msg))
    (cl:cons ':image_points (image_points msg))
))

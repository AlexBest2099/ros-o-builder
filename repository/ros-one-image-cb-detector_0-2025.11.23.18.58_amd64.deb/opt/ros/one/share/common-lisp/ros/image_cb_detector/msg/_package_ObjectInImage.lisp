(cl:in-package image_cb_detector-msg)
(cl:export '(HEADER-VAL
          HEADER
          MODEL_POINTS-VAL
          MODEL_POINTS
          IMAGE_POINTS-VAL
          IMAGE_POINTS
))
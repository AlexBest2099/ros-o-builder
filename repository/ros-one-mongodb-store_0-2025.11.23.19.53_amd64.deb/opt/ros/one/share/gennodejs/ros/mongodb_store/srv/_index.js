
"use strict";

let SetParam = require('./SetParam.js')
let MongoUpdate = require('./MongoUpdate.js')
let GetParam = require('./GetParam.js')
let MongoInsert = require('./MongoInsert.js')
let MongoFind = require('./MongoFind.js')

module.exports = {
  SetParam: SetParam,
  MongoUpdate: MongoUpdate,
  GetParam: GetParam,
  MongoInsert: MongoInsert,
  MongoFind: MongoFind,
};

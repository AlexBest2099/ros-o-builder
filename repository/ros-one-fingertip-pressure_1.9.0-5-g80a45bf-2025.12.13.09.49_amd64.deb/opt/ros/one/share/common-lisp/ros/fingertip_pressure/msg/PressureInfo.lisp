; Auto-generated. Do not edit!


(cl:in-package fingertip_pressure-msg)


;//! \htmlinclude PressureInfo.msg.html

(cl:defclass <PressureInfo> (roslisp-msg-protocol:ros-message)
  ((sensor
    :reader sensor
    :initarg :sensor
    :type (cl:vector fingertip_pressure-msg:PressureInfoElement)
   :initform (cl:make-array 0 :element-type 'fingertip_pressure-msg:PressureInfoElement :initial-element (cl:make-instance 'fingertip_pressure-msg:PressureInfoElement))))
)

(cl:defclass PressureInfo (<PressureInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PressureInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PressureInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name fingertip_pressure-msg:<PressureInfo> is deprecated: use fingertip_pressure-msg:PressureInfo instead.")))

(cl:ensure-generic-function 'sensor-val :lambda-list '(m))
(cl:defmethod sensor-val ((m <PressureInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader fingertip_pressure-msg:sensor-val is deprecated.  Use fingertip_pressure-msg:sensor instead.")
  (sensor m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PressureInfo>) ostream)
  "Serializes a message object of type '<PressureInfo>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'sensor))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'sensor))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PressureInfo>) istream)
  "Deserializes a message object of type '<PressureInfo>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'sensor) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'sensor)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'fingertip_pressure-msg:PressureInfoElement))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PressureInfo>)))
  "Returns string type for a message object of type '<PressureInfo>"
  "fingertip_pressure/PressureInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PressureInfo)))
  "Returns string type for a message object of type 'PressureInfo"
  "fingertip_pressure/PressureInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PressureInfo>)))
  "Returns md5sum for a message object of type '<PressureInfo>"
  "a11fc5bae3534aa023741e378743af5b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PressureInfo)))
  "Returns md5sum for a message object of type 'PressureInfo"
  "a11fc5bae3534aa023741e378743af5b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PressureInfo>)))
  "Returns full string definition for message of type '<PressureInfo>"
  (cl:format cl:nil "PressureInfoElement[] sensor # List of pressure sensors for which information is being published~%~%================================================================================~%MSG: fingertip_pressure/PressureInfoElement~%string frame_id # Frame ID~%geometry_msgs/Vector3[] center # Corner of sensor (meters)~%geometry_msgs/Vector3[] halfside1 # Half of one edge of sensor (meters)~%geometry_msgs/Vector3[] halfside2 # Half of perpendicular edge of sensor (meters)~%# Sensor corners are at center+-halfside1+-halfside2~%# Cross product of halfside1 and halfside2 points out~%float64[] force_per_unit # Multiply this by the raw sensor value to get a force~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PressureInfo)))
  "Returns full string definition for message of type 'PressureInfo"
  (cl:format cl:nil "PressureInfoElement[] sensor # List of pressure sensors for which information is being published~%~%================================================================================~%MSG: fingertip_pressure/PressureInfoElement~%string frame_id # Frame ID~%geometry_msgs/Vector3[] center # Corner of sensor (meters)~%geometry_msgs/Vector3[] halfside1 # Half of one edge of sensor (meters)~%geometry_msgs/Vector3[] halfside2 # Half of perpendicular edge of sensor (meters)~%# Sensor corners are at center+-halfside1+-halfside2~%# Cross product of halfside1 and halfside2 points out~%float64[] force_per_unit # Multiply this by the raw sensor value to get a force~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PressureInfo>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'sensor) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PressureInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'PressureInfo
    (cl:cons ':sensor (sensor msg))
))

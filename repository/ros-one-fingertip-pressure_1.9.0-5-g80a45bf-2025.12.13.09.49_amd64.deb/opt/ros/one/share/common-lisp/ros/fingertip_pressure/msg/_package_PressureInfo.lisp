(cl:in-package fingertip_pressure-msg)
(cl:export '(SENSOR-VAL
          SENSOR
))
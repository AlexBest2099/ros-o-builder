(cl:defpackage fingertip_pressure-msg
  (:use )
  (:export
   "<PRESSUREINFO>"
   "PRESSUREINFO"
   "<PRESSUREINFOELEMENT>"
   "PRESSUREINFOELEMENT"
  ))



(cl:in-package :asdf)

(defsystem "fingertip_pressure-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
)
  :components ((:file "_package")
    (:file "PressureInfo" :depends-on ("_package_PressureInfo"))
    (:file "_package_PressureInfo" :depends-on ("_package"))
    (:file "PressureInfoElement" :depends-on ("_package_PressureInfoElement"))
    (:file "_package_PressureInfoElement" :depends-on ("_package"))
  ))
(cl:in-package app_manager-srv)
(cl:export '(NAME-VAL
          NAME
          ARGS-VAL
          ARGS
          STARTED-VAL
          STARTED
          ERROR_CODE-VAL
          ERROR_CODE
          MESSAGE-VAL
          MESSAGE
          NAMESPACE-VAL
          NAMESPACE
))
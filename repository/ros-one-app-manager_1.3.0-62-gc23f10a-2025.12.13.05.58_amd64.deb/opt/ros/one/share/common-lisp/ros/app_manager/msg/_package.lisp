(cl:defpackage app_manager-msg
  (:use )
  (:export
   "<APP>"
   "APP"
   "<APPINSTALLATIONSTATE>"
   "APPINSTALLATIONSTATE"
   "<APPLIST>"
   "APPLIST"
   "<APPSTATUS>"
   "APPSTATUS"
   "<CLIENTAPP>"
   "CLIENTAPP"
   "<EXCHANGEAPP>"
   "EXCHANGEAPP"
   "<ICON>"
   "ICON"
   "<KEYVALUE>"
   "KEYVALUE"
   "<STATUSCODES>"
   "STATUSCODES"
  ))


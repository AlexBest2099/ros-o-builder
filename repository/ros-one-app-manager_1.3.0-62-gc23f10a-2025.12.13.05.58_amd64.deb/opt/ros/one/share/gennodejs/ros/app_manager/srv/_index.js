
"use strict";

let UninstallApp = require('./UninstallApp.js')
let ListApps = require('./ListApps.js')
let StopApp = require('./StopApp.js')
let GetAppDetails = require('./GetAppDetails.js')
let GetInstallationState = require('./GetInstallationState.js')
let InstallApp = require('./InstallApp.js')
let StartApp = require('./StartApp.js')

module.exports = {
  UninstallApp: UninstallApp,
  ListApps: ListApps,
  StopApp: StopApp,
  GetAppDetails: GetAppDetails,
  GetInstallationState: GetInstallationState,
  InstallApp: InstallApp,
  StartApp: StartApp,
};

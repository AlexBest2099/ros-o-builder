# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${interval_intersection_DIR}/.." "msg" interval_intersection_MSG_INCLUDE_DIRS UNIQUE)
set(interval_intersection_MSG_DEPENDENCIES actionlib_msgs;calibration_msgs;geometry_msgs;std_msgs)

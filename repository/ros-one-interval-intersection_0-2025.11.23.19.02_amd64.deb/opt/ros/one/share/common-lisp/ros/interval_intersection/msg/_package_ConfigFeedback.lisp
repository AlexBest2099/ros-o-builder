(cl:in-package interval_intersection-msg)
(cl:export '())
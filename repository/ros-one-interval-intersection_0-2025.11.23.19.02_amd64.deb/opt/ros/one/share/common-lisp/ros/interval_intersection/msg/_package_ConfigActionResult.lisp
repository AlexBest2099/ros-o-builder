(cl:in-package interval_intersection-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          RESULT-VAL
          RESULT
))
(cl:in-package interval_intersection-msg)
(cl:export '(HEADER-VAL
          HEADER
          GOAL_ID-VAL
          GOAL_ID
          GOAL-VAL
          GOAL
))

"use strict";

let AnalogIOState = require('./AnalogIOState.js');
let IODataStatus = require('./IODataStatus.js');
let SEAJointState = require('./SEAJointState.js');
let AnalogOutputCommand = require('./AnalogOutputCommand.js');
let RobotAssemblyState = require('./RobotAssemblyState.js');
let IOComponentStatus = require('./IOComponentStatus.js');
let CameraControl = require('./CameraControl.js');
let IOComponentConfiguration = require('./IOComponentConfiguration.js');
let AnalogIOStates = require('./AnalogIOStates.js');
let IOComponentCommand = require('./IOComponentCommand.js');
let JointCommand = require('./JointCommand.js');
let IONodeConfiguration = require('./IONodeConfiguration.js');
let EndpointStates = require('./EndpointStates.js');
let NavigatorStates = require('./NavigatorStates.js');
let HomingCommand = require('./HomingCommand.js');
let HomingState = require('./HomingState.js');
let EndpointState = require('./EndpointState.js');
let IODeviceStatus = require('./IODeviceStatus.js');
let IOStatus = require('./IOStatus.js');
let IONodeStatus = require('./IONodeStatus.js');
let JointLimits = require('./JointLimits.js');
let NavigatorState = require('./NavigatorState.js');
let DigitalOutputCommand = require('./DigitalOutputCommand.js');
let CollisionDetectionState = require('./CollisionDetectionState.js');
let HeadState = require('./HeadState.js');
let DigitalIOStates = require('./DigitalIOStates.js');
let EndpointNamesArray = require('./EndpointNamesArray.js');
let CameraSettings = require('./CameraSettings.js');
let URDFConfiguration = require('./URDFConfiguration.js');
let HeadPanCommand = require('./HeadPanCommand.js');
let IODeviceConfiguration = require('./IODeviceConfiguration.js');
let InteractionControlCommand = require('./InteractionControlCommand.js');
let CollisionAvoidanceState = require('./CollisionAvoidanceState.js');
let InteractionControlState = require('./InteractionControlState.js');
let DigitalIOState = require('./DigitalIOState.js');
let CalibrationCommandResult = require('./CalibrationCommandResult.js');
let CalibrationCommandGoal = require('./CalibrationCommandGoal.js');
let CalibrationCommandActionFeedback = require('./CalibrationCommandActionFeedback.js');
let CalibrationCommandActionGoal = require('./CalibrationCommandActionGoal.js');
let CalibrationCommandFeedback = require('./CalibrationCommandFeedback.js');
let CalibrationCommandAction = require('./CalibrationCommandAction.js');
let CalibrationCommandActionResult = require('./CalibrationCommandActionResult.js');

module.exports = {
  AnalogIOState: AnalogIOState,
  IODataStatus: IODataStatus,
  SEAJointState: SEAJointState,
  AnalogOutputCommand: AnalogOutputCommand,
  RobotAssemblyState: RobotAssemblyState,
  IOComponentStatus: IOComponentStatus,
  CameraControl: CameraControl,
  IOComponentConfiguration: IOComponentConfiguration,
  AnalogIOStates: AnalogIOStates,
  IOComponentCommand: IOComponentCommand,
  JointCommand: JointCommand,
  IONodeConfiguration: IONodeConfiguration,
  EndpointStates: EndpointStates,
  NavigatorStates: NavigatorStates,
  HomingCommand: HomingCommand,
  HomingState: HomingState,
  EndpointState: EndpointState,
  IODeviceStatus: IODeviceStatus,
  IOStatus: IOStatus,
  IONodeStatus: IONodeStatus,
  JointLimits: JointLimits,
  NavigatorState: NavigatorState,
  DigitalOutputCommand: DigitalOutputCommand,
  CollisionDetectionState: CollisionDetectionState,
  HeadState: HeadState,
  DigitalIOStates: DigitalIOStates,
  EndpointNamesArray: EndpointNamesArray,
  CameraSettings: CameraSettings,
  URDFConfiguration: URDFConfiguration,
  HeadPanCommand: HeadPanCommand,
  IODeviceConfiguration: IODeviceConfiguration,
  InteractionControlCommand: InteractionControlCommand,
  CollisionAvoidanceState: CollisionAvoidanceState,
  InteractionControlState: InteractionControlState,
  DigitalIOState: DigitalIOState,
  CalibrationCommandResult: CalibrationCommandResult,
  CalibrationCommandGoal: CalibrationCommandGoal,
  CalibrationCommandActionFeedback: CalibrationCommandActionFeedback,
  CalibrationCommandActionGoal: CalibrationCommandActionGoal,
  CalibrationCommandFeedback: CalibrationCommandFeedback,
  CalibrationCommandAction: CalibrationCommandAction,
  CalibrationCommandActionResult: CalibrationCommandActionResult,
};

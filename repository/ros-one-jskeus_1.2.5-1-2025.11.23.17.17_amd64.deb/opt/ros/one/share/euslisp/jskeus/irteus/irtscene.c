/* ./irtscene.c :  entry=irtscene */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sun Nov 23 17:09:44 UTC 2025) */
#include "eus.h"
#include "irtscene.h"
#pragma init (register_irtscene)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtscene();
extern pointer build_quote_vector();
static int register_irtscene()
  { add_module_initializer("___irtscene", ___irtscene);}


/*:init*/
static pointer irtsceneM635scene_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtsceneRST637:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtsceneKEY638;
	local[1] = fqv[1];
irtsceneKEY638:
	if (n & (1<<1)) goto irtsceneKEY639;
	local[2] = NIL;
irtsceneKEY639:
	if (n & (1<<2)) goto irtsceneKEY640;
	local[3] = NIL;
irtsceneKEY640:
	local[4]= (pointer)get_sym_func(fqv[2]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[3]));
	local[7]= fqv[4];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,5,local+4); /*apply*/
	argv[0]->c.obj.iv[8] = fqv[5];
	argv[0]->c.obj.iv[9] = local[2];
	if (local[3]==NIL) goto irtsceneIF641;
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtsceneCLO643,env,argv,local);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[0])(ctx,2,local+4,&ftab[0],fqv[6]); /*delete-if*/
	local[4]= w;
	goto irtsceneIF642;
irtsceneIF641:
	local[4]= argv[0]->c.obj.iv[9];
irtsceneIF642:
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[9];
irtsceneWHL644:
	if (local[5]==NIL) goto irtsceneWHX645;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[7];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)GETCLASS(ctx,1,local+6); /*class*/
	local[6]= w;
	if (loadglobal(fqv[8])!=local[6]) goto irtsceneIF647;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= fqv[9];
	ctx->vsp=local+9;
	w=(pointer)PUTPROP(ctx,3,local+6); /*putprop*/
	local[6]= local[4];
	local[7]= fqv[10];
	local[8]= fqv[11];
	ctx->vsp=local+9;
	w=(pointer)PUTPROP(ctx,3,local+6); /*putprop*/
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)300L);
	local[8]= fqv[12];
	ctx->vsp=local+9;
	w=(pointer)PUTPROP(ctx,3,local+6); /*putprop*/
	local[6]= w;
	goto irtsceneIF648;
irtsceneIF647:
	local[6]= NIL;
irtsceneIF648:
	goto irtsceneWHL644;
irtsceneWHX645:
	local[6]= NIL;
irtsceneBLK646:
	w = NIL;
	w = argv[0];
	local[0]= w;
irtsceneBLK636:
	ctx->vsp=local; return(local[0]);}

/*:objects*/
static pointer irtsceneM649scene_model_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtsceneBLK650:
	ctx->vsp=local; return(local[0]);}

/*:add-objects*/
static pointer irtsceneM651scene_model_add_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[2];
irtsceneWHL653:
	if (local[1]==NIL) goto irtsceneWHX654;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[13];
	local[4]= local[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w==NIL) goto irtsceneIF656;
	local[2]= fqv[14];
	local[3]= local[0];
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,2,local+2); /*error*/
	w = NIL;
	ctx->vsp=local+2;
	local[0]=w;
	goto irtsceneBLK652;
	goto irtsceneIF657;
irtsceneIF656:
	local[2]= NIL;
irtsceneIF657:
	goto irtsceneWHL653;
irtsceneWHX654:
	local[2]= NIL;
irtsceneBLK655:
	w = NIL;
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	local[0]= w;
irtsceneBLK652:
	ctx->vsp=local; return(local[0]);}

/*:add-object*/
static pointer irtsceneM658scene_model_add_object(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtsceneBLK659:
	ctx->vsp=local; return(local[0]);}

/*:remove-objects*/
static pointer irtsceneM660scene_model_remove_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[2];
irtsceneWHL662:
	if (local[2]==NIL) goto irtsceneWHX663;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	w = local[1];
	if (!isstring(w)) goto irtsceneIF665;
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtsceneIF666;
irtsceneIF665:
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= local[1];
	local[6]= fqv[5];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
irtsceneIF666:
	if (local[3]!=NIL) goto irtsceneIF667;
	local[4]= fqv[17];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SIGERROR(ctx,2,local+4); /*error*/
	w = NIL;
	ctx->vsp=local+4;
	local[0]=w;
	goto irtsceneBLK661;
	goto irtsceneIF668;
irtsceneIF667:
	local[4]= NIL;
irtsceneIF668:
	local[4]= local[3];
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	w = local[0];
	goto irtsceneWHL662;
irtsceneWHX663:
	local[3]= NIL;
irtsceneBLK664:
	w = NIL;
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[18]); /*set-difference*/
	argv[0]->c.obj.iv[9] = w;
	w = local[0];
	local[0]= w;
irtsceneBLK661:
	ctx->vsp=local; return(local[0]);}

/*:remove-object*/
static pointer irtsceneM669scene_model_remove_object(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtsceneBLK670:
	ctx->vsp=local; return(local[0]);}

/*:find-object*/
static pointer irtsceneM671scene_model_find_object(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtsceneCLO673,env,argv,local);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtsceneCLO674,env,argv,local);
	local[2]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
irtsceneBLK672:
	ctx->vsp=local; return(local[0]);}

/*:add-spots*/
static pointer irtsceneM675scene_model_add_spots(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[2];
irtsceneWHL677:
	if (local[1]==NIL) goto irtsceneWHX678;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (!isstring(w)) goto irtsceneAND682;
	local[2]= local[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[20]); /*null-string-p*/
	if (w!=NIL) goto irtsceneAND682;
	goto irtsceneIF680;
irtsceneAND682:
	local[2]= fqv[21];
	local[3]= local[0];
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,2,local+2); /*error*/
	w = NIL;
	ctx->vsp=local+2;
	local[0]=w;
	goto irtsceneBLK676;
	goto irtsceneIF681;
irtsceneIF680:
	local[2]= NIL;
irtsceneIF681:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)GETCLASS(ctx,1,local+2); /*class*/
	local[2]= w;
	if (loadglobal(fqv[8])==local[2]) goto irtsceneIF683;
	local[2]= fqv[22];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= w;
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,2,local+2); /*error*/
	w = NIL;
	ctx->vsp=local+2;
	local[0]=w;
	goto irtsceneBLK676;
	goto irtsceneIF684;
irtsceneIF683:
	local[2]= NIL;
irtsceneIF684:
	local[2]= local[0];
	local[3]= fqv[23];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (w==NIL) goto irtsceneIF685;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= fqv[23];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (w==local[2]) goto irtsceneIF685;
	local[2]= fqv[24];
	local[3]= local[0];
	local[4]= fqv[23];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,3,local+2); /*error*/
	w = NIL;
	ctx->vsp=local+2;
	local[0]=w;
	goto irtsceneBLK676;
	goto irtsceneIF686;
irtsceneIF685:
	local[2]= NIL;
irtsceneIF686:
	local[2]= argv[0];
	local[3]= fqv[25];
	local[4]= local[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w==NIL) goto irtsceneIF687;
	local[2]= fqv[26];
	local[3]= local[0];
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,2,local+2); /*error*/
	w = NIL;
	ctx->vsp=local+2;
	local[0]=w;
	goto irtsceneBLK676;
	goto irtsceneIF688;
irtsceneIF687:
	local[2]= NIL;
irtsceneIF688:
	goto irtsceneWHL677;
irtsceneWHX678:
	local[2]= NIL;
irtsceneBLK679:
	w = NIL;
	local[0]= NIL;
	local[1]= argv[2];
irtsceneWHL689:
	if (local[1]==NIL) goto irtsceneWHX690;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[7];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto irtsceneWHL689;
irtsceneWHX690:
	local[2]= NIL;
irtsceneBLK691:
	w = NIL;
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	w = T;
	local[0]= w;
irtsceneBLK676:
	ctx->vsp=local; return(local[0]);}

/*:add-spot*/
static pointer irtsceneM692scene_model_add_spot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtsceneBLK693:
	ctx->vsp=local; return(local[0]);}

/*:remove-spots*/
static pointer irtsceneM694scene_model_remove_spots(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[2];
irtsceneWHL696:
	if (local[1]==NIL) goto irtsceneWHX697;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)GETCLASS(ctx,1,local+2); /*class*/
	local[2]= w;
	if (loadglobal(fqv[8])==local[2]) goto irtsceneIF699;
	local[2]= fqv[28];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= w;
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,2,local+2); /*error*/
	w = NIL;
	ctx->vsp=local+2;
	local[0]=w;
	goto irtsceneBLK695;
	goto irtsceneIF700;
irtsceneIF699:
	local[2]= NIL;
irtsceneIF700:
	goto irtsceneWHL696;
irtsceneWHX697:
	local[2]= NIL;
irtsceneBLK698:
	w = NIL;
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= local[0];
irtsceneWHL701:
	if (local[2]==NIL) goto irtsceneWHX702;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= fqv[23];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[29];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	goto irtsceneWHL701;
irtsceneWHX702:
	local[3]= NIL;
irtsceneBLK703:
	w = NIL;
	w = local[0];
	local[0]= w;
irtsceneBLK695:
	ctx->vsp=local; return(local[0]);}

/*:remove-spot*/
static pointer irtsceneM704scene_model_remove_spot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[30];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtsceneBLK705:
	ctx->vsp=local; return(local[0]);}

/*:spots*/
static pointer irtsceneM706scene_model_spots(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtsceneCLO708,env,argv,local);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtsceneCLO709,env,argv,local);
	local[2]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,2,local+1,&ftab[3],fqv[31]); /*remove-if-not*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
irtsceneBLK707:
	ctx->vsp=local; return(local[0]);}

/*:object*/
static pointer irtsceneM710scene_model_object(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[13];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= local[1];
	if (fqv[32]!=local[2]) goto irtsceneIF712;
	local[2]= makeint((eusinteger_t)1L);
	local[3]= fqv[33];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,3,local+2,&ftab[4],fqv[34]); /*warning-message*/
	local[2]= NIL;
	goto irtsceneIF713;
irtsceneIF712:
	local[2]= local[1];
	if (fqv[35]!=local[2]) goto irtsceneIF714;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	goto irtsceneIF715;
irtsceneIF714:
	if (T==NIL) goto irtsceneIF716;
	local[2]= makeint((eusinteger_t)1L);
	local[3]= fqv[36];
	local[4]= local[0];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,4,local+2,&ftab[4],fqv[34]); /*warning-message*/
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	goto irtsceneIF717;
irtsceneIF716:
	local[2]= NIL;
irtsceneIF717:
irtsceneIF715:
irtsceneIF713:
	w = local[2];
	local[0]= w;
irtsceneBLK711:
	ctx->vsp=local; return(local[0]);}

/*:spot*/
static pointer irtsceneM718scene_model_spot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtsceneCLO720,env,argv,local);
	local[1]= argv[0];
	local[2]= fqv[37];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[31]); /*remove-if-not*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= local[1];
	if (fqv[38]!=local[2]) goto irtsceneIF721;
	local[2]= makeint((eusinteger_t)1L);
	local[3]= fqv[39];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,3,local+2,&ftab[4],fqv[34]); /*warning-message*/
	local[2]= NIL;
	goto irtsceneIF722;
irtsceneIF721:
	local[2]= local[1];
	if (fqv[40]!=local[2]) goto irtsceneIF723;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	goto irtsceneIF724;
irtsceneIF723:
	if (T==NIL) goto irtsceneIF725;
	local[2]= makeint((eusinteger_t)1L);
	local[3]= fqv[41];
	local[4]= local[0];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,4,local+2,&ftab[4],fqv[34]); /*warning-message*/
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	goto irtsceneIF726;
irtsceneIF725:
	local[2]= NIL;
irtsceneIF726:
irtsceneIF724:
irtsceneIF722:
	w = local[2];
	local[0]= w;
irtsceneBLK719:
	ctx->vsp=local; return(local[0]);}

/*:bodies*/
static pointer irtsceneM727scene_model_bodies(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtsceneCLO729,env,argv,local);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[5])(ctx,1,local+0,&ftab[5],fqv[42]); /*flatten*/
	local[0]= w;
irtsceneBLK728:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtsceneCLO643(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[5];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= (isstring(w)?T:NIL);
	if (local[0]==NIL) goto irtsceneAND730;
	local[0]= fqv[43];
	local[1]= argv[0];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[44]); /*substringp*/
	local[0]= w;
irtsceneAND730:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtsceneCLO673(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[45]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto irtsceneIF731;
	local[0]= argv[0];
	local[1]= fqv[13];
	local[2]= env->c.clo.env1[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtsceneIF732;
irtsceneIF731:
	local[0]= NIL;
irtsceneIF732:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtsceneCLO674(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[2];
	local[1]= argv[0];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,2,local+0,&ftab[7],fqv[46]); /*string=*/
	if (w==NIL) goto irtsceneIF733;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtsceneIF734;
irtsceneIF733:
	local[0]= NIL;
irtsceneIF734:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtsceneCLO708(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[45]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto irtsceneIF735;
	local[0]= argv[0];
	local[1]= fqv[37];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtsceneIF736;
irtsceneIF735:
	local[0]= NIL;
irtsceneIF736:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtsceneCLO709(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	w = ((loadglobal(fqv[8]))==(local[0])?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtsceneCLO720(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[2];
	local[1]= argv[0];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,2,local+0,&ftab[7],fqv[46]); /*string=*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtsceneCLO729(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[47];
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,2,local+0,&ftab[8],fqv[48]); /*find-method*/
	if (w==NIL) goto irtsceneIF737;
	local[0]= argv[0];
	local[1]= fqv[47];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtsceneIF738;
irtsceneIF737:
	local[0]= argv[0];
irtsceneIF738:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtscene(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[49];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtsceneIF739;
	local[0]= fqv[50];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[51],w);
	goto irtsceneIF740;
irtsceneIF739:
	local[0]= fqv[52];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtsceneIF740:
	local[0]= fqv[45];
	local[1]= fqv[53];
	local[2]= fqv[45];
	local[3]= fqv[54];
	local[4]= loadglobal(fqv[8]);
	local[5]= fqv[55];
	local[6]= fqv[56];
	local[7]= fqv[57];
	local[8]= NIL;
	local[9]= fqv[58];
	local[10]= NIL;
	local[11]= fqv[12];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[59];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[9])(ctx,13,local+2,&ftab[9],fqv[60]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM635scene_model_init,fqv[4],fqv[45],fqv[61]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM649scene_model_objects,fqv[62],fqv[45],fqv[63]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM651scene_model_add_objects,fqv[15],fqv[45],fqv[64]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM658scene_model_add_object,fqv[65],fqv[45],fqv[66]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM660scene_model_remove_objects,fqv[19],fqv[45],fqv[67]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM669scene_model_remove_object,fqv[68],fqv[45],fqv[69]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM671scene_model_find_object,fqv[13],fqv[45],fqv[70]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM675scene_model_add_spots,fqv[27],fqv[45],fqv[71]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM692scene_model_add_spot,fqv[72],fqv[45],fqv[73]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM694scene_model_remove_spots,fqv[30],fqv[45],fqv[74]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM704scene_model_remove_spot,fqv[75],fqv[45],fqv[76]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM706scene_model_spots,fqv[37],fqv[45],fqv[77]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM710scene_model_object,fqv[16],fqv[45],fqv[78]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM718scene_model_spot,fqv[25],fqv[45],fqv[79]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsceneM727scene_model_bodies,fqv[47],fqv[45],fqv[80]);
	local[0]= fqv[81];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtsceneIF741;
	local[0]= fqv[82];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[51],w);
	goto irtsceneIF742;
irtsceneIF741:
	local[0]= fqv[83];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtsceneIF742:
	local[0]= fqv[84];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(*ftab[10])(ctx,2,local+0,&ftab[10],fqv[86]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<11; i++) ftab[i]=fcallx;
}

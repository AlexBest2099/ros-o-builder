/* ./irtpointcloud.c :  entry=irtpointcloud */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sun Nov 23 17:09:44 UTC 2025) */
#include "eus.h"
#include "irtpointcloud.h"
#pragma init (register_irtpointcloud)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtpointcloud();
extern pointer build_quote_vector();
static int register_irtpointcloud()
  { add_module_initializer("___irtpointcloud", ___irtpointcloud);}

static pointer irtpointF5590make_random_pointcloud();

/*:init*/
static pointer irtpointM5591pointcloud_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtpointRST5593:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto irtpointKEY5594;
	local[1] = NIL;
irtpointKEY5594:
	if (n & (1<<1)) goto irtpointKEY5595;
	local[2] = NIL;
irtpointKEY5595:
	if (n & (1<<2)) goto irtpointKEY5596;
	local[3] = NIL;
irtpointKEY5596:
	if (n & (1<<3)) goto irtpointKEY5597;
	local[4] = NIL;
irtpointKEY5597:
	if (n & (1<<4)) goto irtpointKEY5598;
	local[5] = NIL;
irtpointKEY5598:
	if (n & (1<<5)) goto irtpointKEY5599;
	local[6] = NIL;
irtpointKEY5599:
	if (n & (1<<6)) goto irtpointKEY5600;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)1L);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[7] = w;
irtpointKEY5600:
	if (n & (1<<7)) goto irtpointKEY5601;
	local[8] = makeflt(2.0000000000000000000000e+00);
irtpointKEY5601:
	if (n & (1<<8)) goto irtpointKEY5602;
	local[9] = NIL;
irtpointKEY5602:
	if (n & (1<<9)) goto irtpointKEY5603;
	local[10] = makeflt(2.0000000000000000000000e+00);
irtpointKEY5603:
	if (n & (1<<10)) goto irtpointKEY5604;
	local[11] = makeflt(0.0000000000000000000000e+00);
irtpointKEY5604:
	if (local[1]==NIL) goto irtpointCON5606;
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5606;
	local[12]= argv[0];
	local[13]= fqv[1];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5605;
irtpointCON5606:
	if (local[1]==NIL) goto irtpointCON5607;
	argv[0]->c.obj.iv[8] = local[1];
	local[12]= argv[0]->c.obj.iv[8];
	goto irtpointCON5605;
irtpointCON5607:
	local[12]= NIL;
irtpointCON5605:
	if (local[2]==NIL) goto irtpointCON5609;
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5609;
	local[12]= argv[0];
	local[13]= fqv[2];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5608;
irtpointCON5609:
	if (local[2]==NIL) goto irtpointCON5610;
	argv[0]->c.obj.iv[9] = local[2];
	local[12]= argv[0]->c.obj.iv[9];
	goto irtpointCON5608;
irtpointCON5610:
	argv[0]->c.obj.iv[12] = local[7];
	local[12]= argv[0]->c.obj.iv[12];
	goto irtpointCON5608;
irtpointCON5611:
	local[12]= NIL;
irtpointCON5608:
	if (local[3]==NIL) goto irtpointCON5613;
	local[12]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5613;
	local[12]= argv[0];
	local[13]= fqv[3];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5612;
irtpointCON5613:
	if (local[3]==NIL) goto irtpointCON5614;
	argv[0]->c.obj.iv[10] = local[3];
	local[12]= argv[0]->c.obj.iv[10];
	goto irtpointCON5612;
irtpointCON5614:
	local[12]= NIL;
irtpointCON5612:
	if (local[3]==NIL) goto irtpointCON5616;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5616;
	local[12]= argv[0];
	local[13]= fqv[4];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5615;
irtpointCON5616:
	if (local[3]==NIL) goto irtpointCON5617;
	argv[0]->c.obj.iv[11] = local[4];
	local[12]= argv[0]->c.obj.iv[11];
	goto irtpointCON5615;
irtpointCON5617:
	local[12]= NIL;
irtpointCON5615:
	argv[0]->c.obj.iv[13] = local[8];
	argv[0]->c.obj.iv[14] = local[10];
	argv[0]->c.obj.iv[15] = local[11];
	ctx->vsp=local+12;
	w=(*ftab[0])(ctx,0,local+12,&ftab[0],fqv[5]); /*make-coords*/
	argv[0]->c.obj.iv[19] = w;
	argv[0]->c.obj.iv[20] = fqv[6];
	if (local[5]==NIL) goto irtpointCON5619;
	if (local[6]==NIL) goto irtpointCON5619;
	local[12]= argv[0];
	local[13]= fqv[7];
	local[14]= local[6];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,4,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5618;
irtpointCON5619:
	local[12]= argv[0];
	local[13]= fqv[7];
	if (argv[0]->c.obj.iv[8]==NIL) goto irtpointIF5621;
	local[14]= argv[0]->c.obj.iv[8];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(*ftab[1])(ctx,2,local+14,&ftab[1],fqv[8]); /*array-dimension*/
	local[14]= w;
	goto irtpointIF5622;
irtpointIF5621:
	local[14]= NIL;
irtpointIF5622:
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5618;
irtpointCON5620:
	local[12]= NIL;
irtpointCON5618:
	if (local[9]==NIL) goto irtpointIF5623;
	local[12]= argv[0];
	local[13]= fqv[9];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[10];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	if (local[12]==NIL) goto irtpointIF5625;
	if (local[13]==NIL) goto irtpointIF5625;
	argv[0]->c.obj.iv[12] = NIL;
	local[14]= local[12];
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	argv[0]->c.obj.iv[8] = w;
	local[14]= local[12];
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	argv[0]->c.obj.iv[9] = w;
	local[14]= argv[0]->c.obj.iv[9];
	goto irtpointIF5626;
irtpointIF5625:
	local[14]= NIL;
irtpointIF5626:
	w = local[14];
	local[12]= w;
	goto irtpointIF5624;
irtpointIF5623:
	local[12]= NIL;
irtpointIF5624:
	local[12]= (pointer)get_sym_func(fqv[12]);
	local[13]= argv[0];
	local[14]= *(ovafptr(argv[1],fqv[13]));
	local[15]= fqv[14];
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)APPLY(ctx,5,local+12); /*apply*/
	w = argv[0];
	local[0]= w;
irtpointBLK5592:
	ctx->vsp=local; return(local[0]);}

/*:reset-box*/
static pointer irtpointM5627pointcloud_reset_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto irtpointIF5629;
	local[0]= fqv[16];
	local[1]= fqv[17];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[18]); /*make-bounding-box*/
	local[0]= w;
	goto irtpointIF5630;
irtpointIF5629:
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[18]); /*make-bounding-box*/
	local[0]= w;
irtpointIF5630:
	w = local[0];
	local[0]= w;
irtpointBLK5628:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer irtpointM5631pointcloud_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[16]!=NIL) goto irtpointIF5633;
	local[0]= argv[0];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[16] = w;
	local[0]= argv[0]->c.obj.iv[16];
	goto irtpointIF5634;
irtpointIF5633:
	local[0]= NIL;
irtpointIF5634:
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtpointBLK5632:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer irtpointM5635pointcloud_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[22];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[21];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[23];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
irtpointBLK5636:
	ctx->vsp=local; return(local[0]);}

/*:size*/
static pointer irtpointM5637pointcloud_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[8]==NIL) goto irtpointIF5639;
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[8]); /*array-dimension*/
	local[0]= w;
	goto irtpointIF5640;
irtpointIF5639:
	local[0]= makeint((eusinteger_t)0L);
irtpointIF5640:
	w = local[0];
	local[0]= w;
irtpointBLK5638:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer irtpointM5641pointcloud_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[18];
	local[0]= w;
irtpointBLK5642:
	ctx->vsp=local; return(local[0]);}

/*:height*/
static pointer irtpointM5643pointcloud_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
irtpointBLK5644:
	ctx->vsp=local; return(local[0]);}

/*:size-change*/
static pointer irtpointM5645pointcloud_size_change(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5649;}
	local[0]= NIL;
irtpointENT5649:
	if (n>=4) { local[1]=(argv[3]); goto irtpointENT5648;}
	local[1]= NIL;
irtpointENT5648:
irtpointENT5647:
	if (n>4) maerror();
	if (local[0]==NIL) goto irtpointCON5651;
	if (local[1]==NIL) goto irtpointCON5651;
	argv[0]->c.obj.iv[18] = local[0];
	argv[0]->c.obj.iv[17] = local[1];
	local[2]= argv[0]->c.obj.iv[17];
	goto irtpointCON5650;
irtpointCON5651:
	if (local[0]==NIL) goto irtpointCON5652;
	argv[0]->c.obj.iv[18] = local[0];
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)1L);
	local[2]= argv[0]->c.obj.iv[17];
	goto irtpointCON5650;
irtpointCON5652:
	if (local[1]==NIL) goto irtpointCON5653;
	argv[0]->c.obj.iv[17] = local[1];
	argv[0]->c.obj.iv[18] = makeint((eusinteger_t)1L);
	local[2]= argv[0]->c.obj.iv[18];
	goto irtpointCON5650;
irtpointCON5653:
	if (argv[0]->c.obj.iv[8]==NIL) goto irtpointIF5655;
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,2,local+2,&ftab[1],fqv[8]); /*array-dimension*/
	argv[0]->c.obj.iv[18] = w;
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)1L);
	local[2]= argv[0]->c.obj.iv[17];
	goto irtpointIF5656;
irtpointIF5655:
	argv[0]->c.obj.iv[18] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[17];
irtpointIF5656:
	goto irtpointCON5650;
irtpointCON5654:
	local[2]= NIL;
irtpointCON5650:
	w = local[2];
	local[0]= w;
irtpointBLK5646:
	ctx->vsp=local; return(local[0]);}

/*:view-coords*/
static pointer irtpointM5657pointcloud_view_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5660;}
	local[0]= NIL;
irtpointENT5660:
irtpointENT5659:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5661;
	argv[0]->c.obj.iv[19] = local[0];
	local[1]= argv[0]->c.obj.iv[19];
	goto irtpointIF5662;
irtpointIF5661:
	local[1]= NIL;
irtpointIF5662:
	w = argv[0]->c.obj.iv[19];
	local[0]= w;
irtpointBLK5658:
	ctx->vsp=local; return(local[0]);}

/*:points*/
static pointer irtpointM5663pointcloud_points(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5668;}
	local[0]= NIL;
irtpointENT5668:
	if (n>=4) { local[1]=(argv[3]); goto irtpointENT5667;}
	local[1]= NIL;
irtpointENT5667:
	if (n>=5) { local[2]=(argv[4]); goto irtpointENT5666;}
	local[2]= NIL;
irtpointENT5666:
irtpointENT5665:
	if (n>5) maerror();
	if (local[0]==NIL) goto irtpointIF5669;
	local[3]= argv[0];
	local[4]= fqv[7];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LISTP(ctx,1,local+3); /*listp*/
	if (w==NIL) goto irtpointCON5672;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,2,local+3,&ftab[2],fqv[11]); /*make-matrix*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= local[0];
irtpointWHL5673:
	if (local[6]==NIL) goto irtpointWHX5674;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[3];
	local[8]= local[4];
	local[9]= local[5];
	local[10]= T;
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,4,local+7,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[4] = w;
	goto irtpointWHL5673;
irtpointWHX5674:
	local[7]= NIL;
irtpointBLK5675:
	w = NIL;
	argv[0]->c.obj.iv[8] = local[3];
	w = argv[0]->c.obj.iv[8];
	local[3]= w;
	goto irtpointCON5671;
irtpointCON5672:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,1,local+3,&ftab[5],fqv[25]); /*matrixp*/
	if (w==NIL) goto irtpointCON5676;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[8]); /*array-dimension*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,2,local+3,&ftab[2],fqv[11]); /*make-matrix*/
	local[3]= w;
	local[4]= local[3]->c.obj.iv[1];
	local[5]= local[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)VECREPLACE(ctx,2,local+4); /*system::vector-replace*/
	argv[0]->c.obj.iv[8] = local[3];
	w = argv[0]->c.obj.iv[8];
	local[3]= w;
	goto irtpointCON5671;
irtpointCON5676:
	local[3]= NIL;
irtpointCON5671:
	goto irtpointIF5670;
irtpointIF5669:
	local[3]= NIL;
irtpointIF5670:
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
irtpointBLK5664:
	ctx->vsp=local; return(local[0]);}

/*:colors*/
static pointer irtpointM5677pointcloud_colors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5680;}
	local[0]= NIL;
irtpointENT5680:
irtpointENT5679:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5681;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto irtpointCON5684;
	argv[0]->c.obj.iv[12] = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*make-matrix*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= local[0];
irtpointWHL5685:
	if (local[4]==NIL) goto irtpointWHX5686;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	local[8]= T;
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,4,local+5,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[2] = w;
	goto irtpointWHL5685;
irtpointWHX5686:
	local[5]= NIL;
irtpointBLK5687:
	w = NIL;
	argv[0]->c.obj.iv[9] = local[1];
	w = argv[0]->c.obj.iv[9];
	local[1]= w;
	goto irtpointCON5683;
irtpointCON5684:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[25]); /*matrixp*/
	if (w==NIL) goto irtpointCON5688;
	argv[0]->c.obj.iv[12] = NIL;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[8]); /*array-dimension*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*make-matrix*/
	local[1]= w;
	local[2]= local[1]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VECREPLACE(ctx,2,local+2); /*system::vector-replace*/
	argv[0]->c.obj.iv[9] = local[1];
	w = argv[0]->c.obj.iv[9];
	local[1]= w;
	goto irtpointCON5683;
irtpointCON5688:
	local[1]= NIL;
irtpointCON5683:
	goto irtpointIF5682;
irtpointIF5681:
	local[1]= NIL;
irtpointIF5682:
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtpointBLK5678:
	ctx->vsp=local; return(local[0]);}

/*:normals*/
static pointer irtpointM5689pointcloud_normals(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5692;}
	local[0]= NIL;
irtpointENT5692:
irtpointENT5691:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5693;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto irtpointCON5696;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*make-matrix*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= local[0];
irtpointWHL5697:
	if (local[4]==NIL) goto irtpointWHX5698;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	local[8]= T;
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,4,local+5,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[2] = w;
	goto irtpointWHL5697;
irtpointWHX5698:
	local[5]= NIL;
irtpointBLK5699:
	w = NIL;
	argv[0]->c.obj.iv[10] = local[1];
	w = argv[0]->c.obj.iv[10];
	local[1]= w;
	goto irtpointCON5695;
irtpointCON5696:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[25]); /*matrixp*/
	if (w==NIL) goto irtpointCON5700;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[8]); /*array-dimension*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*make-matrix*/
	local[1]= w;
	local[2]= local[1]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VECREPLACE(ctx,2,local+2); /*system::vector-replace*/
	argv[0]->c.obj.iv[10] = local[1];
	w = argv[0]->c.obj.iv[10];
	local[1]= w;
	goto irtpointCON5695;
irtpointCON5700:
	local[1]= NIL;
irtpointCON5695:
	goto irtpointIF5694;
irtpointIF5693:
	local[1]= NIL;
irtpointIF5694:
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtpointBLK5690:
	ctx->vsp=local; return(local[0]);}

/*:curvatures*/
static pointer irtpointM5701pointcloud_curvatures(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5704;}
	local[0]= NIL;
irtpointENT5704:
irtpointENT5703:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5705;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto irtpointCON5708;
	local[1]= loadglobal(fqv[26]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= local[0];
irtpointWHL5709:
	if (local[4]==NIL) goto irtpointWHX5710;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[0];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SETELT(ctx,3,local+5); /*setelt*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[2] = w;
	goto irtpointWHL5709;
irtpointWHX5710:
	local[5]= NIL;
irtpointBLK5711:
	w = NIL;
	argv[0]->c.obj.iv[11] = local[1];
	w = argv[0]->c.obj.iv[11];
	local[1]= w;
	goto irtpointCON5707;
irtpointCON5708:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)VECTORP(ctx,1,local+1); /*vectorp*/
	if (w==NIL) goto irtpointCON5712;
	local[1]= loadglobal(fqv[26]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)VECREPLACE(ctx,2,local+2); /*system::vector-replace*/
	argv[0]->c.obj.iv[11] = local[1];
	w = argv[0]->c.obj.iv[11];
	local[1]= w;
	goto irtpointCON5707;
irtpointCON5712:
	local[1]= NIL;
irtpointCON5707:
	goto irtpointIF5706;
irtpointIF5705:
	local[1]= NIL;
irtpointIF5706:
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtpointBLK5702:
	ctx->vsp=local; return(local[0]);}

/*:point-list*/
static pointer irtpointM5713pointcloud_point_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5716;}
	local[0]= NIL;
irtpointENT5716:
irtpointENT5715:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0];
	local[5]= fqv[15];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
irtpointWHL5717:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtpointWHX5718;
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[2] = w;
	if (local[0]==NIL) goto irtpointAND5722;
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,1,local+5,&ftab[6],fqv[27]); /*c-isnan*/
	if (w==NIL) goto irtpointAND5722;
	goto irtpointIF5720;
irtpointAND5722:
	local[5]= local[2];
	w = local[1];
	ctx->vsp=local+6;
	local[1] = cons(ctx,local[5],w);
	local[5]= local[1];
	goto irtpointIF5721;
irtpointIF5720:
	local[5]= NIL;
irtpointIF5721:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtpointWHL5717;
irtpointWHX5718:
	local[5]= NIL;
irtpointBLK5719:
	w = NIL;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)REVERSE(ctx,1,local+3); /*reverse*/
	local[0]= w;
irtpointBLK5714:
	ctx->vsp=local; return(local[0]);}

/*:color-list*/
static pointer irtpointM5723pointcloud_color_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5725;
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[9];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,2,local+2,&ftab[1],fqv[8]); /*array-dimension*/
	local[2]= w;
irtpointWHL5727:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtpointWHX5728;
	local[3]= argv[0]->c.obj.iv[9];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtpointWHL5727;
irtpointWHX5728:
	local[3]= NIL;
irtpointBLK5729:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
	goto irtpointIF5726;
irtpointIF5725:
	local[0]= NIL;
irtpointIF5726:
	w = local[0];
	local[0]= w;
irtpointBLK5724:
	ctx->vsp=local; return(local[0]);}

/*:normal-list*/
static pointer irtpointM5730pointcloud_normal_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5732;
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[10];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,2,local+2,&ftab[1],fqv[8]); /*array-dimension*/
	local[2]= w;
irtpointWHL5734:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtpointWHX5735;
	local[3]= argv[0]->c.obj.iv[10];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtpointWHL5734;
irtpointWHX5735:
	local[3]= NIL;
irtpointBLK5736:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
	goto irtpointIF5733;
irtpointIF5732:
	local[0]= NIL;
irtpointIF5733:
	w = local[0];
	local[0]= w;
irtpointBLK5731:
	ctx->vsp=local; return(local[0]);}

/*:curvature-list*/
static pointer irtpointM5737pointcloud_curvature_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[11]==NIL) goto irtpointIF5739;
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
irtpointWHL5741:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtpointWHX5742;
	local[3]= argv[0]->c.obj.iv[11];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtpointWHL5741;
irtpointWHX5742:
	local[3]= NIL;
irtpointBLK5743:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
	goto irtpointIF5740;
irtpointIF5739:
	local[0]= NIL;
irtpointIF5740:
	w = local[0];
	local[0]= w;
irtpointBLK5738:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer irtpointM5744pointcloud_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,2,local+1,&ftab[7],fqv[28]); /*vector-array-mean*/
	w = local[0];
	local[0]= w;
irtpointBLK5745:
	ctx->vsp=local; return(local[0]);}

/*:set-color*/
static pointer irtpointM5746pointcloud_set_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtpointENT5749;}
	local[0]= NIL;
irtpointENT5749:
irtpointENT5748:
	if (n>4) maerror();
	if (argv[2]==NIL) goto irtpointIF5750;
	local[1]= argv[0];
	local[2]= fqv[29];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtpointIF5751;
irtpointIF5750:
	local[1]= NIL;
irtpointIF5751:
	if (local[0]==NIL) goto irtpointIF5752;
	local[1]= argv[0];
	local[2]= fqv[30];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtpointIF5753;
irtpointIF5752:
	local[1]= NIL;
irtpointIF5753:
	w = local[1];
	local[0]= w;
irtpointBLK5747:
	ctx->vsp=local; return(local[0]);}

/*:point-color*/
static pointer irtpointM5754pointcloud_point_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5757;}
	local[0]= NIL;
irtpointENT5757:
irtpointENT5756:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5758;
	argv[0]->c.obj.iv[12] = local[0];
	local[1]= argv[0]->c.obj.iv[12];
	goto irtpointIF5759;
irtpointIF5758:
	local[1]= NIL;
irtpointIF5759:
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
irtpointBLK5755:
	ctx->vsp=local; return(local[0]);}

/*:point-size*/
static pointer irtpointM5760pointcloud_point_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5763;}
	local[0]= NIL;
irtpointENT5763:
irtpointENT5762:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5764;
	argv[0]->c.obj.iv[13] = local[0];
	local[1]= argv[0]->c.obj.iv[13];
	goto irtpointIF5765;
irtpointIF5764:
	local[1]= NIL;
irtpointIF5765:
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
irtpointBLK5761:
	ctx->vsp=local; return(local[0]);}

/*:axis-length*/
static pointer irtpointM5766pointcloud_axis_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5769;}
	local[0]= NIL;
irtpointENT5769:
irtpointENT5768:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5770;
	argv[0]->c.obj.iv[15] = local[0];
	local[1]= argv[0]->c.obj.iv[15];
	goto irtpointIF5771;
irtpointIF5770:
	local[1]= NIL;
irtpointIF5771:
	w = argv[0]->c.obj.iv[15];
	local[0]= w;
irtpointBLK5767:
	ctx->vsp=local; return(local[0]);}

/*:axis-width*/
static pointer irtpointM5772pointcloud_axis_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5775;}
	local[0]= NIL;
irtpointENT5775:
irtpointENT5774:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5776;
	argv[0]->c.obj.iv[14] = local[0];
	local[1]= argv[0]->c.obj.iv[14];
	goto irtpointIF5777;
irtpointIF5776:
	local[1]= NIL;
irtpointIF5777:
	w = argv[0]->c.obj.iv[14];
	local[0]= w;
irtpointBLK5773:
	ctx->vsp=local; return(local[0]);}

/*:append*/
static pointer irtpointM5778pointcloud_append(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[31], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5780;
	local[0] = T;
irtpointKEY5780:
	w = argv[2];
	if (!!iscons(w)) goto irtpointIF5781;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	argv[2] = w;
	local[1]= argv[2];
	goto irtpointIF5782;
irtpointIF5781:
	local[1]= NIL;
irtpointIF5782:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[7]= w;
irtpointWHL5783:
	if (local[7]==NIL) goto irtpointWHX5784;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[4];
	local[9]= local[6];
	local[10]= fqv[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,2,local+9,&ftab[1],fqv[8]); /*array-dimension*/
	local[9]= w;
	if (w!=NIL) goto irtpointOR5786;
	local[9]= makeint((eusinteger_t)0L);
irtpointOR5786:
	local[10]= local[6];
	local[11]= fqv[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(*ftab[1])(ctx,2,local+10,&ftab[1],fqv[8]); /*array-dimension*/
	local[10]= w;
	if (w!=NIL) goto irtpointOR5787;
	local[10]= makeint((eusinteger_t)0L);
irtpointOR5787:
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[1])(ctx,2,local+11,&ftab[1],fqv[8]); /*array-dimension*/
	local[11]= w;
	if (w!=NIL) goto irtpointOR5788;
	local[11]= makeint((eusinteger_t)0L);
irtpointOR5788:
	ctx->vsp=local+12;
	w=(pointer)MAX(ctx,3,local+9); /*max*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[4] = w;
	local[8]= local[1];
	local[9]= local[6];
	local[10]= fqv[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,2,local+9,&ftab[1],fqv[8]); /*array-dimension*/
	local[9]= w;
	if (w!=NIL) goto irtpointOR5789;
	local[9]= makeint((eusinteger_t)0L);
irtpointOR5789:
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[1] = w;
	local[8]= local[2];
	local[9]= local[6];
	local[10]= fqv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,2,local+9,&ftab[1],fqv[8]); /*array-dimension*/
	local[9]= w;
	if (w!=NIL) goto irtpointOR5790;
	local[9]= makeint((eusinteger_t)0L);
irtpointOR5790:
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[2] = w;
	local[8]= local[3];
	local[9]= local[6];
	local[10]= fqv[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,2,local+9,&ftab[1],fqv[8]); /*array-dimension*/
	local[9]= w;
	if (w!=NIL) goto irtpointOR5791;
	local[9]= makeint((eusinteger_t)0L);
irtpointOR5791:
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[3] = w;
	goto irtpointWHL5783;
irtpointWHX5784:
	local[8]= NIL;
irtpointBLK5785:
	w = NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= NIL;
	local[14]= local[1];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtpointIF5792;
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	local[14]= w;
	goto irtpointIF5793;
irtpointIF5792:
	local[14]= NIL;
irtpointIF5793:
	local[6] = local[14];
	local[14]= local[2];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtpointIF5794;
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	local[14]= w;
	goto irtpointIF5795;
irtpointIF5794:
	local[14]= NIL;
irtpointIF5795:
	local[7] = local[14];
	local[14]= local[3];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtpointIF5796;
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	local[14]= w;
	goto irtpointIF5797;
irtpointIF5796:
	local[14]= NIL;
irtpointIF5797:
	local[8] = local[14];
	local[14]= NIL;
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	local[15]= w;
	local[16]= argv[2];
	ctx->vsp=local+17;
	w=(pointer)APPEND(ctx,2,local+15); /*append*/
	local[15]= w;
irtpointWHL5798:
	if (local[15]==NIL) goto irtpointWHX5799;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[14];
	local[17]= fqv[1];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[9] = w;
	local[16]= local[14];
	local[17]= fqv[2];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[10] = w;
	local[16]= local[14];
	local[17]= fqv[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[11] = w;
	local[16]= local[9];
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(*ftab[1])(ctx,2,local+16,&ftab[1],fqv[8]); /*array-dimension*/
	local[16]= w;
	if (w!=NIL) goto irtpointOR5801;
	local[16]= makeint((eusinteger_t)0L);
irtpointOR5801:
	local[17]= local[10];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(*ftab[1])(ctx,2,local+17,&ftab[1],fqv[8]); /*array-dimension*/
	local[17]= w;
	if (w!=NIL) goto irtpointOR5802;
	local[17]= makeint((eusinteger_t)0L);
irtpointOR5802:
	local[18]= local[11];
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(*ftab[1])(ctx,2,local+18,&ftab[1],fqv[8]); /*array-dimension*/
	local[18]= w;
	if (w!=NIL) goto irtpointOR5803;
	local[18]= makeint((eusinteger_t)0L);
irtpointOR5803:
	ctx->vsp=local+19;
	w=(pointer)MAX(ctx,3,local+16); /*max*/
	local[13] = w;
	if (local[9]==NIL) goto irtpointIF5804;
	local[16]= local[6]->c.obj.iv[1];
	local[17]= local[9]->c.obj.iv[1];
	local[18]= makeint((eusinteger_t)3L);
	local[19]= local[12];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)VECREPLACE(ctx,3,local+16); /*system::vector-replace*/
	local[16]= w;
	goto irtpointIF5805;
irtpointIF5804:
	local[16]= NIL;
irtpointIF5805:
	if (local[10]==NIL) goto irtpointIF5806;
	local[16]= local[7]->c.obj.iv[1];
	local[17]= local[10]->c.obj.iv[1];
	local[18]= makeint((eusinteger_t)3L);
	local[19]= local[12];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)VECREPLACE(ctx,3,local+16); /*system::vector-replace*/
	local[16]= w;
	goto irtpointIF5807;
irtpointIF5806:
	local[16]= NIL;
irtpointIF5807:
	if (local[11]==NIL) goto irtpointIF5808;
	local[16]= local[8]->c.obj.iv[1];
	local[17]= local[11]->c.obj.iv[1];
	local[18]= makeint((eusinteger_t)3L);
	local[19]= local[12];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)VECREPLACE(ctx,3,local+16); /*system::vector-replace*/
	local[16]= w;
	goto irtpointIF5809;
irtpointIF5808:
	local[16]= NIL;
irtpointIF5809:
	local[16]= local[12];
	local[17]= local[13];
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[12] = w;
	goto irtpointWHL5798;
irtpointWHX5799:
	local[16]= NIL;
irtpointBLK5800:
	w = NIL;
	if (local[0]==NIL) goto irtpointIF5810;
	local[14]= loadglobal(fqv[32]);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,1,local+14); /*instantiate*/
	local[14]= w;
	local[15]= local[14];
	local[16]= fqv[14];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	w = local[14];
	local[5] = w;
	local[14]= local[5];
	goto irtpointIF5811;
irtpointIF5810:
	local[5] = argv[0];
	local[14]= local[5];
irtpointIF5811:
	local[14]= local[5];
	local[15]= fqv[1];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[2];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[3];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[7];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[33];
	local[16]= argv[0];
	local[17]= fqv[33];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= fqv[34];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[29];
	local[16]= argv[0];
	local[17]= fqv[29];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[35];
	local[16]= argv[0];
	local[17]= fqv[35];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[36];
	local[16]= argv[0];
	local[17]= fqv[36];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[37];
	local[16]= argv[0];
	local[17]= fqv[37];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	w = local[5];
	local[0]= w;
irtpointBLK5779:
	ctx->vsp=local; return(local[0]);}

/*:clear-color*/
static pointer irtpointM5812pointcloud_clear_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[38];
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[39]); /*warn*/
	local[0]= w;
irtpointBLK5813:
	ctx->vsp=local; return(local[0]);}

/*:clear-normal*/
static pointer irtpointM5814pointcloud_clear_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[40];
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[39]); /*warn*/
	local[0]= w;
irtpointBLK5815:
	ctx->vsp=local; return(local[0]);}

/*:nfilter*/
static pointer irtpointM5816pointcloud_nfilter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtpointRST5818:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[41]);
	local[2]= argv[0];
	local[3]= fqv[42];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
irtpointBLK5817:
	ctx->vsp=local; return(local[0]);}

/*:filter*/
static pointer irtpointM5819pointcloud_filter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtpointRST5821:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[43], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtpointKEY5822;
	local[1] = NIL;
irtpointKEY5822:
	local[2]= (pointer)get_sym_func(fqv[41]);
	local[3]= argv[0];
	local[4]= fqv[44];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,4,local+2); /*apply*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[45];
	local[5]= local[2];
	local[6]= fqv[46];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	local[0]= w;
irtpointBLK5820:
	ctx->vsp=local; return(local[0]);}

/*:filter-with-indices*/
static pointer irtpointM5823pointcloud_filter_with_indices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[47], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5825;
	local[0] = NIL;
irtpointKEY5825:
	if (n & (1<<1)) goto irtpointKEY5826;
	local[1] = NIL;
irtpointKEY5826:
	local[2]= argv[0];
	local[3]= fqv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5827;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	goto irtpointIF5828;
irtpointIF5827:
	local[8]= NIL;
irtpointIF5828:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5829;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[9]= w;
	goto irtpointIF5830;
irtpointIF5829:
	local[9]= NIL;
irtpointIF5830:
	local[10]= NIL;
	local[11]= makeint((eusinteger_t)0L);
	if (local[1]==NIL) goto irtpointIF5831;
	local[12]= NIL;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[2];
irtpointWHL5833:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtpointWHX5834;
	local[15]= local[2];
	local[16]= local[13];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,3,local+15); /*-*/
	local[15]= w;
	w = local[12];
	ctx->vsp=local+16;
	local[12] = cons(ctx,local[15],w);
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtpointWHL5833;
irtpointWHX5834:
	local[15]= NIL;
irtpointBLK5835:
	w = NIL;
	local[13]= local[12];
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(*ftab[9])(ctx,2,local+13,&ftab[9],fqv[48]); /*set-difference*/
	argv[2] = w;
	w = argv[2];
	local[12]= w;
	goto irtpointIF5832;
irtpointIF5831:
	local[12]= NIL;
irtpointIF5832:
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[11]); /*make-matrix*/
	local[3] = w;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5836;
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[11]); /*make-matrix*/
	local[12]= w;
	goto irtpointIF5837;
irtpointIF5836:
	local[12]= NIL;
irtpointIF5837:
	local[4] = local[12];
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5838;
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[11]); /*make-matrix*/
	local[12]= w;
	goto irtpointIF5839;
irtpointIF5838:
	local[12]= NIL;
irtpointIF5839:
	local[5] = local[12];
	if (argv[0]->c.obj.iv[11]==NIL) goto irtpointIF5840;
	local[12]= loadglobal(fqv[26]);
	local[13]= argv[2];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[12]= w;
	goto irtpointIF5841;
irtpointIF5840:
	local[12]= NIL;
irtpointIF5841:
	local[6] = local[12];
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5843;
	local[12]= NIL;
	local[13]= argv[2];
irtpointWHL5844:
	if (local[13]==NIL) goto irtpointWHX5845;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= argv[0]->c.obj.iv[8];
	local[15]= local[12];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= local[3];
	local[15]= local[11];
	local[16]= local[7];
	local[17]= T;
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,4,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5847;
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[12];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= local[4];
	local[15]= local[11];
	local[16]= local[8];
	local[17]= T;
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,4,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= w;
	goto irtpointIF5848;
irtpointIF5847:
	local[14]= NIL;
irtpointIF5848:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5849;
	local[14]= argv[0]->c.obj.iv[10];
	local[15]= local[12];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= local[5];
	local[15]= local[11];
	local[16]= local[9];
	local[17]= T;
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,4,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= w;
	goto irtpointIF5850;
irtpointIF5849:
	local[14]= NIL;
irtpointIF5850:
	if (argv[0]->c.obj.iv[11]==NIL) goto irtpointIF5851;
	local[14]= local[6];
	local[15]= local[11];
	local[16]= argv[0]->c.obj.iv[11];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SETELT(ctx,3,local+14); /*setelt*/
	local[14]= w;
	goto irtpointIF5852;
irtpointIF5851:
	local[14]= NIL;
irtpointIF5852:
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[11] = w;
	goto irtpointWHL5844;
irtpointWHX5845:
	local[14]= NIL;
irtpointBLK5846:
	w = NIL;
	local[12]= w;
	goto irtpointCON5842;
irtpointCON5843:
	local[12]= NIL;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)LENGTH(ctx,1,local+14); /*length*/
	local[14]= w;
irtpointWHL5854:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtpointWHX5855;
	local[15]= argv[2];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[12] = w;
	local[15]= argv[0]->c.obj.iv[8];
	local[16]= local[12];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,3,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= local[3];
	local[16]= local[11];
	local[17]= local[7];
	local[18]= T;
	ctx->vsp=local+19;
	w=(*ftab[4])(ctx,4,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5857;
	local[15]= argv[0]->c.obj.iv[9];
	local[16]= local[12];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,3,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= local[4];
	local[16]= local[11];
	local[17]= local[8];
	local[18]= T;
	ctx->vsp=local+19;
	w=(*ftab[4])(ctx,4,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= w;
	goto irtpointIF5858;
irtpointIF5857:
	local[15]= NIL;
irtpointIF5858:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5859;
	local[15]= argv[0]->c.obj.iv[10];
	local[16]= local[12];
	local[17]= local[9];
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,3,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= local[5];
	local[16]= local[11];
	local[17]= local[9];
	local[18]= T;
	ctx->vsp=local+19;
	w=(*ftab[4])(ctx,4,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= w;
	goto irtpointIF5860;
irtpointIF5859:
	local[15]= NIL;
irtpointIF5860:
	if (argv[0]->c.obj.iv[11]==NIL) goto irtpointIF5861;
	local[15]= local[6];
	local[16]= local[11];
	local[17]= argv[0]->c.obj.iv[11];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SETELT(ctx,3,local+15); /*setelt*/
	local[15]= w;
	goto irtpointIF5862;
irtpointIF5861:
	local[15]= NIL;
irtpointIF5862:
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[11] = w;
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtpointWHL5854;
irtpointWHX5855:
	local[15]= NIL;
irtpointBLK5856:
	w = NIL;
	local[12]= w;
	goto irtpointCON5842;
irtpointCON5853:
	local[12]= NIL;
irtpointCON5842:
	if (local[0]==NIL) goto irtpointIF5863;
	local[12]= loadglobal(fqv[32]);
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,1,local+12); /*instantiate*/
	local[12]= w;
	local[13]= local[12];
	local[14]= fqv[14];
	local[15]= fqv[1];
	local[16]= local[3];
	local[17]= fqv[2];
	local[18]= local[4];
	local[19]= fqv[3];
	local[20]= local[5];
	local[21]= fqv[4];
	local[22]= local[6];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,10,local+13); /*send*/
	w = local[12];
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[19];
	local[14]= fqv[34];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= w;
	*(ovafptr(local[12],fqv[49])) = local[14];
	local[13]= local[12];
	local[14]= fqv[50];
	local[15]= argv[0];
	local[16]= fqv[51];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	w = local[12];
	local[12]= w;
	goto irtpointIF5864;
irtpointIF5863:
	argv[0]->c.obj.iv[8] = local[3];
	if (local[4]==NIL) goto irtpointIF5865;
	argv[0]->c.obj.iv[9] = local[4];
	local[12]= argv[0]->c.obj.iv[9];
	goto irtpointIF5866;
irtpointIF5865:
	local[12]= NIL;
irtpointIF5866:
	if (local[5]==NIL) goto irtpointIF5867;
	argv[0]->c.obj.iv[10] = local[5];
	local[12]= argv[0]->c.obj.iv[10];
	goto irtpointIF5868;
irtpointIF5867:
	local[12]= NIL;
irtpointIF5868:
	if (local[6]==NIL) goto irtpointIF5869;
	argv[0]->c.obj.iv[11] = local[6];
	local[12]= argv[0]->c.obj.iv[11];
	goto irtpointIF5870;
irtpointIF5869:
	local[12]= NIL;
irtpointIF5870:
	local[12]= argv[0];
	local[13]= fqv[7];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= argv[0];
irtpointIF5864:
	w = local[12];
	local[0]= w;
irtpointBLK5824:
	ctx->vsp=local; return(local[0]);}

/*:filtered-indices*/
static pointer irtpointM5871pointcloud_filtered_indices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[52], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto irtpointKEY5873;
	local[0] = NIL;
irtpointKEY5873:
	if (n & (1<<1)) goto irtpointKEY5874;
	local[1] = NIL;
irtpointKEY5874:
	if (n & (1<<2)) goto irtpointKEY5875;
	local[2] = NIL;
irtpointKEY5875:
	if (n & (1<<3)) goto irtpointKEY5876;
	local[3] = NIL;
irtpointKEY5876:
	if (n & (1<<4)) goto irtpointKEY5877;
	local[4] = NIL;
irtpointKEY5877:
	if (n & (1<<5)) goto irtpointKEY5878;
	local[5] = NIL;
irtpointKEY5878:
	if (n & (1<<6)) goto irtpointKEY5879;
	local[6] = NIL;
irtpointKEY5879:
	local[7]= NIL;
	local[8]= argv[0];
	local[9]= fqv[15];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= loadglobal(fqv[26]);
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,2,local+9); /*instantiate*/
	local[9]= w;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5880;
	local[10]= loadglobal(fqv[26]);
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[10]= w;
	goto irtpointIF5881;
irtpointIF5880:
	local[10]= NIL;
irtpointIF5881:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5882;
	local[11]= loadglobal(fqv[26]);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,2,local+11); /*instantiate*/
	local[11]= w;
	goto irtpointIF5883;
irtpointIF5882:
	local[11]= NIL;
irtpointIF5883:
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[8];
irtpointWHL5884:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtpointWHX5885;
	local[14]= argv[0]->c.obj.iv[8];
	local[15]= local[12];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	if (local[10]==NIL) goto irtpointIF5887;
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[12];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= w;
	goto irtpointIF5888;
irtpointIF5887:
	local[14]= NIL;
irtpointIF5888:
	if (local[11]==NIL) goto irtpointIF5889;
	local[14]= argv[0]->c.obj.iv[10];
	local[15]= local[12];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= w;
	goto irtpointIF5890;
irtpointIF5889:
	local[14]= NIL;
irtpointIF5890:
	if (local[0]==NIL) goto irtpointOR5893;
	local[14]= local[0];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)FUNCALL(ctx,2,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5893;
	goto irtpointIF5891;
irtpointOR5893:
	if (local[1]==NIL) goto irtpointOR5894;
	if (local[10]==NIL) goto irtpointOR5894;
	local[14]= local[1];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)FUNCALL(ctx,2,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5894;
	goto irtpointIF5891;
irtpointOR5894:
	if (local[2]==NIL) goto irtpointOR5895;
	if (local[11]==NIL) goto irtpointOR5895;
	local[14]= local[2];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)FUNCALL(ctx,2,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5895;
	goto irtpointIF5891;
irtpointOR5895:
	if (local[3]==NIL) goto irtpointOR5896;
	if (local[10]==NIL) goto irtpointOR5896;
	local[14]= local[3];
	local[15]= local[9];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)FUNCALL(ctx,3,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5896;
	goto irtpointIF5891;
irtpointOR5896:
	if (local[4]==NIL) goto irtpointOR5897;
	if (local[11]==NIL) goto irtpointOR5897;
	local[14]= local[4];
	local[15]= local[9];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)FUNCALL(ctx,3,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5897;
	goto irtpointIF5891;
irtpointOR5897:
	if (local[5]==NIL) goto irtpointOR5898;
	if (local[10]==NIL) goto irtpointOR5898;
	if (local[11]==NIL) goto irtpointOR5898;
	local[14]= local[5];
	local[15]= local[9];
	local[16]= local[10];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)FUNCALL(ctx,4,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5898;
	goto irtpointIF5891;
irtpointOR5898:
	if (local[6]!=NIL) goto irtpointIF5899;
	local[14]= local[12];
	w = local[7];
	ctx->vsp=local+15;
	local[7] = cons(ctx,local[14],w);
	local[14]= local[7];
	goto irtpointIF5900;
irtpointIF5899:
	local[14]= NIL;
irtpointIF5900:
	goto irtpointIF5892;
irtpointIF5891:
	if (local[6]==NIL) goto irtpointIF5901;
	local[14]= local[12];
	w = local[7];
	ctx->vsp=local+15;
	local[7] = cons(ctx,local[14],w);
	local[14]= local[7];
	goto irtpointIF5902;
irtpointIF5901:
	local[14]= NIL;
irtpointIF5902:
irtpointIF5892:
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtpointWHL5884;
irtpointWHX5885:
	local[14]= NIL;
irtpointBLK5886:
	w = NIL;
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)NREVERSE(ctx,1,local+12); /*nreverse*/
	local[0]= w;
irtpointBLK5872:
	ctx->vsp=local; return(local[0]);}

/*:viewangle-inlier*/
static pointer irtpointM5903pointcloud_viewangle_inlier(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[53], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5905;
	local[0] = makeflt(0.0000000000000000000000e+00);
irtpointKEY5905:
	if (n & (1<<1)) goto irtpointKEY5906;
	local[1] = makeflt(4.4000000000000000000000e+01);
irtpointKEY5906:
	if (n & (1<<2)) goto irtpointKEY5907;
	local[2] = makeflt(3.5000000000000000000000e+01);
irtpointKEY5907:
	local[3]= local[1];
	local[4]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,1,local+3,&ftab[10],fqv[54]); /*deg2rad*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TAN(ctx,1,local+3); /*tan*/
	local[3]= w;
	local[4]= local[2];
	local[5]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[10])(ctx,1,local+4,&ftab[10],fqv[54]); /*deg2rad*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TAN(ctx,1,local+4); /*tan*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[15];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[6];
irtpointWHL5908:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtpointWHX5909;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(*ftab[4])(ctx,3,local+11,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtpointIF5911;
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ABS(ctx,1,local+11); /*abs*/
	local[11]= w;
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LESSP(ctx,2,local+11); /*<*/
	if (w==NIL) goto irtpointIF5911;
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ABS(ctx,1,local+11); /*abs*/
	local[11]= w;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)LESSP(ctx,2,local+11); /*<*/
	if (w==NIL) goto irtpointIF5911;
	local[11]= local[9];
	w = local[8];
	ctx->vsp=local+12;
	local[8] = cons(ctx,local[11],w);
	local[11]= local[8];
	goto irtpointIF5912;
irtpointIF5911:
	local[11]= NIL;
irtpointIF5912:
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtpointWHL5908;
irtpointWHX5909:
	local[11]= NIL;
irtpointBLK5910:
	w = NIL;
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)NREVERSE(ctx,1,local+9); /*nreverse*/
	local[0]= w;
irtpointBLK5904:
	ctx->vsp=local; return(local[0]);}

/*:image-position-inlier*/
static pointer irtpointM5913pointcloud_image_position_inlier(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[55], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5915;
	local[0] = NIL;
irtpointKEY5915:
	if (n & (1<<1)) goto irtpointKEY5916;
	local[1] = makeint((eusinteger_t)144L);
irtpointKEY5916:
	if (n & (1<<2)) goto irtpointKEY5917;
	local[2] = makeint((eusinteger_t)176L);
irtpointKEY5917:
	if (n & (1<<3)) goto irtpointKEY5918;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[3] = w;
irtpointKEY5918:
	if (n & (1<<4)) goto irtpointKEY5919;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[4] = w;
irtpointKEY5919:
	if (n & (1<<5)) goto irtpointKEY5920;
	local[5] = NIL;
irtpointKEY5920:
	local[6]= NIL;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
irtpointWHL5921:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtpointWHX5922;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[2];
irtpointWHL5924:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtpointWHX5925;
	if (local[0]==NIL) goto irtpointIF5927;
	local[11]= local[0];
	local[12]= local[9];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)FUNCALL(ctx,3,local+11); /*funcall*/
	if (w==NIL) goto irtpointIF5927;
	if (local[5]!=NIL) goto irtpointIF5929;
	local[11]= local[7];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	w = local[6];
	ctx->vsp=local+12;
	local[6] = cons(ctx,local[11],w);
	local[11]= local[6];
	goto irtpointIF5930;
irtpointIF5929:
	local[11]= NIL;
irtpointIF5930:
	goto irtpointIF5928;
irtpointIF5927:
	if (local[5]==NIL) goto irtpointIF5931;
	local[11]= local[7];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	w = local[6];
	ctx->vsp=local+12;
	local[6] = cons(ctx,local[11],w);
	local[11]= local[6];
	goto irtpointIF5932;
irtpointIF5931:
	local[11]= NIL;
irtpointIF5932:
irtpointIF5928:
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtpointWHL5924;
irtpointWHX5925:
	local[11]= NIL;
irtpointBLK5926:
	w = NIL;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtpointWHL5921;
irtpointWHX5922:
	local[9]= NIL;
irtpointBLK5923:
	w = NIL;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	local[0]= w;
irtpointBLK5914:
	ctx->vsp=local; return(local[0]);}

/*:image-circle-filter*/
static pointer irtpointM5933pointcloud_image_circle_filter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[56], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5935;
	local[0] = makeint((eusinteger_t)144L);
irtpointKEY5935:
	if (n & (1<<1)) goto irtpointKEY5936;
	local[1] = makeint((eusinteger_t)176L);
irtpointKEY5936:
	if (n & (1<<2)) goto irtpointKEY5937;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[2] = w;
irtpointKEY5937:
	if (n & (1<<3)) goto irtpointKEY5938;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[3] = w;
irtpointKEY5938:
	if (n & (1<<4)) goto irtpointKEY5939;
	local[4] = NIL;
irtpointKEY5939:
	if (n & (1<<5)) goto irtpointKEY5940;
	local[5] = NIL;
irtpointKEY5940:
	local[6]= argv[0];
	local[7]= fqv[45];
	local[8]= argv[0];
	local[9]= fqv[57];
	local[10]= fqv[58];
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtpointCLO5941,env,argv,local);
	local[12]= fqv[10];
	local[13]= local[0];
	local[14]= fqv[9];
	local[15]= local[1];
	local[16]= fqv[59];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,10,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[46];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,5,local+6); /*send*/
	local[0]= w;
irtpointBLK5934:
	ctx->vsp=local; return(local[0]);}

/*:step-inlier*/
static pointer irtpointM5942pointcloud_step_inlier(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[4];
irtpointTAG5945:
	local[3]= local[2];
	local[4]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	if (w==NIL) goto irtpointIF5946;
	w = NIL;
	ctx->vsp=local+3;
	local[2]=w;
	goto irtpointBLK5944;
	goto irtpointIF5947;
irtpointIF5946:
	local[3]= NIL;
irtpointIF5947:
	local[3]= argv[0]->c.obj.iv[18];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[1] = w;
	local[3]= argv[3];
irtpointTAG5949:
	local[4]= local[3];
	local[5]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+6;
	w=(pointer)GREQP(ctx,2,local+4); /*>=*/
	if (w==NIL) goto irtpointIF5950;
	w = NIL;
	ctx->vsp=local+4;
	local[3]=w;
	goto irtpointBLK5948;
	goto irtpointIF5951;
irtpointIF5950:
	local[4]= NIL;
irtpointIF5951:
	local[4]= local[3];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	local[4]= local[3];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[3] = local[4];
	w = NIL;
	ctx->vsp=local+4;
	goto irtpointTAG5949;
	w = NIL;
	local[3]= w;
irtpointBLK5948:
	local[3]= local[2];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[2] = local[3];
	w = NIL;
	ctx->vsp=local+3;
	goto irtpointTAG5945;
	w = NIL;
	local[2]= w;
irtpointBLK5944:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0]= w;
irtpointBLK5943:
	ctx->vsp=local; return(local[0]);}

/*:step*/
static pointer irtpointM5952pointcloud_step(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[60], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5954;
	local[0] = NIL;
irtpointKEY5954:
	if (n & (1<<1)) goto irtpointKEY5955;
	local[1] = NIL;
irtpointKEY5955:
	local[2]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MOD(ctx,2,local+2); /*mod*/
	local[2]= w;
	local[3]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FLOOR(ctx,1,local+2); /*floor*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MOD(ctx,2,local+3); /*mod*/
	local[3]= w;
	local[4]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)FLOOR(ctx,1,local+3); /*floor*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[18];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[61];
	local[8]= argv[2];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,5,local+6); /*send*/
	local[6]= w;
	local[7]= local[0];
	if (local[7]!=NIL) goto irtpointCON5956;
irtpointCON5957:
	local[7]= argv[0];
	local[8]= fqv[45];
	local[9]= local[6];
	local[10]= fqv[46];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[15];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= local[7];
	local[9]= fqv[7];
	local[10]= local[4];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	w = local[7];
	local[7]= w;
	goto irtpointCON5956;
irtpointCON5958:
	local[7]= NIL;
irtpointCON5956:
	w = local[7];
	local[0]= w;
irtpointBLK5953:
	ctx->vsp=local; return(local[0]);}

/*:generate-color-histogram-hs*/
static pointer irtpointM5959pointcloud_generate_color_histogram_hs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[62], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5961;
	local[0] = makeint((eusinteger_t)9L);
irtpointKEY5961:
	if (n & (1<<1)) goto irtpointKEY5962;
	local[1] = makeint((eusinteger_t)7L);
irtpointKEY5962:
	if (n & (1<<2)) goto irtpointKEY5963;
	local[8]= makeflt(3.6000000000000000000000e+02);
	w = makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+9;
	local[2] = cons(ctx,local[8],w);
irtpointKEY5963:
	if (n & (1<<3)) goto irtpointKEY5964;
	local[8]= makeflt(1.0000000000000000000000e+00);
	w = makeflt(1.4999999999999991118216e-01);
	ctx->vsp=local+9;
	local[3] = cons(ctx,local[8],w);
irtpointKEY5964:
	if (n & (1<<4)) goto irtpointKEY5965;
	local[8]= makeflt(1.0000000000000000000000e+00);
	w = makeflt(2.5000000000000000000000e-01);
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
irtpointKEY5965:
	if (n & (1<<5)) goto irtpointKEY5966;
	local[5] = NIL;
irtpointKEY5966:
	if (n & (1<<6)) goto irtpointKEY5967;
	local[6] = makeflt(2.5500000000000000000000e+02);
irtpointKEY5967:
	if (n & (1<<7)) goto irtpointKEY5968;
	local[7] = makeint((eusinteger_t)1L);
irtpointKEY5968:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtpointFLET5969,env,argv,local);
	local[9]= argv[0];
	local[10]= fqv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[10]= w;
	local[11]= fqv[63];
	local[12]= loadglobal(fqv[26]);
	ctx->vsp=local+13;
	w=(*ftab[11])(ctx,3,local+10,&ftab[11],fqv[64]); /*make-array*/
	local[10]= w;
	local[11]= local[10]->c.obj.iv[1];
	local[12]= loadglobal(fqv[26]);
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= argv[0];
	local[16]= fqv[15];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
irtpointWHL5970:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto irtpointWHX5971;
	local[16]= local[9];
	local[17]= local[14];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(*ftab[4])(ctx,3,local+16,&ftab[4],fqv[24]); /*c-matrix-row*/
	if (local[6]==NIL) goto irtpointIF5973;
	local[16]= local[6];
	local[17]= local[12];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)SCALEVEC(ctx,3,local+16); /*scale*/
	local[16]= w;
	goto irtpointIF5974;
irtpointIF5973:
	local[16]= NIL;
irtpointIF5974:
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(*ftab[12])(ctx,1,local+16,&ftab[12],fqv[65]); /*rgb2his*/
	local[16]= w;
	if (local[5]==NIL) goto irtpointIF5975;
	local[17]= local[16];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[17];
	local[19]= local[5];
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[18]= w;
	local[19]= makeflt(3.6000000000000000000000e+02);
	ctx->vsp=local+20;
	w=(pointer)GREQP(ctx,2,local+18); /*>=*/
	if (w==NIL) goto irtpointIF5977;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[17];
	local[21]= local[5];
	local[22]= makeflt(-3.6000000000000000000000e+02);
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,3,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SETELT(ctx,3,local+18); /*setelt*/
	local[18]= w;
	goto irtpointIF5978;
irtpointIF5977:
	local[18]= local[17];
	local[19]= local[5];
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[18]= w;
	local[19]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+20;
	w=(pointer)LSEQP(ctx,2,local+18); /*<=*/
	if (w==NIL) goto irtpointIF5979;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[17];
	local[21]= local[5];
	local[22]= makeflt(3.6000000000000000000000e+02);
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,3,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SETELT(ctx,3,local+18); /*setelt*/
	local[18]= w;
	goto irtpointIF5980;
irtpointIF5979:
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[17];
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SETELT(ctx,3,local+18); /*setelt*/
	local[18]= w;
irtpointIF5980:
irtpointIF5978:
	w = local[18];
	local[17]= w;
	goto irtpointIF5976;
irtpointIF5975:
	local[17]= NIL;
irtpointIF5976:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.cdr;
	ctx->vsp=local+20;
	w=(pointer)GREQP(ctx,3,local+17); /*>=*/
	if (w==NIL) goto irtpointIF5981;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.cdr;
	ctx->vsp=local+20;
	w=(pointer)GREQP(ctx,3,local+17); /*>=*/
	if (w==NIL) goto irtpointIF5981;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.cdr;
	ctx->vsp=local+20;
	w=(pointer)GREQP(ctx,3,local+17); /*>=*/
	if (w==NIL) goto irtpointIF5981;
	local[17]= local[13];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[13] = w;
	local[17]= local[16];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[0];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.cdr;
	w = local[8];
	ctx->vsp=local+21;
	w=irtpointFLET5969(ctx,4,local+17,w);
	local[17]= w;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	local[19]= local[1];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.cdr;
	w = local[8];
	ctx->vsp=local+22;
	w=irtpointFLET5969(ctx,4,local+18,w);
	local[18]= w;
	local[19]= local[11];
	local[20]= local[17];
	local[21]= local[1];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= local[18];
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)1L);
	local[22]= local[11];
	local[23]= local[17];
	local[24]= local[1];
	ctx->vsp=local+25;
	w=(pointer)TIMES(ctx,2,local+23); /***/
	local[23]= w;
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,2,local+21); /*+*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)SETELT(ctx,3,local+19); /*setelt*/
	local[17]= w;
	goto irtpointIF5982;
irtpointIF5981:
	local[17]= NIL;
irtpointIF5982:
	w = local[17];
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto irtpointWHL5970;
irtpointWHX5971:
	local[16]= NIL;
irtpointBLK5972:
	w = NIL;
	if (local[7]==NIL) goto irtpointOR5985;
	local[14]= local[13];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)GREQP(ctx,2,local+14); /*>=*/
	if (w!=NIL) goto irtpointOR5985;
	goto irtpointIF5983;
irtpointOR5985:
	local[14]= makeflt(1.0000000000000000000000e+00);
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	local[15]= local[10];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(*ftab[13])(ctx,3,local+14,&ftab[13],fqv[66]); /*scale-matrix*/
	local[14]= w;
	goto irtpointIF5984;
irtpointIF5983:
	local[10] = NIL;
	local[14]= local[10];
irtpointIF5984:
	w = local[10];
	local[0]= w;
irtpointBLK5960:
	ctx->vsp=local; return(local[0]);}

/*:copy-from*/
static pointer irtpointM5986pointcloud_copy_from(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[1];
	local[2]= argv[2];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[2];
	local[2]= argv[2];
	local[3]= fqv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[3];
	local[2]= argv[2];
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[2];
	local[1]= fqv[10];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[17] = w;
	local[0]= argv[2];
	local[1]= fqv[9];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[18] = w;
	local[0]= argv[0];
	local[1]= fqv[67];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[50];
	local[2]= argv[2];
	local[3]= fqv[51];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= *(ovafptr(argv[2],fqv[49]));
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[19] = w;
	local[0]= argv[0];
	local[1]= fqv[51];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0];
	local[0]= w;
irtpointBLK5987:
	ctx->vsp=local; return(local[0]);}

/*:transform-points*/
static pointer irtpointM5988pointcloud_transform_points(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[68], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5990;
	local[0] = NIL;
irtpointKEY5990:
	if (local[0]==NIL) goto irtpointIF5991;
	local[1]= loadglobal(fqv[32]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[14];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	local[1]= w;
	goto irtpointIF5992;
irtpointIF5991:
	local[1]= argv[0];
irtpointIF5992:
	if (local[0]==NIL) goto irtpointIF5993;
	local[2]= local[1];
	local[3]= fqv[69];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtpointIF5994;
irtpointIF5993:
	local[2]= NIL;
irtpointIF5994:
	local[2]= *(ovafptr(local[1],fqv[49]));
	local[3]= fqv[50];
	local[4]= argv[2];
	local[5]= fqv[51];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[70];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= local[1];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= fqv[71];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= fqv[72];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,4,local+3,&ftab[14],fqv[73]); /*c-coords-transform-vector*/
	local[2]= local[1];
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (w==NIL) goto irtpointIF5995;
	local[2]= local[1];
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= fqv[72];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,4,local+3,&ftab[14],fqv[73]); /*c-coords-transform-vector*/
	local[2]= w;
	goto irtpointIF5996;
irtpointIF5995:
	local[2]= NIL;
irtpointIF5996:
	w = local[1];
	local[0]= w;
irtpointBLK5989:
	ctx->vsp=local; return(local[0]);}

/*:set-offset*/
static pointer irtpointM5997pointcloud_set_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[74], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5999;
	local[0] = NIL;
irtpointKEY5999:
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= argv[2];
	local[4]= fqv[46];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
irtpointBLK5998:
	ctx->vsp=local; return(local[0]);}

/*:convert-to-world*/
static pointer irtpointM6000pointcloud_convert_to_world(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[76], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY6002;
	local[0] = NIL;
irtpointKEY6002:
	local[1]= argv[0];
	local[2]= fqv[77];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,0,local+3,&ftab[0],fqv[5]); /*make-coords*/
	local[3]= w;
	local[4]= fqv[46];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
irtpointBLK6001:
	ctx->vsp=local; return(local[0]);}

/*:move-origin-to*/
static pointer irtpointM6003pointcloud_move_origin_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[78], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY6005;
	local[0] = NIL;
irtpointKEY6005:
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= argv[0];
	local[4]= fqv[34];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[50];
	local[5]= argv[2];
	local[6]= fqv[79];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[70];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[46];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[67];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (argv[0]->c.obj.iv[3]==NIL) goto irtpointCON6007;
	if (local[0]!=NIL) goto irtpointCON6007;
	local[2]= argv[0];
	local[3]= fqv[50];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[51];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[79];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[50];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtpointCON6006;
irtpointCON6007:
	local[2]= local[1];
	local[3]= fqv[50];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtpointCON6006;
irtpointCON6008:
	local[2]= NIL;
irtpointCON6006:
	local[2]= argv[0];
	local[3]= fqv[51];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	local[0]= w;
irtpointBLK6004:
	ctx->vsp=local; return(local[0]);}

/*:drawnormalmode*/
static pointer irtpointM6009pointcloud_drawnormalmode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT6012;}
	local[0]= NIL;
irtpointENT6012:
irtpointENT6011:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= local[1];
	if (fqv[80]!=local[2]) goto irtpointIF6013;
	argv[0]->c.obj.iv[20] = NIL;
	local[2]= argv[0]->c.obj.iv[20];
	goto irtpointIF6014;
irtpointIF6013:
	if (T==NIL) goto irtpointIF6015;
	argv[0]->c.obj.iv[20] = local[0];
	local[2]= argv[0]->c.obj.iv[20];
	goto irtpointIF6016;
irtpointIF6015:
	local[2]= NIL;
irtpointIF6016:
irtpointIF6014:
	w = local[2];
	w = argv[0]->c.obj.iv[20];
	local[0]= w;
irtpointBLK6010:
	ctx->vsp=local; return(local[0]);}

/*:transparent*/
static pointer irtpointM6017pointcloud_transparent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT6020;}
	local[0]= NIL;
irtpointENT6020:
irtpointENT6019:
	if (n>3) maerror();
	argv[0]->c.obj.iv[21] = local[0];
	if (local[0]==NIL) goto irtpointIF6021;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF6021;
	local[1]= argv[0];
	local[2]= fqv[15];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,2,local+2,&ftab[2],fqv[11]); /*make-matrix*/
	argv[0]->c.obj.iv[22] = w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[1];
irtpointWHL6023:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtpointWHX6024;
	local[4]= argv[0]->c.obj.iv[22];
	local[5]= local[2];
	local[6]= loadglobal(fqv[26]);
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(*ftab[15])(ctx,2,local+7,&ftab[15],fqv[81]); /*matrix-row*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)CONCATENATE(ctx,3,local+6); /*concatenate*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[16])(ctx,3,local+4,&ftab[16],fqv[82]); /*set-matrix-row*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtpointWHL6023;
irtpointWHX6024:
	local[4]= NIL;
irtpointBLK6025:
	w = NIL;
	local[1]= w;
	goto irtpointIF6022;
irtpointIF6021:
	local[1]= NIL;
irtpointIF6022:
	w = local[0];
	local[0]= w;
irtpointBLK6018:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer irtpointM6026pointcloud_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[21]==NIL) goto irtpointIF6028;
	local[0]= makeint((eusinteger_t)0L);
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[83]); /*gl:gldepthmask*/
	local[0]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+1;
	w=(*ftab[18])(ctx,1,local+0,&ftab[18],fqv[84]); /*gl:glenable*/
	local[0]= makeint((eusinteger_t)770L);
	local[1]= makeint((eusinteger_t)771L);
	ctx->vsp=local+2;
	w=(*ftab[19])(ctx,2,local+0,&ftab[19],fqv[85]); /*gl:glblendfunc*/
	local[0]= w;
	goto irtpointIF6029;
irtpointIF6028:
	local[0]= NIL;
irtpointIF6029:
	local[0]= makeint((eusinteger_t)4294967295L);
	ctx->vsp=local+1;
	w=(*ftab[20])(ctx,1,local+0,&ftab[20],fqv[86]); /*gl:glpushattrib*/
	if (argv[2]==NIL) goto irtpointIF6030;
	local[0]= argv[2];
	local[1]= fqv[87];
	local[2]= fqv[88];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtpointIF6031;
irtpointIF6030:
	local[0]= NIL;
irtpointIF6031:
	local[0]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+1;
	w=(*ftab[21])(ctx,1,local+0,&ftab[21],fqv[89]); /*gl:gldisable*/
	ctx->vsp=local+0;
	w=(*ftab[22])(ctx,0,local+0,&ftab[22],fqv[90]); /*gl:glpushmatrix*/
	local[0]= argv[0];
	local[1]= fqv[51];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[91];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[92]);
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,2,local+0); /*transpose*/
	local[0]= w->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(*ftab[23])(ctx,1,local+0,&ftab[23],fqv[93]); /*gl:glmultmatrixf*/
	local[0]= argv[0]->c.obj.iv[15];
	local[1]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto irtpointIF6032;
	local[0]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[24])(ctx,1,local+0,&ftab[24],fqv[94]); /*gl:gllinewidth*/
	local[0]= makeint((eusinteger_t)1L);
	ctx->vsp=local+1;
	w=(*ftab[25])(ctx,1,local+0,&ftab[25],fqv[95]); /*gl:glbegin*/
	local[0]= makeint((eusinteger_t)1L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= argv[0]->c.obj.iv[15];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)1L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	ctx->vsp=local+0;
	w=(*ftab[28])(ctx,0,local+0,&ftab[28],fqv[98]); /*gl:glend*/
	local[0]= w;
	goto irtpointIF6033;
irtpointIF6032:
	local[0]= NIL;
irtpointIF6033:
	local[0]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[29])(ctx,1,local+0,&ftab[29],fqv[99]); /*gl:glpointsize*/
	local[0]= argv[0];
	local[1]= fqv[15];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[100]); /*/=*/
	if (w==NIL) goto irtpointIF6034;
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+2;
	w=(pointer)VECTORP(ctx,1,local+1); /*vectorp*/
	if (w==NIL) goto irtpointCON6037;
	local[0] = NIL;
	local[1]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[1]= w;
	goto irtpointCON6036;
irtpointCON6037:
	local[1]= argv[0]->c.obj.iv[12];
	local[2]= fqv[101];
	local[3]= fqv[102];
	local[4]= fqv[103];
	local[5]= fqv[104];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[31])(ctx,2,local+1,&ftab[31],fqv[105]); /*member*/
	if (w==NIL) goto irtpointCON6038;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[12];
	local[3]= local[2];
	w = fqv[106];
	if (memq(local[3],w)==NIL) goto irtpointIF6039;
	local[1] = makeint((eusinteger_t)2L);
	local[3]= local[1];
	goto irtpointIF6040;
irtpointIF6039:
	local[3]= local[2];
	if (fqv[102]!=local[3]) goto irtpointIF6041;
	local[1] = makeint((eusinteger_t)0L);
	local[3]= local[1];
	goto irtpointIF6042;
irtpointIF6041:
	local[3]= local[2];
	if (fqv[103]!=local[3]) goto irtpointIF6043;
	local[1] = makeint((eusinteger_t)1L);
	local[3]= local[1];
	goto irtpointIF6044;
irtpointIF6043:
	local[3]= NIL;
irtpointIF6044:
irtpointIF6042:
irtpointIF6040:
	w = local[3];
	local[2]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+3;
	w=(*ftab[32])(ctx,1,local+2,&ftab[32],fqv[107]); /*copy-matrix*/
	local[0] = w;
	local[2]= local[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0];
	local[7]= fqv[21];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[23];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[21];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[5] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[0];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[1])(ctx,2,local+7,&ftab[1],fqv[8]); /*array-dimension*/
	local[7]= w;
irtpointWHL6045:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtpointWHX6046;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)-280L);
	local[10]= argv[0]->c.obj.iv[8];
	local[11]= local[6];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(*ftab[33])(ctx,4,local+9,&ftab[33],fqv[108]); /*his2rgb*/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[34])(ctx,2,local+9,&ftab[34],fqv[109]); /*normalize-vector*/
	local[9]= w;
	local[10]= fqv[110];
	local[11]= local[6];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[11]);
		local[11]=(makeint(i * j));}
	ctx->vsp=local+12;
	w=(*ftab[35])(ctx,4,local+8,&ftab[35],fqv[111]); /*replace*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtpointWHL6045;
irtpointWHX6046:
	local[8]= NIL;
irtpointBLK6047:
	w = NIL;
	local[1]= w;
	goto irtpointCON6036;
irtpointCON6038:
	local[1]= NIL;
irtpointCON6036:
	local[1]= makeint((eusinteger_t)32884L);
	ctx->vsp=local+2;
	w=(*ftab[36])(ctx,1,local+1,&ftab[36],fqv[112]); /*gl::glenableclientstate*/
	if (local[0]==NIL) goto irtpointIF6048;
	local[1]= makeint((eusinteger_t)32886L);
	ctx->vsp=local+2;
	w=(*ftab[36])(ctx,1,local+1,&ftab[36],fqv[112]); /*gl::glenableclientstate*/
	local[1]= w;
	goto irtpointIF6049;
irtpointIF6048:
	local[1]= NIL;
irtpointIF6049:
	if (local[0]==NIL) goto irtpointIF6050;
	if (argv[0]->c.obj.iv[21]==NIL) goto irtpointIF6052;
	local[1]= makeint((eusinteger_t)4L);
	goto irtpointIF6053;
irtpointIF6052:
	local[1]= makeint((eusinteger_t)3L);
irtpointIF6053:
	local[2]= makeint((eusinteger_t)5130L);
	local[3]= makeint((eusinteger_t)0L);
	if (argv[0]->c.obj.iv[21]==NIL) goto irtpointIF6054;
	local[4]= argv[0]->c.obj.iv[22];
	goto irtpointIF6055;
irtpointIF6054:
	local[4]= local[0];
irtpointIF6055:
	local[4]= local[4]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(*ftab[37])(ctx,4,local+1,&ftab[37],fqv[113]); /*gl::glcolorpointer*/
	local[1]= w;
	goto irtpointIF6051;
irtpointIF6050:
	local[1]= NIL;
irtpointIF6051:
	local[1]= makeint((eusinteger_t)3L);
	local[2]= makeint((eusinteger_t)5130L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[8]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(*ftab[38])(ctx,4,local+1,&ftab[38],fqv[114]); /*gl::glvertexpointer*/
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[8]); /*array-dimension*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[39])(ctx,3,local+1,&ftab[39],fqv[115]); /*gl::gldrawarrays*/
	local[1]= makeint((eusinteger_t)32884L);
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,1,local+1,&ftab[40],fqv[116]); /*gl::gldisableclientstate*/
	if (local[0]==NIL) goto irtpointIF6056;
	local[1]= makeint((eusinteger_t)32886L);
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,1,local+1,&ftab[40],fqv[116]); /*gl::gldisableclientstate*/
	local[1]= w;
	goto irtpointIF6057;
irtpointIF6056:
	local[1]= NIL;
irtpointIF6057:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF6058;
	if (argv[0]->c.obj.iv[20]==NIL) goto irtpointIF6058;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(*ftab[25])(ctx,1,local+5,&ftab[25],fqv[95]); /*gl:glbegin*/
	if (local[0]!=NIL) goto irtpointIF6060;
	local[4] = argv[0]->c.obj.iv[12];
	local[5]= local[4];
	goto irtpointIF6061;
irtpointIF6060:
	local[5]= NIL;
irtpointIF6061:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[10];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,2,local+6,&ftab[1],fqv[8]); /*array-dimension*/
	local[6]= w;
irtpointWHL6062:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtpointWHX6063;
	local[7]= argv[0]->c.obj.iv[10];
	local[8]= local[5];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,3,local+7,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	{ double left,right;
		right=fltval(makeflt(9.9999999999999977795540e-02)); left=fltval(local[7]);
	if (left >= right) goto irtpointCON6066;}
	local[7]= fqv[117];
	ctx->vsp=local+8;
	w=(*ftab[26])(ctx,1,local+7,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[7]= NIL;
	local[8]= fqv[118];
	local[9]= fqv[119];
	local[10]= fqv[120];
	local[11]= fqv[121];
	local[12]= fqv[122];
	local[13]= fqv[123];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,6,local+8); /*list*/
	local[8]= w;
irtpointWHL6067:
	if (local[8]==NIL) goto irtpointWHX6068;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= argv[0]->c.obj.iv[8];
	local[10]= local[5];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(*ftab[4])(ctx,3,local+9,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,1,local+9,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[9]= local[2];
	local[10]= local[7];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,3,local+9); /*v+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,1,local+9,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	goto irtpointWHL6067;
irtpointWHX6068:
	local[9]= NIL;
irtpointBLK6069:
	w = NIL;
	local[7]= w;
	goto irtpointCON6065;
irtpointCON6066:
	if (local[0]==NIL) goto irtpointIF6071;
	local[7]= local[0];
	local[8]= local[5];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,3,local+7,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[7]= w;
	goto irtpointIF6072;
irtpointIF6071:
	local[7]= NIL;
irtpointIF6072:
	local[7]= argv[0]->c.obj.iv[20];
	local[8]= local[7];
	if (fqv[6]!=local[8]) goto irtpointIF6073;
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[4];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)NUMEQUAL(ctx,3,local+8); /*=*/
	if (w==NIL) goto irtpointIF6075;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(*ftab[26])(ctx,1,local+8,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[8]= w;
	goto irtpointIF6076;
irtpointIF6075:
	local[8]= fqv[124];
	ctx->vsp=local+9;
	w=(*ftab[26])(ctx,1,local+8,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[8]= w;
irtpointIF6076:
	goto irtpointIF6074;
irtpointIF6073:
	local[8]= local[7];
	if (fqv[125]!=local[8]) goto irtpointIF6077;
	local[8]= fqv[126];
	ctx->vsp=local+9;
	w=(*ftab[41])(ctx,1,local+8,&ftab[41],fqv[127]); /*gl:glcolor3f*/
	local[8]= w;
	goto irtpointIF6078;
irtpointIF6077:
	if (T==NIL) goto irtpointIF6079;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(*ftab[26])(ctx,1,local+8,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[8]= w;
	goto irtpointIF6080;
irtpointIF6079:
	local[8]= NIL;
irtpointIF6080:
irtpointIF6078:
irtpointIF6074:
	w = local[8];
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= local[5];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,3,local+7,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(*ftab[27])(ctx,1,local+7,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[7]= local[2];
	local[8]= makeflt(1.0000000000000000000000e+01);
	local[9]= local[3];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[27])(ctx,1,local+7,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[7]= w;
	goto irtpointCON6065;
irtpointCON6070:
	local[7]= NIL;
irtpointCON6065:
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtpointWHL6062;
irtpointWHX6063:
	local[7]= NIL;
irtpointBLK6064:
	w = NIL;
	ctx->vsp=local+5;
	w=(*ftab[28])(ctx,0,local+5,&ftab[28],fqv[98]); /*gl:glend*/
	local[1]= w;
	goto irtpointIF6059;
irtpointIF6058:
	local[1]= NIL;
irtpointIF6059:
	w = local[1];
	local[0]= w;
	goto irtpointIF6035;
irtpointIF6034:
	local[0]= NIL;
irtpointIF6035:
	ctx->vsp=local+0;
	w=(*ftab[42])(ctx,0,local+0,&ftab[42],fqv[128]); /*gl:glpopmatrix*/
	local[0]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+1;
	w=(*ftab[18])(ctx,1,local+0,&ftab[18],fqv[84]); /*gl:glenable*/
	ctx->vsp=local+0;
	w=(*ftab[43])(ctx,0,local+0,&ftab[43],fqv[129]); /*gl:glpopattrib*/
	if (argv[0]->c.obj.iv[21]==NIL) goto irtpointIF6081;
	local[0]= makeint((eusinteger_t)1L);
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[83]); /*gl:gldepthmask*/
	local[0]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+1;
	w=(*ftab[21])(ctx,1,local+0,&ftab[21],fqv[89]); /*gl:gldisable*/
	local[0]= w;
	goto irtpointIF6082;
irtpointIF6081:
	local[0]= NIL;
irtpointIF6082:
	w = local[0];
	local[0]= w;
irtpointBLK6027:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtpointCLO5941(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[3];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= env->c.clo.env2[2];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORM(ctx,1,local+0); /*norm*/
	local[0]= w;
	local[1]= env->c.clo.env1[2];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtpointFLET5969(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto irtpointIF6083;
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	goto irtpointIF6084;
irtpointIF6083:
	local[0]= argv[0];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)FLOOR(ctx,1,local+0); /*floor*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)GREQP(ctx,2,local+1); /*>=*/
	if (w==NIL) goto irtpointIF6085;
	local[1]= argv[1];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	goto irtpointIF6086;
irtpointIF6085:
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,2,local+1); /*<=*/
	if (w==NIL) goto irtpointIF6087;
	local[1]= makeint((eusinteger_t)0L);
	goto irtpointIF6088;
irtpointIF6087:
	local[1]= local[0];
irtpointIF6088:
irtpointIF6086:
	w = local[1];
	local[0]= w;
irtpointIF6084:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-random-pointcloud*/
static pointer irtpointF5590make_random_pointcloud(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[130], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY6090;
	local[0] = makeint((eusinteger_t)1000L);
irtpointKEY6090:
	if (n & (1<<1)) goto irtpointKEY6091;
	local[1] = NIL;
irtpointKEY6091:
	if (n & (1<<2)) goto irtpointKEY6092;
	local[2] = NIL;
irtpointKEY6092:
	if (n & (1<<3)) goto irtpointKEY6093;
	local[3] = makeflt(1.0000000000000000000000e+02);
irtpointKEY6093:
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[0];
irtpointWHL6094:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtpointWHX6095;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[44])(ctx,1,local+10,&ftab[44],fqv[131]); /*random-vector*/
	local[10]= w;
	w = local[4];
	ctx->vsp=local+11;
	local[4] = cons(ctx,local[10],w);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtpointWHL6094;
irtpointWHX6095:
	local[10]= NIL;
irtpointBLK6096:
	w = NIL;
	if (local[1]==NIL) goto irtpointIF6097;
	local[8]= makeflt(5.0000000000000000000000e-01);
	local[9]= makeflt(5.0000000000000000000000e-01);
	local[10]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[0];
irtpointWHL6099:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtpointWHX6100;
	local[11]= local[8];
	local[12]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(*ftab[44])(ctx,1,local+12,&ftab[44],fqv[131]); /*random-vector*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)VPLUS(ctx,2,local+11); /*v+*/
	local[11]= w;
	w = local[5];
	ctx->vsp=local+12;
	local[5] = cons(ctx,local[11],w);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtpointWHL6099;
irtpointWHX6100:
	local[11]= NIL;
irtpointBLK6101:
	w = NIL;
	local[8]= w;
	goto irtpointIF6098;
irtpointIF6097:
	local[8]= NIL;
irtpointIF6098:
	if (local[2]==NIL) goto irtpointIF6102;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[0];
irtpointWHL6104:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtpointWHX6105;
	local[10]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(*ftab[44])(ctx,1,local+10,&ftab[44],fqv[131]); /*random-vector*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[34])(ctx,1,local+10,&ftab[34],fqv[109]); /*normalize-vector*/
	local[10]= w;
	w = local[6];
	ctx->vsp=local+11;
	local[6] = cons(ctx,local[10],w);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtpointWHL6104;
irtpointWHX6105:
	local[10]= NIL;
irtpointBLK6106:
	w = NIL;
	local[8]= w;
	goto irtpointIF6103;
irtpointIF6102:
	local[8]= NIL;
irtpointIF6103:
	local[8]= loadglobal(fqv[32]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[14];
	local[11]= fqv[1];
	local[12]= local[4];
	local[13]= fqv[2];
	local[14]= local[5];
	local[15]= fqv[3];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,8,local+9); /*send*/
	w = local[8];
	local[7] = w;
	w = local[7];
	local[0]= w;
irtpointBLK6089:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtpointcloud(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[132];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtpointIF6107;
	local[0]= fqv[133];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[134],w);
	goto irtpointIF6108;
irtpointIF6107:
	local[0]= fqv[135];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtpointIF6108:
	local[0]= fqv[32];
	local[1]= fqv[136];
	local[2]= fqv[32];
	local[3]= fqv[137];
	local[4]= loadglobal(fqv[138]);
	local[5]= fqv[139];
	local[6]= fqv[140];
	local[7]= fqv[141];
	local[8]= NIL;
	local[9]= fqv[63];
	local[10]= NIL;
	local[11]= fqv[15];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[142];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[45])(ctx,13,local+2,&ftab[45],fqv[143]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5591pointcloud_init,fqv[14],fqv[32],fqv[144]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5627pointcloud_reset_box,fqv[20],fqv[32],fqv[145]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5631pointcloud_box,fqv[21],fqv[32],fqv[146]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5635pointcloud_vertices,fqv[147],fqv[32],fqv[148]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5637pointcloud_size,fqv[15],fqv[32],fqv[149]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5641pointcloud_width,fqv[9],fqv[32],fqv[150]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5643pointcloud_height,fqv[10],fqv[32],fqv[151]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5645pointcloud_size_change,fqv[7],fqv[32],fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5657pointcloud_view_coords,fqv[33],fqv[32],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5663pointcloud_points,fqv[1],fqv[32],fqv[154]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5677pointcloud_colors,fqv[2],fqv[32],fqv[155]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5689pointcloud_normals,fqv[3],fqv[32],fqv[156]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5701pointcloud_curvatures,fqv[4],fqv[32],fqv[157]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5713pointcloud_point_list,fqv[19],fqv[32],fqv[158]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5723pointcloud_color_list,fqv[159],fqv[32],fqv[160]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5730pointcloud_normal_list,fqv[161],fqv[32],fqv[162]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5737pointcloud_curvature_list,fqv[163],fqv[32],fqv[164]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5744pointcloud_centroid,fqv[165],fqv[32],fqv[166]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5746pointcloud_set_color,fqv[167],fqv[32],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5754pointcloud_point_color,fqv[29],fqv[32],fqv[169]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5760pointcloud_point_size,fqv[35],fqv[32],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5766pointcloud_axis_length,fqv[36],fqv[32],fqv[171]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5772pointcloud_axis_width,fqv[37],fqv[32],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5778pointcloud_append,fqv[173],fqv[32],fqv[174]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5812pointcloud_clear_color,fqv[175],fqv[32],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5814pointcloud_clear_normal,fqv[177],fqv[32],fqv[178]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5816pointcloud_nfilter,fqv[179],fqv[32],fqv[180]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5819pointcloud_filter,fqv[42],fqv[32],fqv[181]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5823pointcloud_filter_with_indices,fqv[45],fqv[32],fqv[182]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5871pointcloud_filtered_indices,fqv[44],fqv[32],fqv[183]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5903pointcloud_viewangle_inlier,fqv[184],fqv[32],fqv[185]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5913pointcloud_image_position_inlier,fqv[57],fqv[32],fqv[186]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5933pointcloud_image_circle_filter,fqv[187],fqv[32],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5942pointcloud_step_inlier,fqv[61],fqv[32],fqv[189]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5952pointcloud_step,fqv[190],fqv[32],fqv[191]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5959pointcloud_generate_color_histogram_hs,fqv[192],fqv[32],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5986pointcloud_copy_from,fqv[69],fqv[32],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5988pointcloud_transform_points,fqv[75],fqv[32],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5997pointcloud_set_offset,fqv[196],fqv[32],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM6000pointcloud_convert_to_world,fqv[198],fqv[32],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM6003pointcloud_move_origin_to,fqv[77],fqv[32],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM6009pointcloud_drawnormalmode,fqv[201],fqv[32],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM6017pointcloud_transparent,fqv[30],fqv[32],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM6026pointcloud_draw,fqv[204],fqv[32],fqv[205]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[206],module,irtpointF5590make_random_pointcloud,fqv[207]);
	local[0]= fqv[208];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtpointIF6109;
	local[0]= fqv[209];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[134],w);
	goto irtpointIF6110;
irtpointIF6109:
	local[0]= fqv[210];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtpointIF6110:
	local[0]= fqv[211];
	local[1]= fqv[212];
	ctx->vsp=local+2;
	w=(*ftab[46])(ctx,2,local+0,&ftab[46],fqv[213]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<47; i++) ftab[i]=fcallx;
}

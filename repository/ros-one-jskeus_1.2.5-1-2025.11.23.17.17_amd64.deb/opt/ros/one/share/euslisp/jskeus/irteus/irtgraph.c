/* ./irtgraph.c :  entry=irtgraph */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sun Nov 23 17:09:44 UTC 2025) */
#include "eus.h"
#include "irtgraph.h"
#pragma init (register_irtgraph)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtgraph();
extern pointer build_quote_vector();
static int register_irtgraph()
  { add_module_initializer("___irtgraph", ___irtgraph);}


/*:init*/
static pointer irtgraphM762node_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT765;}
	local[0]= NIL;
irtgraphENT765:
irtgraphENT764:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtgraphBLK763:
	ctx->vsp=local; return(local[0]);}

/*:arc-list*/
static pointer irtgraphM766node_arc_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK767:
	ctx->vsp=local; return(local[0]);}

/*:successors*/
static pointer irtgraphM768node_successors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO770,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtgraphBLK769:
	ctx->vsp=local; return(local[0]);}

/*:add-arc*/
static pointer irtgraphM771node_add_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK772:
	ctx->vsp=local; return(local[0]);}

/*:remove-arc*/
static pointer irtgraphM773node_remove_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[2]); /*remove*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK774:
	ctx->vsp=local; return(local[0]);}

/*:remove-all-arcs*/
static pointer irtgraphM775node_remove_all_arcs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[1] = NIL;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK776:
	ctx->vsp=local; return(local[0]);}

/*:unlink*/
static pointer irtgraphM777node_unlink(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO779,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[3]); /*remove-if*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK778:
	ctx->vsp=local; return(local[0]);}

/*:image*/
static pointer irtgraphM780node_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT783;}
	local[0]= NIL;
irtgraphENT783:
irtgraphENT782:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF784;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto irtgraphIF785;
irtgraphIF784:
	local[1]= NIL;
irtgraphIF785:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK781:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO770(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO779(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[2];
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = ((w)==(local[0])?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM786arc_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = argv[3];
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[5];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	w = argv[0];
	local[0]= w;
irtgraphBLK787:
	ctx->vsp=local; return(local[0]);}

/*:from*/
static pointer irtgraphM788arc_from(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK789:
	ctx->vsp=local; return(local[0]);}

/*:to*/
static pointer irtgraphM790arc_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK791:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer irtgraphM792arc_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT795;}
	local[0]= T;
irtgraphENT795:
irtgraphENT794:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-3);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[6]));
	local[4]= fqv[7];
	local[5]= local[0];
	local[6]= NIL;
	local[7]= fqv[8];
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= local[1];
	if (local[10]!=NIL) goto irtgraphOR796;
	local[10]= fqv[9];
irtgraphOR796:
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,5,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,5,local+2); /*send-message*/
	local[0]= w;
irtgraphBLK793:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM797directed_graph_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
irtgraphBLK798:
	ctx->vsp=local; return(local[0]);}

/*:successors*/
static pointer irtgraphM799directed_graph_successors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[10],w);
irtgraphRST801:
	ctx->vsp=local+3;
	local[3]= minilist(ctx,&argv[n],n-3);
	local[4]= loadglobal(fqv[10]);
	local[5]= fqv[11];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
irtgraphBLK800:
	ctx->vsp=local; return(local[0]);}

/*:node*/
static pointer irtgraphM802directed_graph_node(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtgraphCLO804,env,argv,local);
	local[4]= fqv[13];
	local[5]= (pointer)get_sym_func(fqv[14]);
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,6,local+0,&ftab[2],fqv[15]); /*find*/
	local[0]= w;
irtgraphBLK803:
	ctx->vsp=local; return(local[0]);}

/*:nodes*/
static pointer irtgraphM805directed_graph_nodes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT808;}
	local[0]= NIL;
irtgraphENT808:
irtgraphENT807:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF809;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,2,local+2,&ftab[3],fqv[16]); /*set-difference*/
	local[2]= w;
irtgraphWHL811:
	if (local[2]==NIL) goto irtgraphWHX812;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[0];
	local[4]= fqv[17];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,3,local+3,&ftab[4],fqv[18]); /*send-all*/
	goto irtgraphWHL811;
irtgraphWHX812:
	local[3]= NIL;
irtgraphBLK813:
	w = NIL;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto irtgraphIF810;
irtgraphIF809:
	local[1]= NIL;
irtgraphIF810:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK806:
	ctx->vsp=local; return(local[0]);}

/*:add-node*/
static pointer irtgraphM814directed_graph_add_node(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	w = argv[2];
	local[0]= w;
irtgraphBLK815:
	ctx->vsp=local; return(local[0]);}

/*:remove-node*/
static pointer irtgraphM816directed_graph_remove_node(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[2]); /*remove*/
	argv[0]->c.obj.iv[1] = w;
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[17];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,3,local+0,&ftab[4],fqv[18]); /*send-all*/
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK817:
	ctx->vsp=local; return(local[0]);}

/*:clear-nodes*/
static pointer irtgraphM818directed_graph_clear_nodes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[19];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[18]); /*send-all*/
	argv[0]->c.obj.iv[1] = NIL;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK819:
	ctx->vsp=local; return(local[0]);}

/*:add-arc-from-to*/
static pointer irtgraphM820directed_graph_add_arc_from_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= loadglobal(fqv[20]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[21];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
irtgraphBLK821:
	ctx->vsp=local; return(local[0]);}

/*:remove-arc*/
static pointer irtgraphM822directed_graph_remove_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	local[3]= loadglobal(fqv[20]);
	local[4]= fqv[22];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[23];
	local[5]= loadglobal(fqv[20]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtgraphBLK823:
	ctx->vsp=local; return(local[0]);}

/*:adjacency-matrix*/
static pointer irtgraphM824directed_graph_adjacency_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= local[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,2,local+3,&ftab[5],fqv[24]); /*make-matrix*/
	local[1] = w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
irtgraphWHL826:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtgraphWHX827;
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[4];
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[18]); /*send-all*/
	local[6]= w;
irtgraphWHL829:
	if (local[6]==NIL) goto irtgraphWHX830;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,2,local+7,&ftab[6],fqv[26]); /*position*/
	local[2] = w;
	if (local[2]==NIL) goto irtgraphIF832;
	local[7]= local[1];
	local[8]= local[3];
	local[9]= local[2];
	local[10]= local[1];
	local[11]= local[3];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,4,local+7); /*aset*/
	local[7]= w;
	goto irtgraphIF833;
irtgraphIF832:
	local[7]= NIL;
irtgraphIF833:
	goto irtgraphWHL829;
irtgraphWHX830:
	local[7]= NIL;
irtgraphBLK831:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtgraphWHL826;
irtgraphWHX827:
	local[5]= NIL;
irtgraphBLK828:
	w = NIL;
	w = local[1];
	local[0]= w;
irtgraphBLK825:
	ctx->vsp=local; return(local[0]);}

/*:adjacency-list*/
static pointer irtgraphM834directed_graph_adjacency_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO836,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtgraphBLK835:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO804(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO836(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO837,env,argv,local);
	local[1]= argv[0];
	local[2]= fqv[25];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,2,local+1,&ftab[4],fqv[18]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[27]);
	ctx->vsp=local+2;
	w=(pointer)SORT(ctx,2,local+0); /*sort*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO837(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env0->c.clo.env1[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[26]); /*position*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM838costed_arc_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	argv[0]->c.obj.iv[3] = argv[4];
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[6]));
	local[2]= fqv[21];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= w;
irtgraphBLK839:
	ctx->vsp=local; return(local[0]);}

/*:cost*/
static pointer irtgraphM840costed_arc_cost(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtgraphBLK841:
	ctx->vsp=local; return(local[0]);}

/*:add-arc*/
static pointer irtgraphM842costed_graph_add_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[28], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY844;
	local[0] = NIL;
irtgraphKEY844:
	local[1]= argv[0];
	local[2]= fqv[29];
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= fqv[30];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[0]= w;
irtgraphBLK843:
	ctx->vsp=local; return(local[0]);}

/*:add-arc-from-to*/
static pointer irtgraphM845costed_graph_add_arc_from_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[31], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY847;
	local[0] = NIL;
irtgraphKEY847:
	local[1]= loadglobal(fqv[32]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[21];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	w = local[1];
	local[1]= w;
	if (local[0]==NIL) goto irtgraphIF848;
	local[2]= local[1];
	local[3]= loadglobal(fqv[32]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[21];
	local[6]= argv[3];
	local[7]= argv[2];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	w = local[3];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	goto irtgraphIF849;
irtgraphIF848:
	local[2]= local[1];
irtgraphIF849:
	w = local[2];
	local[0]= w;
irtgraphBLK846:
	ctx->vsp=local; return(local[0]);}

/*:path-cost*/
static pointer irtgraphM850costed_graph_path_cost(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	local[3]= loadglobal(fqv[20]);
	local[4]= fqv[33];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtgraphBLK851:
	ctx->vsp=local; return(local[0]);}

/*:goal-test*/
static pointer irtgraphM852graph_goal_test(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	w = ((argv[2])==(local[0])?T:NIL);
	local[0]= w;
irtgraphBLK853:
	ctx->vsp=local; return(local[0]);}

/*:path-cost*/
static pointer irtgraphM854graph_path_cost(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	local[3]= argv[2];
	local[4]= loadglobal(fqv[32]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto irtgraphIF856;
	local[3]= argv[4];
	local[4]= loadglobal(fqv[32]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto irtgraphIF856;
	local[3]= argv[2];
	local[4]= fqv[33];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= loadglobal(fqv[20]);
	local[5]= fqv[33];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	goto irtgraphIF857;
irtgraphIF856:
	local[3]= makeint((eusinteger_t)1L);
irtgraphIF857:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtgraphBLK855:
	ctx->vsp=local; return(local[0]);}

/*:start-state*/
static pointer irtgraphM858graph_start_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT861;}
	local[0]= NIL;
irtgraphENT861:
irtgraphENT860:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF862;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto irtgraphIF863;
irtgraphIF862:
	local[1]= NIL;
irtgraphIF863:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK859:
	ctx->vsp=local; return(local[0]);}

/*:goal-state*/
static pointer irtgraphM864graph_goal_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT867;}
	local[0]= NIL;
irtgraphENT867:
irtgraphENT866:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF868;
	argv[0]->c.obj.iv[3] = local[0];
	local[1]= argv[0]->c.obj.iv[3];
	goto irtgraphIF869;
irtgraphIF868:
	local[1]= NIL;
irtgraphIF869:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtgraphBLK865:
	ctx->vsp=local; return(local[0]);}

/*:add-arc*/
static pointer irtgraphM870graph_add_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[34], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY872;
	local[0] = NIL;
irtgraphKEY872:
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w!=NIL) goto irtgraphIF873;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	argv[3] = w;
	local[1]= argv[3];
	goto irtgraphIF874;
irtgraphIF873:
	local[1]= NIL;
irtgraphIF874:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtgraphCLO875,env,argv,local);
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
irtgraphBLK871:
	ctx->vsp=local; return(local[0]);}

/*:add-arc-from-to*/
static pointer irtgraphM876graph_add_arc_from_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[35], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY878;
	local[0] = NIL;
irtgraphKEY878:
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[6]));
	local[3]= fqv[29];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeint((eusinteger_t)1L);
	local[7]= fqv[30];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SENDMESSAGE(ctx,8,local+1); /*send-message*/
	local[0]= w;
irtgraphBLK877:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO875(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[29];
	local[2]= env->c.clo.env1[2];
	local[3]= argv[0];
	local[4]= fqv[30];
	local[5]= env->c.clo.env2[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:write-to-dot-stream*/
static pointer irtgraphM879directed_graph_write_to_dot_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT884;}
	local[0]= loadglobal(fqv[36]);
irtgraphENT884:
	if (n>=4) { local[1]=(argv[3]); goto irtgraphENT883;}
	local[1]= NIL;
irtgraphENT883:
	if (n>=5) { local[2]=(argv[4]); goto irtgraphENT882;}
	local[2]= fqv[37];
irtgraphENT882:
irtgraphENT881:
	if (n>5) maerror();
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtgraphCLO885,env,argv,local);
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[38];
	local[6]= fqv[39];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[38];
	local[7]= fqv[40];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[38];
	local[8]= fqv[41];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= ((w)==NIL?T:NIL);
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtgraphFLET886,env,argv,local);
	local[8]= local[0];
	local[9]= fqv[42];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= NIL;
	local[9]= argv[0]->c.obj.iv[1];
irtgraphWHL887:
	if (local[9]==NIL) goto irtgraphWHX888;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[0];
	local[11]= fqv[43];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,2,local+10); /*format*/
	local[10]= local[0];
	local[11]= fqv[44];
	local[12]= local[8];
	w = local[7];
	ctx->vsp=local+13;
	w=irtgraphFLET886(ctx,1,local+12,w);
	local[12]= w;
	local[13]= local[8];
	local[14]= fqv[0];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[8];
	local[15]= fqv[1];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	if (w==NIL) goto irtgraphIF890;
	local[14]= NIL;
	local[15]= fqv[45];
	local[16]= local[8];
	local[17]= fqv[1];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,3,local+14); /*format*/
	local[14]= w;
	goto irtgraphIF891;
irtgraphIF890:
	local[14]= fqv[46];
irtgraphIF891:
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,5,local+10); /*format*/
	goto irtgraphWHL887;
irtgraphWHX888:
	local[10]= NIL;
irtgraphBLK889:
	w = NIL;
	local[8]= fqv[13];
	local[9]= (pointer)get_sym_func(fqv[14]);
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,2,local+8,&ftab[7],fqv[47]); /*make-hash-table*/
	local[8]= w;
	local[9]= fqv[13];
	local[10]= (pointer)get_sym_func(fqv[14]);
	ctx->vsp=local+11;
	w=(*ftab[7])(ctx,2,local+9,&ftab[7],fqv[47]); /*make-hash-table*/
	local[9]= w;
	local[10]= NIL;
irtgraphWHL892:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[11];
	local[10] = w;
	if (local[10]==NIL) goto irtgraphWHX893;
	if (local[1]==NIL) goto irtgraphWHX893;
	local[11]= local[10];
	local[12]= fqv[48];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[48];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[8];
	local[13]= fqv[49];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[50]); /*sethash*/
	goto irtgraphWHL892;
irtgraphWHX893:
	local[11]= NIL;
irtgraphBLK894:
	w = local[11];
	local[10]= NIL;
	local[11]= argv[0]->c.obj.iv[1];
irtgraphWHL895:
	if (local[11]==NIL) goto irtgraphWHX896;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= argv[0];
	local[13]= fqv[11];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= NIL;
	local[14]= local[12];
irtgraphWHL898:
	if (local[14]==NIL) goto irtgraphWHX899;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14] = (w)->c.cons.cdr;
	w = local[15];
	local[13] = w;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.cdr;
	local[17]= T;
	local[18]= NIL;
	local[19]= NIL;
	if (local[6]!=NIL) goto irtgraphIF901;
	local[20]= local[10];
	w = local[16];
	ctx->vsp=local+21;
	local[20]= cons(ctx,local[20],w);
	local[21]= local[8];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,2,local+20,&ftab[9],fqv[51]); /*gethash*/
	if (w==NIL) goto irtgraphIF901;
	local[18] = T;
	local[20]= fqv[52];
	w = local[19];
	ctx->vsp=local+21;
	local[19] = cons(ctx,local[20],w);
	local[20]= local[19];
	goto irtgraphIF902;
irtgraphIF901:
	local[20]= NIL;
irtgraphIF902:
	if (local[5]==NIL) goto irtgraphIF903;
	local[20]= NIL;
	local[21]= fqv[53];
	local[22]= local[15];
	local[23]= fqv[0];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)XFORMAT(ctx,3,local+20); /*format*/
	local[20]= w;
	w = local[19];
	ctx->vsp=local+21;
	local[19] = cons(ctx,local[20],w);
	local[20]= local[19];
	goto irtgraphIF904;
irtgraphIF903:
	local[20]= NIL;
irtgraphIF904:
	if (local[4]!=NIL) goto irtgraphIF905;
	local[20]= local[10];
	w = local[16];
	ctx->vsp=local+21;
	local[20]= cons(ctx,local[20],w);
	local[21]= local[9];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,2,local+20,&ftab[9],fqv[51]); /*gethash*/
	if (w==NIL) goto irtgraphCON908;
	local[17] = NIL;
	local[20]= local[17];
	goto irtgraphCON907;
irtgraphCON908:
	local[20]= local[16];
	w = local[10];
	ctx->vsp=local+21;
	local[20]= cons(ctx,local[20],w);
	local[21]= local[9];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,2,local+20,&ftab[9],fqv[51]); /*gethash*/
	if (w==NIL) goto irtgraphCON909;
	local[17] = NIL;
	local[20]= local[17];
	goto irtgraphCON907;
irtgraphCON909:
	local[20]= local[10];
	local[21]= (pointer)get_sym_func(fqv[54]);
	local[22]= argv[0];
	local[23]= fqv[11];
	local[24]= local[16];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MAPCAR(ctx,2,local+21); /*mapcar*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[10])(ctx,2,local+20,&ftab[10],fqv[55]); /*member*/
	if (w==NIL) goto irtgraphCON910;
	local[20]= fqv[56];
	w = local[19];
	ctx->vsp=local+21;
	local[19] = cons(ctx,local[20],w);
	local[20]= local[19];
	goto irtgraphCON907;
irtgraphCON910:
	local[20]= NIL;
irtgraphCON907:
	goto irtgraphIF906;
irtgraphIF905:
	local[20]= NIL;
irtgraphIF906:
	if (local[19]!=NIL) goto irtgraphIF911;
	local[19] = fqv[57];
	local[20]= local[19];
	goto irtgraphIF912;
irtgraphIF911:
	local[20]= NIL;
irtgraphIF912:
	if (local[17]==NIL) goto irtgraphIF913;
	local[20]= local[10];
	w = local[16];
	ctx->vsp=local+21;
	local[20]= cons(ctx,local[20],w);
	local[21]= local[9];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(*ftab[8])(ctx,3,local+20,&ftab[8],fqv[50]); /*sethash*/
	local[20]= w;
	goto irtgraphIF914;
irtgraphIF913:
	local[20]= NIL;
irtgraphIF914:
	w = local[20];
	goto irtgraphWHL898;
irtgraphWHX899:
	local[15]= NIL;
irtgraphBLK900:
	w = NIL;
	goto irtgraphWHL895;
irtgraphWHX896:
	local[12]= NIL;
irtgraphBLK897:
	w = NIL;
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtgraphFLET915,env,argv,local);
	if (local[6]==NIL) goto irtgraphIF916;
	local[11]= local[8];
	w = local[10];
	ctx->vsp=local+12;
	w=irtgraphFLET915(ctx,1,local+11,w);
	local[11]= w;
	goto irtgraphIF917;
irtgraphIF916:
	local[11]= NIL;
irtgraphIF917:
	local[11]= local[9];
	w = local[10];
	ctx->vsp=local+12;
	w=irtgraphFLET915(ctx,1,local+11,w);
	local[10]= local[0];
	local[11]= fqv[58];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,2,local+10); /*format*/
	w = T;
	local[0]= w;
irtgraphBLK880:
	ctx->vsp=local; return(local[0]);}

/*:write-to-dot*/
static pointer irtgraphM918directed_graph_write_to_dot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT922;}
	local[0]= NIL;
irtgraphENT922:
	if (n>=5) { local[1]=(argv[4]); goto irtgraphENT921;}
	local[1]= fqv[59];
irtgraphENT921:
irtgraphENT920:
	if (n>5) maerror();
	local[2]= argv[2];
	local[3]= fqv[60];
	local[4]= fqv[61];
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,3,local+2,&ftab[11],fqv[62]); /*open*/
	local[2]= w;
	ctx->vsp=local+3;
	w = makeclosure(codevec,quotevec,irtgraphUWP923,env,argv,local);
	local[3]=(pointer)(ctx->protfp); local[4]=w;
	ctx->protfp=(struct protectframe *)(local+3);
	local[5]= argv[0];
	local[6]= fqv[63];
	local[7]= local[2];
	local[8]= local[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	ctx->vsp=local+5;
	irtgraphUWP923(ctx,0,local+5,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	w = T;
	local[0]= w;
irtgraphBLK919:
	ctx->vsp=local; return(local[0]);}

/*:write-to-file*/
static pointer irtgraphM924directed_graph_write_to_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT929;}
	local[0]= NIL;
irtgraphENT929:
	if (n>=5) { local[1]=(argv[4]); goto irtgraphENT928;}
	local[1]= NIL;
irtgraphENT928:
	if (n>=6) { local[2]=(argv[5]); goto irtgraphENT927;}
	local[2]= fqv[64];
irtgraphENT927:
irtgraphENT926:
	if (n>6) maerror();
	local[3]= NIL;
	local[4]= fqv[65];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[66];
	local[6]= local[3];
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= NIL;
	local[5]= fqv[67];
	local[6]= local[3];
	local[7]= local[2];
	local[8]= NIL;
	local[9]= fqv[68];
	local[10]= argv[2];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,4,local+8); /*format*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,5,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SYSTEM(ctx,1,local+4); /*unix:system*/
	w = T;
	local[0]= w;
irtgraphBLK925:
	ctx->vsp=local; return(local[0]);}

/*:write-to-pdf*/
static pointer irtgraphM930directed_graph_write_to_pdf(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT934;}
	local[0]= NIL;
irtgraphENT934:
	if (n>=5) { local[1]=(argv[4]); goto irtgraphENT933;}
	local[1]= fqv[69];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,2,local+1,&ftab[12],fqv[70]); /*string-right-trim*/
	local[1]= w;
irtgraphENT933:
irtgraphENT932:
	if (n>5) maerror();
	local[2]= fqv[71];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,2,local+2,&ftab[13],fqv[72]); /*substringp*/
	if (w==NIL) goto irtgraphIF935;
	local[2]= fqv[73];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,2,local+2,&ftab[12],fqv[70]); /*string-right-trim*/
	local[2]= w;
	local[3]= local[2];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SUB1(ctx,1,local+4); /*1-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)46L);
	ctx->vsp=local+5;
	w=(pointer)NUMEQUAL(ctx,2,local+3); /*=*/
	if (w==NIL) goto irtgraphIF937;
	local[3]= local[2];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	argv[2] = w;
	local[3]= argv[2];
	goto irtgraphIF938;
irtgraphIF937:
	local[3]= NIL;
irtgraphIF938:
	w = local[3];
	local[2]= w;
	goto irtgraphIF936;
irtgraphIF935:
	local[2]= NIL;
irtgraphIF936:
	local[2]= argv[0];
	local[3]= fqv[74];
	local[4]= argv[2];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[0]= w;
irtgraphBLK931:
	ctx->vsp=local; return(local[0]);}

/*:original-draw-mode*/
static pointer irtgraphM939directed_graph_original_draw_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[39];
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[40];
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[41];
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgraphBLK940:
	ctx->vsp=local; return(local[0]);}

/*:current-draw-mode*/
static pointer irtgraphM941directed_graph_current_draw_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[39];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[40];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[41];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgraphBLK942:
	ctx->vsp=local; return(local[0]);}

/*:draw-both-arc*/
static pointer irtgraphM943directed_graph_draw_both_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT946;}
	local[0]= fqv[30];
irtgraphENT946:
irtgraphENT945:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[30]==local[1]) goto irtgraphIF947;
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= fqv[39];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF948;
irtgraphIF947:
	local[1]= NIL;
irtgraphIF948:
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[39];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtgraphBLK944:
	ctx->vsp=local; return(local[0]);}

/*:draw-arc-label*/
static pointer irtgraphM949directed_graph_draw_arc_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT952;}
	local[0]= fqv[76];
irtgraphENT952:
irtgraphENT951:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[76]==local[1]) goto irtgraphIF953;
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= fqv[40];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF954;
irtgraphIF953:
	local[1]= NIL;
irtgraphIF954:
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[40];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtgraphBLK950:
	ctx->vsp=local; return(local[0]);}

/*:draw-merged-result*/
static pointer irtgraphM955directed_graph_draw_merged_result(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT958;}
	local[0]= fqv[77];
irtgraphENT958:
irtgraphENT957:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[77]==local[1]) goto irtgraphIF959;
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= fqv[41];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF960;
irtgraphIF959:
	local[1]= NIL;
irtgraphIF960:
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[41];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtgraphBLK956:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO885(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,1,local+1,&ftab[14],fqv[78]); /*string*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphFLET886(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[3];
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,2,local+0,&ftab[15],fqv[79]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphFLET915(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO961,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[80]); /*maphash*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO961(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[82];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w = env->c.clo.env0->c.clo.env2[7];
	ctx->vsp=local+3;
	w=irtgraphFLET886(ctx,1,local+2,w);
	local[2]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	w = env->c.clo.env0->c.clo.env2[7];
	ctx->vsp=local+4;
	w=irtgraphFLET886(ctx,1,local+3,w);
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[1];
	if (fqv[57]!=local[0]) goto irtgraphIF962;
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[83];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
	goto irtgraphIF963;
irtgraphIF962:
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[84];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= NIL;
	local[1]= argv[1];
irtgraphWHL964:
	if (local[1]==NIL) goto irtgraphWHX965;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==local[2]) goto irtgraphIF967;
	local[2]= env->c.clo.env0->c.clo.env2[0];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[2]= w;
	goto irtgraphIF968;
irtgraphIF967:
	local[2]= NIL;
irtgraphIF968:
	local[2]= env->c.clo.env0->c.clo.env2[0];
	local[3]= fqv[86];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	goto irtgraphWHL964;
irtgraphWHX965:
	local[2]= NIL;
irtgraphBLK966:
	w = NIL;
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[87];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
irtgraphIF963:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphUWP923(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[2];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:add-neighbor*/
static pointer irtgraphM969node_add_neighbor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT972;}
	local[0]= NIL;
irtgraphENT972:
irtgraphENT971:
	if (n>4) maerror();
	local[1]= loadglobal(fqv[20]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[21];
	local[4]= argv[0];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[1]= w;
	if (local[0]==NIL) goto irtgraphIF973;
	local[2]= local[1];
	local[3]= fqv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtgraphIF974;
irtgraphIF973:
	local[2]= NIL;
irtgraphIF974:
	local[2]= argv[0];
	local[3]= fqv[88];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[0]= w;
irtgraphBLK970:
	ctx->vsp=local; return(local[0]);}

/*:neighbors*/
static pointer irtgraphM975node_neighbors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT978;}
	local[0]= NIL;
irtgraphENT978:
irtgraphENT977:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF979;
	local[1]= NIL;
	local[2]= local[0];
irtgraphWHL981:
	if (local[2]==NIL) goto irtgraphWHX982;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= loadglobal(fqv[20]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[21];
	local[6]= argv[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	goto irtgraphWHL981;
irtgraphWHX982:
	local[3]= NIL;
irtgraphBLK983:
	w = NIL;
	local[1]= w;
	goto irtgraphIF980;
irtgraphIF979:
	local[1]= NIL;
irtgraphIF980:
	local[1]= (pointer)get_sym_func(fqv[54]);
	local[2]= argv[0];
	local[3]= fqv[11];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
irtgraphBLK976:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM984arced_node_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[89], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY986;
	local[0] = NIL;
irtgraphKEY986:
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[6]));
	local[3]= fqv[21];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,4,local+1); /*send-message*/
	w = argv[0];
	local[0]= w;
irtgraphBLK985:
	ctx->vsp=local; return(local[0]);}

/*:find-action*/
static pointer irtgraphM987arced_node_find_action(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtgraphCLO989,env,argv,local);
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,4,local+0,&ftab[2],fqv[15]); /*find*/
	local[0]= w;
	if (local[0]==NIL) goto irtgraphIF990;
	local[1]= local[0];
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF991;
irtgraphIF990:
	local[1]= NIL;
irtgraphIF991:
	w = local[1];
	local[0]= w;
irtgraphBLK988:
	ctx->vsp=local; return(local[0]);}

/*:neighbor-action-alist*/
static pointer irtgraphM992arced_node_neighbor_action_alist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO994,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtgraphBLK993:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO989(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO994(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM995solver_node_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[90], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY997;
	local[0] = makeint((eusinteger_t)0L);
irtgraphKEY997:
	if (n & (1<<1)) goto irtgraphKEY998;
	local[1] = NIL;
irtgraphKEY998:
	if (n & (1<<2)) goto irtgraphKEY999;
	local[2] = NIL;
irtgraphKEY999:
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = local[0];
	argv[0]->c.obj.iv[3] = local[1];
	argv[0]->c.obj.iv[4] = local[2];
	w = argv[0];
	local[0]= w;
irtgraphBLK996:
	ctx->vsp=local; return(local[0]);}

/*:path*/
static pointer irtgraphM1000solver_node_path(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1003;}
	local[0]= NIL;
irtgraphENT1003:
irtgraphENT1002:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1004;
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtgraphIF1006;
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[92];
	local[3]= argv[0];
	w = local[0];
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF1007;
irtgraphIF1006:
	local[1]= argv[0];
	w = local[0];
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
irtgraphIF1007:
	goto irtgraphIF1005;
irtgraphIF1004:
	if (argv[0]->c.obj.iv[5]==NIL) goto irtgraphIF1008;
	local[1]= argv[0]->c.obj.iv[5];
	goto irtgraphIF1009;
irtgraphIF1008:
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtgraphIF1010;
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[92];
	local[3]= argv[0];
	w = local[0];
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF1011;
irtgraphIF1010:
	local[1]= argv[0];
	w = local[0];
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
irtgraphIF1011:
	argv[0]->c.obj.iv[5] = local[1];
	local[1]= argv[0]->c.obj.iv[5];
irtgraphIF1009:
irtgraphIF1005:
	w = local[1];
	local[0]= w;
irtgraphBLK1001:
	ctx->vsp=local; return(local[0]);}

/*:expand*/
static pointer irtgraphM1012solver_node_expand(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtgraphRST1014:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= (pointer)get_sym_func(fqv[93]);
	local[2]= argv[2];
	local[3]= fqv[11];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[1];
irtgraphWHL1015:
	if (local[4]==NIL) goto irtgraphWHX1016;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= loadglobal(fqv[94]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[21];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[91];
	local[10]= argv[0];
	local[11]= fqv[95];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[33];
	local[14]= argv[2];
	local[15]= fqv[96];
	local[16]= argv[0];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.cdr;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,5,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,9,local+6); /*send*/
	w = local[5];
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	goto irtgraphWHL1015;
irtgraphWHX1016:
	local[5]= NIL;
irtgraphBLK1017:
	w = NIL;
	w = local[2];
	local[0]= w;
irtgraphBLK1013:
	ctx->vsp=local; return(local[0]);}

/*:state*/
static pointer irtgraphM1018solver_node_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1021;}
	local[0]= NIL;
irtgraphENT1021:
irtgraphENT1020:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1022;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto irtgraphIF1023;
irtgraphIF1022:
	local[1]= NIL;
irtgraphIF1023:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1019:
	ctx->vsp=local; return(local[0]);}

/*:cost*/
static pointer irtgraphM1024solver_node_cost(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1027;}
	local[0]= NIL;
irtgraphENT1027:
irtgraphENT1026:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1028;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto irtgraphIF1029;
irtgraphIF1028:
	local[1]= NIL;
irtgraphIF1029:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK1025:
	ctx->vsp=local; return(local[0]);}

/*:parent*/
static pointer irtgraphM1030solver_node_parent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1033;}
	local[0]= NIL;
irtgraphENT1033:
irtgraphENT1032:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1034;
	argv[0]->c.obj.iv[3] = local[0];
	local[1]= argv[0]->c.obj.iv[3];
	goto irtgraphIF1035;
irtgraphIF1034:
	local[1]= NIL;
irtgraphIF1035:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtgraphBLK1031:
	ctx->vsp=local; return(local[0]);}

/*:action*/
static pointer irtgraphM1036solver_node_action(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1039;}
	local[0]= NIL;
irtgraphENT1039:
irtgraphENT1038:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1040;
	argv[0]->c.obj.iv[4] = local[0];
	local[1]= argv[0]->c.obj.iv[4];
	goto irtgraphIF1041;
irtgraphIF1040:
	local[1]= NIL;
irtgraphIF1041:
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
irtgraphBLK1037:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1042solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
irtgraphBLK1043:
	ctx->vsp=local; return(local[0]);}

/*:solve*/
static pointer irtgraphM1044solver_solve(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
irtgraphBLK1045:
	ctx->vsp=local; return(local[0]);}

/*:solve-by-name*/
static pointer irtgraphM1046solver_solve_by_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[97], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1048;
	local[0] = NIL;
irtgraphKEY1048:
	local[1]= argv[2];
	local[2]= fqv[98];
	local[3]= argv[2];
	local[4]= fqv[99];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[2];
	local[2]= fqv[100];
	local[3]= argv[2];
	local[4]= fqv[99];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[101];
	local[3]= argv[2];
	local[4]= fqv[102];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
irtgraphBLK1047:
	ctx->vsp=local; return(local[0]);}

/*:solve-init*/
static pointer irtgraphM1049graph_search_solver_solve_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[2] = NIL;
	local[0]= argv[0];
	local[1]= fqv[103];
	local[2]= loadglobal(fqv[94]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[21];
	local[5]= argv[2];
	local[6]= fqv[98];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[33];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	w = local[2];
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgraphBLK1050:
	ctx->vsp=local; return(local[0]);}

/*:find-node-in-close-list*/
static pointer irtgraphM1051graph_search_solver_find_node_in_close_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[48];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[15]); /*find*/
	local[0]= w;
irtgraphBLK1052:
	ctx->vsp=local; return(local[0]);}

/*:solve*/
static pointer irtgraphM1053graph_search_solver_solve(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[104], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1055;
	local[0] = NIL;
irtgraphKEY1055:
	local[1]= argv[0];
	local[2]= fqv[105];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
irtgraphWHL1056:
	local[1]= argv[0];
	local[2]= fqv[106];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w!=NIL) goto irtgraphWHX1057;
	local[1]= argv[0];
	local[2]= fqv[107];
	local[3]= fqv[108];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[109];
	local[4]= local[1];
	local[5]= fqv[48];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w==NIL) goto irtgraphCON1060;
	local[2]= local[1];
	local[3]= fqv[92];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	ctx->vsp=local+2;
	local[0]=w;
	goto irtgraphBLK1054;
	goto irtgraphCON1059;
irtgraphCON1060:
	local[2]= argv[0];
	local[3]= fqv[110];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w!=NIL) goto irtgraphCON1061;
	local[2]= local[1];
	local[3]= fqv[48];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	w = argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	argv[0]->c.obj.iv[2] = cons(ctx,local[2],w);
	local[2]= argv[0];
	local[3]= fqv[111];
	local[4]= local[1];
	local[5]= fqv[112];
	local[6]= argv[2];
	local[7]= fqv[102];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtgraphCON1059;
irtgraphCON1061:
	local[2]= NIL;
irtgraphCON1059:
	w = local[2];
	goto irtgraphWHL1056;
irtgraphWHX1057:
	local[1]= NIL;
irtgraphBLK1058:
	local[1]= fqv[113];
	local[2]= fqv[101];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[114]); /*warn*/
	local[1]= fqv[115];
	local[2]= fqv[101];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[114]); /*warn*/
	local[1]= argv[0];
	local[2]= fqv[116];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[0]->c.obj.iv[2] = NIL;
	w = NIL;
	local[0]= w;
irtgraphBLK1054:
	ctx->vsp=local; return(local[0]);}

/*:add-to-open-list*/
static pointer irtgraphM1062graph_search_solver_add_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto irtgraphIF1064;
	local[0]= argv[0];
	local[1]= fqv[111];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtgraphIF1065;
irtgraphIF1064:
	local[0]= argv[0];
	local[1]= fqv[117];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgraphIF1065:
	w = local[0];
	local[0]= w;
irtgraphBLK1063:
	ctx->vsp=local; return(local[0]);}

/*:null-open-list?*/
static pointer irtgraphM1066graph_search_solver_null_open_list_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = ((argv[0]->c.obj.iv[1])==NIL?T:NIL);
	local[0]= w;
irtgraphBLK1067:
	ctx->vsp=local; return(local[0]);}

/*:clear-open-list*/
static pointer irtgraphM1068graph_search_solver_clear_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[118];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[114]); /*warn*/
	w = NIL;
	local[0]= w;
irtgraphBLK1069:
	ctx->vsp=local; return(local[0]);}

/*:add-list-to-open-list*/
static pointer irtgraphM1070graph_search_solver_add_list_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[119];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[114]); /*warn*/
	w = NIL;
	local[0]= w;
irtgraphBLK1071:
	ctx->vsp=local; return(local[0]);}

/*:add-object-to-open-list*/
static pointer irtgraphM1072graph_search_solver_add_object_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[120];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[114]); /*warn*/
	w = NIL;
	local[0]= w;
irtgraphBLK1073:
	ctx->vsp=local; return(local[0]);}

/*:pop-from-open-list*/
static pointer irtgraphM1074graph_search_solver_pop_from_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[121], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1076;
	local[0] = NIL;
irtgraphKEY1076:
	local[1]= fqv[122];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,1,local+1,&ftab[17],fqv[114]); /*warn*/
	w = NIL;
	local[0]= w;
irtgraphBLK1075:
	ctx->vsp=local; return(local[0]);}

/*:open-list*/
static pointer irtgraphM1077graph_search_solver_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1080;}
	local[0]= NIL;
irtgraphENT1080:
irtgraphENT1079:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1081;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto irtgraphIF1082;
irtgraphIF1081:
	local[1]= NIL;
irtgraphIF1082:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1078:
	ctx->vsp=local; return(local[0]);}

/*:close-list*/
static pointer irtgraphM1083graph_search_solver_close_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1086;}
	local[0]= NIL;
irtgraphENT1086:
irtgraphENT1085:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1087;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto irtgraphIF1088;
irtgraphIF1087:
	local[1]= NIL;
irtgraphIF1088:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK1084:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1089breadth_first_graph_search_solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(pointer)LIST(ctx,0,local+0); /*list*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0];
	local[0]= w;
irtgraphBLK1090:
	ctx->vsp=local; return(local[0]);}

/*:clear-open-list*/
static pointer irtgraphM1091breadth_first_graph_search_solver_clear_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[1] = NIL;
	w = NIL;
	local[0]= w;
irtgraphBLK1092:
	ctx->vsp=local; return(local[0]);}

/*:add-list-to-open-list*/
static pointer irtgraphM1093breadth_first_graph_search_solver_add_list_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1094:
	ctx->vsp=local; return(local[0]);}

/*:add-object-to-open-list*/
static pointer irtgraphM1095breadth_first_graph_search_solver_add_object_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1096:
	ctx->vsp=local; return(local[0]);}

/*:pop-from-open-list*/
static pointer irtgraphM1097breadth_first_graph_search_solver_pop_from_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[123], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1099;
	local[0] = NIL;
irtgraphKEY1099:
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[1] = (w)->c.cons.cdr;
	w = local[1];
	local[0]= w;
irtgraphBLK1098:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1100depth_first_graph_search_solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(pointer)LIST(ctx,0,local+0); /*list*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0];
	local[0]= w;
irtgraphBLK1101:
	ctx->vsp=local; return(local[0]);}

/*:clear-open-list*/
static pointer irtgraphM1102depth_first_graph_search_solver_clear_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[1] = NIL;
	w = NIL;
	local[0]= w;
irtgraphBLK1103:
	ctx->vsp=local; return(local[0]);}

/*:add-list-to-open-list*/
static pointer irtgraphM1104depth_first_graph_search_solver_add_list_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1105:
	ctx->vsp=local; return(local[0]);}

/*:add-object-to-open-list*/
static pointer irtgraphM1106depth_first_graph_search_solver_add_object_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1107:
	ctx->vsp=local; return(local[0]);}

/*:pop-from-open-list*/
static pointer irtgraphM1108depth_first_graph_search_solver_pop_from_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[124], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1110;
	local[0] = NIL;
irtgraphKEY1110:
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[1] = (w)->c.cons.cdr;
	w = local[1];
	local[0]= w;
irtgraphBLK1109:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1111best_first_graph_search_solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[3] = argv[2];
	ctx->vsp=local+0;
	w=(pointer)LIST(ctx,0,local+0); /*list*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0];
	local[0]= w;
irtgraphBLK1112:
	ctx->vsp=local; return(local[0]);}

/*:clear-open-list*/
static pointer irtgraphM1113best_first_graph_search_solver_clear_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[1] = NIL;
	w = NIL;
	local[0]= w;
irtgraphBLK1114:
	ctx->vsp=local; return(local[0]);}

/*:add-list-to-open-list*/
static pointer irtgraphM1115best_first_graph_search_solver_add_list_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1116:
	ctx->vsp=local; return(local[0]);}

/*:add-object-to-open-list*/
static pointer irtgraphM1117best_first_graph_search_solver_add_object_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1118:
	ctx->vsp=local; return(local[0]);}

/*:pop-from-open-list*/
static pointer irtgraphM1119best_first_graph_search_solver_pop_from_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[125], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1121;
	local[0] = NIL;
irtgraphKEY1121:
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= local[1];
	local[3]= fqv[38];
	local[4]= fqv[126];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	if (w!=NIL) goto irtgraphOR1122;
	local[2]= local[1];
	local[3]= fqv[75];
	local[4]= fqv[126];
	local[5]= argv[0];
	local[6]= fqv[127];
	local[7]= local[1];
	local[8]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= local[1];
	local[3]= fqv[38];
	local[4]= fqv[126];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
irtgraphOR1122:
	if (local[0]==NIL) goto irtgraphIF1123;
	local[3]= fqv[128];
	local[4]= local[1];
	local[5]= fqv[92];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[48];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[18]); /*send-all*/
	local[4]= w;
	local[5]= fqv[0];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[18]); /*send-all*/
	local[4]= w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,3,local+3,&ftab[17],fqv[114]); /*warn*/
	local[3]= w;
	goto irtgraphIF1124;
irtgraphIF1123:
	local[3]= NIL;
irtgraphIF1124:
	local[3]= NIL;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
irtgraphWHL1125:
	if (local[4]==NIL) goto irtgraphWHX1126;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[126];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[5]= w;
	if (w!=NIL) goto irtgraphOR1128;
	local[5]= local[3];
	local[6]= argv[0];
	local[7]= fqv[127];
	local[8]= local[3];
	local[9]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[126];
	ctx->vsp=local+8;
	w=(pointer)PUTPROP(ctx,3,local+5); /*putprop*/
	local[5]= local[3];
	local[6]= fqv[126];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[5]= w;
irtgraphOR1128:
	if (local[0]==NIL) goto irtgraphIF1129;
	local[6]= fqv[129];
	local[7]= local[3];
	local[8]= fqv[92];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[48];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[18]); /*send-all*/
	local[7]= w;
	local[8]= fqv[0];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[18]); /*send-all*/
	local[7]= w;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,3,local+6,&ftab[17],fqv[114]); /*warn*/
	local[6]= w;
	goto irtgraphIF1130;
irtgraphIF1129:
	local[6]= NIL;
irtgraphIF1130:
	local[6]= local[5];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w==NIL) goto irtgraphIF1131;
	local[2] = local[5];
	local[1] = local[3];
	local[6]= local[1];
	goto irtgraphIF1132;
irtgraphIF1131:
	local[6]= NIL;
irtgraphIF1132:
	w = local[6];
	goto irtgraphWHL1125;
irtgraphWHX1126:
	local[5]= NIL;
irtgraphBLK1127:
	w = NIL;
	if (local[0]==NIL) goto irtgraphIF1133;
	local[3]= fqv[130];
	ctx->vsp=local+4;
	w=(*ftab[17])(ctx,1,local+3,&ftab[17],fqv[114]); /*warn*/
	local[3]= fqv[131];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,2,local+3,&ftab[17],fqv[114]); /*warn*/
	local[3]= fqv[132];
	local[4]= local[1];
	local[5]= fqv[92];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[48];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[18]); /*send-all*/
	local[4]= w;
	local[5]= fqv[0];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[18]); /*send-all*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,2,local+3,&ftab[17],fqv[114]); /*warn*/
	local[3]= w;
	goto irtgraphIF1134;
irtgraphIF1133:
	local[3]= NIL;
irtgraphIF1134:
	local[3]= local[1];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= fqv[133];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[18])(ctx,4,local+3,&ftab[18],fqv[134]); /*delete*/
	argv[0]->c.obj.iv[1] = w;
	w = local[1];
	local[0]= w;
irtgraphBLK1120:
	ctx->vsp=local; return(local[0]);}

/*:fn*/
static pointer irtgraphM1135best_first_graph_search_solver_fn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtgraphBLK1136:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1137a__graph_search_solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[6]));
	local[2]= fqv[21];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	w = argv[0];
	local[0]= w;
irtgraphBLK1138:
	ctx->vsp=local; return(local[0]);}

/*:fn*/
static pointer irtgraphM1139a__graph_search_solver_fn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[135], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1141;
	local[0] = NIL;
irtgraphKEY1141:
	if (local[0]==NIL) goto irtgraphIF1142;
	local[1]= fqv[136];
	local[2]= argv[0];
	local[3]= fqv[137];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[114]); /*warn*/
	local[1]= fqv[138];
	local[2]= argv[0];
	local[3]= fqv[139];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[114]); /*warn*/
	local[1]= w;
	goto irtgraphIF1143;
irtgraphIF1142:
	local[1]= NIL;
irtgraphIF1143:
	local[1]= argv[0];
	local[2]= fqv[137];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[139];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[0]= w;
irtgraphBLK1140:
	ctx->vsp=local; return(local[0]);}

/*:gn*/
static pointer irtgraphM1144a__graph_search_solver_gn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtgraphBLK1145:
	ctx->vsp=local; return(local[0]);}

/*:hn*/
static pointer irtgraphM1146a__graph_search_solver_hn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= fqv[140];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[114]); /*warn*/
	w = makeflt(0.0000000000000000000000e+00);
	local[0]= w;
irtgraphBLK1147:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtgraph(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[10];
	local[1]= fqv[141];
	local[2]= fqv[10];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[145];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM762node_init,fqv[21],fqv[10],fqv[151]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM766node_arc_list,fqv[25],fqv[10],fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM768node_successors,fqv[11],fqv[10],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM771node_add_arc,fqv[5],fqv[10],fqv[154]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM773node_remove_arc,fqv[23],fqv[10],fqv[155]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM775node_remove_all_arcs,fqv[19],fqv[10],fqv[156]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM777node_unlink,fqv[17],fqv[10],fqv[157]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM780node_image,fqv[1],fqv[10],fqv[158]);
	local[0]= fqv[20];
	local[1]= fqv[141];
	local[2]= fqv[20];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[159];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM786arc_init,fqv[21],fqv[20],fqv[160]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM788arc_from,fqv[22],fqv[20],fqv[161]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM790arc_to,fqv[4],fqv[20],fqv[162]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM792arc_prin1,fqv[7],fqv[20],fqv[163]);
	local[0]= fqv[164];
	local[1]= fqv[141];
	local[2]= fqv[164];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[165];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM797directed_graph_init,fqv[21],fqv[164],fqv[166]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM799directed_graph_successors,fqv[11],fqv[164],fqv[167]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM802directed_graph_node,fqv[99],fqv[164],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM805directed_graph_nodes,fqv[169],fqv[164],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM814directed_graph_add_node,fqv[171],fqv[164],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM816directed_graph_remove_node,fqv[173],fqv[164],fqv[174]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM818directed_graph_clear_nodes,fqv[175],fqv[164],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM820directed_graph_add_arc_from_to,fqv[29],fqv[164],fqv[177]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM822directed_graph_remove_arc,fqv[23],fqv[164],fqv[178]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM824directed_graph_adjacency_matrix,fqv[179],fqv[164],fqv[180]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM834directed_graph_adjacency_list,fqv[181],fqv[164],fqv[182]);
	local[0]= fqv[32];
	local[1]= fqv[141];
	local[2]= fqv[32];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[20]);
	local[5]= fqv[144];
	local[6]= fqv[183];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM838costed_arc_init,fqv[21],fqv[32],fqv[184]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM840costed_arc_cost,fqv[33],fqv[32],fqv[185]);
	local[0]= fqv[186];
	local[1]= fqv[141];
	local[2]= fqv[186];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[164]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM842costed_graph_add_arc,fqv[5],fqv[186],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM845costed_graph_add_arc_from_to,fqv[29],fqv[186],fqv[189]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM850costed_graph_path_cost,fqv[96],fqv[186],fqv[190]);
	local[0]= fqv[191];
	local[1]= fqv[141];
	local[2]= fqv[191];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[186]);
	local[5]= fqv[144];
	local[6]= fqv[192];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM852graph_goal_test,fqv[109],fqv[191],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM854graph_path_cost,fqv[96],fqv[191],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM858graph_start_state,fqv[98],fqv[191],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM864graph_goal_state,fqv[100],fqv[191],fqv[196]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM870graph_add_arc,fqv[5],fqv[191],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM876graph_add_arc_from_to,fqv[29],fqv[191],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM879directed_graph_write_to_dot_stream,fqv[63],fqv[164],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM918directed_graph_write_to_dot,fqv[66],fqv[164],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM924directed_graph_write_to_file,fqv[74],fqv[164],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM930directed_graph_write_to_pdf,fqv[202],fqv[164],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM939directed_graph_original_draw_mode,fqv[204],fqv[164],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM941directed_graph_current_draw_mode,fqv[206],fqv[164],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM943directed_graph_draw_both_arc,fqv[39],fqv[164],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM949directed_graph_draw_arc_label,fqv[40],fqv[164],fqv[209]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM955directed_graph_draw_merged_result,fqv[41],fqv[164],fqv[210]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM969node_add_neighbor,fqv[211],fqv[10],fqv[212]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM975node_neighbors,fqv[88],fqv[10],fqv[213]);
	local[0]= fqv[214];
	local[1]= fqv[141];
	local[2]= fqv[214];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[10]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM984arced_node_init,fqv[21],fqv[214],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM987arced_node_find_action,fqv[216],fqv[214],fqv[217]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM992arced_node_neighbor_action_alist,fqv[218],fqv[214],fqv[219]);
	local[0]= fqv[94];
	local[1]= fqv[141];
	local[2]= fqv[94];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[220];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM995solver_node_init,fqv[21],fqv[94],fqv[221]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1000solver_node_path,fqv[92],fqv[94],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1012solver_node_expand,fqv[112],fqv[94],fqv[223]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1018solver_node_state,fqv[48],fqv[94],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1024solver_node_cost,fqv[33],fqv[94],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1030solver_node_parent,fqv[91],fqv[94],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1036solver_node_action,fqv[95],fqv[94],fqv[227]);
	local[0]= fqv[228];
	local[1]= fqv[141];
	local[2]= fqv[228];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1042solver_init,fqv[21],fqv[228],fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1044solver_solve,fqv[101],fqv[228],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1046solver_solve_by_name,fqv[231],fqv[228],fqv[232]);
	local[0]= fqv[233];
	local[1]= fqv[141];
	local[2]= fqv[233];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[228]);
	local[5]= fqv[144];
	local[6]= fqv[234];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1049graph_search_solver_solve_init,fqv[105],fqv[233],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1051graph_search_solver_find_node_in_close_list,fqv[110],fqv[233],fqv[236]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1053graph_search_solver_solve,fqv[101],fqv[233],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1062graph_search_solver_add_to_open_list,fqv[103],fqv[233],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1066graph_search_solver_null_open_list_,fqv[106],fqv[233],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1068graph_search_solver_clear_open_list,fqv[116],fqv[233],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1070graph_search_solver_add_list_to_open_list,fqv[111],fqv[233],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1072graph_search_solver_add_object_to_open_list,fqv[117],fqv[233],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1074graph_search_solver_pop_from_open_list,fqv[107],fqv[233],fqv[243]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1077graph_search_solver_open_list,fqv[244],fqv[233],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1083graph_search_solver_close_list,fqv[246],fqv[233],fqv[247]);
	local[0]= fqv[248];
	local[1]= fqv[141];
	local[2]= fqv[248];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[233]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1089breadth_first_graph_search_solver_init,fqv[21],fqv[248],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1091breadth_first_graph_search_solver_clear_open_list,fqv[116],fqv[248],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1093breadth_first_graph_search_solver_add_list_to_open_list,fqv[111],fqv[248],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1095breadth_first_graph_search_solver_add_object_to_open_list,fqv[117],fqv[248],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1097breadth_first_graph_search_solver_pop_from_open_list,fqv[107],fqv[248],fqv[253]);
	local[0]= fqv[254];
	local[1]= fqv[141];
	local[2]= fqv[254];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[233]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1100depth_first_graph_search_solver_init,fqv[21],fqv[254],fqv[255]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1102depth_first_graph_search_solver_clear_open_list,fqv[116],fqv[254],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1104depth_first_graph_search_solver_add_list_to_open_list,fqv[111],fqv[254],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1106depth_first_graph_search_solver_add_object_to_open_list,fqv[117],fqv[254],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1108depth_first_graph_search_solver_pop_from_open_list,fqv[107],fqv[254],fqv[259]);
	local[0]= fqv[260];
	local[1]= fqv[141];
	local[2]= fqv[260];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[233]);
	local[5]= fqv[144];
	local[6]= fqv[261];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1111best_first_graph_search_solver_init,fqv[21],fqv[260],fqv[262]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1113best_first_graph_search_solver_clear_open_list,fqv[116],fqv[260],fqv[263]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1115best_first_graph_search_solver_add_list_to_open_list,fqv[111],fqv[260],fqv[264]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1117best_first_graph_search_solver_add_object_to_open_list,fqv[117],fqv[260],fqv[265]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1119best_first_graph_search_solver_pop_from_open_list,fqv[107],fqv[260],fqv[266]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1135best_first_graph_search_solver_fn,fqv[127],fqv[260],fqv[267]);
	local[0]= fqv[268];
	local[1]= fqv[141];
	local[2]= fqv[268];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[260]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1137a__graph_search_solver_init,fqv[21],fqv[268],fqv[269]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1139a__graph_search_solver_fn,fqv[127],fqv[268],fqv[270]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1144a__graph_search_solver_gn,fqv[137],fqv[268],fqv[271]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1146a__graph_search_solver_hn,fqv[139],fqv[268],fqv[272]);
	local[0]= fqv[273];
	local[1]= fqv[274];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,2,local+0,&ftab[20],fqv[275]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<21; i++) ftab[i]=fcallx;
}

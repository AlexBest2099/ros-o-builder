/* ./irtviewer.c :  entry=irtviewer */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sun Nov 23 17:09:44 UTC 2025) */
#include "eus.h"
#include "irtviewer.h"
#pragma init (register_irtviewer)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtviewer();
extern pointer build_quote_vector();
static int register_irtviewer()
  { add_module_initializer("___irtviewer", ___irtviewer);}

static pointer irtvieweF688make_lr_ud_coords();
static pointer irtvieweF689make_mpeg_from_images();
static pointer irtvieweF690make_animgif_from_images();
static pointer irtvieweF691draw_things();
static pointer irtvieweF692objects();
static pointer irtvieweF693make_irtviewer();
static pointer irtvieweF694make_irtviewer_dummy();
static pointer irtvieweF695geometry__default_pixmapsurface();
static pointer irtvieweF696make_irtviewer_no_window();

/*make-lr-ud-coords*/
static pointer irtvieweF688make_lr_ud_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(*ftab[0])(ctx,0,local+0,&ftab[0],fqv[0]); /*geometry:make-coords*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[2]); /*deg2rad*/
	local[3]= w;
	local[4]= fqv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= local[0];
	local[2]= fqv[1];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[2]); /*deg2rad*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
irtvieweBLK697:
	ctx->vsp=local; return(local[0]);}

/*:draw-circle*/
static pointer irtvieweM698geometry_viewer_draw_circle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[5], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY700;
	local[0] = makeint((eusinteger_t)50L);
irtvieweKEY700:
	if (n & (1<<1)) goto irtvieweKEY701;
	local[1] = NIL;
irtvieweKEY701:
	if (n & (1<<2)) goto irtvieweKEY702;
	local[2] = NIL;
irtvieweKEY702:
	if (n & (1<<3)) goto irtvieweKEY703;
	local[3] = makeflt(6.2831853071795862319959e+00);
irtvieweKEY703:
	if (n & (1<<4)) goto irtvieweKEY704;
	local[4] = fqv[6];
irtvieweKEY704:
	local[5]= makeint((eusinteger_t)16L);
	local[6]= local[3];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[5];
irtvieweWHL705:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtvieweWHX706;
	local[11]= argv[2];
	local[12]= fqv[7];
	local[13]= local[0];
	local[14]= local[9];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SIN(ctx,1,local+14); /*sin*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	local[14]= local[0];
	local[15]= local[9];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)COS(ctx,1,local+15); /*cos*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,3,local+13); /*float-vector*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[8] = w;
	if (local[7]==NIL) goto irtvieweIF708;
	local[11]= argv[0];
	local[12]= fqv[8];
	local[13]= local[7];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= w;
	goto irtvieweIF709;
irtvieweIF708:
	local[11]= NIL;
irtvieweIF709:
	local[7] = local[8];
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtvieweWHL705;
irtvieweWHX706:
	local[11]= NIL;
irtvieweBLK707:
	w = NIL;
	local[9]= argv[2];
	local[10]= fqv[7];
	local[11]= local[0];
	local[12]= local[5];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SIN(ctx,1,local+12); /*sin*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[0];
	local[13]= local[5];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)COS(ctx,1,local+13); /*cos*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[8] = w;
	if (local[2]==NIL) goto irtvieweIF710;
	local[9]= argv[0];
	local[10]= fqv[9];
	local[11]= local[7];
	local[12]= local[8];
	local[13]= T;
	local[14]= NIL;
	local[15]= fqv[10];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,8,local+9); /*send*/
	local[9]= w;
	goto irtvieweIF711;
irtvieweIF710:
	local[9]= argv[0];
	local[10]= fqv[8];
	local[11]= local[7];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
irtvieweIF711:
	if (local[1]==NIL) goto irtvieweIF712;
	local[9]= argv[0];
	local[10]= fqv[11];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	goto irtvieweIF713;
irtvieweIF712:
	local[9]= NIL;
irtvieweIF713:
	w = local[9];
	local[0]= w;
irtvieweBLK699:
	ctx->vsp=local; return(local[0]);}

/*:draw-objects*/
static pointer irtvieweM714geometry_viewer_draw_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST716:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[12]);
	local[2]= argv[0];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	local[3]= fqv[14];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
irtvieweBLK715:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer irtvieweM717irtviewer_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST719:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[15], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtvieweKEY720;
	local[1] = fqv[16];
irtvieweKEY720:
	if (n & (1<<1)) goto irtvieweKEY721;
	local[11]= fqv[17];
	ctx->vsp=local+12;
	w=(pointer)GENSYM(ctx,1,local+11); /*gensym*/
	local[2] = w;
irtvieweKEY721:
	if (n & (1<<2)) goto irtvieweKEY722;
	local[3] = makeflt(2.0000000000000000000000e+02);
irtvieweKEY722:
	if (n & (1<<3)) goto irtvieweKEY723;
	local[4] = makeflt(5.0000000000000000000000e+04);
irtvieweKEY723:
	if (n & (1<<4)) goto irtvieweKEY724;
	local[5] = makeint((eusinteger_t)500L);
irtvieweKEY724:
	if (n & (1<<5)) goto irtvieweKEY725;
	local[6] = makeint((eusinteger_t)500L);
irtvieweKEY725:
	if (n & (1<<6)) goto irtvieweKEY726;
	local[7] = makeint((eusinteger_t)150L);
irtvieweKEY726:
	if (n & (1<<7)) goto irtvieweKEY727;
	local[8] = NIL;
irtvieweKEY727:
	if (n & (1<<8)) goto irtvieweKEY728;
	local[9] = fqv[18];
irtvieweKEY728:
	if (n & (1<<9)) goto irtvieweKEY729;
	local[10] = T;
irtvieweKEY729:
	argv[0]->c.obj.iv[29] = makeint((eusinteger_t)60L);
	argv[0]->c.obj.iv[30] = makeint((eusinteger_t)20L);
	local[11]= makeint((eusinteger_t)700L);
	local[12]= makeint((eusinteger_t)400L);
	local[13]= makeint((eusinteger_t)250L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	argv[0]->c.obj.iv[31] = w;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	argv[0]->c.obj.iv[32] = w;
	argv[0]->c.obj.iv[34] = local[7];
	argv[0]->c.obj.iv[35] = local[8];
	argv[0]->c.obj.iv[36] = local[9];
	argv[0]->c.obj.iv[38] = NIL;
	if (local[10]==NIL) goto irtvieweIF730;
	local[11]= (pointer)get_sym_func(fqv[19]);
	local[12]= argv[0];
	local[13]= *(ovafptr(argv[1],fqv[20]));
	local[14]= fqv[21];
	local[15]= fqv[22];
	local[16]= local[5];
	local[17]= fqv[23];
	local[18]= local[6];
	local[19]= fqv[24];
	local[20]= local[1];
	local[21]= fqv[25];
	local[22]= fqv[26];
	local[23]= local[0];
	ctx->vsp=local+24;
	w=(pointer)APPLY(ctx,13,local+11); /*apply*/
	local[11]= w;
	goto irtvieweIF731;
irtvieweIF730:
	local[11]= NIL;
irtvieweIF731:
	local[11]= local[4];
	storeglobal(fqv[27],local[11]);
	local[11]= local[3];
	storeglobal(fqv[28],local[11]);
	local[11]= (pointer)get_sym_func(fqv[29]);
	local[12]= fqv[30];
	local[13]= argv[0];
	local[14]= fqv[31];
	local[15]= makeint((eusinteger_t)0L);
	local[16]= fqv[4];
	local[17]= makeint((eusinteger_t)0L);
	local[18]= fqv[22];
	local[19]= local[5];
	local[20]= fqv[23];
	local[21]= local[6];
	local[22]= fqv[24];
	local[23]= local[1];
	local[24]= fqv[32];
	local[25]= local[2];
	local[26]= local[0];
	ctx->vsp=local+27;
	w=(pointer)APPLY(ctx,16,local+11); /*apply*/
	argv[0]->c.obj.iv[25] = w;
	local[11]= argv[0]->c.obj.iv[25];
	local[12]= argv[0];
	local[13]= fqv[13];
	ctx->vsp=local+14;
	w=(pointer)PUTPROP(ctx,3,local+11); /*putprop*/
	local[11]= argv[0]->c.obj.iv[25];
	storeglobal(fqv[33],local[11]);
	local[11]= makeflt(9.9999999999999977795540e-02);
	local[12]= makeflt(9.9999999999999977795540e-02);
	local[13]= makeflt(9.9999999999999977795540e-02);
	local[14]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,4,local+11); /*float-vector*/
	local[11]= w;
	local[12]= makeflt(1.0000000000000000000000e+00);
	local[13]= makeflt(1.0000000000000000000000e+00);
	local[14]= makeflt(1.0000000000000000000000e+00);
	local[15]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,4,local+12); /*float-vector*/
	local[12]= w;
	local[13]= makeflt(9.9999999999999977795540e-02);
	local[14]= makeflt(9.9999999999999977795540e-02);
	local[15]= makeflt(9.9999999999999977795540e-02);
	local[16]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,4,local+13); /*float-vector*/
	local[13]= w;
	local[14]= makeflt(1.0000000000000000000000e+00);
	local[15]= makeflt(6.9999999999999973354647e-01);
	local[16]= makeflt(3.9999999999999991118216e-01);
	local[17]= makeflt(2.5000000000000000000000e-01);
	local[18]= loadglobal(fqv[34]);
	ctx->vsp=local+19;
	w=(pointer)INSTANTIATE(ctx,1,local+18); /*instantiate*/
	local[18]= w;
	local[19]= local[18];
	local[20]= fqv[21];
	local[21]= makeint((eusinteger_t)0L);
	local[22]= fqv[35];
	local[23]= local[14];
	local[24]= local[11];
	ctx->vsp=local+25;
	w=(pointer)SCALEVEC(ctx,2,local+23); /*scale*/
	local[23]= w;
	local[24]= fqv[36];
	local[25]= local[14];
	local[26]= local[12];
	ctx->vsp=local+27;
	w=(pointer)SCALEVEC(ctx,2,local+25); /*scale*/
	local[25]= w;
	local[26]= fqv[37];
	local[27]= local[14];
	local[28]= local[13];
	ctx->vsp=local+29;
	w=(pointer)SCALEVEC(ctx,2,local+27); /*scale*/
	local[27]= w;
	local[28]= fqv[38];
	local[29]= makeflt(4.0000000000000000000000e+03);
	local[30]= makeflt(3.0000000000000000000000e+03);
	local[31]= makeflt(0.0000000000000000000000e+00);
	local[32]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+33;
	w=(pointer)MKFLTVEC(ctx,4,local+29); /*float-vector*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,11,local+19); /*send*/
	w = local[18];
	local[18]= w;
	storeglobal(fqv[39],w);
	local[18]= loadglobal(fqv[34]);
	ctx->vsp=local+19;
	w=(pointer)INSTANTIATE(ctx,1,local+18); /*instantiate*/
	local[18]= w;
	local[19]= local[18];
	local[20]= fqv[21];
	local[21]= makeint((eusinteger_t)1L);
	local[22]= fqv[35];
	local[23]= local[15];
	local[24]= local[11];
	ctx->vsp=local+25;
	w=(pointer)SCALEVEC(ctx,2,local+23); /*scale*/
	local[23]= w;
	local[24]= fqv[36];
	local[25]= local[15];
	local[26]= local[12];
	ctx->vsp=local+27;
	w=(pointer)SCALEVEC(ctx,2,local+25); /*scale*/
	local[25]= w;
	local[26]= fqv[37];
	local[27]= local[15];
	local[28]= local[13];
	ctx->vsp=local+29;
	w=(pointer)SCALEVEC(ctx,2,local+27); /*scale*/
	local[27]= w;
	local[28]= fqv[38];
	local[29]= makeflt(-4.0000000000000000000000e+03);
	local[30]= makeflt(-2.0000000000000000000000e+03);
	local[31]= makeflt(-2.0000000000000000000000e+03);
	local[32]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+33;
	w=(pointer)MKFLTVEC(ctx,4,local+29); /*float-vector*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,11,local+19); /*send*/
	w = local[18];
	local[18]= w;
	storeglobal(fqv[40],w);
	local[18]= loadglobal(fqv[34]);
	ctx->vsp=local+19;
	w=(pointer)INSTANTIATE(ctx,1,local+18); /*instantiate*/
	local[18]= w;
	local[19]= local[18];
	local[20]= fqv[21];
	local[21]= makeint((eusinteger_t)2L);
	local[22]= fqv[35];
	local[23]= local[16];
	local[24]= local[11];
	ctx->vsp=local+25;
	w=(pointer)SCALEVEC(ctx,2,local+23); /*scale*/
	local[23]= w;
	local[24]= fqv[36];
	local[25]= local[16];
	local[26]= local[12];
	ctx->vsp=local+27;
	w=(pointer)SCALEVEC(ctx,2,local+25); /*scale*/
	local[25]= w;
	local[26]= fqv[37];
	local[27]= local[16];
	local[28]= local[13];
	ctx->vsp=local+29;
	w=(pointer)SCALEVEC(ctx,2,local+27); /*scale*/
	local[27]= w;
	local[28]= fqv[38];
	local[29]= makeflt(-2.0000000000000000000000e+03);
	local[30]= makeflt(-2.0000000000000000000000e+03);
	local[31]= makeflt(2.5000000000000000000000e+03);
	local[32]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+33;
	w=(pointer)MKFLTVEC(ctx,4,local+29); /*float-vector*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,11,local+19); /*send*/
	w = local[18];
	local[18]= w;
	storeglobal(fqv[41],w);
	local[18]= loadglobal(fqv[34]);
	ctx->vsp=local+19;
	w=(pointer)INSTANTIATE(ctx,1,local+18); /*instantiate*/
	local[18]= w;
	local[19]= local[18];
	local[20]= fqv[21];
	local[21]= makeint((eusinteger_t)3L);
	local[22]= fqv[35];
	local[23]= local[17];
	local[24]= local[11];
	ctx->vsp=local+25;
	w=(pointer)SCALEVEC(ctx,2,local+23); /*scale*/
	local[23]= w;
	local[24]= fqv[36];
	local[25]= local[17];
	local[26]= local[12];
	ctx->vsp=local+27;
	w=(pointer)SCALEVEC(ctx,2,local+25); /*scale*/
	local[25]= w;
	local[26]= fqv[37];
	local[27]= local[17];
	local[28]= local[13];
	ctx->vsp=local+29;
	w=(pointer)SCALEVEC(ctx,2,local+27); /*scale*/
	local[27]= w;
	local[28]= fqv[38];
	local[29]= makeflt(0.0000000000000000000000e+00);
	local[30]= makeflt(0.0000000000000000000000e+00);
	local[31]= makeflt(0.0000000000000000000000e+00);
	local[32]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+33;
	w=(pointer)MKFLTVEC(ctx,4,local+29); /*float-vector*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,11,local+19); /*send*/
	w = local[18];
	local[18]= w;
	storeglobal(fqv[42],w);
	w = local[18];
	local[11]= loadglobal(fqv[39]);
	local[12]= fqv[43];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= loadglobal(fqv[40]);
	local[12]= fqv[43];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= loadglobal(fqv[41]);
	local[12]= fqv[43];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= loadglobal(fqv[42]);
	local[12]= fqv[43];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= argv[0]->c.obj.iv[25];
	local[12]= fqv[44];
	local[13]= fqv[45];
	local[14]= fqv[46];
	local[15]= fqv[47];
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,6,local+11); /*send*/
	local[11]= argv[0]->c.obj.iv[25];
	local[12]= fqv[44];
	local[13]= fqv[45];
	local[14]= fqv[48];
	local[15]= fqv[49];
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,6,local+11); /*send*/
	local[11]= argv[0]->c.obj.iv[25];
	local[12]= fqv[44];
	local[13]= fqv[45];
	local[14]= fqv[50];
	local[15]= fqv[51];
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,6,local+11); /*send*/
	local[11]= argv[0]->c.obj.iv[25];
	local[12]= fqv[44];
	local[13]= fqv[45];
	local[14]= fqv[52];
	local[15]= fqv[51];
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,6,local+11); /*send*/
	local[11]= argv[0];
	local[12]= fqv[53];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= argv[0];
	local[12]= fqv[14];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	w = argv[0];
	local[0]= w;
irtvieweBLK718:
	ctx->vsp=local; return(local[0]);}

/*:viewer*/
static pointer irtvieweM732irtviewer_viewer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST734:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[54]); /*user::forward-message-to*/
	local[0]= w;
irtvieweBLK733:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer irtvieweM735irtviewer_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[14];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtvieweBLK736:
	ctx->vsp=local; return(local[0]);}

/*:expose*/
static pointer irtvieweM737irtviewer_expose(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK738:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer irtvieweM739irtviewer_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[20]));
	local[2]= fqv[56];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[56];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[57];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[58];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[2];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)MAX(ctx,2,local+0); /*max*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= fqv[59];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[56];
	local[3]= fqv[22];
	local[4]= local[0];
	local[5]= fqv[23];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= fqv[60];
	local[8]= argv[2];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= fqv[61];
	local[10]= argv[3];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,10,local+1); /*send*/
	local[0]= argv[0];
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtvieweBLK740:
	ctx->vsp=local; return(local[0]);}

/*:configurenotify*/
static pointer irtvieweM741irtviewer_configurenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	if (loadglobal(fqv[63])==NIL) goto irtvieweIF743;
	local[3]= fqv[64];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[3])(ctx,2,local+3,&ftab[3],fqv[65]); /*warn*/
	local[3]= w;
	goto irtvieweIF744;
irtvieweIF743:
	local[3]= NIL;
irtvieweIF744:
	local[3]= argv[0];
	local[4]= loadglobal(fqv[66]);
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,3,local+3); /*send-message*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= loadglobal(fqv[66]);
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,3,local+4); /*send-message*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[67]); /*/=*/
	if (w!=NIL) goto irtvieweOR747;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[67]); /*/=*/
	if (w!=NIL) goto irtvieweOR747;
	goto irtvieweIF745;
irtvieweOR747:
	local[5]= argv[0];
	local[6]= fqv[56];
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto irtvieweIF746;
irtvieweIF745:
	local[5]= NIL;
irtvieweIF746:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK742:
	ctx->vsp=local; return(local[0]);}

/*:viewtarget*/
static pointer irtvieweM748irtviewer_viewtarget(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT751;}
	local[0]= NIL;
irtvieweENT751:
irtvieweENT750:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtvieweIF752;
	argv[0]->c.obj.iv[32] = local[0];
	local[1]= argv[0]->c.obj.iv[32];
	goto irtvieweIF753;
irtvieweIF752:
	local[1]= NIL;
irtvieweIF753:
	w = argv[0]->c.obj.iv[32];
	local[0]= w;
irtvieweBLK749:
	ctx->vsp=local; return(local[0]);}

/*:viewpoint*/
static pointer irtvieweM754irtviewer_viewpoint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT757;}
	local[0]= NIL;
irtvieweENT757:
irtvieweENT756:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtvieweIF758;
	argv[0]->c.obj.iv[31] = local[0];
	local[1]= argv[0]->c.obj.iv[31];
	goto irtvieweIF759;
irtvieweIF758:
	local[1]= NIL;
irtvieweIF759:
	w = argv[0]->c.obj.iv[31];
	local[0]= w;
irtvieweBLK755:
	ctx->vsp=local; return(local[0]);}

/*:look1*/
static pointer irtvieweM760irtviewer_look1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT765;}
	local[0]= argv[0]->c.obj.iv[32];
irtvieweENT765:
	if (n>=4) { local[1]=(argv[3]); goto irtvieweENT764;}
	local[1]= argv[0]->c.obj.iv[29];
irtvieweENT764:
	if (n>=5) { local[2]=(argv[4]); goto irtvieweENT763;}
	local[2]= argv[0]->c.obj.iv[30];
irtvieweENT763:
irtvieweENT762:
	if (n>5) maerror();
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)irtvieweF688make_lr_ud_coords(ctx,2,local+3); /*make-lr-ud-coords*/
	local[3]= w;
	local[4]= local[0];
	local[5]= local[3];
	local[6]= fqv[7];
	local[7]= argv[0]->c.obj.iv[31];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,2,local+7); /*v-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	local[5]= local[3];
	local[6]= fqv[68];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[69];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[70];
	local[8]= fqv[71];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (w==NIL) goto irtvieweIF766;
	local[6]= argv[0];
	local[7]= fqv[70];
	local[8]= fqv[71];
	local[9]= fqv[72];
	local[10]= argv[0]->c.obj.iv[31];
	local[11]= local[0];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,7,local+6); /*send*/
	local[6]= w;
	goto irtvieweIF767;
irtvieweIF766:
	local[6]= NIL;
irtvieweIF767:
	w = local[6];
	local[0]= w;
irtvieweBLK761:
	ctx->vsp=local; return(local[0]);}

/*:look-all*/
static pointer irtvieweM768irtviewer_look_all(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT771;}
	local[0]= NIL;
irtvieweENT771:
irtvieweENT770:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= loadglobal(fqv[73]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	local[1]= w;
	if (w!=NIL) goto irtvieweCON772;
irtvieweCON773:
	if (local[0]!=NIL) goto irtvieweCON774;
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= fqv[76];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[77]); /*flatten*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[78]); /*geometry:make-bounding-box*/
	local[0] = w;
	local[1]= local[0];
	goto irtvieweCON772;
irtvieweCON774:
	if (local[0]==NIL) goto irtvieweCON775;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)irtvieweF691draw_things(ctx,1,local+1); /*draw-things*/
	local[1]= w;
	local[2]= fqv[76];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[77]); /*flatten*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[78]); /*geometry:make-bounding-box*/
	local[0] = w;
	local[1]= local[0];
	goto irtvieweCON772;
irtvieweCON775:
	local[1]= NIL;
irtvieweCON772:
	if (local[0]==NIL) goto irtvieweIF776;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[0];
	local[5]= fqv[79];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[1] = w;
	local[4]= (pointer)get_sym_func(fqv[80]);
	local[5]= local[0];
	local[6]= fqv[81];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= loadglobal(fqv[82]);
	ctx->vsp=local+7;
	w=(pointer)COERCE(ctx,2,local+5); /*coerce*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= argv[0];
	local[7]= fqv[70];
	local[8]= fqv[71];
	local[9]= fqv[83];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TAN(ctx,1,local+6); /*tan*/
	{ double x,y;
		y=fltval(w); x=fltval(local[5]);
		local[5]=(makeflt(x * y));}
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[3] = w;
	local[4]= local[3];
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w!=NIL) goto irtvieweOR780;
	local[4]= local[3];
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w!=NIL) goto irtvieweOR780;
	goto irtvieweIF778;
irtvieweOR780:
	local[4]= makeint((eusinteger_t)2L);
	local[5]= fqv[84];
	local[6]= local[3];
	local[7]= loadglobal(fqv[27]);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,3,local+4,&ftab[8],fqv[85]); /*warning-message*/
	local[4]= local[3];
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= loadglobal(fqv[28]);
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	storeglobal(fqv[28],w);
	local[4]= local[3];
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	storeglobal(fqv[27],w);
	goto irtvieweIF779;
irtvieweIF778:
	local[4]= NIL;
irtvieweIF779:
	local[4]= loadglobal(fqv[27]);
	local[5]= makeflt(7.9999999999999982236432e-01);
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= loadglobal(fqv[28]);
	local[6]= makeflt(1.5000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MAX(ctx,2,local+5); /*max*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MIN(ctx,2,local+4); /*min*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VNORMALIZE(ctx,1,local+5); /*normalize-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[2] = w;
	local[4]= argv[0];
	local[5]= fqv[86];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[69];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,2,local+6); /*v+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[1]= w;
	goto irtvieweIF777;
irtvieweIF776:
	local[1]= NIL;
irtvieweIF777:
	local[1]= argv[0];
	local[2]= fqv[53];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0]= w;
irtvieweBLK769:
	ctx->vsp=local; return(local[0]);}

/*:move-viewing-around-viewtarget*/
static pointer irtvieweM781irtviewer_move_viewing_around_viewtarget(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=8) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[87]); /*event-middle*/
	if (w==NIL) goto irtvieweCON784;
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= argv[7];
	local[5]= fqv[71];
	local[6]= fqv[7];
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VNORM(ctx,1,local+8); /*norm*/
	{ double x,y;
		y=fltval(w); x=fltval(local[7]);
		local[7]=(makeflt(x * y));}
	local[8]= makeint((eusinteger_t)-1L);
	local[9]= argv[5];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= argv[6];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[86];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,2,local+6); /*v-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[69];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[86];
	local[9]= local[5];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)VPLUS(ctx,2,local+9); /*v+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[3]= w;
	goto irtvieweCON783;
irtvieweCON784:
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,1,local+3,&ftab[10],fqv[88]); /*event-right*/
	if (w!=NIL) goto irtvieweOR786;
	local[3]= makeint((eusinteger_t)60L);
	local[4]= argv[3];
	local[5]= argv[7];
	local[6]= fqv[44];
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)60L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,3,local+3); /*<*/
	if (w==NIL) goto irtvieweAND787;
	local[3]= makeint((eusinteger_t)60L);
	local[4]= argv[4];
	local[5]= argv[7];
	local[6]= fqv[44];
	local[7]= fqv[23];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)60L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,3,local+3); /*<*/
	if (w==NIL) goto irtvieweAND787;
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[11])(ctx,1,local+3,&ftab[11],fqv[89]); /*event-left*/
	if (w==NIL) goto irtvieweAND787;
	goto irtvieweOR786;
irtvieweAND787:
	goto irtvieweCON785;
irtvieweOR786:
	local[3]= argv[0]->c.obj.iv[29];
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	argv[0]->c.obj.iv[29] = w;
	local[3]= argv[0]->c.obj.iv[30];
	local[4]= argv[6];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	argv[0]->c.obj.iv[30] = w;
	local[3]= argv[0]->c.obj.iv[30];
	goto irtvieweCON783;
irtvieweCON785:
	local[3]= argv[3];
	local[4]= argv[7];
	local[5]= fqv[44];
	local[6]= fqv[22];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)60L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w!=NIL) goto irtvieweOR789;
	local[3]= argv[4];
	local[4]= makeint((eusinteger_t)60L);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w!=NIL) goto irtvieweOR789;
	goto irtvieweCON788;
irtvieweOR789:
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[69];
	local[6]= argv[0]->c.obj.iv[31];
	local[7]= makeflt(9.9999999999999950039964e-03);
	local[8]= argv[4];
	local[9]= makeint((eusinteger_t)60L);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtvieweIF790;
	local[8]= argv[5];
	goto irtvieweIF791;
irtvieweIF790:
	local[8]= argv[6];
irtvieweIF791:
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,3,local+7); /***/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VNORMALIZE(ctx,1,local+8); /*normalize-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,2,local+6); /*v+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3]= w;
	goto irtvieweCON783;
irtvieweCON788:
	local[3]= argv[4];
	local[4]= argv[7];
	local[5]= fqv[44];
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)60L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w!=NIL) goto irtvieweOR793;
	local[3]= argv[3];
	local[4]= makeint((eusinteger_t)60L);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w!=NIL) goto irtvieweOR793;
	goto irtvieweCON792;
irtvieweOR793:
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= argv[7];
	local[5]= fqv[71];
	local[6]= fqv[7];
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VNORM(ctx,1,local+8); /*norm*/
	{ double x,y;
		y=fltval(w); x=fltval(local[7]);
		local[7]=(makeflt(x * y));}
	local[8]= argv[3];
	local[9]= makeint((eusinteger_t)60L);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtvieweIF794;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[6];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	goto irtvieweIF795;
irtvieweIF794:
	local[8]= makeint((eusinteger_t)-1L);
	local[9]= argv[5];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
irtvieweIF795:
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[86];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,2,local+6); /*v-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[69];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[86];
	local[9]= local[5];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)VPLUS(ctx,2,local+9); /*v+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[3]= w;
	goto irtvieweCON783;
irtvieweCON792:
	local[3]= NIL;
irtvieweCON783:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK782:
	ctx->vsp=local; return(local[0]);}

/*:set-cursor-pos-event*/
static pointer irtvieweM796irtviewer_set_cursor_pos_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,1,local+3,&ftab[12],fqv[90]); /*event-pos*/
	argv[0]->c.obj.iv[28] = w;
	local[3]= argv[0]->c.obj.iv[28];
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK797:
	ctx->vsp=local; return(local[0]);}

/*:move-coords-event*/
static pointer irtvieweM798irtviewer_move_coords_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	if (argv[0]->c.obj.iv[28]!=NIL) goto irtvieweIF800;
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,1,local+3,&ftab[12],fqv[90]); /*event-pos*/
	argv[0]->c.obj.iv[28] = w;
	local[3]= argv[0]->c.obj.iv[28];
	goto irtvieweIF801;
irtvieweIF800:
	local[3]= NIL;
irtvieweIF801:
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,1,local+3,&ftab[12],fqv[90]); /*event-pos*/
	local[3]= w;
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[28];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[28];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[91];
	local[10]= loadglobal(fqv[55]);
	local[11]= local[4];
	local[12]= local[5];
	local[13]= local[6];
	local[14]= local[7];
	local[15]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,8,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[53];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[14];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	argv[0]->c.obj.iv[28] = local[3];
	w = argv[0]->c.obj.iv[28];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK799:
	ctx->vsp=local; return(local[0]);}

/*:draw-event*/
static pointer irtvieweM802irtviewer_draw_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	local[3]= argv[0];
	local[4]= fqv[14];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK803:
	ctx->vsp=local; return(local[0]);}

/*:draw-objects*/
static pointer irtvieweM804irtviewer_draw_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST806:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= fqv[44];
	local[3]= fqv[57];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (argv[0]->c.obj.iv[38]==NIL) goto irtvieweIF807;
	local[1]= argv[0];
	local[2]= fqv[92];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtvieweIF808;
irtvieweIF807:
	local[1]= NIL;
irtvieweIF808:
	local[1]= (pointer)get_sym_func(fqv[93]);
	local[2]= argv[0]->c.obj.iv[25];
	local[3]= argv[0]->c.obj.iv[27];
	local[4]= fqv[94];
	local[5]= argv[0]->c.obj.iv[34];
	local[6]= fqv[95];
	local[7]= argv[0]->c.obj.iv[35];
	local[8]= fqv[96];
	local[9]= argv[0]->c.obj.iv[36];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,10,local+1); /*apply*/
	local[0]= w;
irtvieweBLK805:
	ctx->vsp=local; return(local[0]);}

/*:objects*/
static pointer irtvieweM809irtviewer_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST811:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto irtvieweIF812;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car!=NIL) goto irtvieweCON815;
	argv[0]->c.obj.iv[26] = NIL;
	local[1]= argv[0]->c.obj.iv[26];
	goto irtvieweCON814;
irtvieweCON815:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto irtvieweCON816;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[26] = (w)->c.cons.car;
	local[1]= argv[0]->c.obj.iv[26];
	goto irtvieweCON814;
irtvieweCON816:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtvieweCON817;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	argv[0]->c.obj.iv[26] = w;
	local[1]= argv[0]->c.obj.iv[26];
	goto irtvieweCON814;
irtvieweCON817:
	local[1]= NIL;
irtvieweCON814:
	goto irtvieweIF813;
irtvieweIF812:
	local[1]= NIL;
irtvieweIF813:
	local[1]= argv[0]->c.obj.iv[26];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+2;
	w=(pointer)irtvieweF691draw_things(ctx,1,local+1); /*draw-things*/
	argv[0]->c.obj.iv[27] = w;
	w = argv[0]->c.obj.iv[26];
	local[0]= w;
irtvieweBLK810:
	ctx->vsp=local; return(local[0]);}

/*:select-drawmode*/
static pointer irtvieweM818irtviewer_select_drawmode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[33]==local[0]) goto irtvieweIF820;
	local[0]= argv[0];
	local[1]= fqv[70];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= *(ovafptr(w,fqv[97]));
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[27];
irtvieweWHL822:
	if (local[2]==NIL) goto irtvieweWHX823;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= fqv[98];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,1,local+3,&ftab[13],fqv[99]); /*gl::delete-displaylist-id*/
	local[3]= local[1];
	local[4]= NIL;
	local[5]= fqv[98];
	ctx->vsp=local+6;
	w=(pointer)PUTPROP(ctx,3,local+3); /*putprop*/
	local[3]= argv[2];
	local[4]= local[3];
	if (fqv[100]!=local[4]) goto irtvieweIF825;
	local[4]= local[1];
	local[5]= local[0];
	w = T;
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[101];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= w;
	goto irtvieweIF826;
irtvieweIF825:
	if (T==NIL) goto irtvieweIF827;
	local[4]= local[1];
	local[5]= NIL;
	local[6]= fqv[101];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= w;
	goto irtvieweIF828;
irtvieweIF827:
	local[4]= NIL;
irtvieweIF828:
irtvieweIF826:
	w = local[4];
	goto irtvieweWHL822;
irtvieweWHX823:
	local[3]= NIL;
irtvieweBLK824:
	w = NIL;
	local[0]= w;
	goto irtvieweIF821;
irtvieweIF820:
	local[0]= NIL;
irtvieweIF821:
	argv[0]->c.obj.iv[33] = argv[2];
	w = argv[0]->c.obj.iv[33];
	local[0]= w;
irtvieweBLK819:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer irtvieweM829irtviewer_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[25]==NIL) goto irtvieweIF831;
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[102];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtvieweIF832;
irtvieweIF831:
	local[0]= NIL;
irtvieweIF832:
	w = local[0];
	local[0]= w;
irtvieweBLK830:
	ctx->vsp=local; return(local[0]);}

/*:change-background*/
static pointer irtvieweM833irtviewer_change_background(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[70];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[57];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[2];
	local[2]= local[1];
	*(ovafptr(local[0],fqv[103])) = local[2];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,1,local+1,&ftab[14],fqv[104]); /*gl:glclearcolorfv*/
	local[0]= w;
irtvieweBLK834:
	ctx->vsp=local; return(local[0]);}

/*:draw-origin*/
static pointer irtvieweM835irtviewer_draw_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT838;}
	local[0]= fqv[105];
irtvieweENT838:
irtvieweENT837:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[105]==local[1]) goto irtvieweIF839;
	argv[0]->c.obj.iv[34] = local[0];
	local[1]= argv[0]->c.obj.iv[34];
	goto irtvieweIF840;
irtvieweIF839:
	local[1]= argv[0]->c.obj.iv[34];
irtvieweIF840:
	w = local[1];
	local[0]= w;
irtvieweBLK836:
	ctx->vsp=local; return(local[0]);}

/*:draw-floor*/
static pointer irtvieweM841irtviewer_draw_floor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT844;}
	local[0]= fqv[105];
irtvieweENT844:
irtvieweENT843:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[105]==local[1]) goto irtvieweIF845;
	argv[0]->c.obj.iv[35] = local[0];
	local[1]= argv[0]->c.obj.iv[35];
	goto irtvieweIF846;
irtvieweIF845:
	local[1]= argv[0]->c.obj.iv[35];
irtvieweIF846:
	w = local[1];
	local[0]= w;
irtvieweBLK842:
	ctx->vsp=local; return(local[0]);}

/*:floor-color*/
static pointer irtvieweM847irtviewer_floor_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT850;}
	local[0]= fqv[105];
irtvieweENT850:
irtvieweENT849:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[105]==local[1]) goto irtvieweIF851;
	argv[0]->c.obj.iv[36] = local[0];
	local[1]= argv[0]->c.obj.iv[36];
	goto irtvieweIF852;
irtvieweIF851:
	local[1]= argv[0]->c.obj.iv[36];
irtvieweIF852:
	w = local[1];
	local[0]= w;
irtvieweBLK848:
	ctx->vsp=local; return(local[0]);}

/*make-mpeg-from-images*/
static pointer irtvieweF689make_mpeg_from_images(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[106], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY854;
	local[0] = T;
irtvieweKEY854:
	if (n & (1<<1)) goto irtvieweKEY855;
	local[1] = makeint((eusinteger_t)1L);
irtvieweKEY855:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[15])(ctx,1,local+3,&ftab[15],fqv[107]); /*pathname-name*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)65536L);
	ctx->vsp=local+5;
	w=(pointer)RANDOM(ctx,1,local+4); /*random*/
	local[4]= w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= fqv[108];
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[67]); /*/=*/
	if (w==NIL) goto irtvieweIF856;
	local[7]= makeint((eusinteger_t)1L);
	local[8]= fqv[109];
	ctx->vsp=local+9;
	w=(*ftab[8])(ctx,2,local+7,&ftab[8],fqv[85]); /*warning-message*/
	w = NIL;
	ctx->vsp=local+7;
	local[0]=w;
	goto irtvieweBLK853;
	goto irtvieweIF857;
irtvieweIF856:
	local[7]= NIL;
irtvieweIF857:
	local[7]= fqv[110];
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[67]); /*/=*/
	if (w==NIL) goto irtvieweIF858;
	local[7]= makeint((eusinteger_t)1L);
	local[8]= fqv[111];
	ctx->vsp=local+9;
	w=(*ftab[8])(ctx,2,local+7,&ftab[8],fqv[85]); /*warning-message*/
	w = NIL;
	ctx->vsp=local+7;
	local[0]=w;
	goto irtvieweBLK853;
	goto irtvieweIF859;
irtvieweIF858:
	local[7]= NIL;
irtvieweIF859:
	local[7]= fqv[112];
	local[8]= local[3];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] - (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,2,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[16])(ctx,2,local+7,&ftab[16],fqv[113]); /*string=*/
	if (w==NIL) goto irtvieweIF860;
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] - (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[3] = w;
	local[7]= local[3];
	goto irtvieweIF861;
irtvieweIF860:
	local[7]= NIL;
irtvieweIF861:
	local[7]= NIL;
	local[8]= argv[1];
irtvieweWHL862:
	if (local[8]==NIL) goto irtvieweWHX863;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= NIL;
	local[10]= fqv[114];
	local[11]= local[3];
	local[12]= local[4];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,5,local+9); /*format*/
	local[5] = w;
	local[9]= local[7];
	local[10]= fqv[22];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,1,local+9,&ftab[17],fqv[115]); /*oddp*/
	if (w==NIL) goto irtvieweCON866;
	local[9]= NIL;
	local[10]= fqv[116];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[117]); /*user::write-image-file*/
	local[9]= NIL;
	local[10]= fqv[118];
	local[11]= NIL;
	local[12]= fqv[119];
	local[13]= local[3];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,4,local+11); /*format*/
	local[11]= w;
	local[12]= local[7];
	local[13]= fqv[22];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ROUND(ctx,1,local+12); /*round*/
	local[12]= w;
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)2L)); i=intval(local[12]);
		local[12]=(makeint(i * j));}
	local[13]= local[7];
	local[14]= fqv[23];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ROUND(ctx,1,local+13); /*round*/
	local[13]= w;
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)2L)); i=intval(local[13]);
		local[13]=(makeint(i * j));}
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,6,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SYSTEM(ctx,1,local+9); /*unix:system*/
	local[9]= w;
	goto irtvieweCON865;
irtvieweCON866:
	local[9]= local[5];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[117]); /*user::write-image-file*/
	local[9]= w;
	goto irtvieweCON865;
irtvieweCON867:
	local[9]= NIL;
irtvieweCON865:
	local[9]= T;
	local[10]= fqv[120];
	local[11]= local[5];
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)13L);
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,5,local+9); /*format*/
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[2] = w;
	goto irtvieweWHL862;
irtvieweWHX863:
	local[9]= NIL;
irtvieweBLK864:
	w = NIL;
	local[7]= NIL;
	local[8]= fqv[121];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= NIL;
	local[8]= fqv[122];
	local[9]= makeint((eusinteger_t)25L);
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= local[3];
	local[11]= local[4];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,6,local+7); /*format*/
	local[6] = w;
	if (loadglobal(fqv[63])==NIL) goto irtvieweIF868;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,1,local+7,&ftab[3],fqv[65]); /*warn*/
	local[7]= w;
	goto irtvieweIF869;
irtvieweIF868:
	local[7]= NIL;
irtvieweIF869:
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= T;
	local[8]= fqv[123];
	local[9]= local[3];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,4,local+7); /*format*/
	if (local[0]==NIL) goto irtvieweIF870;
	local[7]= NIL;
	local[8]= fqv[124];
	local[9]= local[3];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,4,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= w;
	goto irtvieweIF871;
irtvieweIF870:
	local[7]= NIL;
irtvieweIF871:
	w = local[7];
	local[0]= w;
irtvieweBLK853:
	ctx->vsp=local; return(local[0]);}

/*make-animgif-from-images*/
static pointer irtvieweF690make_animgif_from_images(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[125], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY873;
	local[0] = T;
irtvieweKEY873:
	if (n & (1<<1)) goto irtvieweKEY874;
	local[1] = NIL;
irtvieweKEY874:
	if (n & (1<<2)) goto irtvieweKEY875;
	local[2] = T;
irtvieweKEY875:
	if (n & (1<<3)) goto irtvieweKEY876;
	local[3] = makeint((eusinteger_t)10L);
irtvieweKEY876:
	if (n & (1<<4)) goto irtvieweKEY877;
	local[4] = fqv[126];
irtvieweKEY877:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[15])(ctx,1,local+6,&ftab[15],fqv[107]); /*pathname-name*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= fqv[127];
	local[10]= NIL;
	local[11]= fqv[128];
	ctx->vsp=local+12;
	w=(pointer)SYSTEM(ctx,1,local+11); /*unix:system*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,2,local+11,&ftab[4],fqv[67]); /*/=*/
	if (w==NIL) goto irtvieweIF878;
	local[11]= makeint((eusinteger_t)1L);
	local[12]= fqv[129];
	ctx->vsp=local+13;
	w=(*ftab[8])(ctx,2,local+11,&ftab[8],fqv[85]); /*warning-message*/
	w = NIL;
	ctx->vsp=local+11;
	local[0]=w;
	goto irtvieweBLK872;
	goto irtvieweIF879;
irtvieweIF878:
	local[11]= NIL;
irtvieweIF879:
	local[11]= fqv[130];
	ctx->vsp=local+12;
	w=(pointer)SYSTEM(ctx,1,local+11); /*unix:system*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,2,local+11,&ftab[4],fqv[67]); /*/=*/
	if (w==NIL) goto irtvieweIF880;
	local[11]= makeint((eusinteger_t)1L);
	local[12]= fqv[131];
	ctx->vsp=local+13;
	w=(*ftab[8])(ctx,2,local+11,&ftab[8],fqv[85]); /*warning-message*/
	w = NIL;
	ctx->vsp=local+11;
	local[0]=w;
	goto irtvieweBLK872;
	goto irtvieweIF881;
irtvieweIF880:
	local[11]= NIL;
irtvieweIF881:
	local[11]= fqv[132];
	local[12]= local[6];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[13]= (pointer)((eusinteger_t)local[13] - (eusinteger_t)w);
	ctx->vsp=local+14;
	w=(pointer)SUBSEQ(ctx,2,local+12); /*subseq*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[16])(ctx,2,local+11,&ftab[16],fqv[113]); /*string=*/
	if (w==NIL) goto irtvieweIF882;
	local[11]= local[6];
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[13]= (pointer)((eusinteger_t)local[13] - (eusinteger_t)w);
	ctx->vsp=local+14;
	w=(pointer)SUBSEQ(ctx,3,local+11); /*subseq*/
	local[6] = w;
	local[11]= local[6];
	goto irtvieweIF883;
irtvieweIF882:
	local[11]= NIL;
irtvieweIF883:
	local[11]= NIL;
	local[12]= fqv[133];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[7] = w;
	local[11]= NIL;
	local[12]= argv[1];
irtvieweWHL884:
	if (local[12]==NIL) goto irtvieweWHX885;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.cdr;
	w = local[13];
	local[11] = w;
	local[13]= NIL;
	local[14]= fqv[134];
	local[15]= local[6];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,4,local+13); /*format*/
	local[8] = w;
	local[13]= NIL;
	local[14]= fqv[135];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,3,local+13); /*format*/
	local[7] = w;
	local[13]= loadglobal(fqv[136]);
	local[14]= local[9];
	local[15]= fqv[137];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)CONCATENATE(ctx,4,local+13); /*concatenate*/
	local[9] = w;
	local[13]= local[8];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[18])(ctx,2,local+13,&ftab[18],fqv[117]); /*user::write-image-file*/
	local[13]= T;
	local[14]= fqv[138];
	local[15]= local[8];
	local[16]= argv[1];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)13L);
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= T;
	ctx->vsp=local+14;
	w=(pointer)FINOUT(ctx,1,local+13); /*finish-output*/
	local[13]= NIL;
	local[14]= fqv[139];
	local[15]= local[8];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,4,local+13); /*format*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SYSTEM(ctx,1,local+13); /*unix:system*/
	if (local[0]==NIL) goto irtvieweIF887;
	local[13]= NIL;
	local[14]= fqv[140];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,3,local+13); /*format*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SYSTEM(ctx,1,local+13); /*unix:system*/
	local[13]= w;
	goto irtvieweIF888;
irtvieweIF887:
	local[13]= NIL;
irtvieweIF888:
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[5] = w;
	goto irtvieweWHL884;
irtvieweWHX885:
	local[13]= NIL;
irtvieweBLK886:
	w = NIL;
	local[11]= NIL;
	local[12]= fqv[141];
	local[13]= local[3];
	if (local[1]==NIL) goto irtvieweIF889;
	local[14]= NIL;
	local[15]= fqv[142];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,3,local+14); /*format*/
	local[14]= w;
	goto irtvieweIF890;
irtvieweIF889:
	local[14]= fqv[143];
irtvieweIF890:
	if (local[2]==NIL) goto irtvieweIF891;
	local[15]= fqv[144];
	goto irtvieweIF892;
irtvieweIF891:
	local[15]= fqv[145];
irtvieweIF892:
	local[16]= local[9];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,7,local+11); /*format*/
	local[10] = w;
	if (loadglobal(fqv[63])==NIL) goto irtvieweIF893;
	local[11]= local[10];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,1,local+11,&ftab[3],fqv[65]); /*warn*/
	local[11]= w;
	goto irtvieweIF894;
irtvieweIF893:
	local[11]= NIL;
irtvieweIF894:
	local[11]= local[10];
	ctx->vsp=local+12;
	w=(pointer)SYSTEM(ctx,1,local+11); /*unix:system*/
	local[11]= T;
	local[12]= fqv[146];
	local[13]= local[6];
	local[14]= argv[1];
	ctx->vsp=local+15;
	w=(pointer)LENGTH(ctx,1,local+14); /*length*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,4,local+11); /*format*/
	if (local[0]==NIL) goto irtvieweIF895;
	local[11]= NIL;
	local[12]= fqv[147];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SYSTEM(ctx,1,local+11); /*unix:system*/
	local[11]= w;
	goto irtvieweIF896;
irtvieweIF895:
	local[11]= NIL;
irtvieweIF896:
	w = local[11];
	local[0]= w;
irtvieweBLK872:
	ctx->vsp=local; return(local[0]);}

/*:logging*/
static pointer irtvieweM897irtviewer_logging(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT900;}
	local[0]= fqv[148];
irtvieweENT900:
irtvieweENT899:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= local[1];
	w = fqv[149];
	if (memq(local[2],w)==NIL) goto irtvieweIF901;
	local[2]= argv[0];
	local[3]= fqv[150];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto irtvieweIF902;
irtvieweIF901:
	local[2]= local[1];
	w = fqv[151];
	if (memq(local[2],w)==NIL) goto irtvieweIF903;
	argv[0]->c.obj.iv[38] = T;
	local[2]= argv[0];
	local[3]= fqv[92];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto irtvieweIF904;
irtvieweIF903:
	local[2]= local[1];
	w = fqv[152];
	if (memq(local[2],w)==NIL) goto irtvieweIF905;
	local[2]= argv[0];
	local[3]= fqv[153];
	local[4]= fqv[154];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[153];
	local[4]= fqv[155];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtvieweIF906;
irtvieweIF905:
	local[2]= local[1];
	w = fqv[156];
	if (memq(local[2],w)==NIL) goto irtvieweIF907;
	local[2]= argv[0];
	local[3]= fqv[92];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	argv[0]->c.obj.iv[38] = NIL;
	local[2]= argv[0]->c.obj.iv[38];
	goto irtvieweIF908;
irtvieweIF907:
	local[2]= NIL;
irtvieweIF908:
irtvieweIF906:
irtvieweIF904:
irtvieweIF902:
	w = local[2];
	local[0]= w;
irtvieweBLK898:
	ctx->vsp=local; return(local[0]);}

/*:clear-log*/
static pointer irtvieweM909irtviewer_clear_log(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[150];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtvieweBLK910:
	ctx->vsp=local; return(local[0]);}

/*:push-image*/
static pointer irtvieweM911irtviewer_push_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[157];
	local[3]= fqv[22];
	local[4]= argv[0]->c.obj.iv[25];
	local[5]= fqv[44];
	local[6]= fqv[22];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= fqv[23];
	local[6]= argv[0]->c.obj.iv[25];
	local[7]= fqv[44];
	local[8]= fqv[23];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,7,local+0); /*send*/
	local[0]= w;
	w = argv[0]->c.obj.iv[37];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[37] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[37];
	local[0]= w;
irtvieweBLK912:
	ctx->vsp=local; return(local[0]);}

/*:clear-image-sequence*/
static pointer irtvieweM913irtviewer_clear_image_sequence(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[37] = NIL;
	w = argv[0]->c.obj.iv[37];
	local[0]= w;
irtvieweBLK914:
	ctx->vsp=local; return(local[0]);}

/*:image-sequence*/
static pointer irtvieweM915irtviewer_image_sequence(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[37];
	ctx->vsp=local+1;
	w=(pointer)REVERSE(ctx,1,local+0); /*reverse*/
	local[0]= w;
irtvieweBLK916:
	ctx->vsp=local; return(local[0]);}

/*:save-mpeg*/
static pointer irtvieweM917irtviewer_save_mpeg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[158], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY919;
	local[0] = fqv[159];
irtvieweKEY919:
	if (n & (1<<1)) goto irtvieweKEY920;
	local[1] = makeint((eusinteger_t)5L);
irtvieweKEY920:
	if (n & (1<<2)) goto irtvieweKEY921;
	local[2] = T;
irtvieweKEY921:
	local[3]= argv[0];
	local[4]= fqv[70];
	local[5]= fqv[44];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= *(ovafptr(w,fqv[103]));
	local[4]= argv[0];
	local[5]= fqv[160];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (w!=NIL) goto irtvieweIF922;
	local[4]= argv[0];
	local[5]= fqv[92];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto irtvieweIF923;
irtvieweIF922:
	local[4]= NIL;
irtvieweIF923:
	local[4]= local[0];
	local[5]= argv[0];
	local[6]= fqv[160];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[161];
	local[7]= local[1];
	local[8]= fqv[162];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)irtvieweF689make_mpeg_from_images(ctx,6,local+4); /*make-mpeg-from-images*/
	local[0]= w;
irtvieweBLK918:
	ctx->vsp=local; return(local[0]);}

/*:save-animgif*/
static pointer irtvieweM924irtviewer_save_animgif(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[163], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY926;
	local[0] = fqv[164];
irtvieweKEY926:
	if (n & (1<<1)) goto irtvieweKEY927;
	local[1] = makeint((eusinteger_t)5L);
irtvieweKEY927:
	if (n & (1<<2)) goto irtvieweKEY928;
	local[2] = T;
irtvieweKEY928:
	if (n & (1<<3)) goto irtvieweKEY929;
	local[3] = T;
irtvieweKEY929:
	if (n & (1<<4)) goto irtvieweKEY930;
	local[4] = T;
irtvieweKEY930:
	local[5]= argv[0];
	local[6]= fqv[70];
	local[7]= fqv[44];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= *(ovafptr(w,fqv[103]));
	local[6]= argv[0];
	local[7]= fqv[160];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (w!=NIL) goto irtvieweIF931;
	local[6]= argv[0];
	local[7]= fqv[92];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	goto irtvieweIF932;
irtvieweIF931:
	local[6]= NIL;
irtvieweIF932:
	local[6]= local[0];
	local[7]= argv[0];
	local[8]= fqv[160];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[161];
	local[9]= local[1];
	local[10]= fqv[165];
	local[11]= local[3];
	local[12]= fqv[162];
	local[13]= local[4];
	local[14]= fqv[166];
	local[15]= local[2];
	local[16]= fqv[167];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(*ftab[19])(ctx,1,local+17,&ftab[19],fqv[168]); /*float-vector-p*/
	if (w==NIL) goto irtvieweCON934;
	local[17]= NIL;
	local[18]= fqv[169];
	local[19]= makeint((eusinteger_t)255L);
	local[20]= makeint((eusinteger_t)1L);
	local[21]= local[5];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MIN(ctx,2,local+20); /*min*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ROUND(ctx,1,local+19); /*round*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)255L);
	local[21]= makeint((eusinteger_t)1L);
	local[22]= local[5];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MIN(ctx,2,local+21); /*min*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ROUND(ctx,1,local+20); /*round*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)255L);
	local[22]= makeint((eusinteger_t)1L);
	local[23]= local[5];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)MIN(ctx,2,local+22); /*min*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)ROUND(ctx,1,local+21); /*round*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,5,local+17); /*format*/
	local[17]= w;
	goto irtvieweCON933;
irtvieweCON934:
	local[17]= fqv[170];
	goto irtvieweCON933;
irtvieweCON935:
	local[17]= NIL;
irtvieweCON933:
	ctx->vsp=local+18;
	w=(pointer)irtvieweF690make_animgif_from_images(ctx,12,local+6); /*make-animgif-from-images*/
	local[0]= w;
irtvieweBLK925:
	ctx->vsp=local; return(local[0]);}

/*:save-animgif*/
static pointer irtvieweM936irtviewer_save_animgif(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[171], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY938;
	local[0] = fqv[172];
irtvieweKEY938:
	if (n & (1<<1)) goto irtvieweKEY939;
	local[1] = makeint((eusinteger_t)5L);
irtvieweKEY939:
	if (n & (1<<2)) goto irtvieweKEY940;
	local[2] = T;
irtvieweKEY940:
	if (n & (1<<3)) goto irtvieweKEY941;
	local[3] = T;
irtvieweKEY941:
	if (n & (1<<4)) goto irtvieweKEY942;
	local[4] = T;
irtvieweKEY942:
	local[5]= argv[0];
	local[6]= fqv[70];
	local[7]= fqv[44];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= *(ovafptr(w,fqv[103]));
	local[6]= argv[0];
	local[7]= fqv[160];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (w!=NIL) goto irtvieweIF943;
	local[6]= argv[0];
	local[7]= fqv[92];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	goto irtvieweIF944;
irtvieweIF943:
	local[6]= NIL;
irtvieweIF944:
	local[6]= local[0];
	local[7]= argv[0];
	local[8]= fqv[160];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[161];
	local[9]= local[1];
	local[10]= fqv[165];
	local[11]= local[3];
	local[12]= fqv[162];
	local[13]= local[4];
	local[14]= fqv[166];
	local[15]= local[2];
	local[16]= fqv[167];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(*ftab[19])(ctx,1,local+17,&ftab[19],fqv[168]); /*float-vector-p*/
	if (w==NIL) goto irtvieweCON946;
	local[17]= NIL;
	local[18]= fqv[173];
	local[19]= makeint((eusinteger_t)255L);
	local[20]= makeint((eusinteger_t)1L);
	local[21]= local[5];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MIN(ctx,2,local+20); /*min*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ROUND(ctx,1,local+19); /*round*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)255L);
	local[21]= makeint((eusinteger_t)1L);
	local[22]= local[5];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MIN(ctx,2,local+21); /*min*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ROUND(ctx,1,local+20); /*round*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)255L);
	local[22]= makeint((eusinteger_t)1L);
	local[23]= local[5];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)MIN(ctx,2,local+22); /*min*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)ROUND(ctx,1,local+21); /*round*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,5,local+17); /*format*/
	local[17]= w;
	goto irtvieweCON945;
irtvieweCON946:
	local[17]= fqv[174];
	goto irtvieweCON945;
irtvieweCON947:
	local[17]= NIL;
irtvieweCON945:
	ctx->vsp=local+18;
	w=(pointer)irtvieweF690make_animgif_from_images(ctx,12,local+6); /*make-animgif-from-images*/
	local[0]= w;
irtvieweBLK937:
	ctx->vsp=local; return(local[0]);}

/*:save-image*/
static pointer irtvieweM948irtviewer_save_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= fqv[44];
	local[3]= fqv[157];
	local[4]= fqv[22];
	local[5]= argv[0]->c.obj.iv[25];
	local[6]= fqv[44];
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= fqv[23];
	local[7]= argv[0]->c.obj.iv[25];
	local[8]= fqv[44];
	local[9]= fqv[23];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[117]); /*user::write-image-file*/
	local[0]= w;
irtvieweBLK949:
	ctx->vsp=local; return(local[0]);}

/*draw-things*/
static pointer irtvieweF691draw_things(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!!iscons(w)) goto irtvieweCON952;
	if (argv[0]!=NIL) goto irtvieweCON954;
	local[0]= NIL;
	goto irtvieweCON953;
irtvieweCON954:
	local[0]= argv[0];
	local[1]= fqv[175];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,2,local+0,&ftab[20],fqv[176]); /*find-method*/
	if (w==NIL) goto irtvieweCON955;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtvieweCON953;
irtvieweCON955:
	local[0]= argv[0];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,2,local+0,&ftab[20],fqv[176]); /*find-method*/
	if (w==NIL) goto irtvieweCON956;
	local[0]= argv[0];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtvieweCON953;
irtvieweCON956:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtvieweCON953;
irtvieweCON957:
	local[0]= NIL;
irtvieweCON953:
	goto irtvieweCON951;
irtvieweCON952:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)irtvieweF691draw_things(ctx,1,local+0); /*draw-things*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)irtvieweF691draw_things(ctx,1,local+1); /*draw-things*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	goto irtvieweCON951;
irtvieweCON958:
	local[0]= NIL;
irtvieweCON951:
	w = local[0];
	local[0]= w;
irtvieweBLK950:
	ctx->vsp=local; return(local[0]);}

/*:look*/
static pointer irtvieweM959viewing_look(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtvieweENT963;}
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtvieweENT963:
	if (n>=5) { local[1]=(argv[4]); goto irtvieweENT962;}
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
irtvieweENT962:
irtvieweENT961:
	if (n>5) maerror();
	local[2]= local[0];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,2,local+2); /*v-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VNORMALIZE(ctx,1,local+2); /*normalize-vector*/
	local[2]= w;
	local[3]= local[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+3); /*v**/
	local[3]= w;
	local[4]= NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)VNORM(ctx,1,local+5); /*norm*/
	local[5]= w;
	local[6]= loadglobal(fqv[178]);
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	if (w==NIL) goto irtvieweIF964;
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)-1L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+5); /*v**/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VNORMALIZE(ctx,1,local+5); /*normalize-vector*/
	local[4] = w;
	local[5]= local[4];
	goto irtvieweIF965;
irtvieweIF964:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)VNORMALIZE(ctx,1,local+5); /*normalize-vector*/
	local[4] = w;
	local[5]= local[4];
irtvieweIF965:
	local[5]= local[4];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+5); /*v**/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VNORMALIZE(ctx,1,local+5); /*normalize-vector*/
	local[1] = w;
	local[5]= makeflt(-1.0000000000000000000000e+00);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[2] = w;
	local[5]= loadglobal(fqv[179]);
	local[6]= local[4];
	local[7]= local[1];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)CONCATENATE(ctx,4,local+5); /*concatenate*/
	local[5]= w;
	local[6]= w;
	w = argv[0]->c.obj.iv[1];
	w->c.obj.iv[1] = local[6];
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,2,local+5); /*transpose*/
	local[5]= argv[0];
	local[6]= fqv[180];
	local[7]= argv[2];
	local[8]= fqv[181];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[74];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[0]= w;
irtvieweBLK960:
	ctx->vsp=local; return(local[0]);}

/*objects*/
static pointer irtvieweF692objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto irtvieweENT969;}
	local[0]= T;
irtvieweENT969:
	if (n>=2) { local[1]=(argv[1]); goto irtvieweENT968;}
	local[1]= NIL;
irtvieweENT968:
irtvieweENT967:
	if (n>2) maerror();
	if (local[0]==NIL) goto irtvieweIF970;
	local[2]= fqv[182];
	ctx->vsp=local+3;
	w=(pointer)BOUNDP(ctx,1,local+2); /*boundp*/
	if (w!=NIL) goto irtvieweIF970;
	if (local[1]!=NIL) goto irtvieweIF970;
	local[2]= fqv[183];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[65]); /*warn*/
	ctx->vsp=local+2;
	w=(pointer)irtvieweF693make_irtviewer(ctx,0,local+2); /*make-irtviewer*/
	local[2]= w;
	goto irtvieweIF971;
irtvieweIF970:
	local[2]= NIL;
irtvieweIF971:
	if (local[1]!=NIL) goto irtvieweIF972;
	local[1] = loadglobal(fqv[182]);
	local[2]= local[1];
	goto irtvieweIF973;
irtvieweIF972:
	local[2]= NIL;
irtvieweIF973:
	local[2]= NIL;
	local[3]= local[0];
	if (T!=local[3]) goto irtvieweIF974;
	local[3]= local[1];
	local[4]= fqv[184];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
	goto irtvieweIF975;
irtvieweIF974:
	local[3]= local[1];
	local[4]= fqv[184];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
irtvieweIF975:
	local[3]= local[1];
	local[4]= fqv[185];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	w = local[2];
	local[0]= w;
irtvieweBLK966:
	ctx->vsp=local; return(local[0]);}

/*make-irtviewer*/
static pointer irtvieweF693make_irtviewer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtvieweRST977:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	if (loadglobal(fqv[186])==NIL) goto irtvieweOR980;
	local[1]= loadglobal(fqv[186]);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w!=NIL) goto irtvieweOR980;
	goto irtvieweCON979;
irtvieweOR980:
	local[1]= makeint((eusinteger_t)1L);
	local[2]= fqv[187];
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,2,local+1,&ftab[8],fqv[85]); /*warning-message*/
	ctx->vsp=local+1;
	w=(pointer)irtvieweF694make_irtviewer_dummy(ctx,0,local+1); /*make-irtviewer-dummy*/
	local[1]= w;
	goto irtvieweCON978;
irtvieweCON979:
	local[1]= fqv[188];
	w = local[0];
	if (memq(local[1],w)==NIL) goto irtvieweCON981;
	ctx->vsp=local+1;
	w=(pointer)irtvieweF696make_irtviewer_no_window(ctx,0,local+1); /*make-irtviewer-no-window*/
	local[1]= w;
	goto irtvieweCON978;
irtvieweCON981:
	local[1]= (pointer)get_sym_func(fqv[12]);
	local[2]= loadglobal(fqv[189]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[21];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	storeglobal(fqv[182],w);
	goto irtvieweCON978;
irtvieweCON982:
	local[1]= NIL;
irtvieweCON978:
	w = loadglobal(fqv[182]);
	local[0]= w;
irtvieweBLK976:
	ctx->vsp=local; return(local[0]);}

/*:nomethod*/
static pointer irtvieweM983viewer_dummy_nomethod(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST985:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w = T;
	local[0]= w;
irtvieweBLK984:
	ctx->vsp=local; return(local[0]);}

/*:objects*/
static pointer irtvieweM986irtviewer_dummy_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST988:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto irtvieweIF989;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car!=NIL) goto irtvieweCON992;
	argv[0]->c.obj.iv[1] = NIL;
	local[1]= argv[0]->c.obj.iv[1];
	goto irtvieweCON991;
irtvieweCON992:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto irtvieweCON993;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[1] = (w)->c.cons.car;
	local[1]= argv[0]->c.obj.iv[1];
	goto irtvieweCON991;
irtvieweCON993:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtvieweCON994;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= argv[0]->c.obj.iv[1];
	goto irtvieweCON991;
irtvieweCON994:
	local[1]= NIL;
irtvieweCON991:
	goto irtvieweIF990;
irtvieweIF989:
	local[1]= NIL;
irtvieweIF990:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)irtvieweF691draw_things(ctx,1,local+1); /*x::draw-things*/
	argv[0]->c.obj.iv[2] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtvieweBLK987:
	ctx->vsp=local; return(local[0]);}

/*:nomethod*/
static pointer irtvieweM995irtviewer_dummy_nomethod(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST997:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w = T;
	local[0]= w;
irtvieweBLK996:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtvieweM998irtviewer_no_window_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST1000:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[189]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0];
	local[0]= w;
irtvieweBLK999:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer irtvieweM1001irtviewer_no_window_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST1003:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[12]);
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= fqv[21];
	local[4]= fqv[190];
	local[5]= NIL;
	local[6]= fqv[191];
	local[7]= T;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,8,local+1); /*apply*/
	local[0]= w;
irtvieweBLK1002:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer irtvieweM1004irtviewer_no_window_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[70];
	local[2]= fqv[44];
	local[3]= fqv[56];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[70];
	local[2]= fqv[44];
	local[3]= fqv[57];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[70];
	local[2]= fqv[44];
	local[3]= fqv[58];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[2];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)MAX(ctx,2,local+0); /*max*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[70];
	local[3]= fqv[59];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[56];
	local[3]= fqv[22];
	local[4]= local[0];
	local[5]= fqv[23];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= fqv[60];
	local[8]= argv[2];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= fqv[61];
	local[10]= argv[3];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,10,local+1); /*send*/
	local[0]= argv[0];
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtvieweBLK1005:
	ctx->vsp=local; return(local[0]);}

/*:nomethod*/
static pointer irtvieweM1006irtviewer_no_window_nomethod(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST1008:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[12]);
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[0]= w;
irtvieweBLK1007:
	ctx->vsp=local; return(local[0]);}

/*make-irtviewer-dummy*/
static pointer irtvieweF694make_irtviewer_dummy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtvieweRST1010:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= makeint((eusinteger_t)1L);
	local[2]= fqv[192];
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,2,local+1,&ftab[8],fqv[85]); /*warning-message*/
	local[1]= loadglobal(fqv[193]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	storeglobal(fqv[182],w);
	local[1]= loadglobal(fqv[194]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	storeglobal(fqv[33],w);
	local[1]= loadglobal(fqv[33]);
	local[2]= loadglobal(fqv[182]);
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	w = loadglobal(fqv[182]);
	local[0]= w;
irtvieweBLK1009:
	ctx->vsp=local; return(local[0]);}

/*geometry::default-pixmapsurface*/
static pointer irtvieweF695geometry__default_pixmapsurface(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtvieweRST1012:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[12]);
	local[2]= loadglobal(fqv[195]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[21];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
irtvieweBLK1011:
	ctx->vsp=local; return(local[0]);}

/*make-irtviewer-no-window*/
static pointer irtvieweF696make_irtviewer_no_window(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtvieweRST1014:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[196];
	local[2]= fqv[197];
	ctx->vsp=local+3;
	w=(pointer)SYMFUNC(ctx,1,local+2); /*symbol-function*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[197];
	local[2]= fqv[198];
	ctx->vsp=local+3;
	w=(pointer)SYMFUNC(ctx,1,local+2); /*symbol-function*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= loadglobal(fqv[199]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[200];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	local[1]= w;
	storeglobal(fqv[182],w);
	local[1]= (pointer)get_sym_func(fqv[12]);
	local[2]= loadglobal(fqv[182]);
	local[3]= fqv[21];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= fqv[197];
	local[2]= fqv[196];
	ctx->vsp=local+3;
	w=(pointer)SYMFUNC(ctx,1,local+2); /*symbol-function*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	w = loadglobal(fqv[182]);
	local[0]= w;
irtvieweBLK1013:
	ctx->vsp=local; return(local[0]);}

/*with-save-mpeg*/
static pointer irtvieweF1015(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtvieweRST1017:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[201];
	local[2]= fqv[202];
	local[3]= fqv[12];
	local[4]= fqv[182];
	local[5]= fqv[153];
	local[6]= fqv[154];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[12];
	local[5]= fqv[182];
	local[6]= fqv[153];
	local[7]= fqv[155];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[0];
	local[6]= fqv[12];
	local[7]= fqv[182];
	local[8]= fqv[203];
	local[9]= fqv[204];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[12];
	local[8]= fqv[182];
	local[9]= fqv[153];
	local[10]= fqv[205];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtvieweBLK1016:
	ctx->vsp=local; return(local[0]);}

/*with-save-animgif*/
static pointer irtvieweF1018(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtvieweRST1020:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[201];
	local[2]= fqv[202];
	local[3]= fqv[12];
	local[4]= fqv[182];
	local[5]= fqv[153];
	local[6]= fqv[154];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[12];
	local[5]= fqv[182];
	local[6]= fqv[153];
	local[7]= fqv[155];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[0];
	local[6]= fqv[12];
	local[7]= fqv[182];
	local[8]= fqv[206];
	local[9]= fqv[204];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[12];
	local[8]= fqv[182];
	local[9]= fqv[153];
	local[10]= fqv[205];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtvieweBLK1019:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtviewer(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[207];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtvieweIF1021;
	local[0]= fqv[208];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[209],w);
	goto irtvieweIF1022;
irtvieweIF1021:
	local[0]= fqv[210];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtvieweIF1022:
	ctx->vsp=local+0;
	compfun(ctx,fqv[211],module,irtvieweF688make_lr_ud_coords,fqv[212]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM698geometry_viewer_draw_circle,fqv[213],fqv[214],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM714geometry_viewer_draw_objects,fqv[14],fqv[214],fqv[216]);
	local[0]= fqv[42];
	local[1]= fqv[217];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto irtvieweIF1023;
	local[0]= fqv[42];
	local[1]= fqv[217];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[42];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto irtvieweIF1025;
	local[0]= fqv[42];
	local[1]= fqv[218];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto irtvieweIF1026;
irtvieweIF1025:
	local[0]= NIL;
irtvieweIF1026:
	local[0]= fqv[42];
	goto irtvieweIF1024;
irtvieweIF1023:
	local[0]= NIL;
irtvieweIF1024:
	local[0]= fqv[189];
	local[1]= fqv[218];
	local[2]= fqv[189];
	local[3]= fqv[219];
	local[4]= loadglobal(fqv[220]);
	local[5]= fqv[221];
	local[6]= fqv[222];
	local[7]= fqv[223];
	local[8]= NIL;
	local[9]= fqv[224];
	local[10]= NIL;
	local[11]= fqv[225];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[226];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[227]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM717irtviewer_create,fqv[21],fqv[189],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM732irtviewer_viewer,fqv[70],fqv[189],fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM735irtviewer_redraw,fqv[62],fqv[189],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM737irtviewer_expose,fqv[231],fqv[189],fqv[232]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM739irtviewer_resize,fqv[56],fqv[189],fqv[233]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM741irtviewer_configurenotify,fqv[234],fqv[189],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM748irtviewer_viewtarget,fqv[86],fqv[189],fqv[236]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM754irtviewer_viewpoint,fqv[69],fqv[189],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM760irtviewer_look1,fqv[53],fqv[189],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM768irtviewer_look_all,fqv[185],fqv[189],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM781irtviewer_move_viewing_around_viewtarget,fqv[91],fqv[189],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM796irtviewer_set_cursor_pos_event,fqv[49],fqv[189],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM798irtviewer_move_coords_event,fqv[51],fqv[189],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM802irtviewer_draw_event,fqv[47],fqv[189],fqv[243]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM804irtviewer_draw_objects,fqv[14],fqv[189],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM809irtviewer_objects,fqv[184],fqv[189],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM818irtviewer_select_drawmode,fqv[246],fqv[189],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM829irtviewer_flush,fqv[11],fqv[189],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM833irtviewer_change_background,fqv[249],fqv[189],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM835irtviewer_draw_origin,fqv[94],fqv[189],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM841irtviewer_draw_floor,fqv[95],fqv[189],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM847irtviewer_floor_color,fqv[96],fqv[189],fqv[253]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[254],module,irtvieweF689make_mpeg_from_images,fqv[255]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[256],module,irtvieweF690make_animgif_from_images,fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM897irtviewer_logging,fqv[153],fqv[189],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM909irtviewer_clear_log,fqv[259],fqv[189],fqv[260]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM911irtviewer_push_image,fqv[92],fqv[189],fqv[261]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM913irtviewer_clear_image_sequence,fqv[150],fqv[189],fqv[262]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM915irtviewer_image_sequence,fqv[160],fqv[189],fqv[263]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM917irtviewer_save_mpeg,fqv[203],fqv[189],fqv[264]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM924irtviewer_save_animgif,fqv[206],fqv[189],fqv[265]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM936irtviewer_save_animgif,fqv[206],fqv[189],fqv[266]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM948irtviewer_save_image,fqv[267],fqv[189],fqv[268]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[269],module,irtvieweF691draw_things,fqv[270]);
	local[0]= fqv[271];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtvieweIF1027;
	local[0]= fqv[272];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[209],w);
	goto irtvieweIF1028;
irtvieweIF1027:
	local[0]= fqv[273];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtvieweIF1028:
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM959viewing_look,fqv[72],fqv[274],fqv[275]);
	local[0]= fqv[276];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtvieweIF1029;
	local[0]= fqv[277];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[209],w);
	goto irtvieweIF1030;
irtvieweIF1029:
	local[0]= fqv[278];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtvieweIF1030:
	ctx->vsp=local+0;
	compfun(ctx,fqv[279],module,irtvieweF692objects,fqv[280]);
	local[0]= fqv[281];
	ctx->vsp=local+1;
	w=(pointer)PROCLAIM(ctx,1,local+0); /*proclaim*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[282],module,irtvieweF693make_irtviewer,fqv[283]);
	local[0]= fqv[194];
	local[1]= fqv[218];
	local[2]= fqv[194];
	local[3]= fqv[219];
	local[4]= loadglobal(fqv[284]);
	local[5]= fqv[221];
	local[6]= fqv[202];
	local[7]= fqv[223];
	local[8]= NIL;
	local[9]= fqv[224];
	local[10]= NIL;
	local[11]= fqv[225];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[226];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[227]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM983viewer_dummy_nomethod,fqv[285],fqv[194],fqv[286]);
	local[0]= fqv[193];
	local[1]= fqv[218];
	local[2]= fqv[193];
	local[3]= fqv[219];
	local[4]= loadglobal(fqv[284]);
	local[5]= fqv[221];
	local[6]= fqv[287];
	local[7]= fqv[223];
	local[8]= NIL;
	local[9]= fqv[224];
	local[10]= NIL;
	local[11]= fqv[225];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[226];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[227]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM986irtviewer_dummy_objects,fqv[184],fqv[193],fqv[288]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM995irtviewer_dummy_nomethod,fqv[285],fqv[193],fqv[289]);
	local[0]= fqv[199];
	local[1]= fqv[218];
	local[2]= fqv[199];
	local[3]= fqv[219];
	local[4]= loadglobal(fqv[284]);
	local[5]= fqv[221];
	local[6]= fqv[290];
	local[7]= fqv[223];
	local[8]= NIL;
	local[9]= fqv[224];
	local[10]= NIL;
	local[11]= fqv[225];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[226];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[227]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM998irtviewer_no_window_init,fqv[200],fqv[199],fqv[291]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1001irtviewer_no_window_create,fqv[21],fqv[199],fqv[292]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1004irtviewer_no_window_resize,fqv[56],fqv[199],fqv[293]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1006irtviewer_no_window_nomethod,fqv[285],fqv[199],fqv[294]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[295],module,irtvieweF694make_irtviewer_dummy,fqv[296]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[198],module,irtvieweF695geometry__default_pixmapsurface,fqv[297]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[298],module,irtvieweF696make_irtviewer_no_window,fqv[299]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[300],module,irtvieweF1015,fqv[301]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[302],module,irtvieweF1018,fqv[303]);
	local[0]= fqv[304];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtvieweIF1031;
	local[0]= fqv[305];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[209],w);
	goto irtvieweIF1032;
irtvieweIF1031:
	local[0]= fqv[306];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtvieweIF1032:
	local[0]= fqv[307];
	local[1]= fqv[308];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[309]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<23; i++) ftab[i]=fcallx;
}

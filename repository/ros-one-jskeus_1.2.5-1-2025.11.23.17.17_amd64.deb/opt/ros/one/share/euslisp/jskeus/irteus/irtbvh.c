/* ./irtbvh.c :  entry=irtbvh */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sun Nov 23 17:09:44 UTC 2025) */
#include "eus.h"
#include "irtbvh.h"
#pragma init (register_irtbvh)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtbvh();
extern pointer build_quote_vector();
static int register_irtbvh()
  { add_module_initializer("___irtbvh", ___irtbvh);}

static pointer irtbvhF4487parse_bvh_sexp();
static pointer irtbvhF4488read_bvh();
static pointer irtbvhF4489make_bvh_robot_model();
static pointer irtbvhF4490bvh2eus();
static pointer irtbvhF4491load_mcd();
static pointer irtbvhF4492rikiya_bvh2eus();
static pointer irtbvhF4493cmu_bvh2eus();
static pointer irtbvhF4494tum_bvh2eus();
static pointer irtbvhF4495rikiya_file();
static pointer irtbvhF4496tum_kitchen_file();
static pointer irtbvhF4497cmu_mocap_file();

/*:init*/
static pointer irtbvhM4498bvh_link_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=8) maerror();
	local[0]= makeint((eusinteger_t)30L);
	local[1]= NIL;
	argv[0]->c.obj.iv[29] = argv[3];
	argv[0]->c.obj.iv[30] = argv[4];
	argv[0]->c.obj.iv[31] = argv[5];
	local[2]= local[0];
	local[3]= local[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,3,local+2,&ftab[0],fqv[0]); /*make-cube*/
	local[2]= w;
	local[3]= makeflt(9.9999999999999977795540e-02);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= fqv[1];
	local[7]= makeflt(5.9999999999999964472863e-01);
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[0])(ctx,5,local+3,&ftab[0],fqv[0]); /*make-cube*/
	local[3]= w;
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= makeflt(5.9999999999999964472863e-01);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[1])(ctx,2,local+4,&ftab[1],fqv[2]); /*make-cylinder*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[1] = w;
	local[2]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
irtbvhWHL4500:
	if (local[3]==NIL) goto irtbvhWHX4501;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[3];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	goto irtbvhWHL4500;
irtbvhWHX4501:
	local[4]= NIL;
irtbvhBLK4502:
	w = NIL;
	local[2]= NIL;
	local[3]= argv[7];
irtbvhWHL4503:
	if (local[3]==NIL) goto irtbvhWHX4504;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[4]); /*normalize-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,1,local+4); /*v-*/
	local[4]= w;
	local[5]= local[0];
	local[6]= makeflt(3.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)VNORM(ctx,1,local+6); /*norm*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,2,local+5,&ftab[1],fqv[2]); /*make-cylinder*/
	local[5]= w;
	local[6]= local[4];
	local[7]= fqv[5];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+6); /*v**/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,1,local+6,&ftab[2],fqv[4]); /*normalize-vector*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	local[9]= w;
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[6]); /*eps=*/
	if (w==NIL) goto irtbvhIF4506;
	local[6] = fqv[7];
	local[9]= local[6];
	goto irtbvhIF4507;
irtbvhIF4506:
	local[9]= NIL;
irtbvhIF4507:
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,0,local+9,&ftab[4],fqv[8]); /*make-coords*/
	local[9]= w;
	local[10]= fqv[9];
	local[11]= local[4];
	local[12]= fqv[10];
	ctx->vsp=local+13;
	w=(pointer)VINNERPRODUCT(ctx,2,local+11); /*v.*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,1,local+11,&ftab[5],fqv[11]); /*acos*/
	local[11]= w;
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[12];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[7] = w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)12L);
irtbvhWHL4508:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtbvhWHX4509;
	local[11]= local[7];
	local[12]= local[0];
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= makeflt(-6.2831853071795862319959e+00);
	local[14]= local[9];
	local[15]= makeflt(1.2000000000000000000000e+01);
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SIN(ctx,1,local+13); /*sin*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= local[0];
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= makeflt(-6.2831853071795862319959e+00);
	local[15]= local[9];
	local[16]= makeflt(1.2000000000000000000000e+01);
	ctx->vsp=local+17;
	w=(pointer)QUOTIENT(ctx,2,local+15); /*/*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)COS(ctx,1,local+14); /*cos*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TRANSFORM(ctx,2,local+11); /*transform*/
	local[11]= w;
	w = local[8];
	ctx->vsp=local+12;
	local[8] = cons(ctx,local[11],w);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtbvhWHL4508;
irtbvhWHX4509:
	local[11]= NIL;
irtbvhBLK4510:
	w = NIL;
	local[9]= local[8];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,2,local+9,&ftab[6],fqv[13]); /*make-prism*/
	local[5] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[3];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= local[1];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)NCONC(ctx,2,local+9); /*nconc*/
	local[1] = w;
	w = local[1];
	goto irtbvhWHL4503;
irtbvhWHX4504:
	local[4]= NIL;
irtbvhBLK4505:
	w = NIL;
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[14]));
	local[4]= fqv[15];
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,0,local+5,&ftab[7],fqv[16]); /*make-cascoords*/
	local[5]= w;
	local[6]= fqv[17];
	local[7]= local[1];
	local[8]= fqv[18];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SENDMESSAGE(ctx,8,local+2); /*send-message*/
	local[2]= argv[0]->c.obj.iv[29];
	local[3]= local[2];
	w = fqv[19];
	if (memq(local[3],w)==NIL) goto irtbvhIF4511;
	local[3]= argv[0];
	local[4]= fqv[17];
	local[5]= fqv[20];
	local[6]= fqv[21];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtbvhIF4512;
irtbvhIF4511:
	local[3]= local[2];
	w = fqv[22];
	if (memq(local[3],w)==NIL) goto irtbvhIF4513;
	local[3]= argv[0];
	local[4]= fqv[17];
	local[5]= fqv[20];
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtbvhIF4514;
irtbvhIF4513:
	if (T==NIL) goto irtbvhIF4515;
	local[3]= argv[0];
	local[4]= fqv[17];
	local[5]= fqv[20];
	local[6]= fqv[24];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtbvhIF4516;
irtbvhIF4515:
	local[3]= NIL;
irtbvhIF4516:
irtbvhIF4514:
irtbvhIF4512:
	w = local[3];
	local[2]= argv[0];
	local[3]= fqv[25];
	if (argv[6]==NIL) goto irtbvhIF4517;
	local[4]= argv[6];
	local[5]= fqv[26];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[30];
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	goto irtbvhIF4518;
irtbvhIF4517:
	local[4]= argv[0]->c.obj.iv[30];
irtbvhIF4518:
	local[5]= fqv[27];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	if (argv[6]==NIL) goto irtbvhIF4519;
	local[2]= argv[6];
	local[3]= fqv[3];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtbvhIF4520;
irtbvhIF4519:
	local[2]= NIL;
irtbvhIF4520:
	local[2]= argv[0];
	local[3]= fqv[28];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4499:
	ctx->vsp=local; return(local[0]);}

/*:type*/
static pointer irtbvhM4521bvh_link_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[29];
	local[0]= w;
irtbvhBLK4522:
	ctx->vsp=local; return(local[0]);}

/*:offset*/
static pointer irtbvhM4523bvh_link_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[30];
	local[0]= w;
irtbvhBLK4524:
	ctx->vsp=local; return(local[0]);}

/*:channels*/
static pointer irtbvhM4525bvh_link_channels(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[31];
	local[0]= w;
irtbvhBLK4526:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4527bvh_sphere_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4529:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[29], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtbvhKEY4530;
	local[3]= fqv[30];
	local[4]= fqv[31];
	local[5]= fqv[32];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[1] = w;
irtbvhKEY4530:
	if (n & (1<<1)) goto irtbvhKEY4531;
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(*ftab[8])(ctx,1,local+3,&ftab[8],fqv[33]); /*unit-matrix*/
	local[2] = w;
irtbvhKEY4531:
	argv[0]->c.obj.iv[15] = local[1];
	argv[0]->c.obj.iv[16] = local[2];
	local[3]= (pointer)get_sym_func(fqv[34]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[14]));
	local[6]= fqv[15];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	local[0]= w;
irtbvhBLK4528:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh*/
static pointer irtbvhM4532bvh_sphere_joint_joint_angle_bvh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4535;}
	local[0]= NIL;
irtbvhENT4535:
irtbvhENT4534:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[33]); /*unit-matrix*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtbvhBLK4533:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh-offset*/
static pointer irtbvhM4536bvh_sphere_joint_joint_angle_bvh_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4539;}
	local[0]= NIL;
irtbvhENT4539:
irtbvhENT4538:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtbvhBLK4537:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh-impl*/
static pointer irtbvhM4540bvh_sphere_joint_joint_angle_bvh_impl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	if (argv[2]==NIL) goto irtbvhIF4542;
	local[2]= loadglobal(fqv[36]);
	local[3]= (pointer)get_sym_func(fqv[37]);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[0] = w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[15];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+2); /*rotation-matrix*/
	local[1] = w;
	local[2]= local[1];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[15];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= T;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ROTMAT(ctx,5,local+2); /*rotate-matrix*/
	local[2]= local[1];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[15];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= T;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ROTMAT(ctx,5,local+2); /*rotate-matrix*/
	local[2]= argv[0];
	local[3]= fqv[38];
	local[4]= loadglobal(fqv[36]);
	local[5]= (pointer)get_sym_func(fqv[39]);
	local[6]= argv[3];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,1,local+6,&ftab[9],fqv[40]); /*matrix-log*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtbvhIF4543;
irtbvhIF4542:
	local[2]= NIL;
irtbvhIF4543:
	local[2]= loadglobal(fqv[41]);
	local[3]= (pointer)get_sym_func(fqv[39]);
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)TRANSPOSE(ctx,1,local+4); /*transpose*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= fqv[12];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,2,local+4); /*m**/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+6;
	w=(*ftab[10])(ctx,2,local+4,&ftab[10],fqv[42]); /*matrix-to-euler-angle*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[0]= w;
irtbvhBLK4541:
	ctx->vsp=local; return(local[0]);}

/*:axis-order*/
static pointer irtbvhM4544bvh_sphere_joint_axis_order(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[15];
	local[0]= w;
irtbvhBLK4545:
	ctx->vsp=local; return(local[0]);}

/*:bvh-offset-rotation*/
static pointer irtbvhM4546bvh_sphere_joint_bvh_offset_rotation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtbvhBLK4547:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4548bvh_6dof_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4550:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[43], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtbvhKEY4551;
	local[4]= fqv[31];
	local[5]= fqv[32];
	local[6]= fqv[30];
	local[7]= fqv[30];
	local[8]= fqv[31];
	local[9]= fqv[32];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,6,local+4); /*list*/
	local[1] = w;
irtbvhKEY4551:
	if (n & (1<<1)) goto irtbvhKEY4552;
	local[2] = NIL;
irtbvhKEY4552:
	if (n & (1<<2)) goto irtbvhKEY4553;
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[33]); /*unit-matrix*/
	local[3] = w;
irtbvhKEY4553:
	argv[0]->c.obj.iv[16] = local[1];
	if (local[2]==NIL) goto irtbvhIF4554;
	local[4]= local[2];
	goto irtbvhIF4555;
irtbvhIF4554:
	local[4]= makeflt(1.0000000000000000000000e+00);
irtbvhIF4555:
	argv[0]->c.obj.iv[15] = local[4];
	argv[0]->c.obj.iv[17] = local[3];
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[14]));
	local[7]= fqv[15];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,5,local+4); /*apply*/
	local[0]= w;
irtbvhBLK4549:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh*/
static pointer irtbvhM4556bvh_6dof_joint_joint_angle_bvh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4559;}
	local[0]= NIL;
irtbvhENT4559:
irtbvhENT4558:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[33]); /*unit-matrix*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtbvhBLK4557:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh-offset*/
static pointer irtbvhM4560bvh_6dof_joint_joint_angle_bvh_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4563;}
	local[0]= NIL;
irtbvhENT4563:
irtbvhENT4562:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtbvhBLK4561:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh-impl*/
static pointer irtbvhM4564bvh_6dof_joint_joint_angle_bvh_impl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	if (argv[2]==NIL) goto irtbvhIF4566;
	local[3]= loadglobal(fqv[36]);
	local[4]= (pointer)get_sym_func(fqv[37]);
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)6L);
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAP(ctx,3,local+3); /*map*/
	local[1] = w;
	local[3]= argv[0]->c.obj.iv[15];
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[2] = w;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[16];
	local[5]= makeint((eusinteger_t)5L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[0] = w;
	local[3]= local[0];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[16];
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= T;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)ROTMAT(ctx,5,local+3); /*rotate-matrix*/
	local[3]= local[0];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[16];
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= T;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)ROTMAT(ctx,5,local+3); /*rotate-matrix*/
	local[3]= argv[0];
	local[4]= fqv[38];
	local[5]= loadglobal(fqv[36]);
	local[6]= argv[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)TRANSFORM(ctx,2,local+6); /*transform*/
	local[6]= w;
	local[7]= loadglobal(fqv[41]);
	local[8]= (pointer)get_sym_func(fqv[39]);
	local[9]= argv[0]->c.obj.iv[17];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[9])(ctx,1,local+9,&ftab[9],fqv[40]); /*matrix-log*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAP(ctx,3,local+7); /*map*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,3,local+5); /*concatenate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtbvhIF4567;
irtbvhIF4566:
	local[3]= NIL;
irtbvhIF4567:
	local[3]= loadglobal(fqv[41]);
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)TRANSPOSE(ctx,1,local+4); /*transpose*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000208167e-03);
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= fqv[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TRANSFORM(ctx,2,local+4); /*transform*/
	local[4]= w;
	local[5]= loadglobal(fqv[41]);
	local[6]= (pointer)get_sym_func(fqv[39]);
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= fqv[12];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[16];
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)6L);
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,3,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[10])(ctx,2,local+7,&ftab[10],fqv[42]); /*matrix-to-euler-angle*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAP(ctx,3,local+5); /*map*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)CONCATENATE(ctx,3,local+3); /*concatenate*/
	local[0]= w;
irtbvhBLK4565:
	ctx->vsp=local; return(local[0]);}

/*:axis-order*/
static pointer irtbvhM4568bvh_6dof_joint_axis_order(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtbvhBLK4569:
	ctx->vsp=local; return(local[0]);}

/*:bvh-offset-rotation*/
static pointer irtbvhM4570bvh_6dof_joint_bvh_offset_rotation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
irtbvhBLK4571:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4572bvh_robot_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4574:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[44], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto irtbvhKEY4575;
	local[1] = NIL;
irtbvhKEY4575:
	if (n & (1<<1)) goto irtbvhKEY4576;
	local[2] = NIL;
irtbvhKEY4576:
	if (n & (1<<2)) goto irtbvhKEY4577;
	local[3] = NIL;
irtbvhKEY4577:
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[14]));
	local[7]= fqv[15];
	local[8]= fqv[45];
	ctx->vsp=local+9;
	w=(*ftab[7])(ctx,0,local+9,&ftab[7],fqv[16]); /*make-cascoords*/
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,7,local+4); /*apply*/
	local[4]= argv[0];
	local[5]= fqv[46];
	local[6]= local[1];
	local[7]= fqv[47];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	if (local[2]==NIL) goto irtbvhIF4578;
	local[4]= argv[0];
	local[5]= fqv[48];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtbvhIF4579;
irtbvhIF4578:
	local[4]= NIL;
irtbvhIF4579:
	local[4]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+5;
	w=(pointer)REVERSE(ctx,1,local+4); /*reverse*/
	argv[0]->c.obj.iv[8] = w;
	local[4]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+5;
	w=(pointer)REVERSE(ctx,1,local+4); /*reverse*/
	argv[0]->c.obj.iv[9] = w;
	local[4]= argv[0];
	local[5]= fqv[49];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4573:
	ctx->vsp=local; return(local[0]);}

/*:make-bvh-link*/
static pointer irtbvhM4580bvh_robot_model_make_bvh_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[50], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4582;
	local[0] = NIL;
irtbvhKEY4582:
	if (n & (1<<1)) goto irtbvhKEY4583;
	local[1] = NIL;
irtbvhKEY4583:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	if (local[1]!=NIL) goto irtbvhIF4584;
	local[1] = makeflt(1.0000000000000000000000e+00);
	local[8]= local[1];
	goto irtbvhIF4585;
irtbvhIF4584:
	local[8]= NIL;
irtbvhIF4585:
	local[8]= loadglobal(fqv[51]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[15];
	local[11]= local[3];
	local[12]= local[2];
	local[13]= local[4];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= local[0];
	ctx->vsp=local+16;
	local[16]= makeclosure(codevec,quotevec,irtbvhCLO4586,env,argv,local);
	local[17]= argv[2];
	ctx->vsp=local+18;
	w=(pointer)MAPCAR(ctx,2,local+16); /*mapcar*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,8,local+9); /*send*/
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	w = argv[0]->c.obj.iv[8];
	ctx->vsp=local+9;
	argv[0]->c.obj.iv[8] = cons(ctx,local[8],w);
	local[8]= local[2];
	local[9]= fqv[52];
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w!=NIL) goto irtbvhIF4587;
	local[8]= NIL;
	local[9]= local[2];
	local[10]= fqv[53];
	ctx->vsp=local+11;
	w=(pointer)EQ(ctx,2,local+9); /*eql*/
	if (w==NIL) goto irtbvhIF4589;
	local[9]= loadglobal(fqv[54]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[15];
	ctx->vsp=local+12;
	w=(*ftab[7])(ctx,0,local+12,&ftab[7],fqv[16]); /*make-cascoords*/
	local[12]= w;
	local[13]= fqv[18];
	local[14]= fqv[55];
	local[15]= fqv[17];
	local[16]= makeint((eusinteger_t)10L);
	local[17]= makeint((eusinteger_t)10L);
	local[18]= makeint((eusinteger_t)10L);
	ctx->vsp=local+19;
	w=(*ftab[0])(ctx,3,local+16,&ftab[0],fqv[0]); /*make-cube*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,7,local+10); /*send*/
	w = local[9];
	local[0] = w;
	local[9]= local[0];
	local[10]= fqv[3];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[3];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	goto irtbvhIF4590;
irtbvhIF4589:
	local[9]= NIL;
irtbvhIF4590:
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[9];
	if (fqv[56]!=local[10]) goto irtbvhIF4591;
	local[8] = loadglobal(fqv[57]);
	local[10]= local[8];
	goto irtbvhIF4592;
irtbvhIF4591:
	local[10]= local[9];
	if (fqv[58]!=local[10]) goto irtbvhIF4593;
	local[8] = loadglobal(fqv[59]);
	local[10]= local[8];
	goto irtbvhIF4594;
irtbvhIF4593:
	if (T==NIL) goto irtbvhIF4595;
	local[10]= makeint((eusinteger_t)1L);
	local[11]= fqv[60];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(*ftab[11])(ctx,3,local+10,&ftab[11],fqv[61]); /*warning-message*/
	local[10]= w;
	goto irtbvhIF4596;
irtbvhIF4595:
	local[10]= NIL;
irtbvhIF4596:
irtbvhIF4594:
irtbvhIF4592:
	w = local[10];
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[15];
	local[12]= fqv[18];
	local[13]= local[3];
	local[14]= fqv[62];
	local[15]= local[6];
	local[16]= fqv[63];
	local[17]= local[0];
	local[18]= fqv[64];
	local[19]= argv[0];
	local[20]= fqv[65];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= fqv[66];
	ctx->vsp=local+21;
	local[21]= makeclosure(codevec,quotevec,irtbvhCLO4597,env,argv,local);
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.cdr;
	local[23]= fqv[31];
	w = fqv[67];
	ctx->vsp=local+24;
	local[23]= cons(ctx,local[23],w);
	local[24]= fqv[32];
	w = fqv[68];
	ctx->vsp=local+25;
	local[24]= cons(ctx,local[24],w);
	local[25]= fqv[30];
	w = fqv[69];
	ctx->vsp=local+26;
	local[25]= cons(ctx,local[25],w);
	ctx->vsp=local+26;
	w=(pointer)LIST(ctx,4,local+22); /*list*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(*ftab[12])(ctx,2,local+21,&ftab[12],fqv[70]); /*reduce*/
	local[21]= w;
	local[22]= fqv[47];
	local[23]= local[1];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,14,local+10); /*send*/
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	w = argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	argv[0]->c.obj.iv[9] = cons(ctx,local[9],w);
	w = argv[0]->c.obj.iv[9];
	local[8]= w;
	goto irtbvhIF4588;
irtbvhIF4587:
	local[8]= NIL;
irtbvhIF4588:
	local[8]= NIL;
	local[9]= argv[2];
irtbvhWHL4598:
	if (local[9]==NIL) goto irtbvhWHX4599;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= argv[0];
	local[11]= fqv[46];
	local[12]= local[8];
	local[13]= fqv[71];
	local[14]= local[6];
	local[15]= fqv[47];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,7,local+10); /*send*/
	goto irtbvhWHL4598;
irtbvhWHX4599:
	local[10]= NIL;
irtbvhBLK4600:
	w = NIL;
	w = local[0];
	local[0]= w;
irtbvhBLK4581:
	ctx->vsp=local; return(local[0]);}

/*:angle-vector*/
static pointer irtbvhM4601bvh_robot_model_angle_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4605;}
	local[0]= NIL;
irtbvhENT4605:
	if (n>=4) { local[1]=(argv[3]); goto irtbvhENT4604;}
	local[1]= loadglobal(fqv[36]);
	local[2]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,1,local+2,&ftab[13],fqv[72]); /*calc-target-joint-dimension*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
irtbvhENT4604:
irtbvhENT4603:
	if (n>4) maerror();
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[9];
irtbvhWHL4606:
	if (local[5]==NIL) goto irtbvhWHX4607;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	if (local[0]==NIL) goto irtbvhIF4609;
	local[6]= local[4];
	local[7]= fqv[73];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[74]!=local[7]) goto irtbvhIF4611;
	local[7]= local[4];
	local[8]= fqv[38];
	local[9]= local[0];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtbvhIF4612;
irtbvhIF4611:
	local[7]= local[6];
	if (fqv[75]!=local[7]) goto irtbvhIF4613;
	local[7]= local[0];
	local[8]= local[2];
	local[9]= local[2];
	local[10]= local[4];
	local[11]= fqv[73];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	local[8]= local[4];
	local[9]= fqv[76];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[7]= w;
	goto irtbvhIF4614;
irtbvhIF4613:
	if (T==NIL) goto irtbvhIF4615;
	local[7]= local[4];
	local[8]= fqv[76];
	local[9]= local[0];
	local[10]= local[2];
	local[11]= local[2];
	local[12]= local[4];
	local[13]= fqv[73];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SUBSEQ(ctx,3,local+9); /*subseq*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtbvhIF4616;
irtbvhIF4615:
	local[7]= NIL;
irtbvhIF4616:
irtbvhIF4614:
irtbvhIF4612:
	w = local[7];
	local[6]= w;
	goto irtbvhIF4610;
irtbvhIF4609:
	local[6]= NIL;
irtbvhIF4610:
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[4];
	local[8]= fqv[73];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
irtbvhWHL4617:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtbvhWHX4618;
	local[8]= local[1];
	local[9]= local[2];
	local[10]= local[4];
	local[11]= fqv[76];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SETELT(ctx,3,local+8); /*setelt*/
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[2] = w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtbvhWHL4617;
irtbvhWHX4618:
	local[8]= NIL;
irtbvhBLK4619:
	w = NIL;
	goto irtbvhWHL4606;
irtbvhWHX4607:
	local[6]= NIL;
irtbvhBLK4608:
	w = NIL;
	w = local[1];
	local[0]= w;
irtbvhBLK4602:
	ctx->vsp=local; return(local[0]);}

/*:dump-joints*/
static pointer irtbvhM4620bvh_robot_model_dump_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[77], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4622;
	local[0] = makeint((eusinteger_t)0L);
irtbvhKEY4622:
	if (n & (1<<1)) goto irtbvhKEY4623;
	local[1] = loadglobal(fqv[78]);
irtbvhKEY4623:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,1,local+2,&ftab[14],fqv[79]); /*make-string*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)32L);
	ctx->vsp=local+4;
	w=(*ftab[15])(ctx,2,local+2,&ftab[15],fqv[80]); /*fill*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[2];
irtbvhWHL4624:
	if (local[7]==NIL) goto irtbvhWHX4625;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[81];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[3] = w;
	local[8]= local[6];
	local[9]= fqv[82];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[4] = w;
	local[8]= local[6];
	local[9]= fqv[83];
	local[10]= fqv[84];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[5] = w;
	local[8]= local[1];
	local[9]= fqv[85];
	local[10]= local[2];
	local[11]= local[6];
	local[12]= fqv[86];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,1,local+11,&ftab[16],fqv[87]); /*string-upcase*/
	local[11]= w;
	local[12]= local[6];
	local[13]= fqv[83];
	local[14]= fqv[18];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,5,local+8); /*format*/
	local[8]= local[1];
	local[9]= fqv[88];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= local[1];
	local[9]= fqv[89];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[3];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[3];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,6,local+8); /*format*/
	local[8]= local[1];
	local[9]= fqv[90];
	local[10]= local[2];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,4,local+8); /*format*/
	local[8]= NIL;
	local[9]= local[5];
irtbvhWHL4627:
	if (local[9]==NIL) goto irtbvhWHX4628;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= local[10];
	if (fqv[31]!=local[11]) goto irtbvhIF4630;
	local[11]= local[1];
	local[12]= fqv[91];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= w;
	goto irtbvhIF4631;
irtbvhIF4630:
	local[11]= local[10];
	if (fqv[32]!=local[11]) goto irtbvhIF4632;
	local[11]= local[1];
	local[12]= fqv[92];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= w;
	goto irtbvhIF4633;
irtbvhIF4632:
	local[11]= local[10];
	if (fqv[30]!=local[11]) goto irtbvhIF4634;
	local[11]= local[1];
	local[12]= fqv[93];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= w;
	goto irtbvhIF4635;
irtbvhIF4634:
	if (T==NIL) goto irtbvhIF4636;
	local[11]= local[1];
	local[12]= fqv[94];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
	goto irtbvhIF4637;
irtbvhIF4636:
	local[11]= NIL;
irtbvhIF4637:
irtbvhIF4635:
irtbvhIF4633:
irtbvhIF4631:
	w = local[11];
	goto irtbvhWHL4627;
irtbvhWHX4628:
	local[10]= NIL;
irtbvhBLK4629:
	w = NIL;
	local[8]= local[1];
	local[9]= fqv[95];
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,2,local+8); /*format*/
	local[8]= local[6];
	local[9]= fqv[96];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w==NIL) goto irtbvhIF4638;
	local[8]= argv[0];
	local[9]= fqv[97];
	local[10]= local[6];
	local[11]= fqv[96];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)REVERSE(ctx,1,local+10); /*reverse*/
	local[10]= w;
	local[11]= fqv[98];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[12]= w;
	local[13]= fqv[99];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,7,local+8); /*send*/
	local[8]= w;
	goto irtbvhIF4639;
irtbvhIF4638:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4640,env,argv,local);
	local[9]= local[6];
	local[10]= fqv[100];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[101]); /*find-if*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[81];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[1];
	local[11]= fqv[102];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= local[1];
	local[11]= fqv[103];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= local[1];
	local[11]= fqv[104];
	local[12]= local[2];
	local[13]= local[9];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[9];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= local[9];
	local[16]= makeint((eusinteger_t)2L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,6,local+10); /*format*/
	local[10]= local[1];
	local[11]= fqv[105];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[8]= w;
irtbvhIF4639:
	local[8]= local[1];
	local[9]= fqv[106];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	goto irtbvhWHL4624;
irtbvhWHX4625:
	local[8]= NIL;
irtbvhBLK4626:
	w = NIL;
	local[0]= w;
irtbvhBLK4621:
	ctx->vsp=local; return(local[0]);}

/*:dump-hierarchy*/
static pointer irtbvhM4641bvh_robot_model_dump_hierarchy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4644;}
	local[0]= loadglobal(fqv[78]);
irtbvhENT4644:
irtbvhENT4643:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= fqv[107];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= argv[0];
	local[2]= fqv[97];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[99];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= local[0];
	local[2]= fqv[108];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= local[0];
	local[2]= fqv[109];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= local[0];
	local[2]= fqv[110];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[0]= w;
irtbvhBLK4642:
	ctx->vsp=local; return(local[0]);}

/*:dump-motion*/
static pointer irtbvhM4645bvh_robot_model_dump_motion(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4648;}
	local[0]= loadglobal(fqv[78]);
irtbvhENT4648:
irtbvhENT4647:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[8];
irtbvhWHL4649:
	if (local[3]==NIL) goto irtbvhWHX4650;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= fqv[83];
	local[6]= fqv[111];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[1] = w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
irtbvhWHL4652:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtbvhWHX4653;
	local[6]= local[0];
	local[7]= fqv[112];
	local[8]= local[1];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtbvhWHL4652;
irtbvhWHX4653:
	local[6]= NIL;
irtbvhBLK4654:
	w = NIL;
	goto irtbvhWHL4649;
irtbvhWHX4650:
	local[4]= NIL;
irtbvhBLK4651:
	w = NIL;
	local[2]= local[0];
	local[3]= fqv[113];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[0]= w;
irtbvhBLK4646:
	ctx->vsp=local; return(local[0]);}

/*:copy-state-to*/
static pointer irtbvhM4655bvh_robot_model_copy_state_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1L);
	local[1]= fqv[114];
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,2,local+0,&ftab[11],fqv[61]); /*warning-message*/
	local[0]= w;
irtbvhBLK4656:
	ctx->vsp=local; return(local[0]);}

/*:fix-joint-angle*/
static pointer irtbvhM4657bvh_robot_model_fix_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	w = argv[6];
	local[0]= w;
irtbvhBLK4658:
	ctx->vsp=local; return(local[0]);}

/*:fix-joint-order*/
static pointer irtbvhM4659bvh_robot_model_fix_joint_order(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[2];
	local[0]= w;
irtbvhBLK4660:
	ctx->vsp=local; return(local[0]);}

/*:bvh-offset-rotate*/
static pointer irtbvhM4661bvh_robot_model_bvh_offset_rotate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)3L);
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[33]); /*unit-matrix*/
	local[0]= w;
irtbvhBLK4662:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4586(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[115];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[116]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4597(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,3,local+0,&ftab[19],fqv[117]); /*substitute*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4640(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[51]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*parse-bvh-sexp*/
static pointer irtbvhF4487parse_bvh_sexp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[118], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4664;
	local[0] = NIL;
irtbvhKEY4664:
	if (local[0]!=NIL) goto irtbvhIF4665;
	local[0] = makeflt(1.0000000000000000000000e+00);
	local[1]= local[0];
	goto irtbvhIF4666;
irtbvhIF4665:
	local[1]= NIL;
irtbvhIF4666:
	w = argv[0];
	if (!!iscons(w)) goto irtbvhIF4667;
	local[1]= argv[0];
	goto irtbvhIF4668;
irtbvhIF4667:
	local[1]= NIL;
	local[2]= NIL;
irtbvhWHL4669:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	if (local[1]==NIL) goto irtbvhWHX4670;
	local[3]= local[1];
	local[4]= local[3];
	w = fqv[119];
	if (memq(local[4],w)==NIL) goto irtbvhIF4672;
	local[4]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	local[6]= fqv[47];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)irtbvhF4487parse_bvh_sexp(ctx,3,local+5); /*parse-bvh-sexp*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
	goto irtbvhIF4673;
irtbvhIF4672:
	local[4]= local[3];
	if (fqv[115]!=local[4]) goto irtbvhIF4674;
	local[4]= local[1];
	local[5]= local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[6];
	local[6]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[7];
	local[7]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
	goto irtbvhIF4675;
irtbvhIF4674:
	local[4]= local[3];
	if (fqv[120]!=local[4]) goto irtbvhIF4676;
	local[4]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
irtbvhTAG4679:
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)SUB1(ctx,1,local+7); /*1-*/
	local[5] = w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto irtbvhIF4680;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)REVERSE(ctx,1,local+7); /*reverse*/
	ctx->vsp=local+7;
	local[5]=w;
	goto irtbvhBLK4678;
	goto irtbvhIF4681;
irtbvhIF4680:
	local[7]= NIL;
irtbvhIF4681:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[7];
	local[7]= w;
	w = local[6];
	ctx->vsp=local+8;
	local[6] = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	goto irtbvhTAG4679;
	w = NIL;
	local[5]= w;
irtbvhBLK4678:
	w = local[5];
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
	goto irtbvhIF4677;
irtbvhIF4676:
	if (T==NIL) goto irtbvhIF4682;
	w = local[1];
	if (!issymbol(w)) goto irtbvhIF4684;
	local[4]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	local[6]= fqv[47];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)irtbvhF4487parse_bvh_sexp(ctx,3,local+5); /*parse-bvh-sexp*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
	goto irtbvhIF4685;
irtbvhIF4684:
	local[4]= local[1];
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
irtbvhIF4685:
	goto irtbvhIF4683;
irtbvhIF4682:
	local[4]= NIL;
irtbvhIF4683:
irtbvhIF4677:
irtbvhIF4675:
irtbvhIF4673:
	w = local[4];
	goto irtbvhWHL4669;
irtbvhWHX4670:
	local[3]= NIL;
irtbvhBLK4671:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)REVERSE(ctx,1,local+3); /*reverse*/
	local[1]= w;
irtbvhIF4668:
	w = local[1];
	local[0]= w;
irtbvhBLK4663:
	ctx->vsp=local; return(local[0]);}

/*read-bvh*/
static pointer irtbvhF4488read_bvh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[121], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4687;
	local[0] = NIL;
irtbvhKEY4687:
	ctx->vsp=local+1;
	w=(*ftab[20])(ctx,0,local+1,&ftab[20],fqv[122]); /*copy-readtable*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	w = local[1];
	ctx->vsp=local+7;
	bindspecial(ctx,fqv[123],w);
	local[10]= makeint((eusinteger_t)35L);
	local[11]= makeint((eusinteger_t)59L);
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[124]); /*set-syntax-from-char*/
	local[10]= makeint((eusinteger_t)58L);
	local[11]= makeint((eusinteger_t)32L);
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[124]); /*set-syntax-from-char*/
	local[10]= makeint((eusinteger_t)125L);
	local[11]= makeint((eusinteger_t)41L);
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[124]); /*set-syntax-from-char*/
	local[10]= makeint((eusinteger_t)123L);
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtbvhCLO4688,env,argv,local);
	ctx->vsp=local+12;
	w=(pointer)SETMACROCH(ctx,2,local+10); /*set-macro-character*/
	local[10]= argv[0];
	local[11]= fqv[125];
	local[12]= fqv[126];
	ctx->vsp=local+13;
	w=(*ftab[22])(ctx,3,local+10,&ftab[22],fqv[127]); /*open*/
	local[10]= w;
	ctx->vsp=local+11;
	w = makeclosure(codevec,quotevec,irtbvhUWP4689,env,argv,local);
	local[11]=(pointer)(ctx->protfp); local[12]=w;
	ctx->protfp=(struct protectframe *)(local+11);
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[13]= NIL;
irtbvhTAG4691:
	local[14]= local[13];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)EQ(ctx,2,local+14); /*eql*/
	if (w!=NIL) goto irtbvhOR4694;
	local[14]= local[13];
	local[15]= fqv[128];
	ctx->vsp=local+16;
	w=(pointer)EQ(ctx,2,local+14); /*eql*/
	if (w!=NIL) goto irtbvhOR4694;
	goto irtbvhIF4692;
irtbvhOR4694:
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)NREVERSE(ctx,1,local+14); /*nreverse*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[3];
	ctx->vsp=local+14;
	local[13]=w;
	goto irtbvhBLK4690;
	goto irtbvhIF4693;
irtbvhIF4692:
	local[14]= NIL;
irtbvhIF4693:
	local[14]= local[13];
	w = local[3];
	ctx->vsp=local+15;
	local[3] = cons(ctx,local[14],w);
	local[14]= local[10];
	local[15]= NIL;
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)READ(ctx,3,local+14); /*read*/
	local[13] = w;
	ctx->vsp=local+14;
	goto irtbvhTAG4691;
	w = NIL;
	local[13]= w;
irtbvhBLK4690:
	local[13]= local[3];
	local[14]= fqv[47];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)irtbvhF4487parse_bvh_sexp(ctx,3,local+13); /*parse-bvh-sexp*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[5] = w;
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[6] = w;
	local[13]= fqv[129];
	w = local[13];
	ctx->vsp=local+13;
	bindspecial(ctx,fqv[130],w);
irtbvhTAG4696:
	if (loadglobal(fqv[130])!=NIL) goto irtbvhIF4697;
	w = NIL;
	ctx->vsp=local+16;
	unwind(ctx,local+13);
	local[13]=w;
	goto irtbvhBLK4695;
	goto irtbvhIF4698;
irtbvhIF4697:
	local[16]= NIL;
irtbvhIF4698:
	local[16]= NIL;
	local[17]= fqv[131];
	local[18]= loadglobal(fqv[130]);
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,3,local+16); /*format*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[23])(ctx,1,local+16,&ftab[23],fqv[132]); /*read-from-string*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)EVAL(ctx,1,local+16); /*eval*/
	local[16]= w;
	local[17]= local[16];
	ctx->vsp=local+18;
	w=(pointer)LENGTH(ctx,1,local+17); /*length*/
	local[17]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[17] <= (eusinteger_t)w) goto irtbvhIF4699;
	local[17]= local[16];
	w = local[4];
	ctx->vsp=local+18;
	local[4] = cons(ctx,local[17],w);
	local[17]= local[4];
	goto irtbvhIF4700;
irtbvhIF4699:
	local[17]= NIL;
irtbvhIF4700:
	w = local[17];
	local[16]= local[10];
	local[17]= NIL;
	local[18]= NIL;
	ctx->vsp=local+19;
	w=(pointer)READLINE(ctx,3,local+16); /*read-line*/
	local[16]= w;
	storeglobal(fqv[130],w);
	ctx->vsp=local+16;
	goto irtbvhTAG4696;
	local[16]= NIL;
	ctx->vsp=local+17;
	unbindx(ctx,1);
	w = local[16];
	local[13]= w;
irtbvhBLK4695:
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)NREVERSE(ctx,1,local+13); /*nreverse*/
	local[4] = w;
	local[13]= makeint((eusinteger_t)2L);
	local[14]= fqv[133];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(*ftab[11])(ctx,3,local+13,&ftab[11],fqv[61]); /*warning-message*/
	local[13]= makeint((eusinteger_t)2L);
	local[14]= fqv[134];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[11])(ctx,4,local+13,&ftab[11],fqv[61]); /*warning-message*/
	local[13]= fqv[135];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[136];
	local[15]= fqv[137];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	local[16]= fqv[138];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= local[4];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	irtbvhUWP4689(ctx,0,local+13,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[10]= w;
	ctx->vsp=local+11;
	unbindx(ctx,1);
	w = local[10];
	local[0]= w;
irtbvhBLK4686:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4688(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)125L);
	local[1]= argv[0];
	local[2]= T;
	ctx->vsp=local+3;
	w=(*ftab[24])(ctx,3,local+0,&ftab[24],fqv[139]); /*read-delimited-list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhUWP4689(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[10];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-bvh-robot-model*/
static pointer irtbvhF4489make_bvh_robot_model(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4702:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= loadglobal(fqv[140]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[141]);
	local[3]= local[1];
	local[4]= fqv[15];
	local[5]= fqv[142];
	local[6]= argv[0];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,6,local+2); /*apply*/
	w = local[1];
	local[0]= w;
irtbvhBLK4701:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4703motion_capture_data_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[143], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4705;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,0,local+2,&ftab[4],fqv[8]); /*make-coords*/
	local[0] = w;
irtbvhKEY4705:
	if (n & (1<<1)) goto irtbvhKEY4706;
	local[1] = NIL;
irtbvhKEY4706:
	local[2]= NIL;
	local[3]= argv[2];
	local[4]= fqv[47];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)irtbvhF4488read_bvh(ctx,3,local+3); /*read-bvh*/
	local[2] = w;
	local[3]= fqv[135];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[116]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= fqv[45];
	local[5]= local[0];
	local[6]= fqv[47];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)irtbvhF4489make_bvh_robot_model(ctx,5,local+3); /*make-bvh-robot-model*/
	argv[0]->c.obj.iv[2] = w;
	local[3]= fqv[136];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[116]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(*ftab[25])(ctx,1,local+3,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[3] = (w)->c.cons.car;
	argv[0]->c.obj.iv[1] = makeint((eusinteger_t)0L);
	w = argv[0];
	local[0]= w;
irtbvhBLK4704:
	ctx->vsp=local; return(local[0]);}

/*:model*/
static pointer irtbvhM4707motion_capture_data_model(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4709:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4708:
	ctx->vsp=local; return(local[0]);}

/*:animation*/
static pointer irtbvhM4710motion_capture_data_animation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4712:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4711:
	ctx->vsp=local; return(local[0]);}

/*:frame*/
static pointer irtbvhM4713motion_capture_data_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4716;}
	local[0]= NIL;
irtbvhENT4716:
irtbvhENT4715:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtbvhIF4717;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto irtbvhIF4718;
irtbvhIF4717:
	local[1]= NIL;
irtbvhIF4718:
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[146];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
irtbvhWHL4719:
	if (local[4]==NIL) goto irtbvhWHX4720;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[111];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= fqv[73];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[2] = w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	goto irtbvhWHL4719;
irtbvhWHX4720:
	local[5]= NIL;
irtbvhBLK4721:
	w = NIL;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtbvhBLK4714:
	ctx->vsp=local; return(local[0]);}

/*:frame-length*/
static pointer irtbvhM4722motion_capture_data_frame_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
irtbvhBLK4723:
	ctx->vsp=local; return(local[0]);}

/*:animate*/
static pointer irtbvhM4724motion_capture_data_animate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4726:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[147], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtbvhKEY4727;
	local[1] = makeint((eusinteger_t)0L);
irtbvhKEY4727:
	if (n & (1<<1)) goto irtbvhKEY4728;
	local[2] = makeint((eusinteger_t)1L);
irtbvhKEY4728:
	if (n & (1<<2)) goto irtbvhKEY4729;
	local[5]= argv[0];
	local[6]= fqv[148];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[3] = w;
irtbvhKEY4729:
	if (n & (1<<3)) goto irtbvhKEY4730;
	local[4] = makeint((eusinteger_t)20L);
irtbvhKEY4730:
	local[5]= argv[0];
	local[6]= fqv[149];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	{jmp_buf jb;
	w = fqv[150];
	ctx->vsp=local+5;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto irtbvhCAT4731;}
irtbvhWHL4732:
	if (T==NIL) goto irtbvhWHX4733;
	local[11]= argv[0];
	local[12]= fqv[149];
	local[13]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= loadglobal(fqv[151]);
	local[12]= fqv[152];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	local[12]= fqv[153];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= NIL;
	ctx->vsp=local+12;
	w=(*ftab[27])(ctx,0,local+12,&ftab[27],fqv[154]); /*objects*/
	local[12]= w;
irtbvhWHL4735:
	if (local[12]==NIL) goto irtbvhWHX4736;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.cdr;
	w = local[13];
	local[11] = w;
	local[13]= local[11];
	local[14]= loadglobal(fqv[140]);
	ctx->vsp=local+15;
	w=(pointer)DERIVEDP(ctx,2,local+13); /*derivedp*/
	if (w!=NIL) goto irtbvhIF4738;
	local[13]= local[11];
	local[14]= loadglobal(fqv[155]);
	ctx->vsp=local+15;
	w=(pointer)DERIVEDP(ctx,2,local+13); /*derivedp*/
	if (w==NIL) goto irtbvhIF4738;
	local[13]= argv[0];
	local[14]= fqv[156];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= fqv[157];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	goto irtbvhIF4739;
irtbvhIF4738:
	local[13]= NIL;
irtbvhIF4739:
	goto irtbvhWHL4735;
irtbvhWHX4736:
	local[13]= NIL;
irtbvhBLK4737:
	w = NIL;
	local[11]= argv[0]->c.obj.iv[1];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	argv[0]->c.obj.iv[1] = w;
	local[11]= argv[0]->c.obj.iv[1];
	local[12]= argv[0];
	local[13]= fqv[148];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto irtbvhIF4740;
	local[11]= fqv[150];
	w = NIL;
	ctx->vsp=local+12;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto irtbvhIF4741;
irtbvhIF4740:
	local[11]= NIL;
irtbvhIF4741:
	local[11]= loadglobal(fqv[158]);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	local[12]= makeflt(9.9999999999999969005032e-09);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[159]); /*select-stream*/
	if (w==NIL) goto irtbvhIF4742;
	local[11]= fqv[150];
	w = NIL;
	ctx->vsp=local+12;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto irtbvhIF4743;
irtbvhIF4742:
	local[11]= NIL;
irtbvhIF4743:
	if (local[4]==NIL) goto irtbvhIF4744;
	local[11]= makeint((eusinteger_t)1000L);
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[29])(ctx,1,local+11,&ftab[29],fqv[160]); /*unix:usleep*/
	local[11]= w;
	goto irtbvhIF4745;
irtbvhIF4744:
	local[11]= NIL;
irtbvhIF4745:
	ctx->vsp=local+11;
	w=(*ftab[30])(ctx,0,local+11,&ftab[30],fqv[161]); /*x::window-main-one*/
	goto irtbvhWHL4732;
irtbvhWHX4733:
	local[11]= NIL;
irtbvhBLK4734:
	w = local[11];
irtbvhCAT4731:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[0]= w;
irtbvhBLK4725:
	ctx->vsp=local; return(local[0]);}

/*bvh2eus*/
static pointer irtbvhF4490bvh2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4747:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[162], &argv[1], n-1, local+1, 1);
	if (n & (1<<0)) goto irtbvhKEY4748;
	local[1] = NIL;
irtbvhKEY4748:
	local[2]= NIL;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LISTP(ctx,1,local+3); /*listp*/
	if (w!=NIL) goto irtbvhIF4749;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[1] = w;
	local[3]= local[1];
	goto irtbvhIF4750;
irtbvhIF4749:
	local[3]= NIL;
irtbvhIF4750:
	local[3]= (pointer)get_sym_func(fqv[163]);
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,3,local+3); /*apply*/
	local[2] = w;
	local[3]= local[2];
	local[4]= fqv[156];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[27])(ctx,1,local+3,&ftab[27],fqv[154]); /*objects*/
	local[3]= local[2];
	local[4]= fqv[150];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	w = local[2];
	local[0]= w;
irtbvhBLK4746:
	ctx->vsp=local; return(local[0]);}

/*:init-end-coords*/
static pointer irtbvhM4751bvh_robot_model_init_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4753,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[13] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4754,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[14] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4755,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[15] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4756,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[16] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4757,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[18] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4758,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[17] = w;
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
irtbvhBLK4752:
	ctx->vsp=local; return(local[0]);}

/*:init-root-link*/
static pointer irtbvhM4759bvh_robot_model_init_root_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[27];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[19] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[28];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[20] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[29];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[21] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[30];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[22] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[31];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[24] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[32];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[23] = (w)->c.cons.car;
	w = argv[0]->c.obj.iv[23];
	local[0]= w;
irtbvhBLK4760:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4753(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4761;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[27];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4761:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4754(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4762;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[28];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4762:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4755(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4763;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[29];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4763:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4756(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4764;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[30];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4764:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4757(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4765;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[31];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4765:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4758(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4766;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[32];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4766:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4767rikiya_bvh_robot_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4769:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[34]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[14]));
	local[4]= fqv[15];
	local[5]= fqv[45];
	local[6]= fqv[165];
	local[7]= makeflt(1.5707963267948965579990e+00);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeflt(1.5707963267948965579990e+00);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[8]); /*make-coords*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[1]= fqv[166];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4770,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[169];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4771,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[170];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4772,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[171];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4773,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,4,local+1); /*list*/
	argv[0]->c.obj.iv[27] = w;
	local[1]= fqv[172];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4774,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[173];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4775,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[174];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4776,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[175];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4777,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,4,local+1); /*list*/
	argv[0]->c.obj.iv[28] = w;
	local[1]= fqv[176];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4778,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[177];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4779,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[178];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4780,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	argv[0]->c.obj.iv[29] = w;
	local[1]= fqv[179];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4781,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[180];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4782,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[181];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4783,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	argv[0]->c.obj.iv[30] = w;
	local[1]= fqv[182];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4784,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	argv[0]->c.obj.iv[31] = w;
	local[1]= fqv[183];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4785,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[184];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4786,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	argv[0]->c.obj.iv[32] = w;
	local[1]= argv[0];
	local[2]= fqv[185];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[186];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4768:
	ctx->vsp=local; return(local[0]);}

/*:larm-collar*/
static pointer irtbvhM4787rikiya_bvh_robot_model_larm_collar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4789:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4788:
	ctx->vsp=local; return(local[0]);}

/*:larm-shoulder*/
static pointer irtbvhM4790rikiya_bvh_robot_model_larm_shoulder(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4792:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4791:
	ctx->vsp=local; return(local[0]);}

/*:larm-elbow*/
static pointer irtbvhM4793rikiya_bvh_robot_model_larm_elbow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4795:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4794:
	ctx->vsp=local; return(local[0]);}

/*:larm-wrist*/
static pointer irtbvhM4796rikiya_bvh_robot_model_larm_wrist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4798:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4797:
	ctx->vsp=local; return(local[0]);}

/*:rarm-collar*/
static pointer irtbvhM4799rikiya_bvh_robot_model_rarm_collar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4801:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4800:
	ctx->vsp=local; return(local[0]);}

/*:rarm-shoulder*/
static pointer irtbvhM4802rikiya_bvh_robot_model_rarm_shoulder(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4804:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4803:
	ctx->vsp=local; return(local[0]);}

/*:rarm-elbow*/
static pointer irtbvhM4805rikiya_bvh_robot_model_rarm_elbow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4807:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4806:
	ctx->vsp=local; return(local[0]);}

/*:rarm-wrist*/
static pointer irtbvhM4808rikiya_bvh_robot_model_rarm_wrist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4810:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4809:
	ctx->vsp=local; return(local[0]);}

/*:lleg-crotch*/
static pointer irtbvhM4811rikiya_bvh_robot_model_lleg_crotch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4813:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[29];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4812:
	ctx->vsp=local; return(local[0]);}

/*:lleg-knee*/
static pointer irtbvhM4814rikiya_bvh_robot_model_lleg_knee(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4816:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[29];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4815:
	ctx->vsp=local; return(local[0]);}

/*:lleg-ankle*/
static pointer irtbvhM4817rikiya_bvh_robot_model_lleg_ankle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4819:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[29];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4818:
	ctx->vsp=local; return(local[0]);}

/*:rleg-crotch*/
static pointer irtbvhM4820rikiya_bvh_robot_model_rleg_crotch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4822:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[30];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4821:
	ctx->vsp=local; return(local[0]);}

/*:rleg-knee*/
static pointer irtbvhM4823rikiya_bvh_robot_model_rleg_knee(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4825:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[30];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4824:
	ctx->vsp=local; return(local[0]);}

/*:rleg-ankle*/
static pointer irtbvhM4826rikiya_bvh_robot_model_rleg_ankle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4828:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[30];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4827:
	ctx->vsp=local; return(local[0]);}

/*:torso-chest*/
static pointer irtbvhM4829rikiya_bvh_robot_model_torso_chest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4831:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[31];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4830:
	ctx->vsp=local; return(local[0]);}

/*:head-neck*/
static pointer irtbvhM4832rikiya_bvh_robot_model_head_neck(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4834:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[32];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4833:
	ctx->vsp=local; return(local[0]);}

/*:copy-joint-to*/
static pointer irtbvhM4835rikiya_bvh_robot_model_copy_joint_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	w = argv[4];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[187],w);
	if (n>=6) { local[3]=(argv[5]); goto irtbvhENT4838;}
	local[3]= makeint((eusinteger_t)1L);
irtbvhENT4838:
irtbvhENT4837:
	if (n>6) maerror();
	local[4]= argv[2];
	local[5]= NIL;
	local[6]= fqv[188];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(*ftab[32])(ctx,1,local+7,&ftab[32],fqv[189]); /*symbol-name*/
	local[7]= w;
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	local[6]= fqv[190];
	ctx->vsp=local+7;
	w=(pointer)INTERN(ctx,2,local+5); /*intern*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[33])(ctx,2,local+4,&ftab[33],fqv[191]); /*find-method*/
	if (w==NIL) goto irtbvhIF4839;
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= NIL;
	local[7]= fqv[192];
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= fqv[193];
	ctx->vsp=local+8;
	w=(pointer)INTERN(ctx,2,local+6); /*intern*/
	local[6]= w;
	local[7]= fqv[38];
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= argv[3];
	local[11]= loadglobal(fqv[187]);
	local[12]= fqv[83];
	local[13]= fqv[38];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto irtbvhIF4840;
irtbvhIF4839:
	local[4]= NIL;
irtbvhIF4840:
	local[4]= argv[2];
	local[5]= NIL;
	local[6]= fqv[194];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(*ftab[32])(ctx,1,local+7,&ftab[32],fqv[189]); /*symbol-name*/
	local[7]= w;
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	local[6]= fqv[195];
	ctx->vsp=local+7;
	w=(pointer)INTERN(ctx,2,local+5); /*intern*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[33])(ctx,2,local+4,&ftab[33],fqv[191]); /*find-method*/
	if (w==NIL) goto irtbvhIF4841;
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= NIL;
	local[7]= fqv[196];
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= fqv[197];
	ctx->vsp=local+8;
	w=(pointer)INTERN(ctx,2,local+6); /*intern*/
	local[6]= w;
	local[7]= fqv[38];
	local[8]= argv[0];
	local[9]= argv[3];
	local[10]= loadglobal(fqv[187]);
	local[11]= fqv[83];
	local[12]= fqv[38];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto irtbvhIF4842;
irtbvhIF4841:
	local[4]= NIL;
irtbvhIF4842:
	local[4]= argv[2];
	local[5]= NIL;
	local[6]= fqv[198];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(*ftab[32])(ctx,1,local+7,&ftab[32],fqv[189]); /*symbol-name*/
	local[7]= w;
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	local[6]= fqv[199];
	ctx->vsp=local+7;
	w=(pointer)INTERN(ctx,2,local+5); /*intern*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[33])(ctx,2,local+4,&ftab[33],fqv[191]); /*find-method*/
	if (w==NIL) goto irtbvhIF4843;
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= NIL;
	local[7]= fqv[200];
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= fqv[201];
	ctx->vsp=local+8;
	w=(pointer)INTERN(ctx,2,local+6); /*intern*/
	local[6]= w;
	local[7]= fqv[38];
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= argv[3];
	local[11]= loadglobal(fqv[187]);
	local[12]= fqv[83];
	local[13]= fqv[38];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto irtbvhIF4844;
irtbvhIF4843:
	local[4]= NIL;
irtbvhIF4844:
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
irtbvhBLK4836:
	ctx->vsp=local; return(local[0]);}

/*:copy-state-to*/
static pointer irtbvhM4845rikiya_bvh_robot_model_copy_state_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= fqv[202];
irtbvhWHL4847:
	if (local[2]==NIL) goto irtbvhWHX4848;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= NIL;
	local[4]= fqv[203];
	w = local[3];
	ctx->vsp=local+5;
	bindspecial(ctx,fqv[187],w);
irtbvhWHL4850:
	if (local[4]==NIL) goto irtbvhWHX4851;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	storeglobal(fqv[187],w);
	local[8]= fqv[204];
	ctx->vsp=local+9;
	w=(pointer)BOUNDP(ctx,1,local+8); /*boundp*/
	if (w==NIL) goto irtbvhIF4853;
	local[8]= argv[2];
	local[9]= loadglobal(fqv[204]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtbvhIF4853;
	local[8]= argv[0];
	local[9]= fqv[205];
	local[10]= argv[2];
	local[11]= local[1];
	local[12]= loadglobal(fqv[187]);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	local[8]= w;
	goto irtbvhIF4854;
irtbvhIF4853:
	local[8]= argv[0];
	local[9]= fqv[205];
	local[10]= argv[2];
	local[11]= local[1];
	local[12]= loadglobal(fqv[187]);
	local[13]= local[1];
	local[14]= local[13];
	if (fqv[206]!=local[14]) goto irtbvhIF4855;
	local[14]= makeint((eusinteger_t)-1L);
	goto irtbvhIF4856;
irtbvhIF4855:
	if (T==NIL) goto irtbvhIF4857;
	local[14]= makeint((eusinteger_t)1L);
	goto irtbvhIF4858;
irtbvhIF4857:
	local[14]= NIL;
irtbvhIF4858:
irtbvhIF4856:
	w = local[14];
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= w;
irtbvhIF4854:
	goto irtbvhWHL4850;
irtbvhWHX4851:
	local[8]= NIL;
irtbvhBLK4852:
	local[8]= NIL;
	ctx->vsp=local+9;
	unbindx(ctx,1);
	w = local[8];
	goto irtbvhWHL4847;
irtbvhWHX4848:
	local[3]= NIL;
irtbvhBLK4849:
	w = NIL;
	local[1]= NIL;
	local[2]= fqv[207];
irtbvhWHL4859:
	if (local[2]==NIL) goto irtbvhWHX4860;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= NIL;
	local[4]= fqv[208];
	w = local[3];
	ctx->vsp=local+5;
	bindspecial(ctx,fqv[187],w);
irtbvhWHL4862:
	if (local[4]==NIL) goto irtbvhWHX4863;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	storeglobal(fqv[187],w);
	local[8]= fqv[204];
	ctx->vsp=local+9;
	w=(pointer)BOUNDP(ctx,1,local+8); /*boundp*/
	if (w==NIL) goto irtbvhIF4865;
	local[8]= argv[2];
	local[9]= loadglobal(fqv[204]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtbvhIF4865;
	local[8]= argv[0];
	local[9]= fqv[205];
	local[10]= argv[2];
	local[11]= local[1];
	local[12]= loadglobal(fqv[187]);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	local[8]= w;
	goto irtbvhIF4866;
irtbvhIF4865:
	local[8]= argv[0];
	local[9]= fqv[205];
	local[10]= argv[2];
	local[11]= local[1];
	local[12]= loadglobal(fqv[187]);
	local[13]= local[1];
	local[14]= local[13];
	if (fqv[209]!=local[14]) goto irtbvhIF4867;
	local[14]= makeint((eusinteger_t)-1L);
	goto irtbvhIF4868;
irtbvhIF4867:
	if (T==NIL) goto irtbvhIF4869;
	local[14]= makeint((eusinteger_t)1L);
	goto irtbvhIF4870;
irtbvhIF4869:
	local[14]= NIL;
irtbvhIF4870:
irtbvhIF4868:
	w = local[14];
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= w;
irtbvhIF4866:
	goto irtbvhWHL4862;
irtbvhWHX4863:
	local[8]= NIL;
irtbvhBLK4864:
	local[8]= NIL;
	ctx->vsp=local+9;
	unbindx(ctx,1);
	w = local[8];
	goto irtbvhWHL4859;
irtbvhWHX4860:
	local[3]= NIL;
irtbvhBLK4861:
	w = NIL;
	local[1]= argv[0];
	local[2]= fqv[205];
	local[3]= argv[2];
	local[4]= fqv[210];
	local[5]= fqv[211];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[205];
	local[3]= argv[2];
	local[4]= fqv[212];
	local[5]= fqv[213];
	local[6]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[2];
	local[2]= fqv[214];
	local[3]= argv[0];
	local[4]= fqv[215];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[27];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtbvhBLK4846:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4770(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4771(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4772(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4773(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4774(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4775(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4776(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4777(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4778(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4779(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4780(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4781(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4782(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4783(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4784(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4785(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4786(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4871tum_bvh_robot_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4873:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[34]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[14]));
	local[4]= fqv[15];
	local[5]= fqv[45];
	local[6]= fqv[165];
	local[7]= makeflt(1.5707963267948965579990e+00);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[8]); /*make-coords*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[1]= fqv[216];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4874,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[217];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4875,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[218];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4876,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[219];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4877,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[220];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4878,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[27] = w;
	local[1]= fqv[221];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4879,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[222];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4880,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[223];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4881,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[224];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4882,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[225];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4883,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[28] = w;
	local[1]= fqv[226];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4884,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[227];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4885,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[228];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4886,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[229];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4887,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,4,local+1); /*list*/
	argv[0]->c.obj.iv[29] = w;
	local[1]= fqv[230];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4888,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[231];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4889,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[232];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4890,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[233];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4891,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,4,local+1); /*list*/
	argv[0]->c.obj.iv[30] = w;
	local[1]= fqv[234];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4892,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[235];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4893,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[236];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4894,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[237];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4895,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[238];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4896,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	local[6]= fqv[239];
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= fqv[167];
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtbvhCLO4897,env,argv,local);
	ctx->vsp=local+10;
	w=(*ftab[31])(ctx,4,local+6,&ftab[31],fqv[168]); /*find*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,6,local+1); /*list*/
	argv[0]->c.obj.iv[31] = w;
	local[1]= fqv[240];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4898,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[241];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4899,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	argv[0]->c.obj.iv[32] = w;
	local[1]= argv[0];
	local[2]= fqv[185];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[186];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4872:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4874(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4875(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4876(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4877(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4878(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4879(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4880(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4881(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4882(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4883(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4884(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4885(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4886(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4887(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4888(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4889(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4890(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4891(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4892(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4893(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4894(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4895(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4896(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4897(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4898(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4899(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4900cmu_bvh_robot_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4902:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[34]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[14]));
	local[4]= fqv[15];
	local[5]= fqv[45];
	local[6]= fqv[165];
	local[7]= makeflt(1.5707963267948965579990e+00);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeflt(1.5707963267948965579990e+00);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[8]); /*make-coords*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[1]= fqv[169];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4903,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[242];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4904,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[243];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4905,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[244];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4906,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[245];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4907,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[27] = w;
	local[1]= fqv[173];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4908,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[246];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4909,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[247];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4910,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[248];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4911,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[249];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4912,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[28] = w;
	local[1]= fqv[250];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4913,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[251];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4914,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[252];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4915,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[253];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4916,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[254];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4917,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[29] = w;
	local[1]= fqv[255];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4918,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[256];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4919,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[257];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4920,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[258];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4921,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[259];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4922,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[30] = w;
	local[1]= fqv[260];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4923,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[261];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4924,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[262];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4925,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	argv[0]->c.obj.iv[31] = w;
	local[1]= fqv[183];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4926,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[263];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4927,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[184];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4928,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	argv[0]->c.obj.iv[32] = w;
	local[1]= argv[0];
	local[2]= fqv[185];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[186];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4901:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4903(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4904(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4905(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4906(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4907(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4908(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4909(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4910(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4911(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4912(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4913(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4914(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4915(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4916(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4917(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4918(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4919(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4920(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4921(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4922(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4923(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4924(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4925(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4926(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4927(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4928(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*load-mcd*/
static pointer irtbvhF4491load_mcd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[264], &argv[1], n-1, local+0, 1);
	if (n & (1<<0)) goto irtbvhKEY4930;
	local[0] = NIL;
irtbvhKEY4930:
	if (n & (1<<1)) goto irtbvhKEY4931;
	local[1] = NIL;
irtbvhKEY4931:
	if (n & (1<<2)) goto irtbvhKEY4932;
	local[2] = loadglobal(fqv[140]);
irtbvhKEY4932:
	local[3]= local[2];
	w = local[3];
	ctx->vsp=local+4;
	bindspecial(ctx,fqv[140],w);
	local[7]= loadglobal(fqv[265]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[15];
	local[10]= argv[0];
	local[11]= fqv[45];
	local[12]= local[1];
	local[13]= fqv[47];
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,7,local+8); /*send*/
	w = local[7];
	local[7]= w;
	ctx->vsp=local+8;
	unbindx(ctx,1);
	w = local[7];
	local[0]= w;
irtbvhBLK4929:
	ctx->vsp=local; return(local[0]);}

/*rikiya-bvh2eus*/
static pointer irtbvhF4492rikiya_bvh2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4934:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[266]);
	local[2]= argv[0];
	local[3]= fqv[47];
	local[4]= makeflt(1.0000000000000000000000e+01);
	local[5]= fqv[267];
	local[6]= loadglobal(fqv[268]);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[0]= w;
irtbvhBLK4933:
	ctx->vsp=local; return(local[0]);}

/*cmu-bvh2eus*/
static pointer irtbvhF4493cmu_bvh2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4936:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[266]);
	local[2]= argv[0];
	local[3]= fqv[47];
	local[4]= makeflt(1.0000000000000000000000e+02);
	local[5]= fqv[267];
	local[6]= loadglobal(fqv[269]);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[0]= w;
irtbvhBLK4935:
	ctx->vsp=local; return(local[0]);}

/*tum-bvh2eus*/
static pointer irtbvhF4494tum_bvh2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4938:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[266]);
	local[2]= argv[0];
	local[3]= fqv[47];
	local[4]= makeflt(1.0000000000000000000000e+01);
	local[5]= fqv[267];
	local[6]= loadglobal(fqv[270]);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[0]= w;
irtbvhBLK4937:
	ctx->vsp=local; return(local[0]);}

/*rikiya-file*/
static pointer irtbvhF4495rikiya_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[271], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4940;
	local[0] = makeint((eusinteger_t)1L);
irtbvhKEY4940:
	if (n & (1<<1)) goto irtbvhKEY4941;
	local[1] = fqv[272];
irtbvhKEY4941:
	local[2]= NIL;
	local[3]= fqv[273];
	local[4]= fqv[274];
	ctx->vsp=local+5;
	w=(pointer)GETENV(ctx,1,local+4); /*unix:getenv*/
	local[4]= w;
	local[5]= local[1];
	local[6]= NIL;
	local[7]= fqv[275];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[16])(ctx,1,local+6,&ftab[16],fqv[87]); /*string-upcase*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,6,local+2); /*format*/
	local[0]= w;
irtbvhBLK4939:
	ctx->vsp=local; return(local[0]);}

/*tum-kitchen-file*/
static pointer irtbvhF4496tum_kitchen_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[276], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4943;
	local[0] = makeint((eusinteger_t)1L);
irtbvhKEY4943:
	if (n & (1<<1)) goto irtbvhKEY4944;
	local[1] = makeint((eusinteger_t)0L);
irtbvhKEY4944:
	local[2]= NIL;
	local[3]= fqv[277];
	local[4]= fqv[278];
	ctx->vsp=local+5;
	w=(pointer)GETENV(ctx,1,local+4); /*unix:getenv*/
	local[4]= w;
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,5,local+2); /*format*/
	local[0]= w;
irtbvhBLK4942:
	ctx->vsp=local; return(local[0]);}

/*cmu-mocap-file*/
static pointer irtbvhF4497cmu_mocap_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[279], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4946;
	local[0] = makeint((eusinteger_t)1L);
irtbvhKEY4946:
	if (n & (1<<1)) goto irtbvhKEY4947;
	local[1] = makeint((eusinteger_t)1L);
irtbvhKEY4947:
	local[2]= NIL;
	local[3]= fqv[280];
	local[4]= fqv[281];
	ctx->vsp=local+5;
	w=(pointer)GETENV(ctx,1,local+4); /*unix:getenv*/
	local[4]= w;
	local[5]= local[1];
	local[6]= local[1];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,6,local+2); /*format*/
	local[0]= w;
irtbvhBLK4945:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtbvh(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[282];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtbvhIF4948;
	local[0]= fqv[283];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[284],w);
	goto irtbvhIF4949;
irtbvhIF4948:
	local[0]= fqv[285];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtbvhIF4949:
	local[0]= fqv[51];
	local[1]= fqv[286];
	local[2]= fqv[51];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[54]);
	local[5]= fqv[288];
	local[6]= fqv[289];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4498bvh_link_init,fqv[15],fqv[51],fqv[295]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4521bvh_link_type,fqv[86],fqv[51],fqv[296]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4523bvh_link_offset,fqv[81],fqv[51],fqv[297]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4525bvh_link_channels,fqv[82],fqv[51],fqv[298]);
	local[0]= fqv[57];
	local[1]= fqv[286];
	local[2]= fqv[57];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[299]);
	local[5]= fqv[288];
	local[6]= fqv[300];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4527bvh_sphere_joint_init,fqv[15],fqv[57],fqv[301]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4532bvh_sphere_joint_joint_angle_bvh,fqv[111],fqv[57],fqv[302]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4536bvh_sphere_joint_joint_angle_bvh_offset,fqv[76],fqv[57],fqv[303]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4540bvh_sphere_joint_joint_angle_bvh_impl,fqv[35],fqv[57],fqv[304]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4544bvh_sphere_joint_axis_order,fqv[84],fqv[57],fqv[305]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4546bvh_sphere_joint_bvh_offset_rotation,fqv[64],fqv[57],fqv[306]);
	local[0]= fqv[59];
	local[1]= fqv[286];
	local[2]= fqv[59];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[307]);
	local[5]= fqv[288];
	local[6]= fqv[308];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4548bvh_6dof_joint_init,fqv[15],fqv[59],fqv[309]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4556bvh_6dof_joint_joint_angle_bvh,fqv[111],fqv[59],fqv[310]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4560bvh_6dof_joint_joint_angle_bvh_offset,fqv[76],fqv[59],fqv[311]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4564bvh_6dof_joint_joint_angle_bvh_impl,fqv[35],fqv[59],fqv[312]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4568bvh_6dof_joint_axis_order,fqv[84],fqv[59],fqv[313]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4570bvh_6dof_joint_bvh_offset_rotation,fqv[64],fqv[59],fqv[314]);
	local[0]= fqv[140];
	local[1]= fqv[286];
	local[2]= fqv[140];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[155]);
	local[5]= fqv[288];
	local[6]= fqv[315];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4572bvh_robot_model_init,fqv[15],fqv[140],fqv[316]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4580bvh_robot_model_make_bvh_link,fqv[46],fqv[140],fqv[317]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4601bvh_robot_model_angle_vector,fqv[318],fqv[140],fqv[319]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4620bvh_robot_model_dump_joints,fqv[97],fqv[140],fqv[320]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4641bvh_robot_model_dump_hierarchy,fqv[321],fqv[140],fqv[322]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4645bvh_robot_model_dump_motion,fqv[323],fqv[140],fqv[324]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4655bvh_robot_model_copy_state_to,fqv[157],fqv[140],fqv[325]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4657bvh_robot_model_fix_joint_angle,fqv[326],fqv[140],fqv[327]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4659bvh_robot_model_fix_joint_order,fqv[328],fqv[140],fqv[329]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4661bvh_robot_model_bvh_offset_rotate,fqv[65],fqv[140],fqv[330]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[331],module,irtbvhF4487parse_bvh_sexp,fqv[332]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[333],module,irtbvhF4488read_bvh,fqv[334]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[335],module,irtbvhF4489make_bvh_robot_model,fqv[336]);
	local[0]= fqv[265];
	local[1]= fqv[286];
	local[2]= fqv[265];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[337]);
	local[5]= fqv[288];
	local[6]= fqv[338];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4703motion_capture_data_init,fqv[15],fqv[265],fqv[339]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4707motion_capture_data_model,fqv[156],fqv[265],fqv[340]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4710motion_capture_data_animation,fqv[341],fqv[265],fqv[342]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4713motion_capture_data_frame,fqv[149],fqv[265],fqv[343]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4722motion_capture_data_frame_length,fqv[148],fqv[265],fqv[344]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4724motion_capture_data_animate,fqv[150],fqv[265],fqv[345]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[266],module,irtbvhF4490bvh2eus,fqv[346]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4751bvh_robot_model_init_end_coords,fqv[185],fqv[140],fqv[347]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4759bvh_robot_model_init_root_link,fqv[186],fqv[140],fqv[348]);
	local[0]= fqv[268];
	local[1]= fqv[286];
	local[2]= fqv[268];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[140]);
	local[5]= fqv[288];
	local[6]= fqv[315];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4767rikiya_bvh_robot_model_init,fqv[15],fqv[268],fqv[349]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4787rikiya_bvh_robot_model_larm_collar,fqv[350],fqv[268],fqv[351]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4790rikiya_bvh_robot_model_larm_shoulder,fqv[352],fqv[268],fqv[353]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4793rikiya_bvh_robot_model_larm_elbow,fqv[354],fqv[268],fqv[355]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4796rikiya_bvh_robot_model_larm_wrist,fqv[356],fqv[268],fqv[357]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4799rikiya_bvh_robot_model_rarm_collar,fqv[358],fqv[268],fqv[359]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4802rikiya_bvh_robot_model_rarm_shoulder,fqv[360],fqv[268],fqv[361]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4805rikiya_bvh_robot_model_rarm_elbow,fqv[362],fqv[268],fqv[363]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4808rikiya_bvh_robot_model_rarm_wrist,fqv[364],fqv[268],fqv[365]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4811rikiya_bvh_robot_model_lleg_crotch,fqv[366],fqv[268],fqv[367]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4814rikiya_bvh_robot_model_lleg_knee,fqv[368],fqv[268],fqv[369]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4817rikiya_bvh_robot_model_lleg_ankle,fqv[370],fqv[268],fqv[371]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4820rikiya_bvh_robot_model_rleg_crotch,fqv[372],fqv[268],fqv[373]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4823rikiya_bvh_robot_model_rleg_knee,fqv[374],fqv[268],fqv[375]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4826rikiya_bvh_robot_model_rleg_ankle,fqv[376],fqv[268],fqv[377]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4829rikiya_bvh_robot_model_torso_chest,fqv[378],fqv[268],fqv[379]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4832rikiya_bvh_robot_model_head_neck,fqv[380],fqv[268],fqv[381]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4835rikiya_bvh_robot_model_copy_joint_to,fqv[205],fqv[268],fqv[382]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4845rikiya_bvh_robot_model_copy_state_to,fqv[157],fqv[268],fqv[383]);
	local[0]= fqv[270];
	local[1]= fqv[286];
	local[2]= fqv[270];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[140]);
	local[5]= fqv[288];
	local[6]= fqv[315];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4871tum_bvh_robot_model_init,fqv[15],fqv[270],fqv[384]);
	local[0]= fqv[269];
	local[1]= fqv[286];
	local[2]= fqv[269];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[140]);
	local[5]= fqv[288];
	local[6]= fqv[315];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4900cmu_bvh_robot_model_init,fqv[15],fqv[269],fqv[385]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[163],module,irtbvhF4491load_mcd,fqv[386]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[387],module,irtbvhF4492rikiya_bvh2eus,fqv[388]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[389],module,irtbvhF4493cmu_bvh2eus,fqv[390]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[391],module,irtbvhF4494tum_bvh2eus,fqv[392]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[393],module,irtbvhF4495rikiya_file,fqv[394]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[395],module,irtbvhF4496tum_kitchen_file,fqv[396]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[397],module,irtbvhF4497cmu_mocap_file,fqv[398]);
	local[0]= fqv[399];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtbvhIF4950;
	local[0]= fqv[400];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[284],w);
	goto irtbvhIF4951;
irtbvhIF4950:
	local[0]= fqv[401];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtbvhIF4951:
	local[0]= fqv[402];
	local[1]= fqv[403];
	ctx->vsp=local+2;
	w=(*ftab[35])(ctx,2,local+0,&ftab[35],fqv[404]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<36; i++) ftab[i]=fcallx;
}

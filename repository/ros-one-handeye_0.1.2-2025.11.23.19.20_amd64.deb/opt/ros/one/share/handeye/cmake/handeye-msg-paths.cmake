# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${handeye_DIR}/.." "" handeye_MSG_INCLUDE_DIRS UNIQUE)
set(handeye_MSG_DEPENDENCIES geometry_msgs;std_msgs)

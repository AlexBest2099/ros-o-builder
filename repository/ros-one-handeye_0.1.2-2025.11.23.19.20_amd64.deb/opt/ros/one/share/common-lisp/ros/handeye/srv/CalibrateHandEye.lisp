; Auto-generated. Do not edit!


(cl:in-package handeye-srv)


;//! \htmlinclude CalibrateHandEye-request.msg.html

(cl:defclass <CalibrateHandEye-request> (roslisp-msg-protocol:ros-message)
  ((setup
    :reader setup
    :initarg :setup
    :type cl:string
    :initform "")
   (solver
    :reader solver
    :initarg :solver
    :type cl:string
    :initform "")
   (effector_wrt_world
    :reader effector_wrt_world
    :initarg :effector_wrt_world
    :type geometry_msgs-msg:PoseArray
    :initform (cl:make-instance 'geometry_msgs-msg:PoseArray))
   (object_wrt_sensor
    :reader object_wrt_sensor
    :initarg :object_wrt_sensor
    :type geometry_msgs-msg:PoseArray
    :initform (cl:make-instance 'geometry_msgs-msg:PoseArray)))
)

(cl:defclass CalibrateHandEye-request (<CalibrateHandEye-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CalibrateHandEye-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CalibrateHandEye-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name handeye-srv:<CalibrateHandEye-request> is deprecated: use handeye-srv:CalibrateHandEye-request instead.")))

(cl:ensure-generic-function 'setup-val :lambda-list '(m))
(cl:defmethod setup-val ((m <CalibrateHandEye-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader handeye-srv:setup-val is deprecated.  Use handeye-srv:setup instead.")
  (setup m))

(cl:ensure-generic-function 'solver-val :lambda-list '(m))
(cl:defmethod solver-val ((m <CalibrateHandEye-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader handeye-srv:solver-val is deprecated.  Use handeye-srv:solver instead.")
  (solver m))

(cl:ensure-generic-function 'effector_wrt_world-val :lambda-list '(m))
(cl:defmethod effector_wrt_world-val ((m <CalibrateHandEye-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader handeye-srv:effector_wrt_world-val is deprecated.  Use handeye-srv:effector_wrt_world instead.")
  (effector_wrt_world m))

(cl:ensure-generic-function 'object_wrt_sensor-val :lambda-list '(m))
(cl:defmethod object_wrt_sensor-val ((m <CalibrateHandEye-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader handeye-srv:object_wrt_sensor-val is deprecated.  Use handeye-srv:object_wrt_sensor instead.")
  (object_wrt_sensor m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CalibrateHandEye-request>) ostream)
  "Serializes a message object of type '<CalibrateHandEye-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'setup))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'setup))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'solver))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'solver))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'effector_wrt_world) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'object_wrt_sensor) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CalibrateHandEye-request>) istream)
  "Deserializes a message object of type '<CalibrateHandEye-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'setup) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'setup) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'solver) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'solver) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'effector_wrt_world) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'object_wrt_sensor) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CalibrateHandEye-request>)))
  "Returns string type for a service object of type '<CalibrateHandEye-request>"
  "handeye/CalibrateHandEyeRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CalibrateHandEye-request)))
  "Returns string type for a service object of type 'CalibrateHandEye-request"
  "handeye/CalibrateHandEyeRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CalibrateHandEye-request>)))
  "Returns md5sum for a message object of type '<CalibrateHandEye-request>"
  "04f81db812e7be5af7dacdfd384d6a48")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CalibrateHandEye-request)))
  "Returns md5sum for a message object of type 'CalibrateHandEye-request"
  "04f81db812e7be5af7dacdfd384d6a48")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CalibrateHandEye-request>)))
  "Returns full string definition for message of type '<CalibrateHandEye-request>"
  (cl:format cl:nil "string                    setup~%string                    solver~%geometry_msgs/PoseArray   effector_wrt_world~%geometry_msgs/PoseArray   object_wrt_sensor~%~%================================================================================~%MSG: geometry_msgs/PoseArray~%# An array of poses with a header for global reference.~%~%Header header~%~%Pose[] poses~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CalibrateHandEye-request)))
  "Returns full string definition for message of type 'CalibrateHandEye-request"
  (cl:format cl:nil "string                    setup~%string                    solver~%geometry_msgs/PoseArray   effector_wrt_world~%geometry_msgs/PoseArray   object_wrt_sensor~%~%================================================================================~%MSG: geometry_msgs/PoseArray~%# An array of poses with a header for global reference.~%~%Header header~%~%Pose[] poses~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CalibrateHandEye-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'setup))
     4 (cl:length (cl:slot-value msg 'solver))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'effector_wrt_world))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'object_wrt_sensor))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CalibrateHandEye-request>))
  "Converts a ROS message object to a list"
  (cl:list 'CalibrateHandEye-request
    (cl:cons ':setup (setup msg))
    (cl:cons ':solver (solver msg))
    (cl:cons ':effector_wrt_world (effector_wrt_world msg))
    (cl:cons ':object_wrt_sensor (object_wrt_sensor msg))
))
;//! \htmlinclude CalibrateHandEye-response.msg.html

(cl:defclass <CalibrateHandEye-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (sensor_frame
    :reader sensor_frame
    :initarg :sensor_frame
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (rotation_rmse
    :reader rotation_rmse
    :initarg :rotation_rmse
    :type cl:float
    :initform 0.0)
   (translation_rmse
    :reader translation_rmse
    :initarg :translation_rmse
    :type cl:float
    :initform 0.0))
)

(cl:defclass CalibrateHandEye-response (<CalibrateHandEye-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CalibrateHandEye-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CalibrateHandEye-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name handeye-srv:<CalibrateHandEye-response> is deprecated: use handeye-srv:CalibrateHandEye-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <CalibrateHandEye-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader handeye-srv:success-val is deprecated.  Use handeye-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'sensor_frame-val :lambda-list '(m))
(cl:defmethod sensor_frame-val ((m <CalibrateHandEye-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader handeye-srv:sensor_frame-val is deprecated.  Use handeye-srv:sensor_frame instead.")
  (sensor_frame m))

(cl:ensure-generic-function 'rotation_rmse-val :lambda-list '(m))
(cl:defmethod rotation_rmse-val ((m <CalibrateHandEye-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader handeye-srv:rotation_rmse-val is deprecated.  Use handeye-srv:rotation_rmse instead.")
  (rotation_rmse m))

(cl:ensure-generic-function 'translation_rmse-val :lambda-list '(m))
(cl:defmethod translation_rmse-val ((m <CalibrateHandEye-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader handeye-srv:translation_rmse-val is deprecated.  Use handeye-srv:translation_rmse instead.")
  (translation_rmse m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CalibrateHandEye-response>) ostream)
  "Serializes a message object of type '<CalibrateHandEye-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'sensor_frame) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'rotation_rmse))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'translation_rmse))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CalibrateHandEye-response>) istream)
  "Deserializes a message object of type '<CalibrateHandEye-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'sensor_frame) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'rotation_rmse) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'translation_rmse) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CalibrateHandEye-response>)))
  "Returns string type for a service object of type '<CalibrateHandEye-response>"
  "handeye/CalibrateHandEyeResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CalibrateHandEye-response)))
  "Returns string type for a service object of type 'CalibrateHandEye-response"
  "handeye/CalibrateHandEyeResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CalibrateHandEye-response>)))
  "Returns md5sum for a message object of type '<CalibrateHandEye-response>"
  "04f81db812e7be5af7dacdfd384d6a48")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CalibrateHandEye-response)))
  "Returns md5sum for a message object of type 'CalibrateHandEye-response"
  "04f81db812e7be5af7dacdfd384d6a48")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CalibrateHandEye-response>)))
  "Returns full string definition for message of type '<CalibrateHandEye-response>"
  (cl:format cl:nil "bool                      success~%# For a Moving setup, sensor_frame contains:~%# The estimated pose between the sensor and the robot end-effector~%# For a Fixed setup, sensor_frame contains:~%# The estimated pose between the sensor and the world~%geometry_msgs/Pose        sensor_frame~%float64                   rotation_rmse~%float64                   translation_rmse~%~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CalibrateHandEye-response)))
  "Returns full string definition for message of type 'CalibrateHandEye-response"
  (cl:format cl:nil "bool                      success~%# For a Moving setup, sensor_frame contains:~%# The estimated pose between the sensor and the robot end-effector~%# For a Fixed setup, sensor_frame contains:~%# The estimated pose between the sensor and the world~%geometry_msgs/Pose        sensor_frame~%float64                   rotation_rmse~%float64                   translation_rmse~%~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CalibrateHandEye-response>))
  (cl:+ 0
     1
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'sensor_frame))
     8
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CalibrateHandEye-response>))
  "Converts a ROS message object to a list"
  (cl:list 'CalibrateHandEye-response
    (cl:cons ':success (success msg))
    (cl:cons ':sensor_frame (sensor_frame msg))
    (cl:cons ':rotation_rmse (rotation_rmse msg))
    (cl:cons ':translation_rmse (translation_rmse msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'CalibrateHandEye)))
  'CalibrateHandEye-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'CalibrateHandEye)))
  'CalibrateHandEye-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CalibrateHandEye)))
  "Returns string type for a service object of type '<CalibrateHandEye>"
  "handeye/CalibrateHandEye")
/* ./irtmodel.c :  entry=irtmodel */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "irtmodel.h"
#pragma init (register_irtmodel)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtmodel();
extern pointer build_quote_vector();
static int register_irtmodel()
  { add_module_initializer("___irtmodel", ___irtmodel);}

static pointer irtmodelF743calc_jacobian_default_rotate_vector();
static pointer irtmodelF744calc_jacobian_rotational();
static pointer irtmodelF745calc_jacobian_linear();
static pointer irtmodelF746calc_angle_speed_gain_scalar();
static pointer irtmodelF747calc_angle_speed_gain_vector();
static pointer irtmodelF748all_child_links();
static pointer irtmodelF749calc_dif_with_axis();
static pointer irtmodelF750calc_target_joint_dimension();
static pointer irtmodelF751calc_joint_angle_min_max_for_limit_calculation();
static pointer irtmodelF752joint_angle_limit_weight();
static pointer irtmodelF753joint_angle_limit_nspace();
static pointer irtmodelF754calc_jacobian_from_link_list_including_robot_and_obj_virtual_joint();
static pointer irtmodelF755append_obj_virtual_joint();
static pointer irtmodelF756append_multiple_obj_virtual_joint();
static pointer irtmodelF757eusmodel_validity_check_one();
static pointer irtmodelF758eusmodel_validity_check();

/*:init*/
static pointer irtmodelM759joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto irtmodelKEY761;
	local[9]= NIL;
	local[10]= fqv[1];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)ADDRESS(ctx,1,local+11); /*system:address*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,3,local+9); /*format*/
	local[9]= w;
	local[10]= fqv[2];
	ctx->vsp=local+11;
	w=(pointer)INTERN(ctx,2,local+9); /*intern*/
	local[0] = w;
irtmodelKEY761:
	if (n & (1<<1)) goto irtmodelKEY762;
	local[1] = NIL;
irtmodelKEY762:
	if (n & (1<<2)) goto irtmodelKEY763;
	local[2] = NIL;
irtmodelKEY763:
	if (n & (1<<3)) goto irtmodelKEY764;
	local[3] = makeint((eusinteger_t)-90L);
irtmodelKEY764:
	if (n & (1<<4)) goto irtmodelKEY765;
	local[4] = makeint((eusinteger_t)90L);
irtmodelKEY765:
	if (n & (1<<5)) goto irtmodelKEY766;
	local[5] = NIL;
irtmodelKEY766:
	if (n & (1<<6)) goto irtmodelKEY767;
	local[6] = NIL;
irtmodelKEY767:
	if (n & (1<<7)) goto irtmodelKEY768;
	local[7] = NIL;
irtmodelKEY768:
	if (n & (1<<8)) goto irtmodelKEY769;
	local[8] = NIL;
irtmodelKEY769:
	local[9]= argv[0];
	local[10]= fqv[3];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	argv[0]->c.obj.iv[1] = local[2];
	argv[0]->c.obj.iv[2] = local[1];
	argv[0]->c.obj.iv[4] = local[3];
	argv[0]->c.obj.iv[5] = local[4];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelAND773;
	local[9]= local[5];
	local[10]= loadglobal(fqv[5]);
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VGREATERP(ctx,2,local+9); /*v>*/
	if (w!=NIL) goto irtmodelAND773;
	goto irtmodelOR772;
irtmodelAND773:
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w!=NIL) goto irtmodelAND774;
	local[9]= local[5];
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto irtmodelAND774;
	goto irtmodelOR772;
irtmodelAND774:
	goto irtmodelIF770;
irtmodelOR772:
	local[9]= fqv[6];
	local[10]= local[0];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SIGERROR(ctx,3,local+9); /*error*/
	local[9]= w;
	goto irtmodelIF771;
irtmodelIF770:
	local[9]= NIL;
irtmodelIF771:
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelAND778;
	local[9]= local[6];
	local[10]= loadglobal(fqv[5]);
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VGREATERP(ctx,2,local+9); /*v>*/
	if (w!=NIL) goto irtmodelAND778;
	goto irtmodelOR777;
irtmodelAND778:
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w!=NIL) goto irtmodelAND779;
	local[9]= local[6];
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto irtmodelAND779;
	goto irtmodelOR777;
irtmodelAND779:
	goto irtmodelIF775;
irtmodelOR777:
	local[9]= fqv[7];
	local[10]= local[0];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SIGERROR(ctx,3,local+9); /*error*/
	local[9]= w;
	goto irtmodelIF776;
irtmodelIF775:
	local[9]= NIL;
irtmodelIF776:
	local[9]= argv[0];
	local[10]= fqv[8];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[9];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[10];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[11];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= fqv[12];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	argv[0]->c.obj.iv[6] = w;
	w = argv[0];
	local[0]= w;
irtmodelBLK760:
	ctx->vsp=local; return(local[0]);}

/*:min-angle*/
static pointer irtmodelM780joint_min_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT783;}
	local[0]= NIL;
irtmodelENT783:
irtmodelENT782:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF784;
	argv[0]->c.obj.iv[4] = local[0];
	local[1]= argv[0]->c.obj.iv[4];
	goto irtmodelIF785;
irtmodelIF784:
	local[1]= NIL;
irtmodelIF785:
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
irtmodelBLK781:
	ctx->vsp=local; return(local[0]);}

/*:max-angle*/
static pointer irtmodelM786joint_max_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT789;}
	local[0]= NIL;
irtmodelENT789:
irtmodelENT788:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF790;
	argv[0]->c.obj.iv[5] = local[0];
	local[1]= argv[0]->c.obj.iv[5];
	goto irtmodelIF791;
irtmodelIF790:
	local[1]= NIL;
irtmodelIF791:
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
irtmodelBLK787:
	ctx->vsp=local; return(local[0]);}

/*:parent-link*/
static pointer irtmodelM792joint_parent_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST794:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[13]); /*forward-message-to*/
	local[0]= w;
irtmodelBLK793:
	ctx->vsp=local; return(local[0]);}

/*:child-link*/
static pointer irtmodelM795joint_child_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST797:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[13]); /*forward-message-to*/
	local[0]= w;
irtmodelBLK796:
	ctx->vsp=local; return(local[0]);}

/*:calc-dav-gain*/
static pointer irtmodelM798joint_calc_dav_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= fqv[14];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK799:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM800joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[16];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK801:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM802joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST804:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[17];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK803:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM805joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST807:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[18];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK806:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM808joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST810:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[19];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK809:
	ctx->vsp=local; return(local[0]);}

/*:joint-velocity*/
static pointer irtmodelM811joint_joint_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT814;}
	local[0]= NIL;
irtmodelENT814:
irtmodelENT813:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF815;
	argv[0]->c.obj.iv[7] = local[0];
	local[1]= argv[0]->c.obj.iv[7];
	goto irtmodelIF816;
irtmodelIF815:
	local[1]= argv[0]->c.obj.iv[7];
irtmodelIF816:
	w = local[1];
	local[0]= w;
irtmodelBLK812:
	ctx->vsp=local; return(local[0]);}

/*:joint-acceleration*/
static pointer irtmodelM817joint_joint_acceleration(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT820;}
	local[0]= NIL;
irtmodelENT820:
irtmodelENT819:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF821;
	argv[0]->c.obj.iv[8] = local[0];
	local[1]= argv[0]->c.obj.iv[8];
	goto irtmodelIF822;
irtmodelIF821:
	local[1]= argv[0]->c.obj.iv[8];
irtmodelIF822:
	w = local[1];
	local[0]= w;
irtmodelBLK818:
	ctx->vsp=local; return(local[0]);}

/*:joint-torque*/
static pointer irtmodelM823joint_joint_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT826;}
	local[0]= NIL;
irtmodelENT826:
irtmodelENT825:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF827;
	argv[0]->c.obj.iv[9] = local[0];
	local[1]= argv[0]->c.obj.iv[9];
	goto irtmodelIF828;
irtmodelIF827:
	local[1]= argv[0]->c.obj.iv[9];
irtmodelIF828:
	w = local[1];
	local[0]= w;
irtmodelBLK824:
	ctx->vsp=local; return(local[0]);}

/*:max-joint-velocity*/
static pointer irtmodelM829joint_max_joint_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT832;}
	local[0]= NIL;
irtmodelENT832:
irtmodelENT831:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF833;
	argv[0]->c.obj.iv[10] = local[0];
	local[1]= argv[0]->c.obj.iv[10];
	goto irtmodelIF834;
irtmodelIF833:
	local[1]= argv[0]->c.obj.iv[10];
irtmodelIF834:
	w = local[1];
	local[0]= w;
irtmodelBLK830:
	ctx->vsp=local; return(local[0]);}

/*:max-joint-torque*/
static pointer irtmodelM835joint_max_joint_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT838;}
	local[0]= NIL;
irtmodelENT838:
irtmodelENT837:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF839;
	argv[0]->c.obj.iv[11] = local[0];
	local[1]= argv[0]->c.obj.iv[11];
	goto irtmodelIF840;
irtmodelIF839:
	local[1]= argv[0]->c.obj.iv[11];
irtmodelIF840:
	w = local[1];
	local[0]= w;
irtmodelBLK836:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-table*/
static pointer irtmodelM841joint_joint_min_max_table(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT844;}
	local[0]= NIL;
irtmodelENT844:
irtmodelENT843:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF845;
	argv[0]->c.obj.iv[12] = local[0];
	local[1]= argv[0]->c.obj.iv[12];
	goto irtmodelIF846;
irtmodelIF845:
	local[1]= argv[0]->c.obj.iv[12];
irtmodelIF846:
	w = local[1];
	local[0]= w;
irtmodelBLK842:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-target*/
static pointer irtmodelM847joint_joint_min_max_target(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT850;}
	local[0]= NIL;
irtmodelENT850:
irtmodelENT849:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF851;
	argv[0]->c.obj.iv[13] = local[0];
	local[1]= argv[0]->c.obj.iv[13];
	goto irtmodelIF852;
irtmodelIF851:
	local[1]= argv[0]->c.obj.iv[13];
irtmodelIF852:
	w = local[1];
	local[0]= w;
irtmodelBLK848:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-table-angle-interpolate*/
static pointer irtmodelM853joint_joint_min_max_table_angle_interpolate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)FLOOR(ctx,1,local+0); /*floor*/
	local[0]= w;
	local[1]= local[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO855,env,argv,local);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)EUSFLOAT(ctx,1,local+4); /*float*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[0]= w;
irtmodelBLK854:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-table-min-angle*/
static pointer irtmodelM856joint_joint_min_max_table_min_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT859;}
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtmodelENT859:
irtmodelENT858:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[21];
	local[3]= local[0];
	local[4]= fqv[22];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtmodelBLK857:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-table-max-angle*/
static pointer irtmodelM860joint_joint_min_max_table_max_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT863;}
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtmodelENT863:
irtmodelENT862:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[21];
	local[3]= local[0];
	local[4]= fqv[23];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtmodelBLK861:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO855(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[12];
	local[1]= env->c.clo.env1[3];
	local[2]= local[1];
	if (fqv[22]!=local[2]) goto irtmodelIF864;
	local[2]= makeint((eusinteger_t)1L);
	goto irtmodelIF865;
irtmodelIF864:
	local[2]= local[1];
	if (fqv[23]!=local[2]) goto irtmodelIF866;
	local[2]= makeint((eusinteger_t)2L);
	goto irtmodelIF867;
irtmodelIF866:
	if (T==NIL) goto irtmodelIF868;
	local[2]= NIL;
	goto irtmodelIF869;
irtmodelIF868:
	local[2]= NIL;
irtmodelIF869:
irtmodelIF867:
irtmodelIF865:
	w = local[2];
	local[1]= w;
	local[2]= env->c.clo.env1[0]->c.obj.iv[12];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,3,local+2); /*aref*/
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MAX(ctx,2,local+2); /*max*/
	local[2]= w;
	local[3]= env->c.clo.env1[0]->c.obj.iv[12];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= env->c.clo.env1[0]->c.obj.iv[12];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,2,local+5,&ftab[3],fqv[24]); /*array-dimension*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MIN(ctx,2,local+2); /*min*/
	local[2]= w;
	local[3]= env->c.clo.env1[0]->c.obj.iv[12];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ROUND(ctx,1,local+2); /*round*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*calc-jacobian-default-rotate-vector*/
static pointer irtmodelF743calc_jacobian_default_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	if (argv[2]==NIL) goto irtmodelIF871;
	local[0]= makeflt(-1.0000000000000000000000e+00);
	goto irtmodelIF872;
irtmodelIF871:
	local[0]= makeflt(1.0000000000000000000000e+00);
irtmodelIF872:
	local[1]= argv[1];
	local[2]= fqv[25];
	local[3]= argv[0];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,2,local+1,&ftab[4],fqv[26]); /*normalize-vector*/
	local[1]= w;
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	argv[4] = w;
	local[0]= argv[3];
	local[1]= fqv[27];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[5];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,2,local+0); /*transpose*/
	local[0]= w;
	local[1]= argv[4];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)TRANSFORM(ctx,3,local+0); /*transform*/
	local[0]= w;
irtmodelBLK870:
	ctx->vsp=local; return(local[0]);}

/*calc-jacobian-rotational*/
static pointer irtmodelF744calc_jacobian_rotational(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=19) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[4];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[9];
	local[7]= argv[15];
	local[8]= argv[18];
	ctx->vsp=local+9;
	w=(pointer)irtmodelF743calc_jacobian_default_rotate_vector(ctx,6,local+3); /*calc-jacobian-default-rotate-vector*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= argv[9];
	local[6]= fqv[27];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[18];
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,2,local+5); /*transpose*/
	local[5]= w;
	local[6]= argv[8];
	local[7]= fqv[29];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[5];
	local[8]= fqv[29];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[16];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,3,local+6); /*v-*/
	local[6]= w;
	local[7]= argv[16];
	ctx->vsp=local+8;
	w=(pointer)TRANSFORM(ctx,3,local+5); /*transform*/
	local[5]= w;
	local[6]= argv[16];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,3,local+4); /*scale*/
	local[4]= w;
	local[5]= local[3];
	local[6]= local[4];
	local[7]= argv[17];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= local[5];
	local[7]= argv[11];
	local[8]= argv[12];
	local[9]= argv[13];
	local[10]= argv[14];
	ctx->vsp=local+11;
	w=(pointer)irtmodelF749calc_dif_with_axis(ctx,5,local+6); /*calc-dif-with-axis*/
	local[5] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
irtmodelWHL874:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX875;
	local[8]= argv[0];
	local[9]= local[6];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= argv[2];
	local[11]= local[5];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ASET(ctx,4,local+8); /*aset*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL874;
irtmodelWHX875:
	local[8]= NIL;
irtmodelBLK876:
	w = NIL;
	local[6]= local[3];
	local[7]= argv[10];
	local[8]= argv[12];
	local[9]= argv[13];
	local[10]= argv[14];
	ctx->vsp=local+11;
	w=(pointer)irtmodelF749calc_dif_with_axis(ctx,5,local+6); /*calc-dif-with-axis*/
	local[3] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
irtmodelWHL877:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX878;
	local[8]= argv[0];
	local[9]= local[6];
	local[10]= argv[1];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,3,local+9); /*+*/
	local[9]= w;
	local[10]= argv[2];
	local[11]= local[3];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ASET(ctx,4,local+8); /*aset*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL877;
irtmodelWHX878:
	local[8]= NIL;
irtmodelBLK879:
	w = NIL;
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK873:
	ctx->vsp=local; return(local[0]);}

/*calc-jacobian-linear*/
static pointer irtmodelF745calc_jacobian_linear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=19) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[4];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[9];
	local[7]= argv[15];
	local[8]= argv[18];
	ctx->vsp=local+9;
	w=(pointer)irtmodelF743calc_jacobian_default_rotate_vector(ctx,6,local+3); /*calc-jacobian-default-rotate-vector*/
	local[3]= w;
	local[4]= fqv[30];
	local[5]= local[3];
	local[6]= argv[11];
	local[7]= argv[12];
	local[8]= argv[13];
	local[9]= argv[14];
	ctx->vsp=local+10;
	w=(pointer)irtmodelF749calc_dif_with_axis(ctx,5,local+5); /*calc-dif-with-axis*/
	local[3] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtmodelWHL881:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX882;
	local[7]= argv[0];
	local[8]= local[5];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[3];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,4,local+7); /*aset*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL881;
irtmodelWHX882:
	local[7]= NIL;
irtmodelBLK883:
	w = NIL;
	local[5]= local[4];
	local[6]= argv[10];
	local[7]= argv[12];
	local[8]= argv[13];
	local[9]= argv[14];
	ctx->vsp=local+10;
	w=(pointer)irtmodelF749calc_dif_with_axis(ctx,5,local+5); /*calc-dif-with-axis*/
	local[4] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtmodelWHL884:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX885;
	local[7]= argv[0];
	local[8]= local[5];
	local[9]= argv[1];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,3,local+8); /*+*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[4];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,4,local+7); /*aset*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL884;
irtmodelWHX885:
	local[7]= NIL;
irtmodelBLK886:
	w = NIL;
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK880:
	ctx->vsp=local; return(local[0]);}

/*calc-angle-speed-gain-scalar*/
static pointer irtmodelF746calc_angle_speed_gain_scalar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[8];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtmodelIF888;
	local[1]= local[0];
	goto irtmodelIF889;
irtmodelIF888:
	local[1]= makeflt(1.0000000000000000000000e+00);
irtmodelIF889:
	w = local[1];
	local[0]= w;
irtmodelBLK887:
	ctx->vsp=local; return(local[0]);}

/*calc-angle-speed-gain-vector*/
static pointer irtmodelF747calc_angle_speed_gain_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= fqv[31];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
irtmodelWHL891:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtmodelWHX892;
	local[3]= argv[0];
	local[4]= fqv[8];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[1];
	local[5]= local[1];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ABS(ctx,1,local+3); /*abs*/
	local[3]= w;
	local[4]= local[3];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto irtmodelIF894;
	local[0] = local[3];
	local[4]= local[0];
	goto irtmodelIF895;
irtmodelIF894:
	local[4]= NIL;
irtmodelIF895:
	w = local[4];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtmodelWHL891;
irtmodelWHX892:
	local[3]= NIL;
irtmodelBLK893:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK890:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM896rotational_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST898:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[32], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY899;
	local[1] = fqv[33];
irtmodelKEY899:
	if (n & (1<<1)) goto irtmodelKEY900;
	local[2] = makeint((eusinteger_t)5L);
irtmodelKEY900:
	if (n & (1<<2)) goto irtmodelKEY901;
	local[3] = makeint((eusinteger_t)100L);
irtmodelKEY901:
	argv[0]->c.obj.iv[14] = local[1];
	argv[0]->c.obj.iv[3] = makeflt(0.0000000000000000000000e+00);
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[35]));
	local[7]= fqv[36];
	local[8]= fqv[8];
	local[9]= local[2];
	local[10]= fqv[9];
	local[11]= local[3];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,9,local+4); /*apply*/
	if (argv[0]->c.obj.iv[4]!=NIL) goto irtmodelIF902;
	argv[0]->c.obj.iv[4] = makeflt(-9.0000000000000000000000e+01);
	local[4]= argv[0]->c.obj.iv[4];
	goto irtmodelIF903;
irtmodelIF902:
	local[4]= NIL;
irtmodelIF903:
	if (argv[0]->c.obj.iv[5]!=NIL) goto irtmodelIF904;
	local[4]= makeflt(1.8000000000000000000000e+02);
	local[5]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	argv[0]->c.obj.iv[5] = w;
	local[4]= argv[0]->c.obj.iv[5];
	goto irtmodelIF905;
irtmodelIF904:
	local[4]= NIL;
irtmodelIF905:
	local[4]= argv[0];
	local[5]= fqv[37];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[38];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[39];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = argv[0];
	local[0]= w;
irtmodelBLK897:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM906rotational_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT909;}
	local[0]= NIL;
irtmodelENT909:
irtmodelENT908:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[40], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY910;
	local[1] = NIL;
irtmodelKEY910:
	if (local[0]==NIL) goto irtmodelIF911;
	if (argv[0]->c.obj.iv[12]==NIL) goto irtmodelIF913;
	if (argv[0]->c.obj.iv[13]==NIL) goto irtmodelIF913;
	local[2]= argv[0];
	local[3]= fqv[41];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	argv[0]->c.obj.iv[4] = w;
	local[2]= argv[0];
	local[3]= fqv[42];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	argv[0]->c.obj.iv[5] = w;
	local[2]= argv[0]->c.obj.iv[5];
	goto irtmodelIF914;
irtmodelIF913:
	local[2]= NIL;
irtmodelIF914:
	if (local[1]==NIL) goto irtmodelIF915;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[0] = w;
	local[2]= local[0];
	goto irtmodelIF916;
irtmodelIF915:
	local[2]= NIL;
irtmodelIF916:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmodelCON918;
	if (local[1]!=NIL) goto irtmodelIF919;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= fqv[43];
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,5,local+2,&ftab[5],fqv[44]); /*warning-message*/
	local[2]= w;
	goto irtmodelIF920;
irtmodelIF919:
	local[2]= NIL;
irtmodelIF920:
	local[0] = argv[0]->c.obj.iv[5];
	local[2]= local[0];
	goto irtmodelCON917;
irtmodelCON918:
	local[2]= NIL;
irtmodelCON917:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtmodelCON922;
	if (local[1]!=NIL) goto irtmodelIF923;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= fqv[45];
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,5,local+2,&ftab[5],fqv[44]); /*warning-message*/
	local[2]= w;
	goto irtmodelIF924;
irtmodelIF923:
	local[2]= NIL;
irtmodelIF924:
	local[0] = argv[0]->c.obj.iv[4];
	local[2]= local[0];
	goto irtmodelCON921;
irtmodelCON922:
	local[2]= NIL;
irtmodelCON921:
	argv[0]->c.obj.iv[3] = local[0];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[47];
	local[4]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[48]); /*deg2rad*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto irtmodelIF912;
irtmodelIF911:
	local[2]= NIL;
irtmodelIF912:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK907:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM925rotational_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)1L);
	local[0]= w;
irtmodelBLK926:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM927rotational_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF746calc_angle_speed_gain_scalar(ctx,4,local+0); /*calc-angle-speed-gain-scalar*/
	local[0]= w;
irtmodelBLK928:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM929rotational_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[7])(ctx,1,local+0,&ftab[7],fqv[49]); /*rad2deg*/
	local[0]= w;
irtmodelBLK930:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM931rotational_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,1,local+0,&ftab[6],fqv[48]); /*deg2rad*/
	local[0]= w;
irtmodelBLK932:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM933rotational_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST935:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[50]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[0]= w;
irtmodelBLK934:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM936linear_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST938:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[51], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY939;
	local[1] = fqv[33];
irtmodelKEY939:
	if (n & (1<<1)) goto irtmodelKEY940;
	local[4]= makeflt(3.1415926535897931159980e+00);
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[2] = w;
irtmodelKEY940:
	if (n & (1<<2)) goto irtmodelKEY941;
	local[3] = makeint((eusinteger_t)100L);
irtmodelKEY941:
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelIF942;
	local[4]= local[1];
	goto irtmodelIF943;
irtmodelIF942:
	local[4]= local[1];
	local[5]= local[4];
	if (fqv[52]!=local[5]) goto irtmodelIF944;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF945;
irtmodelIF944:
	local[5]= local[4];
	if (fqv[53]!=local[5]) goto irtmodelIF946;
	local[5]= makeint((eusinteger_t)-1L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF947;
irtmodelIF946:
	local[5]= local[4];
	if (fqv[54]!=local[5]) goto irtmodelIF948;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF949;
irtmodelIF948:
	local[5]= local[4];
	if (fqv[55]!=local[5]) goto irtmodelIF950;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)-1L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF951;
irtmodelIF950:
	local[5]= local[4];
	if (fqv[33]!=local[5]) goto irtmodelIF952;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF953;
irtmodelIF952:
	local[5]= local[4];
	if (fqv[56]!=local[5]) goto irtmodelIF954;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF955;
irtmodelIF954:
	local[5]= NIL;
irtmodelIF955:
irtmodelIF953:
irtmodelIF951:
irtmodelIF949:
irtmodelIF947:
irtmodelIF945:
	w = local[5];
	local[4]= w;
irtmodelIF943:
	argv[0]->c.obj.iv[14] = local[4];
	argv[0]->c.obj.iv[3] = makeflt(0.0000000000000000000000e+00);
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[35]));
	local[7]= fqv[36];
	local[8]= fqv[8];
	local[9]= local[2];
	local[10]= fqv[9];
	local[11]= local[3];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,9,local+4); /*apply*/
	if (argv[0]->c.obj.iv[4]!=NIL) goto irtmodelIF956;
	argv[0]->c.obj.iv[4] = makeflt(-9.0000000000000000000000e+01);
	local[4]= argv[0]->c.obj.iv[4];
	goto irtmodelIF957;
irtmodelIF956:
	local[4]= NIL;
irtmodelIF957:
	if (argv[0]->c.obj.iv[5]!=NIL) goto irtmodelIF958;
	argv[0]->c.obj.iv[5] = makeflt(9.0000000000000000000000e+01);
	local[4]= argv[0]->c.obj.iv[5];
	goto irtmodelIF959;
irtmodelIF958:
	local[4]= NIL;
irtmodelIF959:
	local[4]= argv[0];
	local[5]= fqv[37];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[38];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[39];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = argv[0];
	local[0]= w;
irtmodelBLK937:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM960linear_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT963;}
	local[0]= NIL;
irtmodelENT963:
irtmodelENT962:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[57], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY964;
	local[1] = NIL;
irtmodelKEY964:
	if (local[0]==NIL) goto irtmodelIF965;
	if (local[1]==NIL) goto irtmodelIF967;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[0] = w;
	local[2]= local[0];
	goto irtmodelIF968;
irtmodelIF967:
	local[2]= NIL;
irtmodelIF968:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmodelIF969;
	if (local[1]!=NIL) goto irtmodelIF971;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= fqv[58];
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,5,local+2,&ftab[5],fqv[44]); /*warning-message*/
	local[2]= w;
	goto irtmodelIF972;
irtmodelIF971:
	local[2]= NIL;
irtmodelIF972:
	local[0] = argv[0]->c.obj.iv[5];
	local[2]= local[0];
	goto irtmodelIF970;
irtmodelIF969:
	local[2]= NIL;
irtmodelIF970:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtmodelIF973;
	if (local[1]!=NIL) goto irtmodelIF975;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= fqv[59];
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,5,local+2,&ftab[5],fqv[44]); /*warning-message*/
	local[2]= w;
	goto irtmodelIF976;
irtmodelIF975:
	local[2]= NIL;
irtmodelIF976:
	local[0] = argv[0]->c.obj.iv[4];
	local[2]= local[0];
	goto irtmodelIF974;
irtmodelIF973:
	local[2]= NIL;
irtmodelIF974:
	argv[0]->c.obj.iv[3] = local[0];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[60];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtmodelIF966;
irtmodelIF965:
	local[2]= NIL;
irtmodelIF966:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK961:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM977linear_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)1L);
	local[0]= w;
irtmodelBLK978:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM979linear_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF746calc_angle_speed_gain_scalar(ctx,4,local+0); /*calc-angle-speed-gain-scalar*/
	local[0]= w;
irtmodelBLK980:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM981linear_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1000L);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
irtmodelBLK982:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM983linear_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
irtmodelBLK984:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM985linear_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST987:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[61]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[0]= w;
irtmodelBLK986:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM988wheel_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST990:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[62], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY991;
	local[5]= loadglobal(fqv[63]);
	local[6]= loadglobal(fqv[63]);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[1] = w;
irtmodelKEY991:
	if (n & (1<<1)) goto irtmodelKEY992;
	local[5]= loadglobal(fqv[64]);
	local[6]= loadglobal(fqv[64]);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[2] = w;
irtmodelKEY992:
	if (n & (1<<2)) goto irtmodelKEY993;
	local[5]= makeflt(7.9999999999999960031971e-02);
	local[6]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= makeflt(3.1415926535897931159980e+00);
	local[7]= makeint((eusinteger_t)4L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[3] = w;
irtmodelKEY993:
	if (n & (1<<3)) goto irtmodelKEY994;
	local[5]= makeint((eusinteger_t)100L);
	local[6]= makeint((eusinteger_t)100L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[4] = w;
irtmodelKEY994:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	local[5]= fqv[65];
	local[6]= fqv[33];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	argv[0]->c.obj.iv[14] = w;
	local[5]= (pointer)get_sym_func(fqv[34]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[35]));
	local[8]= fqv[36];
	local[9]= fqv[66];
	local[10]= local[1];
	local[11]= fqv[67];
	local[12]= local[2];
	local[13]= fqv[8];
	local[14]= local[3];
	local[15]= fqv[9];
	local[16]= local[4];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,13,local+5); /*apply*/
	w = argv[0];
	local[0]= w;
irtmodelBLK989:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM995wheel_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT998;}
	local[0]= NIL;
irtmodelENT998:
irtmodelENT997:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[68], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY999;
	local[1] = NIL;
irtmodelKEY999:
	local[2]= NIL;
	local[3]= NIL;
	if (local[1]!=NIL) goto irtmodelIF1000;
	if (local[0]==NIL) goto irtmodelIF1002;
	local[4]= fqv[69];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[15]); /*warn*/
	local[4]= w;
	goto irtmodelIF1003;
irtmodelIF1002:
	local[4]= NIL;
irtmodelIF1003:
	w = argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	local[0]=w;
	goto irtmodelBLK996;
	goto irtmodelIF1001;
irtmodelIF1000:
	local[4]= NIL;
irtmodelIF1001:
	if (local[0]==NIL) goto irtmodelIF1004;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[2] = w;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[3] = w;
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[60];
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[47];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,1,local+6,&ftab[6],fqv[48]); /*deg2rad*/
	local[6]= w;
	local[7]= fqv[33];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto irtmodelIF1005;
irtmodelIF1004:
	local[4]= NIL;
irtmodelIF1005:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK996:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM1006wheel_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)2L);
	local[0]= w;
irtmodelBLK1007:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM1008wheel_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF747calc_angle_speed_gain_vector(ctx,4,local+0); /*calc-angle-speed-gain-vector*/
	local[0]= w;
irtmodelBLK1009:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM1010wheel_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1000L);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[49]); /*rad2deg*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1011:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM1012wheel_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[48]); /*deg2rad*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1013:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM1014wheel_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	w = argv[5];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[70];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF745calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[71];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF744calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK1015:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM1016omniwheel_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1018:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[72], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1019;
	local[5]= loadglobal(fqv[63]);
	local[6]= loadglobal(fqv[63]);
	local[7]= loadglobal(fqv[63]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[1] = w;
irtmodelKEY1019:
	if (n & (1<<1)) goto irtmodelKEY1020;
	local[5]= loadglobal(fqv[64]);
	local[6]= loadglobal(fqv[64]);
	local[7]= loadglobal(fqv[64]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[2] = w;
irtmodelKEY1020:
	if (n & (1<<2)) goto irtmodelKEY1021;
	local[5]= makeflt(7.9999999999999960031971e-02);
	local[6]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= makeflt(7.9999999999999960031971e-02);
	local[7]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeflt(3.1415926535897931159980e+00);
	local[8]= makeint((eusinteger_t)4L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[3] = w;
irtmodelKEY1021:
	if (n & (1<<3)) goto irtmodelKEY1022;
	local[5]= makeint((eusinteger_t)100L);
	local[6]= makeint((eusinteger_t)100L);
	local[7]= makeint((eusinteger_t)100L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[4] = w;
irtmodelKEY1022:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	local[5]= fqv[73];
	local[6]= fqv[74];
	local[7]= fqv[33];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,3,local+5); /*list*/
	argv[0]->c.obj.iv[14] = w;
	local[5]= (pointer)get_sym_func(fqv[34]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[35]));
	local[8]= fqv[36];
	local[9]= fqv[66];
	local[10]= local[1];
	local[11]= fqv[67];
	local[12]= local[2];
	local[13]= fqv[8];
	local[14]= local[3];
	local[15]= fqv[9];
	local[16]= local[4];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,13,local+5); /*apply*/
	w = argv[0];
	local[0]= w;
irtmodelBLK1017:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM1023omniwheel_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1026;}
	local[0]= NIL;
irtmodelENT1026:
irtmodelENT1025:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[75], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1027;
	local[1] = NIL;
irtmodelKEY1027:
	if (local[0]==NIL) goto irtmodelIF1028;
	if (local[1]==NIL) goto irtmodelIF1030;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,2,local+2); /*v+*/
	local[0] = w;
	local[2]= local[0];
	goto irtmodelIF1031;
irtmodelIF1030:
	local[2]= NIL;
irtmodelIF1031:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)VMAX(ctx,2,local+2); /*vmax*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)VMIN(ctx,2,local+2); /*vmin*/
	argv[0]->c.obj.iv[3] = w;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[60];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[47];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[48]); /*deg2rad*/
	local[4]= w;
	local[5]= fqv[33];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto irtmodelIF1029;
irtmodelIF1028:
	local[2]= NIL;
irtmodelIF1029:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK1024:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM1032omniwheel_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)3L);
	local[0]= w;
irtmodelBLK1033:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM1034omniwheel_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF747calc_angle_speed_gain_vector(ctx,4,local+0); /*calc-angle-speed-gain-vector*/
	local[0]= w;
irtmodelBLK1035:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM1036omniwheel_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1000L);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1000L);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,1,local+2,&ftab[7],fqv[49]); /*rad2deg*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1037:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM1038omniwheel_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,1,local+2,&ftab[6],fqv[48]); /*deg2rad*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1039:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM1040omniwheel_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	w = argv[5];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[76];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF745calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[77];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF745calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[78];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF744calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK1041:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM1042sphere_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1044:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[79], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1045;
	local[5]= loadglobal(fqv[63]);
	local[6]= loadglobal(fqv[63]);
	local[7]= loadglobal(fqv[63]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[1] = w;
irtmodelKEY1045:
	if (n & (1<<1)) goto irtmodelKEY1046;
	local[5]= loadglobal(fqv[64]);
	local[6]= loadglobal(fqv[64]);
	local[7]= loadglobal(fqv[64]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[2] = w;
irtmodelKEY1046:
	if (n & (1<<2)) goto irtmodelKEY1047;
	local[5]= makeflt(3.1415926535897931159980e+00);
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= makeflt(3.1415926535897931159980e+00);
	local[7]= makeint((eusinteger_t)4L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeflt(3.1415926535897931159980e+00);
	local[8]= makeint((eusinteger_t)4L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[3] = w;
irtmodelKEY1047:
	if (n & (1<<3)) goto irtmodelKEY1048;
	local[5]= makeint((eusinteger_t)100L);
	local[6]= makeint((eusinteger_t)100L);
	local[7]= makeint((eusinteger_t)100L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[4] = w;
irtmodelKEY1048:
	local[5]= fqv[52];
	local[6]= fqv[54];
	local[7]= fqv[33];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,3,local+5); /*list*/
	argv[0]->c.obj.iv[14] = w;
	local[5]= (pointer)get_sym_func(fqv[34]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[35]));
	local[8]= fqv[36];
	local[9]= fqv[66];
	local[10]= local[1];
	local[11]= fqv[67];
	local[12]= local[2];
	local[13]= fqv[8];
	local[14]= local[3];
	local[15]= fqv[9];
	local[16]= local[4];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,13,local+5); /*apply*/
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0];
	local[0]= w;
irtmodelBLK1043:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM1049sphere_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1052;}
	local[0]= NIL;
irtmodelENT1052:
irtmodelENT1051:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[80], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1053;
	local[1] = NIL;
irtmodelKEY1053:
	if (local[0]==NIL) goto irtmodelIF1054;
	if (local[1]==NIL) goto irtmodelCON1057;
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= makeflt(0.0000000000000000000000e+00);
	local[5]= makeflt(9.9999999999999949376344e-21);
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,3,local+3,&ftab[8],fqv[81]); /*eps=*/
	if (w!=NIL) goto irtmodelIF1058;
	local[3]= loadglobal(fqv[5]);
	local[4]= (pointer)get_sym_func(fqv[48]);
	local[5]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+6;
	w=(pointer)MAP(ctx,3,local+3); /*map*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)VNORM(ctx,1,local+4); /*norm*/
	local[4]= w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[26]); /*normalize-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+4); /*rotation-matrix*/
	local[4]= w;
	local[5]= local[3];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MATTIMES(ctx,3,local+4); /*m**/
	local[4]= loadglobal(fqv[5]);
	local[5]= (pointer)get_sym_func(fqv[49]);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[10])(ctx,1,local+6,&ftab[10],fqv[83]); /*matrix-log*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[3]= w;
	goto irtmodelIF1059;
irtmodelIF1058:
	local[3]= NIL;
irtmodelIF1059:
	w = local[3];
	local[2]= w;
	goto irtmodelCON1056;
irtmodelCON1057:
	argv[0]->c.obj.iv[3] = local[0];
	local[2]= argv[0]->c.obj.iv[3];
	goto irtmodelCON1056;
irtmodelCON1060:
	local[2]= NIL;
irtmodelCON1056:
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)VMAX(ctx,2,local+2); /*vmax*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)VMIN(ctx,2,local+2); /*vmin*/
	argv[0]->c.obj.iv[3] = w;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[84];
	local[4]= fqv[85];
	local[5]= loadglobal(fqv[5]);
	local[6]= (pointer)get_sym_func(fqv[48]);
	local[7]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+8;
	w=(pointer)MAP(ctx,3,local+5); /*map*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[9])(ctx,1,local+5,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,2,local+4,&ftab[11],fqv[86]); /*make-coords*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtmodelIF1055;
irtmodelIF1054:
	local[2]= NIL;
irtmodelIF1055:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK1050:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-rpy*/
static pointer irtmodelM1061sphere_joint_joint_angle_rpy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1064;}
	local[0]= NIL;
irtmodelENT1064:
irtmodelENT1063:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[87], &argv[3], n-3, local+1, 0);
	if (n & (1<<0)) goto irtmodelKEY1065;
	local[1] = NIL;
irtmodelKEY1065:
	if (local[0]==NIL) goto irtmodelIF1066;
	if (local[1]==NIL) goto irtmodelIF1068;
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
	local[3]= loadglobal(fqv[5]);
	local[4]= (pointer)get_sym_func(fqv[48]);
	local[5]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+6;
	w=(pointer)MAP(ctx,3,local+3); /*map*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INV_RPY(ctx,1,local+3); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= loadglobal(fqv[5]);
	ctx->vsp=local+5;
	w=(pointer)COERCE(ctx,2,local+3); /*coerce*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,2,local+2); /*v+*/
	local[2]= w;
	goto irtmodelIF1069;
irtmodelIF1068:
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
irtmodelIF1069:
	local[3]= argv[0];
	local[4]= fqv[20];
	local[5]= loadglobal(fqv[88]);
	local[6]= (pointer)get_sym_func(fqv[49]);
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[2];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[12])(ctx,3,local+7,&ftab[12],fqv[89]); /*rpy-matrix*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[83]); /*matrix-log*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAP(ctx,3,local+5); /*map*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2]= w;
	goto irtmodelIF1067;
irtmodelIF1066:
	local[2]= NIL;
irtmodelIF1067:
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[49]);
	local[4]= loadglobal(fqv[5]);
	local[5]= (pointer)get_sym_func(fqv[48]);
	local[6]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,1,local+4,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INV_RPY(ctx,1,local+4); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[0]= w;
irtmodelBLK1062:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM1070sphere_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)3L);
	local[0]= w;
irtmodelBLK1071:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM1072sphere_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF747calc_angle_speed_gain_vector(ctx,4,local+0); /*calc-angle-speed-gain-vector*/
	local[0]= w;
irtmodelBLK1073:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM1074sphere_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[7])(ctx,1,local+0,&ftab[7],fqv[49]); /*rad2deg*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[49]); /*rad2deg*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,1,local+2,&ftab[7],fqv[49]); /*rad2deg*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1075:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM1076sphere_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,1,local+0,&ftab[6],fqv[48]); /*deg2rad*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[48]); /*deg2rad*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,1,local+2,&ftab[6],fqv[48]); /*deg2rad*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1077:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM1078sphere_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	w = argv[5];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[90];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF744calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[91];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF744calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[92];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF744calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK1079:
	ctx->vsp=local; return(local[0]);}

/*:joint-euler-angle*/
static pointer irtmodelM1080sphere_joint_joint_euler_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[93], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1082;
	local[0] = fqv[94];
irtmodelKEY1082:
	if (n & (1<<1)) goto irtmodelKEY1083;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
irtmodelKEY1083:
	local[2]= loadglobal(fqv[88]);
	local[3]= (pointer)get_sym_func(fqv[49]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= local[4];
	if (fqv[95]!=local[5]) goto irtmodelIF1084;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[54]!=local[6]) goto irtmodelIF1086;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,2,local+6,&ftab[13],fqv[96]); /*atan2*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	goto irtmodelIF1087;
irtmodelIF1086:
	local[6]= local[5];
	if (fqv[52]!=local[6]) goto irtmodelIF1088;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,2,local+6,&ftab[13],fqv[96]); /*atan2*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	goto irtmodelIF1089;
irtmodelIF1088:
	local[6]= local[5];
	if (fqv[33]!=local[6]) goto irtmodelIF1090;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,2,local+6,&ftab[13],fqv[96]); /*atan2*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	goto irtmodelIF1091;
irtmodelIF1090:
	local[6]= NIL;
irtmodelIF1091:
irtmodelIF1089:
irtmodelIF1087:
	w = local[6];
	local[5]= w;
	goto irtmodelIF1085;
irtmodelIF1084:
	local[5]= local[4];
	if (fqv[97]!=local[5]) goto irtmodelIF1092;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[54]!=local[6]) goto irtmodelIF1094;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[52]!=local[7]) goto irtmodelIF1096;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1097;
irtmodelIF1096:
	local[7]= local[6];
	if (fqv[33]!=local[7]) goto irtmodelIF1098;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1099;
irtmodelIF1098:
	local[7]= local[6];
	if (fqv[54]!=local[7]) goto irtmodelIF1100;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1101;
irtmodelIF1100:
	local[7]= NIL;
irtmodelIF1101:
irtmodelIF1099:
irtmodelIF1097:
	w = local[7];
	local[6]= w;
	goto irtmodelIF1095;
irtmodelIF1094:
	local[6]= local[5];
	if (fqv[52]!=local[6]) goto irtmodelIF1102;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[54]!=local[7]) goto irtmodelIF1104;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1105;
irtmodelIF1104:
	local[7]= local[6];
	if (fqv[33]!=local[7]) goto irtmodelIF1106;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1107;
irtmodelIF1106:
	local[7]= local[6];
	if (fqv[52]!=local[7]) goto irtmodelIF1108;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1109;
irtmodelIF1108:
	local[7]= NIL;
irtmodelIF1109:
irtmodelIF1107:
irtmodelIF1105:
	w = local[7];
	local[6]= w;
	goto irtmodelIF1103;
irtmodelIF1102:
	local[6]= local[5];
	if (fqv[33]!=local[6]) goto irtmodelIF1110;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[54]!=local[7]) goto irtmodelIF1112;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1113;
irtmodelIF1112:
	local[7]= local[6];
	if (fqv[52]!=local[7]) goto irtmodelIF1114;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1115;
irtmodelIF1114:
	local[7]= local[6];
	if (fqv[33]!=local[7]) goto irtmodelIF1116;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1117;
irtmodelIF1116:
	local[7]= NIL;
irtmodelIF1117:
irtmodelIF1115:
irtmodelIF1113:
	w = local[7];
	local[6]= w;
	goto irtmodelIF1111;
irtmodelIF1110:
	local[6]= NIL;
irtmodelIF1111:
irtmodelIF1103:
irtmodelIF1095:
	w = local[6];
	local[5]= w;
	goto irtmodelIF1093;
irtmodelIF1092:
	local[5]= local[4];
	if (fqv[98]!=local[5]) goto irtmodelIF1118;
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,2,local+5,&ftab[14],fqv[99]); /*matrix-to-euler-angle*/
	local[5]= w;
	goto irtmodelIF1119;
irtmodelIF1118:
	local[5]= NIL;
irtmodelIF1119:
irtmodelIF1093:
irtmodelIF1085:
	w = local[5];
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[0]= w;
irtmodelBLK1081:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM11206dof_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1122:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[100], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1123;
	local[6]= loadglobal(fqv[63]);
	local[7]= loadglobal(fqv[63]);
	local[8]= loadglobal(fqv[63]);
	local[9]= loadglobal(fqv[63]);
	local[10]= loadglobal(fqv[63]);
	local[11]= loadglobal(fqv[63]);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	local[1] = w;
irtmodelKEY1123:
	if (n & (1<<1)) goto irtmodelKEY1124;
	local[6]= loadglobal(fqv[64]);
	local[7]= loadglobal(fqv[64]);
	local[8]= loadglobal(fqv[64]);
	local[9]= loadglobal(fqv[64]);
	local[10]= loadglobal(fqv[64]);
	local[11]= loadglobal(fqv[64]);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	local[2] = w;
irtmodelKEY1124:
	if (n & (1<<2)) goto irtmodelKEY1125;
	local[6]= makeflt(7.9999999999999960031971e-02);
	local[7]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeflt(7.9999999999999960031971e-02);
	local[8]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	local[8]= makeflt(7.9999999999999960031971e-02);
	local[9]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= makeflt(3.1415926535897931159980e+00);
	local[10]= makeint((eusinteger_t)4L);
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= makeflt(3.1415926535897931159980e+00);
	local[11]= makeint((eusinteger_t)4L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= makeflt(3.1415926535897931159980e+00);
	local[12]= makeint((eusinteger_t)4L);
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	local[3] = w;
irtmodelKEY1125:
	if (n & (1<<3)) goto irtmodelKEY1126;
	local[6]= makeint((eusinteger_t)100L);
	local[7]= makeint((eusinteger_t)100L);
	local[8]= makeint((eusinteger_t)100L);
	local[9]= makeint((eusinteger_t)100L);
	local[10]= makeint((eusinteger_t)100L);
	local[11]= makeint((eusinteger_t)100L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	local[4] = w;
irtmodelKEY1126:
	if (n & (1<<4)) goto irtmodelKEY1127;
	local[5] = NIL;
irtmodelKEY1127:
	local[6]= fqv[101];
	local[7]= fqv[102];
	local[8]= fqv[103];
	local[9]= fqv[52];
	local[10]= fqv[54];
	local[11]= fqv[33];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,6,local+6); /*list*/
	argv[0]->c.obj.iv[14] = w;
	local[6]= (pointer)get_sym_func(fqv[34]);
	local[7]= argv[0];
	local[8]= *(ovafptr(argv[1],fqv[35]));
	local[9]= fqv[36];
	local[10]= fqv[66];
	local[11]= local[1];
	local[12]= fqv[67];
	local[13]= local[2];
	local[14]= fqv[8];
	local[15]= local[3];
	local[16]= fqv[9];
	local[17]= local[4];
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,13,local+6); /*apply*/
	if (local[5]==NIL) goto irtmodelIF1128;
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= fqv[104];
	local[8]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[105];
	local[8]= argv[0]->c.obj.iv[6];
	local[9]= fqv[29];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[11])(ctx,2,local+7,&ftab[11],fqv[86]); /*make-coords*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[106];
	local[10]= local[6];
	local[11]= fqv[29];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= local[7];
	local[10]= fqv[27];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TRANSPOSE(ctx,1,local+9); /*transpose*/
	local[9]= w;
	local[10]= local[6];
	local[11]= fqv[27];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,1,local+9,&ftab[10],fqv[83]); /*matrix-log*/
	local[9]= w;
	local[10]= local[8];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[8];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[8];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[9];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[7])(ctx,1,local+13,&ftab[7],fqv[49]); /*rad2deg*/
	local[13]= w;
	local[14]= local[9];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[7])(ctx,1,local+14,&ftab[7],fqv[49]); /*rad2deg*/
	local[14]= w;
	local[15]= local[9];
	local[16]= makeint((eusinteger_t)2L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[7])(ctx,1,local+15,&ftab[7],fqv[49]); /*rad2deg*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,6,local+10); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	argv[0]->c.obj.iv[6] = local[7];
	w = argv[0]->c.obj.iv[6];
	local[6]= w;
	goto irtmodelIF1129;
irtmodelIF1128:
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	local[6]= argv[0]->c.obj.iv[3];
irtmodelIF1129:
	w = argv[0];
	local[0]= w;
irtmodelBLK1121:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM11306dof_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1133;}
	local[0]= NIL;
irtmodelENT1133:
irtmodelENT1132:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[107], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1134;
	local[1] = NIL;
irtmodelKEY1134:
	if (local[0]==NIL) goto irtmodelIF1135;
	local[2]= NIL;
	local[3]= NIL;
	if (local[1]==NIL) goto irtmodelIF1137;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	goto irtmodelIF1138;
irtmodelIF1137:
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
irtmodelIF1138:
	local[2] = local[4];
	if (local[1]==NIL) goto irtmodelCON1140;
	local[4]= loadglobal(fqv[5]);
	local[5]= (pointer)get_sym_func(fqv[48]);
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)3L);
	local[8]= makeint((eusinteger_t)6L);
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)VNORM(ctx,1,local+5); /*norm*/
	local[5]= w;
	local[6]= makeflt(0.0000000000000000000000e+00);
	local[7]= makeflt(9.9999999999999949376344e-21);
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,3,local+5,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelIF1141;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)6L);
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[3] = w;
	local[5]= local[3];
	goto irtmodelIF1142;
irtmodelIF1141:
	local[5]= loadglobal(fqv[5]);
	local[6]= (pointer)get_sym_func(fqv[48]);
	local[7]= argv[0]->c.obj.iv[3];
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)6L);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAP(ctx,3,local+5); /*map*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[9])(ctx,1,local+5,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VNORM(ctx,1,local+6); /*norm*/
	local[6]= w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,1,local+7,&ftab[4],fqv[26]); /*normalize-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+6); /*rotation-matrix*/
	local[6]= w;
	local[7]= local[5];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,3,local+6); /*m**/
	local[6]= loadglobal(fqv[5]);
	local[7]= (pointer)get_sym_func(fqv[49]);
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[10])(ctx,1,local+8,&ftab[10],fqv[83]); /*matrix-log*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAP(ctx,3,local+6); /*map*/
	local[3] = w;
	w = local[3];
	local[5]= w;
irtmodelIF1142:
	w = local[5];
	local[4]= w;
	goto irtmodelCON1139;
irtmodelCON1140:
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)6L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[3] = w;
	local[4]= local[3];
	goto irtmodelCON1139;
irtmodelCON1143:
	local[4]= NIL;
irtmodelCON1139:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)3L);
irtmodelWHL1144:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtmodelWHX1145;
	local[6]= argv[0]->c.obj.iv[3];
	local[7]= local[4];
	local[8]= local[2];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= argv[0]->c.obj.iv[3];
	local[7]= local[4];
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[7]= (pointer)((eusinteger_t)local[7] + (eusinteger_t)w);
	local[8]= local[3];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtmodelWHL1144;
irtmodelWHX1145:
	local[6]= NIL;
irtmodelBLK1146:
	w = NIL;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+6;
	w=(pointer)VMAX(ctx,2,local+4); /*vmax*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+6;
	w=(pointer)VMIN(ctx,2,local+4); /*vmin*/
	argv[0]->c.obj.iv[3] = w;
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[46];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[84];
	local[6]= fqv[85];
	local[7]= loadglobal(fqv[5]);
	local[8]= (pointer)get_sym_func(fqv[48]);
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MAP(ctx,3,local+7); /*map*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[7]= w;
	local[8]= fqv[105];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,4,local+6,&ftab[11],fqv[86]); /*make-coords*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[2]= w;
	goto irtmodelIF1136;
irtmodelIF1135:
	local[2]= NIL;
irtmodelIF1136:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK1131:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-rpy*/
static pointer irtmodelM11476dof_joint_joint_angle_rpy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1150;}
	local[0]= NIL;
irtmodelENT1150:
irtmodelENT1149:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[108], &argv[3], n-3, local+1, 0);
	if (n & (1<<0)) goto irtmodelKEY1151;
	local[1] = NIL;
irtmodelKEY1151:
	if (local[0]==NIL) goto irtmodelIF1152;
	if (local[1]==NIL) goto irtmodelIF1154;
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)6L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
	local[3]= loadglobal(fqv[5]);
	local[4]= (pointer)get_sym_func(fqv[48]);
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)6L);
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAP(ctx,3,local+3); /*map*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INV_RPY(ctx,1,local+3); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= loadglobal(fqv[5]);
	ctx->vsp=local+5;
	w=(pointer)COERCE(ctx,2,local+3); /*coerce*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,2,local+2); /*v+*/
	local[2]= w;
	goto irtmodelIF1155;
irtmodelIF1154:
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)6L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
irtmodelIF1155:
	local[3]= argv[0];
	local[4]= fqv[20];
	local[5]= loadglobal(fqv[5]);
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[6]= w;
	local[7]= loadglobal(fqv[88]);
	local[8]= (pointer)get_sym_func(fqv[49]);
	local[9]= local[2];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[2];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[2];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[12])(ctx,3,local+9,&ftab[12],fqv[89]); /*rpy-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,1,local+9,&ftab[10],fqv[83]); /*matrix-log*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAP(ctx,3,local+7); /*map*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,3,local+5); /*concatenate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2]= w;
	goto irtmodelIF1153;
irtmodelIF1152:
	local[2]= NIL;
irtmodelIF1153:
	local[2]= loadglobal(fqv[5]);
	local[3]= argv[0]->c.obj.iv[3];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	local[3]= w;
	local[4]= loadglobal(fqv[5]);
	local[5]= (pointer)get_sym_func(fqv[49]);
	local[6]= loadglobal(fqv[5]);
	local[7]= (pointer)get_sym_func(fqv[48]);
	local[8]= argv[0]->c.obj.iv[3];
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)6L);
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,3,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAP(ctx,3,local+6); /*map*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,1,local+6,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)INV_RPY(ctx,1,local+6); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)CONCATENATE(ctx,3,local+2); /*concatenate*/
	local[0]= w;
irtmodelBLK1148:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM11566dof_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)6L);
	local[0]= w;
irtmodelBLK1157:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM11586dof_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF747calc_angle_speed_gain_vector(ctx,4,local+0); /*calc-angle-speed-gain-vector*/
	local[0]= w;
irtmodelBLK1159:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM11606dof_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1000L);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1000L);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeint((eusinteger_t)1000L);
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[7])(ctx,1,local+3,&ftab[7],fqv[49]); /*rad2deg*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,1,local+4,&ftab[7],fqv[49]); /*rad2deg*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,1,local+5,&ftab[7],fqv[49]); /*rad2deg*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,6,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1161:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM11626dof_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,1,local+3,&ftab[6],fqv[48]); /*deg2rad*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[48]); /*deg2rad*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,1,local+5,&ftab[6],fqv[48]); /*deg2rad*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,6,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1163:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM11646dof_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	w = argv[5];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[109];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF745calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[110];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF745calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[111];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF745calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[112];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF744calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[113];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF744calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[114];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF744calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK1165:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM1166bodyset_link_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1168:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[115], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1169;
	local[1] = fqv[116];
irtmodelKEY1169:
	if (n & (1<<1)) goto irtmodelKEY1170;
	local[2] = makeint((eusinteger_t)1L);
irtmodelKEY1170:
	if (n & (1<<2)) goto irtmodelKEY1171;
	local[3] = fqv[117];
irtmodelKEY1171:
	if (n & (1<<3)) goto irtmodelKEY1172;
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(*ftab[15])(ctx,1,local+5,&ftab[15],fqv[118]); /*unit-matrix*/
	local[4] = w;
irtmodelKEY1172:
	argv[0]->c.obj.iv[12] = local[1];
	argv[0]->c.obj.iv[14] = local[2];
	argv[0]->c.obj.iv[16] = local[4];
	argv[0]->c.obj.iv[15] = local[3];
	local[5]= argv[0];
	local[6]= fqv[119];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= (pointer)get_sym_func(fqv[34]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[35]));
	local[8]= fqv[36];
	local[9]= argv[2];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,6,local+5); /*apply*/
	local[0]= w;
irtmodelBLK1167:
	ctx->vsp=local; return(local[0]);}

/*:worldcoords*/
static pointer irtmodelM1173bodyset_link_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1176;}
	local[0]= argv[0]->c.obj.iv[12];
irtmodelENT1176:
irtmodelENT1175:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= local[1];
	if (fqv[120]!=local[2]) goto irtmodelIF1177;
	local[2]= argv[0];
	local[3]= loadglobal(fqv[121]);
	local[4]= fqv[122];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,3,local+2); /*send-message*/
	local[2]= w;
	goto irtmodelIF1178;
irtmodelIF1177:
	if (T==NIL) goto irtmodelIF1179;
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[35]));
	local[4]= fqv[122];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,3,local+2); /*send-message*/
	local[2]= w;
	goto irtmodelIF1180;
irtmodelIF1179:
	local[2]= NIL;
irtmodelIF1180:
irtmodelIF1178:
	w = local[2];
	local[0]= w;
irtmodelBLK1174:
	ctx->vsp=local; return(local[0]);}

/*:analysis-level*/
static pointer irtmodelM1181bodyset_link_analysis_level(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1184;}
	local[0]= NIL;
irtmodelENT1184:
irtmodelENT1183:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1185;
	argv[0]->c.obj.iv[12] = local[0];
	local[1]= argv[0]->c.obj.iv[12];
	goto irtmodelIF1186;
irtmodelIF1185:
	local[1]= NIL;
irtmodelIF1186:
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
irtmodelBLK1182:
	ctx->vsp=local; return(local[0]);}

/*:weight*/
static pointer irtmodelM1187bodyset_link_weight(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1190;}
	local[0]= NIL;
irtmodelENT1190:
irtmodelENT1189:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1191;
	argv[0]->c.obj.iv[14] = local[0];
	local[1]= argv[0]->c.obj.iv[14];
	goto irtmodelIF1192;
irtmodelIF1191:
	local[1]= NIL;
irtmodelIF1192:
	w = argv[0]->c.obj.iv[14];
	local[0]= w;
irtmodelBLK1188:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer irtmodelM1193bodyset_link_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1196;}
	local[0]= NIL;
irtmodelENT1196:
irtmodelENT1195:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1197;
	argv[0]->c.obj.iv[15] = local[0];
	local[1]= argv[0]->c.obj.iv[15];
	goto irtmodelIF1198;
irtmodelIF1197:
	local[1]= NIL;
irtmodelIF1198:
	local[1]= argv[0];
	local[2]= fqv[122];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[123];
	local[3]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtmodelBLK1194:
	ctx->vsp=local; return(local[0]);}

/*:inertia-tensor*/
static pointer irtmodelM1199bodyset_link_inertia_tensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1202;}
	local[0]= NIL;
irtmodelENT1202:
irtmodelENT1201:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1203;
	argv[0]->c.obj.iv[16] = local[0];
	local[1]= argv[0]->c.obj.iv[16];
	goto irtmodelIF1204;
irtmodelIF1203:
	local[1]= NIL;
irtmodelIF1204:
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtmodelBLK1200:
	ctx->vsp=local; return(local[0]);}

/*:joint*/
static pointer irtmodelM1205bodyset_link_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1207:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[13]); /*forward-message-to*/
	local[0]= w;
irtmodelBLK1206:
	ctx->vsp=local; return(local[0]);}

/*:add-joint*/
static pointer irtmodelM1208bodyset_link_add_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[9] = argv[2];
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtmodelBLK1209:
	ctx->vsp=local; return(local[0]);}

/*:del-joint*/
static pointer irtmodelM1210bodyset_link_del_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[9] = NIL;
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtmodelBLK1211:
	ctx->vsp=local; return(local[0]);}

/*:parent-link*/
static pointer irtmodelM1212bodyset_link_parent_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtmodelBLK1213:
	ctx->vsp=local; return(local[0]);}

/*:child-links*/
static pointer irtmodelM1214bodyset_link_child_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtmodelBLK1215:
	ctx->vsp=local; return(local[0]);}

/*:add-child-links*/
static pointer irtmodelM1216bodyset_link_add_child_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[124]); /*member*/
	if (w!=NIL) goto irtmodelIF1218;
	if (argv[2]==NIL) goto irtmodelIF1218;
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[11];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[11] = cons(ctx,local[0],w);
	local[0]= argv[0]->c.obj.iv[11];
	goto irtmodelIF1219;
irtmodelIF1218:
	local[0]= NIL;
irtmodelIF1219:
	w = local[0];
	local[0]= w;
irtmodelBLK1217:
	ctx->vsp=local; return(local[0]);}

/*:add-parent-link*/
static pointer irtmodelM1220bodyset_link_add_parent_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[10] = argv[2];
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtmodelBLK1221:
	ctx->vsp=local; return(local[0]);}

/*:del-child-link*/
static pointer irtmodelM1222bodyset_link_del_child_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[125]); /*delete*/
	argv[0]->c.obj.iv[11] = w;
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtmodelBLK1223:
	ctx->vsp=local; return(local[0]);}

/*:del-parent-link*/
static pointer irtmodelM1224bodyset_link_del_parent_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[10] = NIL;
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtmodelBLK1225:
	ctx->vsp=local; return(local[0]);}

/*:default-coords*/
static pointer irtmodelM1226bodyset_link_default_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1229;}
	local[0]= NIL;
irtmodelENT1229:
irtmodelENT1228:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1230;
	argv[0]->c.obj.iv[13] = local[0];
	local[1]= argv[0]->c.obj.iv[13];
	goto irtmodelIF1231;
irtmodelIF1230:
	local[1]= NIL;
irtmodelIF1231:
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
irtmodelBLK1227:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM1232cascaded_link_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1234:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[126], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1235;
	local[1] = NIL;
irtmodelKEY1235:
	local[2]= (pointer)get_sym_func(fqv[34]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[35]));
	local[5]= fqv[36];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,5,local+2); /*apply*/
	w = argv[0];
	local[0]= w;
irtmodelBLK1233:
	ctx->vsp=local; return(local[0]);}

/*:init-ending*/
static pointer irtmodelM1236cascaded_link_init_ending(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[127];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,1,local+0,&ftab[19],fqv[129]); /*flatten*/
	argv[0]->c.obj.iv[10] = w;
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[9];
irtmodelWHL1238:
	if (local[1]==NIL) goto irtmodelWHX1239;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[130];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[131];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= local[0];
	local[3]= fqv[130];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[132];
	local[4]= local[0];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= local[0];
	local[3]= fqv[133];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[134];
	local[4]= local[0];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto irtmodelWHL1238;
irtmodelWHX1239:
	local[2]= NIL;
irtmodelBLK1240:
	w = NIL;
	local[0]= argv[0];
	local[1]= fqv[135];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[136];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
irtmodelWHL1241:
	if (local[1]==NIL) goto irtmodelWHX1242;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[137];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	goto irtmodelWHL1241;
irtmodelWHX1242:
	local[2]= NIL;
irtmodelBLK1243:
	w = NIL;
	local[0]= w;
irtmodelBLK1237:
	ctx->vsp=local; return(local[0]);}

/*:links*/
static pointer irtmodelM1244cascaded_link_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1246:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,2,local+1,&ftab[20],fqv[138]); /*forward-message-to-all*/
	local[0]= w;
irtmodelBLK1245:
	ctx->vsp=local; return(local[0]);}

/*:joint-list*/
static pointer irtmodelM1247cascaded_link_joint_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1249:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,2,local+1,&ftab[20],fqv[138]); /*forward-message-to-all*/
	local[0]= w;
irtmodelBLK1248:
	ctx->vsp=local; return(local[0]);}

/*:link*/
static pointer irtmodelM1250cascaded_link_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= fqv[139];
	local[3]= (pointer)get_sym_func(fqv[140]);
	local[4]= fqv[141];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO1252,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,6,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelBLK1251:
	ctx->vsp=local; return(local[0]);}

/*:joint*/
static pointer irtmodelM1253cascaded_link_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= fqv[139];
	local[3]= (pointer)get_sym_func(fqv[140]);
	local[4]= fqv[141];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO1255,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,6,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelBLK1254:
	ctx->vsp=local; return(local[0]);}

/*:end-coords*/
static pointer irtmodelM1256cascaded_link_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[12];
	local[2]= fqv[139];
	local[3]= (pointer)get_sym_func(fqv[140]);
	local[4]= fqv[141];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO1258,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,6,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelBLK1257:
	ctx->vsp=local; return(local[0]);}

/*:bodies*/
static pointer irtmodelM1259cascaded_link_bodies(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1261:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[10];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,2,local+1,&ftab[20],fqv[138]); /*forward-message-to-all*/
	local[0]= w;
irtmodelBLK1260:
	ctx->vsp=local; return(local[0]);}

/*:faces*/
static pointer irtmodelM1262cascaded_link_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[143];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,1,local+0,&ftab[19],fqv[129]); /*flatten*/
	local[0]= w;
irtmodelBLK1263:
	ctx->vsp=local; return(local[0]);}

/*:update-descendants*/
static pointer irtmodelM1264cascaded_link_update_descendants(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1266:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= fqv[122];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
irtmodelBLK1265:
	ctx->vsp=local; return(local[0]);}

/*:angle-vector*/
static pointer irtmodelM1267cascaded_link_angle_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1271;}
	local[0]= NIL;
irtmodelENT1271:
	if (n>=4) { local[1]=(argv[3]); goto irtmodelENT1270;}
	local[1]= loadglobal(fqv[5]);
	local[2]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+2); /*calc-target-joint-dimension*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
irtmodelENT1270:
irtmodelENT1269:
	if (n>4) maerror();
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[9];
irtmodelWHL1272:
	if (local[4]==NIL) goto irtmodelWHX1273;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	if (local[0]==NIL) goto irtmodelIF1275;
	local[5]= local[3];
	local[6]= fqv[10];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w==NIL) goto irtmodelIF1277;
	local[5]= local[3];
	local[6]= fqv[11];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w==NIL) goto irtmodelIF1277;
	local[5]= local[3];
	local[6]= fqv[31];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto irtmodelIF1279;
	local[5]= local[3];
	local[6]= fqv[11];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[31];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto irtmodelIF1279;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
irtmodelWHL1281:
	local[14]= local[6];
	local[15]= local[3];
	local[16]= fqv[11];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	if (w==local[14]) goto irtmodelWHX1282;
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[5] = w;
	local[14]= local[7];
	local[15]= local[6];
	local[16]= fqv[31];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[7] = w;
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[6] = w;
	goto irtmodelWHL1281;
irtmodelWHX1282:
	local[14]= NIL;
irtmodelBLK1283:
	local[14]= local[0];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[8] = w;
	local[14]= local[0];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[11] = w;
	local[14]= local[3];
	local[15]= fqv[41];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[9] = w;
	local[14]= local[3];
	local[15]= fqv[42];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[10] = w;
	local[14]= local[6];
	local[15]= fqv[41];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[12] = w;
	local[14]= local[6];
	local[15]= fqv[42];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[13] = w;
	local[14]= local[9];
	local[15]= local[8];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)LSEQP(ctx,3,local+14); /*<=*/
	if (w==NIL) goto irtmodelCON1285;
	local[14]= local[8];
	*(ovafptr(local[3],fqv[144])) = local[14];
	local[14]= local[11];
	local[15]= local[14];
	*(ovafptr(local[6],fqv[144])) = local[15];
	goto irtmodelCON1284;
irtmodelCON1285:
	local[14]= makeint((eusinteger_t)0L);
irtmodelTAG1288:
	local[15]= local[14];
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)GREATERP(ctx,2,local+15); /*>*/
	if (w==NIL) goto irtmodelIF1289;
	w = NIL;
	ctx->vsp=local+15;
	local[14]=w;
	goto irtmodelBLK1287;
	goto irtmodelIF1290;
irtmodelIF1289:
	local[15]= NIL;
irtmodelIF1290:
	local[15]= local[3];
	local[16]= fqv[41];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[9] = w;
	local[15]= local[3];
	local[16]= fqv[42];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[10] = w;
	local[15]= local[6];
	local[16]= fqv[41];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[12] = w;
	local[15]= local[6];
	local[16]= fqv[42];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[13] = w;
	local[15]= local[8];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(pointer)LESSP(ctx,2,local+15); /*<*/
	if (w==NIL) goto irtmodelIF1291;
	local[15]= local[8];
	local[16]= local[9];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[8] = w;
	local[15]= local[8];
	goto irtmodelIF1292;
irtmodelIF1291:
	local[15]= NIL;
irtmodelIF1292:
	local[15]= local[8];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)GREATERP(ctx,2,local+15); /*>*/
	if (w==NIL) goto irtmodelIF1293;
	local[15]= local[8];
	local[16]= local[10];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[8] = w;
	local[15]= local[8];
	goto irtmodelIF1294;
irtmodelIF1293:
	local[15]= NIL;
irtmodelIF1294:
	local[15]= local[11];
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)LESSP(ctx,2,local+15); /*<*/
	if (w==NIL) goto irtmodelIF1295;
	local[15]= local[11];
	local[16]= local[12];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[11] = w;
	local[15]= local[11];
	goto irtmodelIF1296;
irtmodelIF1295:
	local[15]= NIL;
irtmodelIF1296:
	local[15]= local[11];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)GREATERP(ctx,2,local+15); /*>*/
	if (w==NIL) goto irtmodelIF1297;
	local[15]= local[11];
	local[16]= local[13];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[11] = w;
	local[15]= local[11];
	goto irtmodelIF1298;
irtmodelIF1297:
	local[15]= NIL;
irtmodelIF1298:
	local[15]= local[14];
	local[16]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[14] = w;
	local[15]= local[14];
	local[14] = local[15];
	w = NIL;
	ctx->vsp=local+15;
	goto irtmodelTAG1288;
	w = NIL;
	local[14]= w;
irtmodelBLK1287:
	local[14]= local[8];
	*(ovafptr(local[3],fqv[144])) = local[14];
	local[14]= local[11];
	local[15]= local[14];
	*(ovafptr(local[6],fqv[144])) = local[15];
	local[14]= local[0];
	local[15]= local[2];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SETELT(ctx,3,local+14); /*setelt*/
	local[14]= local[0];
	local[15]= local[7];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SETELT(ctx,3,local+14); /*setelt*/
	local[14]= w;
	goto irtmodelCON1284;
irtmodelCON1286:
	local[14]= NIL;
irtmodelCON1284:
	w = local[14];
	local[5]= w;
	goto irtmodelIF1280;
irtmodelIF1279:
	local[5]= NIL;
irtmodelIF1280:
	goto irtmodelIF1278;
irtmodelIF1277:
	local[5]= NIL;
irtmodelIF1278:
	local[5]= local[3];
	local[6]= fqv[31];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[145]!=local[6]) goto irtmodelIF1299;
	local[6]= local[3];
	local[7]= fqv[20];
	local[8]= local[0];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtmodelIF1300;
irtmodelIF1299:
	if (T==NIL) goto irtmodelIF1301;
	local[6]= local[3];
	local[7]= fqv[20];
	local[8]= local[0];
	local[9]= local[2];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= fqv[31];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,3,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtmodelIF1302;
irtmodelIF1301:
	local[6]= NIL;
irtmodelIF1302:
irtmodelIF1300:
	w = local[6];
	local[5]= w;
	goto irtmodelIF1276;
irtmodelIF1275:
	local[5]= NIL;
irtmodelIF1276:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	local[7]= fqv[31];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
irtmodelWHL1303:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX1304;
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	local[10]= fqv[31];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[9];
	if (fqv[146]!=local[10]) goto irtmodelIF1306;
	local[10]= local[3];
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	goto irtmodelIF1307;
irtmodelIF1306:
	if (T==NIL) goto irtmodelIF1308;
	local[10]= local[3];
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	goto irtmodelIF1309;
irtmodelIF1308:
	local[10]= NIL;
irtmodelIF1309:
irtmodelIF1307:
	w = local[10];
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[2] = w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL1303;
irtmodelWHX1304:
	local[7]= NIL;
irtmodelBLK1305:
	w = NIL;
	goto irtmodelWHL1272;
irtmodelWHX1273:
	local[5]= NIL;
irtmodelBLK1274:
	w = NIL;
	w = local[1];
	local[0]= w;
irtmodelBLK1268:
	ctx->vsp=local; return(local[0]);}

/*:find-link-route*/
static pointer irtmodelM1310cascaded_link_find_link_route(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtmodelENT1313;}
	local[0]= NIL;
irtmodelENT1313:
irtmodelENT1312:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	if (local[1]==NIL) goto irtmodelCON1315;
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= fqv[136];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[21])(ctx,2,local+2,&ftab[21],fqv[142]); /*find*/
	if (w!=NIL) goto irtmodelCON1315;
	local[2]= argv[0];
	local[3]= fqv[147];
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto irtmodelCON1314;
irtmodelCON1315:
	if (local[1]==NIL) goto irtmodelCON1316;
	local[2]= argv[2];
	if (local[0]==local[2]) goto irtmodelCON1316;
	local[2]= argv[0];
	local[3]= fqv[147];
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	goto irtmodelCON1314;
irtmodelCON1316:
	if (local[1]==NIL) goto irtmodelCON1317;
	local[2]= argv[2];
	if (local[0]!=local[2]) goto irtmodelCON1317;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	goto irtmodelCON1314;
irtmodelCON1317:
	local[2]= NIL;
irtmodelCON1314:
	w = local[2];
	local[0]= w;
irtmodelBLK1311:
	ctx->vsp=local; return(local[0]);}

/*:link-list*/
static pointer irtmodelM1318cascaded_link_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtmodelENT1321;}
	local[0]= NIL;
irtmodelENT1321:
irtmodelENT1320:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[147];
	local[5]= argv[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[1] = w;
	if (local[0]==NIL) goto irtmodelIF1322;
	local[3]= local[0];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==local[3]) goto irtmodelIF1322;
	local[3]= argv[0];
	local[4]= fqv[147];
	local[5]= local[0];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)NCONC(ctx,2,local+3); /*nconc*/
	local[1] = w;
	local[3]= local[1];
	goto irtmodelIF1323;
irtmodelIF1322:
	local[3]= NIL;
irtmodelIF1323:
	w = local[1];
	local[0]= w;
irtmodelBLK1319:
	ctx->vsp=local; return(local[0]);}

/*:make-joint-min-max-table*/
static pointer irtmodelM1324cascaded_link_make_joint_min_max_table(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[148], &argv[6], n-6, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1326;
	local[0] = makeint((eusinteger_t)0L);
irtmodelKEY1326:
	if (n & (1<<1)) goto irtmodelKEY1327;
	local[1] = NIL;
irtmodelKEY1327:
	if (n & (1<<2)) goto irtmodelKEY1328;
	local[2] = NIL;
irtmodelKEY1328:
	if (n & (1<<3)) goto irtmodelKEY1329;
	local[3] = makeflt(0.0000000000000000000000e+00);
irtmodelKEY1329:
	if (n & (1<<4)) goto irtmodelKEY1330;
	local[4] = NIL;
irtmodelKEY1330:
	if (local[2]!=NIL) goto irtmodelIF1331;
	local[5]= argv[0];
	local[6]= fqv[136];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[149];
	local[7]= fqv[120];
	ctx->vsp=local+8;
	w=(*ftab[18])(ctx,3,local+5,&ftab[18],fqv[128]); /*send-all*/
	local[5]= w;
	goto irtmodelIF1332;
irtmodelIF1331:
	local[5]= NIL;
irtmodelIF1332:
	local[5]= NIL;
	local[6]= argv[4];
	local[7]= argv[5];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
irtmodelWHL1333:
	if (local[6]==NIL) goto irtmodelWHX1334;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[150];
	local[9]= fqv[151];
	local[10]= local[5];
	local[11]= fqv[22];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[5];
	local[8]= fqv[150];
	local[9]= fqv[152];
	local[10]= local[5];
	local[11]= fqv[23];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	goto irtmodelWHL1333;
irtmodelWHX1334:
	local[7]= NIL;
irtmodelBLK1335:
	w = NIL;
	local[5]= argv[0];
	local[6]= fqv[153];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[154];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[4];
	local[8]= fqv[22];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRUNCATE(ctx,1,local+7); /*truncate*/
	local[7]= w;
	local[8]= argv[4];
	local[9]= fqv[23];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRUNCATE(ctx,1,local+8); /*truncate*/
	local[8]= w;
	local[9]= argv[5];
	local[10]= fqv[22];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TRUNCATE(ctx,1,local+9); /*truncate*/
	local[9]= w;
	local[10]= argv[5];
	local[11]= fqv[23];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TRUNCATE(ctx,1,local+10); /*truncate*/
	local[10]= w;
	local[11]= local[8];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ROUND(ctx,1,local+11); /*round*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[11]= w;
	local[12]= local[10];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,2,local+12); /*-*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ROUND(ctx,1,local+12); /*round*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[12]= w;
	if (local[2]==NIL) goto irtmodelIF1336;
	local[13]= T;
	local[14]= fqv[155];
	local[15]= argv[4];
	local[16]= fqv[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= argv[4];
	local[17]= fqv[22];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= argv[4];
	local[18]= fqv[23];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= T;
	local[14]= fqv[156];
	local[15]= argv[5];
	local[16]= fqv[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= argv[5];
	local[17]= fqv[22];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= argv[5];
	local[18]= fqv[23];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= T;
	local[14]= fqv[157];
	local[15]= argv[4];
	local[16]= fqv[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= local[7];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= T;
	local[14]= fqv[158];
	local[15]= argv[5];
	local[16]= fqv[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= local[9];
	local[17]= local[10];
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= w;
	goto irtmodelIF1337;
irtmodelIF1336:
	local[13]= NIL;
irtmodelIF1337:
	local[13]= argv[0];
	local[14]= fqv[159];
	ctx->vsp=local+15;
	w=(*ftab[11])(ctx,0,local+15,&ftab[11],fqv[86]); /*make-coords*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[160];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	if (local[4]==NIL) goto irtmodelIF1338;
	local[13]= argv[2];
	local[14]= NIL;
	local[15]= fqv[161];
	ctx->vsp=local+16;
	w=(pointer)PUTPROP(ctx,3,local+13); /*putprop*/
	local[13]= argv[3];
	local[14]= NIL;
	local[15]= fqv[161];
	ctx->vsp=local+16;
	w=(pointer)PUTPROP(ctx,3,local+13); /*putprop*/
	local[13]= argv[2];
	local[14]= argv[3];
	local[15]= makeint((eusinteger_t)2L);
	local[16]= fqv[162];
	local[17]= local[0];
	local[18]= fqv[163];
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(*ftab[22])(ctx,7,local+13,&ftab[22],fqv[164]); /*collision-check*/
	local[13]= w;
	goto irtmodelIF1339;
irtmodelIF1338:
	local[13]= NIL;
irtmodelIF1339:
	local[13]= argv[0];
	local[14]= fqv[165];
	local[15]= argv[2];
	local[16]= argv[3];
	local[17]= argv[4];
	local[18]= argv[5];
	local[19]= local[11];
	local[20]= local[12];
	local[21]= local[7];
	local[22]= local[9];
	local[23]= local[0];
	local[24]= local[1];
	local[25]= local[2];
	local[26]= local[3];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,14,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[154];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[159];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	if (local[2]!=NIL) goto irtmodelIF1340;
	local[13]= argv[0];
	local[14]= fqv[136];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= fqv[149];
	local[15]= fqv[116];
	ctx->vsp=local+16;
	w=(*ftab[18])(ctx,3,local+13,&ftab[18],fqv[128]); /*send-all*/
	local[13]= w;
	goto irtmodelIF1341;
irtmodelIF1340:
	local[13]= NIL;
irtmodelIF1341:
	w = NIL;
	local[0]= w;
irtmodelBLK1325:
	ctx->vsp=local; return(local[0]);}

/*:make-min-max-table-using-collision-check*/
static pointer irtmodelM1342cascaded_link_make_min_max_table_using_collision_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=14) maerror();
	local[0]= argv[7];
	local[1]= argv[6];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[166]); /*make-matrix*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)10L);
	local[4]= makeint((eusinteger_t)0L);
irtmodelTAG1345:
	local[5]= local[4];
	local[6]= argv[7];
	ctx->vsp=local+7;
	w=(pointer)GREQP(ctx,2,local+5); /*>=*/
	if (w==NIL) goto irtmodelIF1346;
	w = NIL;
	ctx->vsp=local+5;
	local[4]=w;
	goto irtmodelBLK1344;
	goto irtmodelIF1347;
irtmodelIF1346:
	local[5]= NIL;
irtmodelIF1347:
	local[5]= argv[5];
	local[6]= fqv[20];
	local[7]= local[4];
	local[8]= argv[9];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[1] = fqv[167];
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)10L);
	ctx->vsp=local+7;
	w=(pointer)MOD(ctx,2,local+5); /*mod*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto irtmodelIF1348;
	local[5]= T;
	local[6]= fqv[168];
	local[7]= makeint((eusinteger_t)13L);
	local[8]= local[4];
	local[9]= argv[6];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= argv[6];
	local[10]= argv[7];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,5,local+5); /*format*/
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,0,local+5); /*finish-output*/
	local[5]= w;
	goto irtmodelIF1349;
irtmodelIF1348:
	local[5]= NIL;
irtmodelIF1349:
	local[5]= makeint((eusinteger_t)0L);
irtmodelTAG1351:
	local[6]= local[5];
	local[7]= argv[6];
	ctx->vsp=local+8;
	w=(pointer)GREQP(ctx,2,local+6); /*>=*/
	if (w==NIL) goto irtmodelIF1352;
	w = NIL;
	ctx->vsp=local+6;
	local[5]=w;
	goto irtmodelBLK1350;
	goto irtmodelIF1353;
irtmodelIF1352:
	local[6]= NIL;
irtmodelIF1353:
	{jmp_buf jb;
	w = fqv[169];
	ctx->vsp=local+6;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto irtmodelCAT1354;}
	local[12]= argv[4];
	local[13]= fqv[20];
	local[14]= local[5];
	local[15]= argv[8];
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ROUND(ctx,1,local+14); /*round*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= local[1];
	if (fqv[170]!=local[12]) goto irtmodelCON1356;
	local[12]= local[5];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)MOD(ctx,2,local+12); /*mod*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[24])(ctx,2,local+12,&ftab[24],fqv[171]); /*/=*/
	if (w==NIL) goto irtmodelCON1356;
	local[12]= local[5];
	local[13]= argv[6];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LSEQP(ctx,2,local+12); /*<=*/
	if (w==NIL) goto irtmodelCON1356;
	local[2] = T;
	local[12]= local[2];
	goto irtmodelCON1355;
irtmodelCON1356:
	local[12]= argv[2];
	local[13]= argv[3];
	local[14]= makeint((eusinteger_t)2L);
	local[15]= fqv[162];
	local[16]= argv[10];
	local[17]= fqv[163];
	local[18]= argv[11];
	ctx->vsp=local+19;
	w=(*ftab[22])(ctx,7,local+12,&ftab[22],fqv[164]); /*collision-check*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)NUMEQUAL(ctx,2,local+12); /*=*/
	local[2] = w;
	local[12]= local[1];
	if (fqv[167]!=local[12]) goto irtmodelCON1359;
	if (local[2]==NIL) goto irtmodelCON1359;
	local[1] = fqv[170];
	local[12]= local[1];
	goto irtmodelCON1358;
irtmodelCON1359:
	local[12]= local[1];
	if (fqv[170]!=local[12]) goto irtmodelCON1360;
	if (local[2]!=NIL) goto irtmodelCON1360;
	local[1] = fqv[172];
	local[12]= local[5];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,2,local+12); /*-*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MAX(ctx,2,local+12); /*max*/
	local[5] = w;
	local[12]= fqv[169];
	w = NIL;
	ctx->vsp=local+13;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto irtmodelCON1358;
irtmodelCON1360:
	local[12]= NIL;
irtmodelCON1358:
	goto irtmodelCON1355;
irtmodelCON1357:
	local[12]= NIL;
irtmodelCON1355:
	local[12]= local[0];
	local[13]= local[4];
	local[14]= local[5];
	if (local[2]==NIL) goto irtmodelIF1361;
	local[15]= makeint((eusinteger_t)1L);
	goto irtmodelIF1362;
irtmodelIF1361:
	local[15]= makeint((eusinteger_t)0L);
irtmodelIF1362:
	ctx->vsp=local+16;
	w=(pointer)ASET(ctx,4,local+12); /*aset*/
	if (argv[12]==NIL) goto irtmodelIF1363;
	local[12]= T;
	local[13]= fqv[173];
	local[14]= argv[5];
	local[15]= fqv[3];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= local[4];
	local[16]= argv[9];
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[15]= w;
	local[16]= argv[4];
	local[17]= fqv[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= local[5];
	local[18]= argv[8];
	ctx->vsp=local+19;
	w=(pointer)PLUS(ctx,2,local+17); /*+*/
	local[17]= w;
	local[18]= local[2];
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(pointer)XFORMAT(ctx,8,local+12); /*format*/
	local[12]= w;
	goto irtmodelIF1364;
irtmodelIF1363:
	local[12]= NIL;
irtmodelIF1364:
	w = local[12];
irtmodelCAT1354:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[5] = local[6];
	w = NIL;
	ctx->vsp=local+6;
	goto irtmodelTAG1351;
	w = NIL;
	local[5]= w;
irtmodelBLK1350:
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[4] = local[5];
	w = NIL;
	ctx->vsp=local+5;
	goto irtmodelTAG1345;
	w = NIL;
	local[4]= w;
irtmodelBLK1344:
	w = local[4];
	local[1]= T;
	local[2]= fqv[174];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelFLET1365,env,argv,local);
	local[2]= argv[6];
	local[3]= argv[7];
	local[4]= argv[8];
	local[5]= argv[9];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtmodelCLO1366,env,argv,local);
	w = local[1];
	ctx->vsp=local+7;
	w=irtmodelFLET1365(ctx,5,local+2,w);
	local[2]= w;
	local[3]= argv[5];
	local[4]= fqv[11];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[5];
	local[4]= fqv[10];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2]= argv[7];
	local[3]= argv[6];
	local[4]= argv[9];
	local[5]= argv[8];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtmodelCLO1367,env,argv,local);
	w = local[1];
	ctx->vsp=local+7;
	w=irtmodelFLET1365(ctx,5,local+2,w);
	local[2]= w;
	local[3]= argv[4];
	local[4]= fqv[11];
	local[5]= argv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[4];
	local[4]= fqv[10];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[0]= w;
irtmodelBLK1343:
	ctx->vsp=local; return(local[0]);}

/*:plot-joint-min-max-table-common*/
static pointer irtmodelM1368cascaded_link_plot_joint_min_max_table_common(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= loadglobal(fqv[175]);
	local[2]= loadglobal(fqv[176]);
	local[3]= NIL;
	ctx->vsp=local+4;
	w = makeclosure(codevec,quotevec,irtmodelUWP1370,env,argv,local);
	local[4]=(pointer)(ctx->protfp); local[5]=w;
	ctx->protfp=(struct protectframe *)(local+4);
	local[6]= fqv[177];
	local[7]= fqv[178];
	local[8]= fqv[179];
	ctx->vsp=local+9;
	w=(*ftab[25])(ctx,3,local+6,&ftab[25],fqv[180]); /*open*/
	local[6]= w;
	ctx->vsp=local+7;
	w = makeclosure(codevec,quotevec,irtmodelUWP1371,env,argv,local);
	local[7]=(pointer)(ctx->protfp); local[8]=w;
	ctx->protfp=(struct protectframe *)(local+7);
	local[9]= local[6];
	storeglobal(fqv[175],local[9]);
	local[9]= local[6];
	storeglobal(fqv[176],local[9]);
	local[9]= argv[2];
	local[10]= fqv[151];
	ctx->vsp=local+11;
	w=(pointer)GETPROP(ctx,2,local+9); /*get*/
	local[9]= w;
irtmodelTAG1373:
	local[10]= local[9];
	local[11]= argv[2];
	local[12]= fqv[152];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)GREATERP(ctx,2,local+10); /*>*/
	if (w==NIL) goto irtmodelIF1374;
	w = NIL;
	ctx->vsp=local+10;
	local[9]=w;
	goto irtmodelBLK1372;
	goto irtmodelIF1375;
irtmodelIF1374:
	local[10]= NIL;
irtmodelIF1375:
	local[10]= argv[0];
	local[11]= fqv[160];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= argv[2];
	local[11]= fqv[20];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[2];
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)EUSFLOAT(ctx,1,local+10); /*float*/
	local[10]= w;
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)EUSFLOAT(ctx,1,local+11); /*float*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[8])(ctx,2,local+10,&ftab[8],fqv[81]); /*eps=*/
	local[10]= w;
	local[11]= argv[3];
	local[12]= fqv[151];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
irtmodelTAG1377:
	local[12]= local[11];
	local[13]= argv[3];
	local[14]= fqv[152];
	ctx->vsp=local+15;
	w=(pointer)GETPROP(ctx,2,local+13); /*get*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmodelIF1378;
	w = NIL;
	ctx->vsp=local+12;
	local[11]=w;
	goto irtmodelBLK1376;
	goto irtmodelIF1379;
irtmodelIF1378:
	local[12]= NIL;
irtmodelIF1379:
	local[12]= argv[3];
	local[13]= fqv[20];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= argv[3];
	local[13]= fqv[20];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)EUSFLOAT(ctx,1,local+12); /*float*/
	local[12]= w;
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)EUSFLOAT(ctx,1,local+13); /*float*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,2,local+12,&ftab[8],fqv[81]); /*eps=*/
	local[12]= w;
	if (local[10]==NIL) goto irtmodelIF1380;
	if (local[12]==NIL) goto irtmodelIF1380;
	local[13]= local[9];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,2,local+13); /*list*/
	local[13]= w;
	w = local[0];
	ctx->vsp=local+14;
	local[0] = cons(ctx,local[13],w);
	local[13]= local[0];
	goto irtmodelIF1381;
irtmodelIF1380:
	local[13]= NIL;
irtmodelIF1381:
	w = local[13];
	local[12]= makeint((eusinteger_t)1L);
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[11] = local[12];
	w = NIL;
	ctx->vsp=local+12;
	goto irtmodelTAG1377;
	w = NIL;
	local[11]= w;
irtmodelBLK1376:
	w = local[11];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[9] = local[10];
	w = NIL;
	ctx->vsp=local+10;
	goto irtmodelTAG1373;
	w = NIL;
	local[9]= w;
irtmodelBLK1372:
	local[3] = local[9];
	w = local[3];
	ctx->vsp=local+9;
	irtmodelUWP1371(ctx,0,local+9,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	ctx->vsp=local+6;
	irtmodelUWP1370(ctx,0,local+6,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
irtmodelBLK1369:
	ctx->vsp=local; return(local[0]);}

/*:plot-joint-min-max-table*/
static pointer irtmodelM1382cascaded_link_plot_joint_min_max_table(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= loadglobal(fqv[181]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[182];
	local[3]= fqv[183];
	local[4]= argv[2];
	local[5]= fqv[184];
	local[6]= fqv[152];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= fqv[184];
	local[7]= fqv[151];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= fqv[185];
	local[6]= argv[3];
	local[7]= fqv[184];
	local[8]= fqv[152];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= argv[3];
	local[8]= fqv[184];
	local[9]= fqv[151];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= fqv[186];
	local[8]= fqv[187];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	w = local[0];
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[188];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= fqv[189];
	local[4]= makeint((eusinteger_t)16777215L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= local[0];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= local[0];
	local[3]= fqv[189];
	local[4]= makeint((eusinteger_t)16711680L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= NIL;
	local[3]= local[1];
irtmodelWHL1384:
	if (local[3]==NIL) goto irtmodelWHX1385;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[0];
	local[5]= fqv[191];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= fqv[151];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= argv[3];
	local[9]= fqv[151];
	ctx->vsp=local+10;
	w=(pointer)GETPROP(ctx,2,local+8); /*get*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,2,local+6); /*float-vector*/
	local[6]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= argv[2];
	local[9]= fqv[151];
	ctx->vsp=local+10;
	w=(pointer)GETPROP(ctx,2,local+8); /*get*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)ROUND(ctx,1,local+8); /*round*/
	local[8]= w;
	local[9]= argv[3];
	local[10]= fqv[151];
	ctx->vsp=local+11;
	w=(pointer)GETPROP(ctx,2,local+9); /*get*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,2,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	goto irtmodelWHL1384;
irtmodelWHX1385:
	local[4]= NIL;
irtmodelBLK1386:
	w = NIL;
	local[2]= local[0];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[0]= w;
irtmodelBLK1383:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1252(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1255(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1258(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET1365(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= makeint((eusinteger_t)3L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[166]); /*make-matrix*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
irtmodelWHL1387:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtmodelWHX1388;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[1];
irtmodelWHL1390:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX1391;
	local[8]= argv[4];
	local[9]= env->c.clo.env2[0];
	local[10]= local[1];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)FUNCALL(ctx,4,local+8); /*funcall*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)NUMEQUAL(ctx,2,local+8); /*=*/
	if (w==NIL) goto irtmodelIF1393;
	local[5] = T;
	local[8]= local[6];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtmodelIF1395;
	local[3] = local[6];
	local[8]= local[3];
	goto irtmodelIF1396;
irtmodelIF1395:
	local[8]= NIL;
irtmodelIF1396:
	local[8]= local[6];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w==NIL) goto irtmodelIF1397;
	local[4] = local[6];
	local[8]= local[4];
	goto irtmodelIF1398;
irtmodelIF1397:
	local[8]= NIL;
irtmodelIF1398:
	goto irtmodelIF1394;
irtmodelIF1393:
	local[8]= NIL;
irtmodelIF1394:
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL1390;
irtmodelWHX1391:
	local[8]= NIL;
irtmodelBLK1392:
	w = NIL;
	if (local[5]!=NIL) goto irtmodelIF1399;
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[3] = w;
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[4] = w;
	local[6]= local[4];
	goto irtmodelIF1400;
irtmodelIF1399:
	local[6]= NIL;
irtmodelIF1400:
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
	local[9]= argv[2];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ROUND(ctx,1,local+9); /*round*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ASET(ctx,4,local+6); /*aset*/
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= local[1];
	local[9]= env->c.clo.env1[13];
	local[10]= argv[3];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,3,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ROUND(ctx,1,local+9); /*round*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ASET(ctx,4,local+6); /*aset*/
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[1];
	local[9]= env->c.clo.env1[13];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= argv[3];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,3,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ROUND(ctx,1,local+9); /*round*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ASET(ctx,4,local+6); /*aset*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtmodelWHL1387;
irtmodelWHX1388:
	local[3]= NIL;
irtmodelBLK1389:
	w = NIL;
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1366(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1367(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP1370(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	storeglobal(fqv[175],local[0]);
	local[0]= env->c.clo.env2[1];
	storeglobal(fqv[176],local[0]);
	w = env->c.clo.env2[3];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP1371(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[6];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:calc-target-axis-dimension*/
static pointer irtmodelM1401cascaded_link_calc_target_axis_dimension(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)6L);
	w = argv[2];
	if (!!iscons(w)) goto irtmodelIF1403;
	local[1]= makeint((eusinteger_t)1L);
	goto irtmodelIF1404;
irtmodelIF1403:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
irtmodelIF1404:
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= NIL;
	w = argv[3];
	if (!!iscons(w)) goto irtmodelIF1405;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	goto irtmodelIF1406;
irtmodelIF1405:
	local[2]= argv[3];
irtmodelIF1406:
	w = argv[2];
	if (!!iscons(w)) goto irtmodelIF1407;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	goto irtmodelIF1408;
irtmodelIF1407:
	local[3]= argv[2];
irtmodelIF1408:
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
irtmodelWHL1409:
	if (local[2]==NIL) goto irtmodelWHX1410;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= local[3];
	w = fqv[192];
	if (memq(local[4],w)==NIL) goto irtmodelIF1412;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[0] = w;
	local[4]= local[0];
	goto irtmodelIF1413;
irtmodelIF1412:
	local[4]= local[3];
	w = fqv[193];
	if (memq(local[4],w)==NIL) goto irtmodelIF1414;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[0] = w;
	local[4]= local[0];
	goto irtmodelIF1415;
irtmodelIF1414:
	local[4]= local[3];
	if (fqv[194]!=local[4]) goto irtmodelIF1416;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[0] = w;
	local[4]= local[0];
	goto irtmodelIF1417;
irtmodelIF1416:
	local[4]= NIL;
irtmodelIF1417:
irtmodelIF1415:
irtmodelIF1413:
	w = local[4];
	goto irtmodelWHL1409;
irtmodelWHX1410:
	local[3]= NIL;
irtmodelBLK1411:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK1402:
	ctx->vsp=local; return(local[0]);}

/*:calc-union-link-list*/
static pointer irtmodelM1418cascaded_link_calc_union_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelCON1421;
	local[0]= argv[2];
	goto irtmodelCON1420;
irtmodelCON1421:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	if (makeint((eusinteger_t)1L)!=local[0]) goto irtmodelCON1422;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	goto irtmodelCON1420;
irtmodelCON1422:
	local[0]= (pointer)get_sym_func(fqv[195]);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,2,local+0,&ftab[26],fqv[196]); /*reduce*/
	local[0]= w;
	goto irtmodelCON1420;
irtmodelCON1423:
	local[0]= NIL;
irtmodelCON1420:
	w = local[0];
	local[0]= w;
irtmodelBLK1419:
	ctx->vsp=local; return(local[0]);}

/*:calc-target-joint-dimension*/
static pointer irtmodelM1424cascaded_link_calc_target_joint_dimension(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[197];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[198];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+0); /*calc-target-joint-dimension*/
	local[0]= w;
irtmodelBLK1425:
	ctx->vsp=local; return(local[0]);}

/*:calc-inverse-jacobian*/
static pointer irtmodelM1426cascaded_link_calc_inverse_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1428:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[199], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1429;
	local[1] = makeflt(9.9999999999999977795540e-02);
irtmodelKEY1429:
	if (n & (1<<1)) goto irtmodelKEY1430;
	local[2] = makeflt(1.0000000000000000208167e-03);
irtmodelKEY1430:
	if (n & (1<<2)) goto irtmodelKEY1431;
	local[3] = NIL;
irtmodelKEY1431:
	if (n & (1<<3)) goto irtmodelKEY1432;
	local[4] = NIL;
irtmodelKEY1432:
	if (n & (1<<4)) goto irtmodelKEY1433;
	local[5] = NIL;
irtmodelKEY1433:
	if (n & (1<<5)) goto irtmodelKEY1434;
	local[6] = NIL;
irtmodelKEY1434:
	if (n & (1<<6)) goto irtmodelKEY1435;
	local[7] = NIL;
irtmodelKEY1435:
	if (n & (1<<7)) goto irtmodelKEY1436;
	local[8] = NIL;
irtmodelKEY1436:
	if (n & (1<<8)) goto irtmodelKEY1437;
	local[9] = NIL;
irtmodelKEY1437:
	if (n & (1<<9)) goto irtmodelKEY1438;
	local[10] = NIL;
irtmodelKEY1438:
	if (n & (1<<10)) goto irtmodelKEY1439;
	local[11] = NIL;
irtmodelKEY1439:
	if (n & (1<<11)) goto irtmodelKEY1440;
	local[12] = NIL;
irtmodelKEY1440:
	if (n & (1<<12)) goto irtmodelKEY1441;
	local[13] = NIL;
irtmodelKEY1441:
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= makeint((eusinteger_t)0L);
	local[18]= argv[2];
	local[19]= local[12];
	local[20]= local[7];
	ctx->vsp=local+21;
	w=(*ftab[27])(ctx,3,local+18,&ftab[27],fqv[200]); /*manipulability*/
	local[15] = w;
	local[18]= local[15];
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(pointer)LESSP(ctx,2,local+18); /*<*/
	if (w==NIL) goto irtmodelIF1442;
	local[18]= local[2];
	local[19]= makeflt(1.0000000000000000000000e+00);
	local[20]= local[15];
	local[21]= local[1];
	ctx->vsp=local+22;
	w=(pointer)QUOTIENT(ctx,2,local+20); /*/*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)MINUS(ctx,2,local+19); /*-*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(*ftab[28])(ctx,2,local+19,&ftab[28],fqv[201]); /*expt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[17] = w;
	local[18]= local[17];
	goto irtmodelIF1443;
irtmodelIF1442:
	local[18]= NIL;
irtmodelIF1443:
	if (local[4]==NIL) goto irtmodelIF1444;
	local[18]= fqv[202];
	w = local[4];
	if (memq(local[18],w)!=NIL) goto irtmodelIF1444;
	local[18]= fqv[203];
	local[19]= local[17];
	local[20]= local[15];
	local[21]= local[2];
	local[22]= local[1];
	local[23]= argv[2];
	ctx->vsp=local+24;
	w=(*ftab[29])(ctx,1,local+23,&ftab[29],fqv[204]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	ctx->vsp=local+24;
	w=(*ftab[2])(ctx,6,local+18,&ftab[2],fqv[15]); /*warn*/
	local[18]= w;
	goto irtmodelIF1445;
irtmodelIF1444:
	local[18]= NIL;
irtmodelIF1445:
	local[18]= argv[2];
	local[19]= local[17];
	local[20]= local[3];
	local[21]= local[5];
	local[22]= local[6];
	local[23]= local[7];
	local[24]= local[8];
	local[25]= local[9];
	local[26]= local[10];
	local[27]= local[11];
	local[28]= local[12];
	local[29]= local[13];
	ctx->vsp=local+30;
	w=(*ftab[30])(ctx,12,local+18,&ftab[30],fqv[205]); /*sr-inverse*/
	local[14] = w;
	w = local[14];
	local[0]= w;
irtmodelBLK1427:
	ctx->vsp=local; return(local[0]);}

/*:calc-gradh-from-link-list*/
static pointer irtmodelM1446cascaded_link_calc_gradh_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtmodelENT1449;}
	local[0]= loadglobal(fqv[5]);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
irtmodelENT1449:
irtmodelENT1448:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[198];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(*ftab[18])(ctx,2,local+2,&ftab[18],fqv[128]); /*send-all*/
	local[2]= w;
	local[3]= local[1];
	local[4]= fqv[22];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[128]); /*send-all*/
	local[3]= w;
	local[4]= local[1];
	local[5]= fqv[23];
	ctx->vsp=local+6;
	w=(*ftab[18])(ctx,2,local+4,&ftab[18],fqv[128]); /*send-all*/
	local[4]= w;
	local[5]= loadglobal(fqv[88]);
	local[6]= (pointer)get_sym_func(fqv[206]);
	local[7]= local[4];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)MAP(ctx,4,local+5); /*map*/
	local[5]= w;
	local[6]= loadglobal(fqv[88]);
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtmodelCLO1450,env,argv,local);
	local[8]= local[4];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MAP(ctx,4,local+6); /*map*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
irtmodelWHL1451:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtmodelWHX1452;
	local[9]= local[0];
	local[10]= local[7];
	local[11]= local[6];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[2];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	local[12]= local[5];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtmodelWHL1451;
irtmodelWHX1452:
	local[9]= NIL;
irtmodelBLK1453:
	w = local[0];
	w = local[0];
	local[0]= w;
irtmodelBLK1447:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian-from-link-list*/
static pointer irtmodelM1454cascaded_link_calc_jacobian_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1456:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[207], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1457;
	local[1] = NIL;
irtmodelKEY1457:
	if (n & (1<<1)) goto irtmodelKEY1458;
	local[2] = local[1];
irtmodelKEY1458:
	if (n & (1<<2)) goto irtmodelKEY1459;
	w = local[1];
	if (!!iscons(w)) goto irtmodelCON1461;
	local[16]= NIL;
	goto irtmodelCON1460;
irtmodelCON1461:
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[31])(ctx,1,local+16,&ftab[31],fqv[208]); /*make-list*/
	local[16]= w;
	goto irtmodelCON1460;
irtmodelCON1462:
	local[16]= NIL;
irtmodelCON1460:
	local[3] = local[16];
irtmodelKEY1459:
	if (n & (1<<3)) goto irtmodelKEY1463;
	w = local[1];
	if (!!iscons(w)) goto irtmodelCON1465;
	local[16]= T;
	goto irtmodelCON1464;
irtmodelCON1465:
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
	local[17]= fqv[209];
	local[18]= T;
	ctx->vsp=local+19;
	w=(*ftab[31])(ctx,3,local+16,&ftab[31],fqv[208]); /*make-list*/
	local[16]= w;
	goto irtmodelCON1464;
irtmodelCON1466:
	local[16]= NIL;
irtmodelCON1464:
	local[4] = local[16];
irtmodelKEY1463:
	if (n & (1<<4)) goto irtmodelKEY1467;
	local[5] = makeint((eusinteger_t)0L);
irtmodelKEY1467:
	if (n & (1<<5)) goto irtmodelKEY1468;
	local[16]= argv[0];
	local[17]= fqv[210];
	local[18]= local[3];
	local[19]= local[4];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,4,local+16); /*send*/
	local[6] = w;
irtmodelKEY1468:
	if (n & (1<<6)) goto irtmodelKEY1469;
	local[16]= argv[0];
	local[17]= fqv[211];
	local[18]= argv[2];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,3,local+16); /*send*/
	local[7] = w;
irtmodelKEY1469:
	if (n & (1<<7)) goto irtmodelKEY1470;
	local[8] = NIL;
irtmodelKEY1470:
	if (n & (1<<8)) goto irtmodelKEY1471;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[9] = w;
irtmodelKEY1471:
	if (n & (1<<9)) goto irtmodelKEY1472;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[10] = w;
irtmodelKEY1472:
	if (n & (1<<10)) goto irtmodelKEY1473;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[11] = w;
irtmodelKEY1473:
	if (n & (1<<11)) goto irtmodelKEY1474;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[12] = w;
irtmodelKEY1474:
	if (n & (1<<12)) goto irtmodelKEY1475;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[13] = w;
irtmodelKEY1475:
	if (n & (1<<13)) goto irtmodelKEY1476;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[14] = w;
irtmodelKEY1476:
	if (n & (1<<14)) goto irtmodelKEY1477;
	local[16]= makeint((eusinteger_t)3L);
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(*ftab[23])(ctx,2,local+16,&ftab[23],fqv[166]); /*make-matrix*/
	local[15] = w;
irtmodelKEY1477:
	local[16]= NIL;
	local[17]= NIL;
	local[18]= NIL;
	local[19]= NIL;
	local[20]= NIL;
	local[21]= NIL;
	local[22]= NIL;
	if (local[8]!=NIL) goto irtmodelIF1478;
	local[23]= local[6];
	local[24]= local[7];
	ctx->vsp=local+25;
	w=(*ftab[23])(ctx,2,local+23,&ftab[23],fqv[166]); /*make-matrix*/
	local[8] = w;
	local[23]= local[8];
	goto irtmodelIF1479;
irtmodelIF1478:
	local[23]= NIL;
irtmodelIF1479:
	local[23]= argv[0];
	local[24]= fqv[197];
	local[25]= argv[2];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[20] = w;
	local[23]= argv[0];
	local[24]= fqv[211];
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[22] = w;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF1480;
	local[23]= argv[2];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	argv[2] = w;
	local[23]= argv[2];
	goto irtmodelIF1481;
irtmodelIF1480:
	local[23]= NIL;
irtmodelIF1481:
	w = local[1];
	if (!!iscons(w)) goto irtmodelIF1482;
	local[23]= local[1];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[1] = w;
	local[23]= local[1];
	goto irtmodelIF1483;
irtmodelIF1482:
	local[23]= NIL;
irtmodelIF1483:
	w = local[2];
	if (!!iscons(w)) goto irtmodelIF1484;
	local[23]= local[2];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[2] = w;
	local[23]= local[2];
	goto irtmodelIF1485;
irtmodelIF1484:
	local[23]= NIL;
irtmodelIF1485:
	w = local[3];
	if (!!iscons(w)) goto irtmodelIF1486;
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[3] = w;
	local[23]= local[3];
	goto irtmodelIF1487;
irtmodelIF1486:
	local[23]= NIL;
irtmodelIF1487:
	w = local[4];
	if (!!iscons(w)) goto irtmodelIF1488;
	local[23]= local[4];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[4] = w;
	local[23]= local[4];
	goto irtmodelIF1489;
irtmodelIF1488:
	local[23]= NIL;
irtmodelIF1489:
	local[23]= local[5];
	local[24]= makeint((eusinteger_t)0L);
irtmodelTAG1491:
	local[25]= local[23];
	local[26]= local[5];
	local[27]= local[22];
	ctx->vsp=local+28;
	w=(pointer)PLUS(ctx,2,local+26); /*+*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)GREQP(ctx,2,local+25); /*>=*/
	if (w==NIL) goto irtmodelIF1492;
	w = NIL;
	ctx->vsp=local+25;
	local[23]=w;
	goto irtmodelBLK1490;
	goto irtmodelIF1493;
irtmodelIF1492:
	local[25]= NIL;
irtmodelIF1493:
	local[25]= local[20];
	local[26]= local[24];
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[17] = w;
	local[18] = makeint((eusinteger_t)0L);
	local[25]= makeint((eusinteger_t)0L);
	local[26]= argv[2];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
irtmodelWHL1494:
	local[27]= local[25];
	w = local[26];
	if ((eusinteger_t)local[27] >= (eusinteger_t)w) goto irtmodelWHX1495;
	local[27]= argv[2];
	local[28]= local[25];
	ctx->vsp=local+29;
	w=(pointer)ELT(ctx,2,local+27); /*elt*/
	local[27]= w;
	local[28]= local[1];
	local[29]= local[25];
	ctx->vsp=local+30;
	w=(pointer)ELT(ctx,2,local+28); /*elt*/
	local[28]= w;
	local[29]= local[2];
	local[30]= local[25];
	ctx->vsp=local+31;
	w=(pointer)ELT(ctx,2,local+29); /*elt*/
	local[29]= w;
	local[30]= local[3];
	local[31]= local[25];
	ctx->vsp=local+32;
	w=(pointer)ELT(ctx,2,local+30); /*elt*/
	local[30]= w;
	local[31]= local[4];
	local[32]= local[25];
	ctx->vsp=local+33;
	w=(pointer)ELT(ctx,2,local+31); /*elt*/
	local[31]= w;
	local[32]= NIL;
	local[33]= local[17];
	local[34]= local[27];
	local[35]= fqv[139];
	local[36]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+37;
	w=(*ftab[16])(ctx,4,local+33,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelIF1497;
	local[33]= local[27];
	ctx->vsp=local+34;
	w=(pointer)LENGTH(ctx,1,local+33); /*length*/
	local[16] = w;
	local[33]= local[17];
	local[34]= local[27];
	local[35]= fqv[139];
	local[36]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+37;
	w=(*ftab[32])(ctx,4,local+33,&ftab[32],fqv[212]); /*position*/
	local[32] = w;
	local[33]= local[17];
	local[34]= fqv[198];
	ctx->vsp=local+35;
	w=(pointer)SEND(ctx,2,local+33); /*send*/
	local[21] = w;
	ctx->vsp=local+33;
	local[33]= makeclosure(codevec,quotevec,irtmodelFLET1499,env,argv,local);
	local[34]= local[21];
	local[35]= fqv[130];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,2,local+34); /*send*/
	local[34]= w;
	local[35]= loadglobal(fqv[213]);
	ctx->vsp=local+36;
	w=(pointer)DERIVEDP(ctx,2,local+34); /*derivedp*/
	if (w!=NIL) goto irtmodelCON1501;
	local[19] = NIL;
	local[34]= local[19];
	goto irtmodelCON1500;
irtmodelCON1501:
	local[34]= local[32];
	local[35]= makeint((eusinteger_t)1L);
	ctx->vsp=local+36;
	w=(pointer)PLUS(ctx,2,local+34); /*+*/
	local[34]= w;
	local[35]= local[16];
	ctx->vsp=local+36;
	w=(pointer)LESSP(ctx,2,local+34); /*<*/
	if (w==NIL) goto irtmodelAND1504;
	local[34]= local[21];
	local[35]= fqv[130];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,2,local+34); /*send*/
	local[34]= w;
	local[35]= local[27];
	local[36]= local[32];
	local[37]= makeint((eusinteger_t)1L);
	ctx->vsp=local+38;
	w=(pointer)PLUS(ctx,2,local+36); /*+*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= fqv[133];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,2,local+35); /*send*/
	local[35]= w;
	local[36]= local[27];
	w = local[33];
	ctx->vsp=local+37;
	w=irtmodelFLET1499(ctx,2,local+35,w);
	if (w==local[34]) goto irtmodelAND1504;
	goto irtmodelOR1503;
irtmodelAND1504:
	local[34]= local[16];
	local[35]= local[32];
	local[36]= makeint((eusinteger_t)1L);
	ctx->vsp=local+37;
	w=(pointer)PLUS(ctx,2,local+35); /*+*/
	local[35]= w;
	ctx->vsp=local+36;
	w=(pointer)NUMEQUAL(ctx,2,local+34); /*=*/
	if (w==NIL) goto irtmodelAND1505;
	local[34]= local[21];
	local[35]= fqv[130];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,2,local+34); /*send*/
	local[34]= w;
	local[35]= local[28];
	local[36]= fqv[214];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,2,local+35); /*send*/
	local[35]= w;
	local[36]= local[27];
	w = local[33];
	ctx->vsp=local+37;
	w=irtmodelFLET1499(ctx,2,local+35,w);
	if (w==local[34]) goto irtmodelAND1505;
	goto irtmodelOR1503;
irtmodelAND1505:
	goto irtmodelCON1502;
irtmodelOR1503:
	local[19] = T;
	local[34]= local[19];
	goto irtmodelCON1500;
irtmodelCON1502:
	local[19] = NIL;
	local[34]= local[19];
	goto irtmodelCON1500;
irtmodelCON1506:
	local[34]= NIL;
irtmodelCON1500:
	w = local[34];
	local[33]= *(ovafptr(local[21],fqv[215]));
	local[34]= local[33];
	if (fqv[52]!=local[34]) goto irtmodelIF1507;
	local[34]= fqv[216];
	goto irtmodelIF1508;
irtmodelIF1507:
	local[34]= local[33];
	if (fqv[54]!=local[34]) goto irtmodelIF1509;
	local[34]= fqv[217];
	goto irtmodelIF1510;
irtmodelIF1509:
	local[34]= local[33];
	if (fqv[33]!=local[34]) goto irtmodelIF1511;
	local[34]= fqv[218];
	goto irtmodelIF1512;
irtmodelIF1511:
	local[34]= local[33];
	if (fqv[219]!=local[34]) goto irtmodelIF1513;
	local[34]= fqv[220];
	goto irtmodelIF1514;
irtmodelIF1513:
	local[34]= local[33];
	if (fqv[221]!=local[34]) goto irtmodelIF1515;
	local[34]= fqv[222];
	goto irtmodelIF1516;
irtmodelIF1515:
	local[34]= local[33];
	if (fqv[223]!=local[34]) goto irtmodelIF1517;
	local[34]= fqv[224];
	goto irtmodelIF1518;
irtmodelIF1517:
	local[34]= local[33];
	if (fqv[53]!=local[34]) goto irtmodelIF1519;
	local[34]= fqv[225];
	goto irtmodelIF1520;
irtmodelIF1519:
	local[34]= local[33];
	if (fqv[55]!=local[34]) goto irtmodelIF1521;
	local[34]= fqv[226];
	goto irtmodelIF1522;
irtmodelIF1521:
	local[34]= local[33];
	if (fqv[56]!=local[34]) goto irtmodelIF1523;
	local[34]= fqv[227];
	goto irtmodelIF1524;
irtmodelIF1523:
	if (T==NIL) goto irtmodelIF1525;
	local[34]= *(ovafptr(local[21],fqv[215]));
	goto irtmodelIF1526;
irtmodelIF1525:
	local[34]= NIL;
irtmodelIF1526:
irtmodelIF1524:
irtmodelIF1522:
irtmodelIF1520:
irtmodelIF1518:
irtmodelIF1516:
irtmodelIF1514:
irtmodelIF1512:
irtmodelIF1510:
irtmodelIF1508:
	w = local[34];
	local[33]= w;
	local[34]= local[21];
	local[35]= fqv[130];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,2,local+34); /*send*/
	local[34]= w;
	local[35]= local[21];
	local[36]= fqv[133];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,2,local+35); /*send*/
	local[35]= w;
	local[36]= *(ovafptr(local[21],fqv[228]));
	local[37]= local[35];
	local[38]= fqv[153];
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,2,local+37); /*send*/
	local[37]= w;
	local[38]= fqv[84];
	local[39]= local[36];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,3,local+37); /*send*/
	local[37]= w;
	local[38]= local[21];
	local[39]= fqv[229];
	local[40]= local[8];
	local[41]= local[18];
	local[42]= local[23];
	local[43]= local[21];
	local[44]= local[33];
	local[45]= local[34];
	local[46]= local[37];
	local[47]= local[19];
	local[48]= local[28];
	local[49]= local[29];
	local[50]= local[30];
	local[51]= local[31];
	local[52]= local[9];
	local[53]= local[10];
	local[54]= local[11];
	local[55]= local[12];
	local[56]= local[13];
	local[57]= local[14];
	local[58]= local[15];
	ctx->vsp=local+59;
	w=(pointer)SEND(ctx,21,local+38); /*send*/
	local[33]= w;
	goto irtmodelIF1498;
irtmodelIF1497:
	local[33]= NIL;
irtmodelIF1498:
	local[33]= local[18];
	local[34]= argv[0];
	local[35]= fqv[210];
	local[36]= local[30];
	local[37]= local[31];
	ctx->vsp=local+38;
	w=(pointer)SEND(ctx,4,local+34); /*send*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)PLUS(ctx,2,local+33); /*+*/
	local[18] = w;
	w = local[18];
	local[27]= local[25];
	ctx->vsp=local+28;
	w=(pointer)ADD1(ctx,1,local+27); /*1+*/
	local[25] = w;
	goto irtmodelWHL1494;
irtmodelWHX1495:
	local[27]= NIL;
irtmodelBLK1496:
	w = NIL;
	local[25]= local[23];
	local[26]= local[21];
	local[27]= fqv[31];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)PLUS(ctx,2,local+25); /*+*/
	local[25]= w;
	local[26]= local[24];
	ctx->vsp=local+27;
	w=(pointer)ADD1(ctx,1,local+26); /*1+*/
	local[26]= w;
	local[23] = local[25];
	local[24] = local[26];
	w = NIL;
	ctx->vsp=local+25;
	goto irtmodelTAG1491;
	w = NIL;
	local[23]= w;
irtmodelBLK1490:
	w = local[8];
	local[0]= w;
irtmodelBLK1455:
	ctx->vsp=local; return(local[0]);}

/*:calc-joint-angle-speed*/
static pointer irtmodelM1527cascaded_link_calc_joint_angle_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1529:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[230], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1530;
	local[1] = NIL;
irtmodelKEY1530:
	if (n & (1<<1)) goto irtmodelKEY1531;
	local[2] = makeflt(5.0000000000000000000000e-01);
irtmodelKEY1531:
	if (n & (1<<2)) goto irtmodelKEY1532;
	local[3] = NIL;
irtmodelKEY1532:
	if (n & (1<<3)) goto irtmodelKEY1533;
	local[4] = NIL;
irtmodelKEY1533:
	if (n & (1<<4)) goto irtmodelKEY1534;
	local[5] = NIL;
irtmodelKEY1534:
	if (n & (1<<5)) goto irtmodelKEY1535;
	local[6] = NIL;
irtmodelKEY1535:
	if (n & (1<<6)) goto irtmodelKEY1536;
	local[7] = NIL;
irtmodelKEY1536:
	if (n & (1<<7)) goto irtmodelKEY1537;
	local[8] = NIL;
irtmodelKEY1537:
	if (n & (1<<8)) goto irtmodelKEY1538;
	local[9] = NIL;
irtmodelKEY1538:
	if (n & (1<<9)) goto irtmodelKEY1539;
	local[10] = NIL;
irtmodelKEY1539:
	if (n & (1<<10)) goto irtmodelKEY1540;
	local[11] = NIL;
irtmodelKEY1540:
	if (n & (1<<11)) goto irtmodelKEY1541;
	local[12] = NIL;
irtmodelKEY1541:
	if (local[3]==NIL) goto irtmodelOR1544;
	if (local[4]==NIL) goto irtmodelOR1544;
	goto irtmodelIF1542;
irtmodelOR1544:
	local[13]= fqv[231];
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,1,local+13,&ftab[2],fqv[15]); /*warn*/
	w = local[5];
	ctx->vsp=local+13;
	local[0]=w;
	goto irtmodelBLK1528;
	goto irtmodelIF1543;
irtmodelIF1542:
	local[13]= NIL;
irtmodelIF1543:
	if (local[12]!=NIL) goto irtmodelIF1545;
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(*ftab[29])(ctx,1,local+13,&ftab[29],fqv[204]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.car;
	local[13]= local[12];
	goto irtmodelIF1546;
irtmodelIF1545:
	local[13]= NIL;
irtmodelIF1546:
	if (local[10]!=NIL) goto irtmodelIF1547;
	local[13]= loadglobal(fqv[5]);
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[10] = w;
	local[13]= local[10];
	goto irtmodelIF1548;
irtmodelIF1547:
	local[13]= NIL;
irtmodelIF1548:
	if (local[11]!=NIL) goto irtmodelIF1549;
	local[13]= loadglobal(fqv[5]);
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[11] = w;
	local[13]= local[11];
	goto irtmodelIF1550;
irtmodelIF1549:
	local[13]= NIL;
irtmodelIF1550:
	local[13]= local[4];
	local[14]= argv[2];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)TRANSFORM(ctx,3,local+13); /*transform*/
	local[13]= w;
	if (local[7]==NIL) goto irtmodelIF1551;
	local[14]= fqv[202];
	w = local[7];
	if (memq(local[14],w)!=NIL) goto irtmodelIF1551;
	local[14]= local[3];
	local[15]= fqv[232];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= fqv[234];
	local[15]= local[3];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(pointer)TRANSPOSE(ctx,1,local+16); /*transpose*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)MATTIMES(ctx,2,local+15); /*m**/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[34])(ctx,1,local+15,&ftab[34],fqv[235]); /*matrix-determinant*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[15]); /*warn*/
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)TRANSPOSE(ctx,1,local+14); /*transpose*/
	local[14]= w;
	local[15]= fqv[236];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= argv[2];
	local[15]= fqv[237];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[238];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= w;
	goto irtmodelIF1552;
irtmodelIF1551:
	local[14]= NIL;
irtmodelIF1552:
	if (local[1]==NIL) goto irtmodelIF1553;
	local[14]= local[2];
	local[15]= local[13];
	local[16]= local[1];
	local[17]= local[13];
	ctx->vsp=local+18;
	w=(*ftab[35])(ctx,4,local+14,&ftab[35],fqv[239]); /*midpoint*/
	local[13] = w;
	if (local[7]==NIL) goto irtmodelIF1555;
	local[14]= fqv[202];
	w = local[7];
	if (memq(local[14],w)!=NIL) goto irtmodelIF1555;
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[240];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[241];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= w;
	goto irtmodelIF1556;
irtmodelIF1555:
	local[14]= NIL;
irtmodelIF1556:
	goto irtmodelIF1554;
irtmodelIF1553:
	local[14]= NIL;
irtmodelIF1554:
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)VECTORP(ctx,1,local+14); /*vectorp*/
	if (w==NIL) goto irtmodelIF1557;
	local[14]= local[12];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)NUMEQUAL(ctx,2,local+14); /*=*/
	if (w==NIL) goto irtmodelIF1557;
	if (local[6]==NIL) goto irtmodelIF1557;
	if (local[8]!=NIL) goto irtmodelIF1559;
	local[14]= loadglobal(fqv[5]);
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,2,local+14); /*instantiate*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(*ftab[36])(ctx,2,local+14,&ftab[36],fqv[242]); /*fill*/
	local[8] = w;
	local[14]= local[8];
	goto irtmodelIF1560;
irtmodelIF1559:
	local[14]= NIL;
irtmodelIF1560:
	if (local[9]!=NIL) goto irtmodelIF1561;
	local[14]= local[12];
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(*ftab[23])(ctx,2,local+14,&ftab[23],fqv[166]); /*make-matrix*/
	local[9] = w;
	local[14]= local[9];
	goto irtmodelIF1562;
irtmodelIF1561:
	local[14]= NIL;
irtmodelIF1562:
	local[14]= makeint((eusinteger_t)0L);
	local[15]= local[12];
irtmodelWHL1563:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto irtmodelWHX1564;
	local[16]= local[9];
	local[17]= local[14];
	local[18]= local[14];
	local[19]= local[8];
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)AREF(ctx,2,local+19); /*aref*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ASET(ctx,4,local+16); /*aset*/
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto irtmodelWHL1563;
irtmodelWHX1564:
	local[16]= NIL;
irtmodelBLK1565:
	w = NIL;
	local[14]= local[13];
	local[15]= local[6];
	local[16]= local[5];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)TRANSFORM(ctx,3,local+15); /*transform*/
	local[15]= w;
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	if (local[7]==NIL) goto irtmodelIF1566;
	local[14]= fqv[202];
	w = local[7];
	if (memq(local[14],w)!=NIL) goto irtmodelIF1566;
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[243];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[244];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= w;
	goto irtmodelIF1567;
irtmodelIF1566:
	local[14]= NIL;
irtmodelIF1567:
	goto irtmodelIF1558;
irtmodelIF1557:
	local[14]= NIL;
irtmodelIF1558:
	w = local[13];
	local[0]= w;
irtmodelBLK1528:
	ctx->vsp=local; return(local[0]);}

/*:calc-joint-angle-speed-gain*/
static pointer irtmodelM1568cascaded_link_calc_joint_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[211];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[5]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
irtmodelTAG1571:
	local[5]= local[4];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)GREQP(ctx,2,local+5); /*>=*/
	if (w==NIL) goto irtmodelIF1572;
	w = NIL;
	ctx->vsp=local+5;
	local[3]=w;
	goto irtmodelBLK1570;
	goto irtmodelIF1573;
irtmodelIF1572:
	local[5]= NIL;
irtmodelIF1573:
	local[5]= argv[2];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= fqv[198];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[2] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
	local[7]= fqv[31];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
irtmodelWHL1574:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX1575;
	local[7]= local[1];
	local[8]= local[3];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= local[2];
	local[10]= fqv[245];
	local[11]= argv[3];
	local[12]= local[3];
	local[13]= argv[4];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL1574;
irtmodelWHX1575:
	local[7]= NIL;
irtmodelBLK1576:
	w = NIL;
	local[5]= local[3];
	local[6]= local[2];
	local[7]= fqv[31];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[3] = w;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[4] = w;
	ctx->vsp=local+5;
	goto irtmodelTAG1571;
	w = NIL;
	local[3]= w;
irtmodelBLK1570:
	w = local[1];
	local[0]= w;
irtmodelBLK1569:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance-links*/
static pointer irtmodelM1577cascaded_link_collision_avoidance_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1580;}
	local[0]= NIL;
irtmodelENT1580:
irtmodelENT1579:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1581;
	argv[0]->c.obj.iv[11] = local[0];
	local[1]= argv[0]->c.obj.iv[11];
	goto irtmodelIF1582;
irtmodelIF1581:
	local[1]= NIL;
irtmodelIF1582:
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtmodelBLK1578:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance-link-pair-from-link-list*/
static pointer irtmodelM1583cascaded_link_collision_avoidance_link_pair_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[246], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1585;
	local[0] = NIL;
irtmodelKEY1585:
	if (n & (1<<1)) goto irtmodelKEY1586;
	local[1] = argv[0]->c.obj.iv[11];
irtmodelKEY1586:
	if (n & (1<<2)) goto irtmodelKEY1587;
	local[2] = NIL;
irtmodelKEY1587:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtmodelCLO1588,env,argv,local);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	local[8]= NIL;
	local[9]= NIL;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF1589;
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	argv[2] = w;
	local[10]= argv[2];
	goto irtmodelIF1590;
irtmodelIF1589:
	local[10]= NIL;
irtmodelIF1590:
	if (local[2]==NIL) goto irtmodelIF1591;
	local[10]= fqv[202];
	w = local[2];
	if (memq(local[10],w)!=NIL) goto irtmodelIF1591;
	local[10]= fqv[247];
	local[11]= local[1];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(*ftab[18])(ctx,2,local+11,&ftab[18],fqv[128]); /*send-all*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[2])(ctx,2,local+10,&ftab[2],fqv[15]); /*warn*/
	local[10]= fqv[248];
	local[11]= local[3];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(*ftab[18])(ctx,2,local+11,&ftab[18],fqv[128]); /*send-all*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[2])(ctx,2,local+10,&ftab[2],fqv[15]); /*warn*/
	local[10]= w;
	goto irtmodelIF1592;
irtmodelIF1591:
	local[10]= NIL;
irtmodelIF1592:
	local[10]= NIL;
	local[11]= argv[2];
irtmodelWHL1593:
	if (local[11]==NIL) goto irtmodelWHX1594;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= local[10];
	local[13]= makeint((eusinteger_t)1L);
irtmodelTAG1597:
	local[14]= local[13];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SUB1(ctx,1,local+15); /*1-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)LESSP(ctx,2,local+14); /*<*/
	if (w==NIL) goto irtmodelAND1600;
	local[14]= local[10];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= fqv[29];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= local[10];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= fqv[29];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)VDISTANCE(ctx,2,local+14); /*distance*/
	local[14]= w;
	local[15]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(*ftab[8])(ctx,2,local+14,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelAND1600;
	goto irtmodelIF1598;
irtmodelAND1600:
	local[14]= local[13];
	ctx->vsp=local+15;
	w=(pointer)SUB1(ctx,1,local+14); /*1-*/
	ctx->vsp=local+14;
	local[13]=w;
	goto irtmodelBLK1596;
	goto irtmodelIF1599;
irtmodelIF1598:
	local[14]= NIL;
irtmodelIF1599:
	local[14]= local[13];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[14]= w;
	local[13] = local[14];
	w = NIL;
	ctx->vsp=local+14;
	goto irtmodelTAG1597;
	w = NIL;
	local[13]= w;
irtmodelBLK1596:
	ctx->vsp=local+14;
	w=(pointer)SUBSEQ(ctx,2,local+12); /*subseq*/
	local[5] = w;
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,irtmodelCLO1601,env,argv,local);
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[6] = w;
	if (local[2]==NIL) goto irtmodelIF1602;
	local[12]= fqv[202];
	w = local[2];
	if (memq(local[12],w)!=NIL) goto irtmodelIF1602;
	local[12]= fqv[249];
	local[13]= local[5];
	local[14]= fqv[3];
	ctx->vsp=local+15;
	w=(*ftab[18])(ctx,2,local+13,&ftab[18],fqv[128]); /*send-all*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[15]); /*warn*/
	local[12]= fqv[250];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[15]); /*warn*/
	local[12]= w;
	goto irtmodelIF1603;
irtmodelIF1602:
	local[12]= NIL;
irtmodelIF1603:
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[7];
irtmodelWHL1604:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtmodelWHX1605;
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[14]= w;
irtmodelTAG1608:
	local[15]= local[14];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)GREQP(ctx,2,local+15); /*>=*/
	if (w==NIL) goto irtmodelIF1609;
	w = NIL;
	ctx->vsp=local+15;
	local[14]=w;
	goto irtmodelBLK1607;
	goto irtmodelIF1610;
irtmodelIF1609:
	local[15]= NIL;
irtmodelIF1610:
	local[15]= local[6];
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[8] = w;
	if (local[8]!=NIL) goto irtmodelOR1613;
	local[15]= local[6];
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	if (w!=NIL) goto irtmodelOR1613;
	goto irtmodelIF1611;
irtmodelOR1613:
	local[15]= local[3];
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[1];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	if (w==local[15]) goto irtmodelIF1611;
	local[15]= local[3];
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[1];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	if (w==local[15]) goto irtmodelIF1611;
	local[15]= local[3];
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[3];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	if (w==local[15]) goto irtmodelIF1611;
	local[15]= local[1];
	if (local[8]==NIL) goto irtmodelIF1614;
	local[16]= local[12];
	goto irtmodelIF1615;
irtmodelIF1614:
	local[16]= local[14];
irtmodelIF1615:
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[1];
	if (local[8]==NIL) goto irtmodelIF1616;
	local[17]= local[14];
	goto irtmodelIF1617;
irtmodelIF1616:
	local[17]= local[12];
irtmodelIF1617:
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,2,local+15); /*list*/
	local[15]= w;
	w = local[9];
	ctx->vsp=local+16;
	local[9] = cons(ctx,local[15],w);
	local[15]= local[9];
	goto irtmodelIF1612;
irtmodelIF1611:
	local[15]= NIL;
irtmodelIF1612:
	local[15]= local[14];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[15]= w;
	local[14] = local[15];
	w = NIL;
	ctx->vsp=local+15;
	goto irtmodelTAG1608;
	w = NIL;
	local[14]= w;
irtmodelBLK1607:
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtmodelWHL1604;
irtmodelWHX1605:
	local[14]= NIL;
irtmodelBLK1606:
	w = NIL;
	if (local[0]==NIL) goto irtmodelIF1618;
	w = local[0];
	if (!!iscons(w)) goto irtmodelIF1620;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[0] = w;
	local[12]= local[0];
	goto irtmodelIF1621;
irtmodelIF1620:
	local[12]= NIL;
irtmodelIF1621:
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[7];
irtmodelWHL1622:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtmodelWHX1623;
	local[14]= local[6];
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	if (w==NIL) goto irtmodelIF1625;
	local[14]= NIL;
	local[15]= local[0];
irtmodelWHL1627:
	if (local[15]==NIL) goto irtmodelWHX1628;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[1];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,2,local+16); /*list*/
	local[16]= w;
	w = local[9];
	ctx->vsp=local+17;
	local[9] = cons(ctx,local[16],w);
	goto irtmodelWHL1627;
irtmodelWHX1628:
	local[16]= NIL;
irtmodelBLK1629:
	w = NIL;
	local[14]= w;
	goto irtmodelIF1626;
irtmodelIF1625:
	local[14]= NIL;
irtmodelIF1626:
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtmodelWHL1622;
irtmodelWHX1623:
	local[14]= NIL;
irtmodelBLK1624:
	w = NIL;
	local[12]= w;
	goto irtmodelIF1619;
irtmodelIF1618:
	local[12]= NIL;
irtmodelIF1619:
	goto irtmodelWHL1593;
irtmodelWHX1594:
	local[12]= NIL;
irtmodelBLK1595:
	w = NIL;
	w = local[9];
	local[0]= w;
irtmodelBLK1584:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance-calc-distance*/
static pointer irtmodelM1630cascaded_link_collision_avoidance_calc_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1632:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[251], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1633;
	local[1] = NIL;
irtmodelKEY1633:
	if (n & (1<<1)) goto irtmodelKEY1634;
	local[2] = T;
irtmodelKEY1634:
	if (n & (1<<2)) goto irtmodelKEY1635;
	local[3] = NIL;
irtmodelKEY1635:
	if (n & (1<<3)) goto irtmodelKEY1636;
	local[4] = makeint((eusinteger_t)10L);
irtmodelKEY1636:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[184];
	local[8]= fqv[252];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	if (local[1]==NIL) goto irtmodelOR1639;
	local[9]= local[5];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)NUMEQUAL(ctx,2,local+9); /*=*/
	if (w!=NIL) goto irtmodelOR1639;
	goto irtmodelIF1637;
irtmodelOR1639:
	w = NIL;
	ctx->vsp=local+9;
	local[0]=w;
	goto irtmodelBLK1631;
	goto irtmodelIF1638;
irtmodelIF1637:
	local[9]= NIL;
irtmodelIF1638:
	if (local[6]==NIL) goto irtmodelOR1642;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[24])(ctx,2,local+9,&ftab[24],fqv[171]); /*/=*/
	if (w!=NIL) goto irtmodelOR1642;
	goto irtmodelIF1640;
irtmodelOR1642:
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[31])(ctx,1,local+9,&ftab[31],fqv[208]); /*make-list*/
	local[6] = w;
	local[9]= local[6];
	goto irtmodelIF1641;
irtmodelIF1640:
	local[9]= NIL;
irtmodelIF1641:
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[5];
irtmodelWHL1643:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtmodelWHX1644;
	local[11]= local[3];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[8] = w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w = local[1];
	if (memq(local[11],w)!=NIL) goto irtmodelIF1646;
	local[11]= fqv[253];
	local[12]= local[8];
	local[13]= fqv[3];
	ctx->vsp=local+14;
	w=(*ftab[18])(ctx,2,local+12,&ftab[18],fqv[128]); /*send-all*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[2])(ctx,2,local+11,&ftab[2],fqv[15]); /*warn*/
	local[11]= local[6];
	local[12]= local[9];
	local[13]= NIL;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
	goto irtmodelIF1647;
irtmodelIF1646:
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[254];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(*ftab[37])(ctx,4,local+11,&ftab[37],fqv[255]); /*collision-distance*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,2,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)NCONC(ctx,2,local+11); /*nconc*/
	local[7] = w;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)LSEQP(ctx,2,local+11); /*<=*/
	if (w==NIL) goto irtmodelIF1648;
	if (local[2]==NIL) goto irtmodelIF1650;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(pointer)LESSP(ctx,2,local+11); /*<*/
	if (w==NIL) goto irtmodelIF1650;
	local[11]= fqv[256];
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[3];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[3];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,4,local+11,&ftab[2],fqv[15]); /*warn*/
	local[11]= w;
	goto irtmodelIF1651;
irtmodelIF1650:
	local[11]= NIL;
irtmodelIF1651:
	local[11]= local[7];
	local[12]= makeint((eusinteger_t)1L);
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[257];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[6];
	local[12]= local[9];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[6];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
	goto irtmodelIF1649;
irtmodelIF1648:
	local[11]= local[6];
	local[12]= local[9];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
irtmodelIF1649:
	local[11]= makeflt(1.0000000000000000208167e-03);
	local[12]= local[7];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[7];
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)VMINUS(ctx,3,local+12); /*v-*/
	local[12]= w;
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[4])(ctx,2,local+12,&ftab[4],fqv[26]); /*normalize-vector*/
	local[12]= w;
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,3,local+11); /*scale*/
	local[11]= w;
irtmodelIF1647:
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtmodelWHL1643;
irtmodelWHX1644:
	local[11]= NIL;
irtmodelBLK1645:
	w = NIL;
	local[9]= local[6];
	local[10]= (pointer)get_sym_func(fqv[258]);
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtmodelCLO1652,env,argv,local);
	ctx->vsp=local+12;
	w=(pointer)SORT(ctx,3,local+9); /*sort*/
	local[9]= argv[0];
	local[10]= fqv[150];
	local[11]= fqv[252];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	w = T;
	local[0]= w;
irtmodelBLK1631:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance-args*/
static pointer irtmodelM1653cascaded_link_collision_avoidance_args(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[184];
	local[2]= fqv[259];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[260];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[211];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w==NIL) goto irtmodelIF1655;
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,1,local+5,&ftab[31],fqv[208]); /*make-list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)NCONC(ctx,2,local+4); /*nconc*/
	local[0] = w;
	local[4]= local[0];
	goto irtmodelIF1656;
irtmodelIF1655:
	local[4]= NIL;
irtmodelIF1656:
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[3] = w;
	if (local[3]!=NIL) goto irtmodelIF1657;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= local[4];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(*ftab[23])(ctx,2,local+6,&ftab[23],fqv[166]); /*make-matrix*/
	local[6]= w;
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(*ftab[23])(ctx,2,local+7,&ftab[23],fqv[166]); /*make-matrix*/
	local[7]= w;
	local[8]= local[4];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[23])(ctx,2,local+8,&ftab[23],fqv[166]); /*make-matrix*/
	local[8]= w;
	local[9]= local[5];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[23])(ctx,2,local+9,&ftab[23],fqv[166]); /*make-matrix*/
	local[9]= w;
	local[10]= local[5];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(*ftab[23])(ctx,2,local+10,&ftab[23],fqv[166]); /*make-matrix*/
	local[10]= w;
	local[11]= local[4];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,2,local+11,&ftab[23],fqv[166]); /*make-matrix*/
	local[11]= w;
	local[12]= local[4];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(*ftab[23])(ctx,2,local+12,&ftab[23],fqv[166]); /*make-matrix*/
	local[12]= w;
	local[13]= local[4];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[23])(ctx,2,local+13,&ftab[23],fqv[166]); /*make-matrix*/
	local[13]= w;
	local[14]= local[5];
	local[15]= local[4];
	ctx->vsp=local+16;
	w=(*ftab[23])(ctx,2,local+14,&ftab[23],fqv[166]); /*make-matrix*/
	local[14]= w;
	local[15]= local[5];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[23])(ctx,2,local+15,&ftab[23],fqv[166]); /*make-matrix*/
	local[15]= w;
	local[16]= local[5];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(*ftab[23])(ctx,2,local+16,&ftab[23],fqv[166]); /*make-matrix*/
	local[16]= w;
	local[17]= local[5];
	local[18]= local[4];
	ctx->vsp=local+19;
	w=(*ftab[23])(ctx,2,local+17,&ftab[23],fqv[166]); /*make-matrix*/
	local[17]= w;
	local[18]= loadglobal(fqv[5]);
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[18]= w;
	local[19]= loadglobal(fqv[5]);
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(pointer)INSTANTIATE(ctx,2,local+19); /*instantiate*/
	local[19]= w;
	local[20]= loadglobal(fqv[5]);
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)INSTANTIATE(ctx,2,local+20); /*instantiate*/
	local[20]= w;
	local[21]= loadglobal(fqv[5]);
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(pointer)INSTANTIATE(ctx,2,local+21); /*instantiate*/
	local[21]= w;
	local[22]= loadglobal(fqv[5]);
	local[23]= makeint((eusinteger_t)3L);
	ctx->vsp=local+24;
	w=(pointer)INSTANTIATE(ctx,2,local+22); /*instantiate*/
	local[22]= w;
	local[23]= loadglobal(fqv[5]);
	local[24]= makeint((eusinteger_t)3L);
	ctx->vsp=local+25;
	w=(pointer)INSTANTIATE(ctx,2,local+23); /*instantiate*/
	local[23]= w;
	local[24]= loadglobal(fqv[5]);
	local[25]= makeint((eusinteger_t)3L);
	ctx->vsp=local+26;
	w=(pointer)INSTANTIATE(ctx,2,local+24); /*instantiate*/
	local[24]= w;
	local[25]= makeint((eusinteger_t)3L);
	local[26]= makeint((eusinteger_t)3L);
	ctx->vsp=local+27;
	w=(*ftab[23])(ctx,2,local+25,&ftab[23],fqv[166]); /*make-matrix*/
	local[25]= w;
	local[26]= loadglobal(fqv[5]);
	local[27]= local[5];
	ctx->vsp=local+28;
	w=(pointer)INSTANTIATE(ctx,2,local+26); /*instantiate*/
	local[26]= w;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[4];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[27]= w;
	local[28]= loadglobal(fqv[5]);
	local[29]= local[4];
	ctx->vsp=local+30;
	w=(pointer)INSTANTIATE(ctx,2,local+28); /*instantiate*/
	local[28]= w;
	local[29]= loadglobal(fqv[5]);
	local[30]= makeint((eusinteger_t)3L);
	ctx->vsp=local+31;
	w=(pointer)INSTANTIATE(ctx,2,local+29); /*instantiate*/
	local[29]= w;
	local[30]= loadglobal(fqv[5]);
	local[31]= makeint((eusinteger_t)3L);
	ctx->vsp=local+32;
	w=(pointer)INSTANTIATE(ctx,2,local+30); /*instantiate*/
	local[30]= w;
	local[31]= fqv[261];
	local[32]= local[6];
	local[33]= fqv[262];
	local[34]= local[7];
	local[35]= fqv[263];
	local[36]= local[8];
	local[37]= fqv[264];
	local[38]= local[9];
	local[39]= fqv[265];
	local[40]= local[10];
	local[41]= fqv[266];
	local[42]= local[11];
	local[43]= fqv[267];
	local[44]= local[12];
	local[45]= fqv[268];
	local[46]= local[13];
	local[47]= fqv[269];
	local[48]= local[14];
	local[49]= fqv[270];
	local[50]= local[15];
	local[51]= fqv[271];
	local[52]= local[16];
	local[53]= fqv[272];
	local[54]= local[17];
	local[55]= fqv[273];
	local[56]= NIL;
	local[57]= fqv[274];
	local[58]= local[18];
	local[59]= fqv[275];
	local[60]= local[19];
	local[61]= fqv[276];
	local[62]= local[20];
	local[63]= fqv[277];
	local[64]= local[21];
	local[65]= fqv[278];
	local[66]= local[22];
	local[67]= fqv[279];
	local[68]= local[23];
	local[69]= fqv[280];
	local[70]= local[24];
	local[71]= fqv[281];
	local[72]= local[25];
	local[73]= fqv[282];
	local[74]= local[26];
	local[75]= fqv[283];
	local[76]= local[27];
	local[77]= fqv[284];
	local[78]= local[28];
	local[79]= fqv[285];
	local[80]= local[29];
	local[81]= fqv[286];
	local[82]= local[30];
	ctx->vsp=local+83;
	w=(pointer)LIST(ctx,52,local+31); /*list*/
	local[3] = w;
	local[31]= local[0];
	local[32]= local[2];
	ctx->vsp=local+33;
	w=(pointer)SUB1(ctx,1,local+32); /*1-*/
	local[32]= w;
	local[33]= local[3];
	ctx->vsp=local+34;
	w=(pointer)SETELT(ctx,3,local+31); /*setelt*/
	local[31]= argv[0];
	local[32]= fqv[150];
	local[33]= fqv[259];
	local[34]= local[0];
	ctx->vsp=local+35;
	w=(pointer)SEND(ctx,4,local+31); /*send*/
	local[4]= w;
	goto irtmodelIF1658;
irtmodelIF1657:
	local[4]= NIL;
irtmodelIF1658:
	w = local[3];
	local[0]= w;
irtmodelBLK1654:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance*/
static pointer irtmodelM1659cascaded_link_collision_avoidance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1661:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[287], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1662;
	local[1] = NIL;
irtmodelKEY1662:
	if (n & (1<<1)) goto irtmodelKEY1663;
	local[2] = NIL;
irtmodelKEY1663:
	if (n & (1<<2)) goto irtmodelKEY1664;
	local[3] = NIL;
irtmodelKEY1664:
	if (n & (1<<3)) goto irtmodelKEY1665;
	local[4] = NIL;
irtmodelKEY1665:
	if (n & (1<<4)) goto irtmodelKEY1666;
	local[5] = NIL;
irtmodelKEY1666:
	if (n & (1<<5)) goto irtmodelKEY1667;
	local[6] = NIL;
irtmodelKEY1667:
	if (n & (1<<6)) goto irtmodelKEY1668;
	local[7] = NIL;
irtmodelKEY1668:
	if (n & (1<<7)) goto irtmodelKEY1669;
	local[10]= argv[0];
	local[11]= fqv[211];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[8] = w;
irtmodelKEY1669:
	if (n & (1<<8)) goto irtmodelKEY1670;
	local[9] = NIL;
irtmodelKEY1670:
	local[10]= (pointer)get_sym_func(fqv[288]);
	local[11]= argv[0];
	local[12]= fqv[289];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,4,local+10); /*apply*/
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= loadglobal(fqv[5]);
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[150];
	local[15]= fqv[290];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF1671;
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[6] = w;
	local[13]= local[6];
	goto irtmodelIF1672;
irtmodelIF1671:
	local[13]= NIL;
irtmodelIF1672:
irtmodelWHL1673:
	local[13]= local[11];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)LESSP(ctx,2,local+13); /*<*/
	if (w==NIL) goto irtmodelWHX1674;
	local[13]= argv[0];
	local[14]= fqv[184];
	local[15]= fqv[252];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[4];
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(*ftab[38])(ctx,1,local+15,&ftab[38],fqv[291]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[11] = w;
	if (local[9]==NIL) goto irtmodelIF1676;
	local[15]= fqv[202];
	w = local[9];
	if (memq(local[15],w)!=NIL) goto irtmodelIF1676;
	local[15]= local[13];
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[13];
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,2,local+15); /*v-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[4])(ctx,1,local+15,&ftab[4],fqv[26]); /*normalize-vector*/
	local[15]= w;
	local[16]= fqv[292];
	local[17]= local[13];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[1];
	ctx->vsp=local+19;
	w=(*ftab[2])(ctx,3,local+16,&ftab[2],fqv[15]); /*warn*/
	local[16]= makeint((eusinteger_t)0L);
	local[17]= makeint((eusinteger_t)3L);
irtmodelWHL1678:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtmodelWHX1679;
	local[18]= fqv[293];
	local[19]= local[15];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[2])(ctx,2,local+18,&ftab[2],fqv[15]); /*warn*/
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtmodelWHL1678;
irtmodelWHX1679:
	local[18]= NIL;
irtmodelBLK1680:
	w = NIL;
	local[16]= fqv[294];
	local[17]= local[14];
	local[18]= fqv[3];
	ctx->vsp=local+19;
	w=(*ftab[18])(ctx,2,local+17,&ftab[18],fqv[128]); /*send-all*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[2])(ctx,2,local+16,&ftab[2],fqv[15]); /*warn*/
	local[15]= w;
	goto irtmodelIF1677;
irtmodelIF1676:
	local[15]= NIL;
irtmodelIF1677:
	local[15]= local[13];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)GREQP(ctx,2,local+15); /*>=*/
	if (w!=NIL) goto irtmodelIF1681;
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtmodelCLO1683,env,argv,local);
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(*ftab[39])(ctx,2,local+15,&ftab[39],fqv[295]); /*find-if*/
	local[15]= w;
	local[16]= argv[0];
	local[17]= fqv[296];
	local[18]= local[14];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,4,local+16); /*send*/
	local[16]= w;
	local[17]= fqv[105];
	local[18]= local[13];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[40])(ctx,2,local+17,&ftab[40],fqv[297]); /*make-cascoords*/
	local[17]= w;
	local[18]= argv[0];
	local[19]= fqv[260];
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,4,local+18); /*send*/
	local[18]= w;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	local[20]= fqv[298];
	local[21]= local[17];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= (pointer)get_sym_func(fqv[288]);
	local[20]= argv[0];
	local[21]= fqv[299];
	local[22]= local[18];
	local[23]= fqv[300];
	local[24]= local[17];
	local[25]= local[16];
	ctx->vsp=local+26;
	w=(pointer)APPLY(ctx,7,local+19); /*apply*/
	local[19]= w;
	local[20]= local[19];
	ctx->vsp=local+21;
	w=(pointer)TRANSPOSE(ctx,1,local+20); /*transpose*/
	local[20]= w;
	local[21]= local[13];
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)TRANSFORM(ctx,2,local+20); /*transform*/
	local[20]= w;
	local[21]= local[1];
	local[22]= local[13];
	local[23]= makeint((eusinteger_t)0L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)QUOTIENT(ctx,2,local+21); /*/*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)1L);
	ctx->vsp=local+23;
	w=(pointer)MINUS(ctx,2,local+21); /*-*/
	local[21]= w;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	local[23]= fqv[301];
	local[24]= local[17];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= NIL;
	local[23]= local[18];
irtmodelWHL1684:
	if (local[23]==NIL) goto irtmodelWHX1685;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23] = (w)->c.cons.cdr;
	w = local[24];
	local[22] = w;
	ctx->vsp=local+24;
	local[24]= makeclosure(codevec,quotevec,irtmodelFLET1687,env,argv,local);
	local[25]= local[22];
	local[26]= local[5];
	w = local[24];
	ctx->vsp=local+27;
	w=irtmodelFLET1687(ctx,2,local+25,w);
	local[25]= w;
	local[26]= local[22];
	local[27]= local[18];
	w = local[24];
	ctx->vsp=local+28;
	w=irtmodelFLET1687(ctx,2,local+26,w);
	local[26]= w;
	local[27]= makeint((eusinteger_t)0L);
	local[28]= local[22];
	local[29]= fqv[198];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,2,local+28); /*send*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)LIST(ctx,1,local+28); /*list*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+28); /*calc-target-joint-dimension*/
	local[28]= w;
irtmodelWHL1688:
	local[29]= local[27];
	w = local[28];
	if ((eusinteger_t)local[29] >= (eusinteger_t)w) goto irtmodelWHX1689;
	local[29]= local[12];
	local[30]= local[27];
	local[31]= local[25];
	ctx->vsp=local+32;
	w=(pointer)PLUS(ctx,2,local+30); /*+*/
	local[30]= w;
	local[31]= local[12];
	local[32]= local[27];
	local[33]= local[25];
	ctx->vsp=local+34;
	w=(pointer)PLUS(ctx,2,local+32); /*+*/
	local[32]= w;
	ctx->vsp=local+33;
	w=(pointer)ELT(ctx,2,local+31); /*elt*/
	local[31]= w;
	local[32]= local[21];
	local[33]= local[20];
	local[34]= local[26];
	local[35]= local[27];
	ctx->vsp=local+36;
	w=(pointer)PLUS(ctx,2,local+34); /*+*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)ELT(ctx,2,local+33); /*elt*/
	local[33]= w;
	ctx->vsp=local+34;
	w=(pointer)TIMES(ctx,2,local+32); /***/
	local[32]= w;
	ctx->vsp=local+33;
	w=(pointer)PLUS(ctx,2,local+31); /*+*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)SETELT(ctx,3,local+29); /*setelt*/
	local[29]= local[27];
	ctx->vsp=local+30;
	w=(pointer)ADD1(ctx,1,local+29); /*1+*/
	local[27] = w;
	goto irtmodelWHL1688;
irtmodelWHX1689:
	local[29]= NIL;
irtmodelBLK1690:
	w = NIL;
	goto irtmodelWHL1684;
irtmodelWHX1685:
	local[24]= NIL;
irtmodelBLK1686:
	w = NIL;
	local[15]= w;
	goto irtmodelIF1682;
irtmodelIF1681:
	local[15]= NIL;
irtmodelIF1682:
	w = local[15];
	goto irtmodelWHL1673;
irtmodelWHX1674:
	local[13]= NIL;
irtmodelBLK1675:
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[8];
irtmodelWHL1691:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtmodelWHX1692;
	local[15]= local[12];
	local[16]= local[13];
	local[17]= local[12];
	local[18]= local[13];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[7];
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SETELT(ctx,3,local+15); /*setelt*/
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtmodelWHL1691;
irtmodelWHX1692:
	local[15]= NIL;
irtmodelBLK1693:
	w = NIL;
	local[13]= argv[0];
	local[14]= fqv[150];
	local[15]= fqv[302];
	local[16]= local[3];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)SCALEVEC(ctx,2,local+16); /*scale*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[150];
	local[15]= fqv[303];
	local[16]= local[2];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)SCALEVEC(ctx,2,local+16); /*scale*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	if (local[9]==NIL) goto irtmodelIF1694;
	local[13]= fqv[202];
	w = local[9];
	if (memq(local[13],w)!=NIL) goto irtmodelIF1694;
	local[13]= loadglobal(fqv[5]);
	local[14]= (pointer)get_sym_func(fqv[49]);
	local[15]= argv[0];
	local[16]= fqv[184];
	local[17]= fqv[303];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)MAP(ctx,3,local+13); /*map*/
	local[13]= w;
	local[14]= fqv[304];
	ctx->vsp=local+15;
	w=(*ftab[33])(ctx,2,local+13,&ftab[33],fqv[233]); /*format-array*/
	local[13]= loadglobal(fqv[5]);
	local[14]= (pointer)get_sym_func(fqv[49]);
	local[15]= argv[0];
	local[16]= fqv[184];
	local[17]= fqv[302];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)MAP(ctx,3,local+13); /*map*/
	local[13]= w;
	local[14]= fqv[305];
	ctx->vsp=local+15;
	w=(*ftab[33])(ctx,2,local+13,&ftab[33],fqv[233]); /*format-array*/
	local[13]= w;
	goto irtmodelIF1695;
irtmodelIF1694:
	local[13]= NIL;
irtmodelIF1695:
	w = local[13];
	local[10]= argv[0];
	local[11]= fqv[184];
	local[12]= fqv[303];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[0]= w;
irtmodelBLK1660:
	ctx->vsp=local; return(local[0]);}

/*:move-joints*/
static pointer irtmodelM1696cascaded_link_move_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1698:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[306], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1699;
	local[1] = NIL;
irtmodelKEY1699:
	if (n & (1<<1)) goto irtmodelKEY1700;
	local[2] = makeflt(4.9999999999999988897770e-02);
irtmodelKEY1700:
	if (n & (1<<2)) goto irtmodelKEY1701;
	local[3] = NIL;
irtmodelKEY1701:
	if (n & (1<<3)) goto irtmodelKEY1702;
	local[4] = NIL;
irtmodelKEY1702:
	if (n & (1<<4)) goto irtmodelKEY1703;
	local[5] = NIL;
irtmodelKEY1703:
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	if (local[4]==NIL) goto irtmodelIF1704;
	w = local[4];
	if (!!iscons(w)) goto irtmodelIF1704;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[4] = w;
	local[9]= local[4];
	goto irtmodelIF1705;
irtmodelIF1704:
	local[9]= NIL;
irtmodelIF1705:
	local[9]= (pointer)get_sym_func(fqv[288]);
	local[10]= argv[0];
	local[11]= fqv[307];
	local[12]= argv[2];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,5,local+9); /*apply*/
	local[6] = w;
	local[9]= argv[0];
	local[10]= fqv[308];
	local[11]= local[1];
	local[12]= local[6];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
irtmodelWHL1706:
	local[13]= local[11];
	w = local[12];
	if ((eusinteger_t)local[13] >= (eusinteger_t)w) goto irtmodelWHX1707;
	local[13]= local[9];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)LESSP(ctx,2,local+13); /*<*/
	if (w==NIL) goto irtmodelIF1709;
	local[13]= local[9];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[10] = w;
	local[13]= local[10];
	goto irtmodelIF1710;
irtmodelIF1709:
	local[13]= NIL;
irtmodelIF1710:
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[11] = w;
	goto irtmodelWHL1706;
irtmodelWHX1707:
	local[13]= NIL;
irtmodelBLK1708:
	w = NIL;
	local[11]= local[10];
	local[12]= local[6];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,3,local+11); /*scale*/
	local[6] = w;
	w = local[6];
	if (local[4]==NIL) goto irtmodelIF1711;
	local[9]= fqv[202];
	w = local[4];
	if (memq(local[9],w)!=NIL) goto irtmodelIF1711;
	local[9]= loadglobal(fqv[5]);
	local[10]= (pointer)get_sym_func(fqv[49]);
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)MAP(ctx,3,local+9); /*map*/
	local[9]= w;
	local[10]= fqv[309];
	ctx->vsp=local+11;
	w=(*ftab[33])(ctx,2,local+9,&ftab[33],fqv[233]); /*format-array*/
	local[9]= w;
	goto irtmodelIF1712;
irtmodelIF1711:
	local[9]= NIL;
irtmodelIF1712:
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
irtmodelTAG1714:
	local[11]= local[10];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto irtmodelIF1715;
	w = NIL;
	ctx->vsp=local+11;
	local[9]=w;
	goto irtmodelBLK1713;
	goto irtmodelIF1716;
irtmodelIF1715:
	local[11]= NIL;
irtmodelIF1716:
	local[11]= local[1];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[198];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[8] = w;
	local[11]= local[8];
	local[12]= fqv[31];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= local[11];
	if (fqv[310]!=local[12]) goto irtmodelIF1717;
	local[12]= local[8];
	local[13]= fqv[311];
	local[14]= local[6];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[7] = w;
	local[12]= local[7];
	goto irtmodelIF1718;
irtmodelIF1717:
	if (T==NIL) goto irtmodelIF1719;
	local[12]= local[8];
	local[13]= fqv[311];
	local[14]= local[6];
	local[15]= local[9];
	local[16]= local[9];
	local[17]= local[8];
	local[18]= fqv[31];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SUBSEQ(ctx,3,local+14); /*subseq*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[7] = w;
	local[12]= local[7];
	goto irtmodelIF1720;
irtmodelIF1719:
	local[12]= NIL;
irtmodelIF1720:
irtmodelIF1718:
	w = local[12];
	local[11]= (pointer)get_sym_func(fqv[288]);
	local[12]= local[1];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= fqv[198];
	local[14]= fqv[20];
	local[15]= local[7];
	local[16]= fqv[312];
	local[17]= T;
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,8,local+11); /*apply*/
	local[11]= local[9];
	local[12]= local[8];
	local[13]= fqv[31];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[12]= w;
	local[9] = local[11];
	local[10] = local[12];
	w = NIL;
	ctx->vsp=local+11;
	goto irtmodelTAG1714;
	w = NIL;
	local[9]= w;
irtmodelBLK1713:
	if (local[5]==NIL) goto irtmodelIF1721;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,1,local+9); /*funcall*/
	local[9]= w;
	goto irtmodelIF1722;
irtmodelIF1721:
	local[9]= NIL;
irtmodelIF1722:
	w = T;
	local[0]= w;
irtmodelBLK1697:
	ctx->vsp=local; return(local[0]);}

/*:find-joint-angle-limit-weight-old-from-union-link-list*/
static pointer irtmodelM1723cascaded_link_find_joint_angle_limit_weight_old_from_union_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[313];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	local[2]= fqv[139];
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtmodelCLO1725,env,argv,local);
	ctx->vsp=local+4;
	w=(*ftab[41])(ctx,4,local+0,&ftab[41],fqv[314]); /*assoc*/
	local[0]= w;
irtmodelBLK1724:
	ctx->vsp=local; return(local[0]);}

/*:reset-joint-angle-limit-weight-old*/
static pointer irtmodelM1726cascaded_link_reset_joint_angle_limit_weight_old(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[315];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	if (local[0]==NIL) goto irtmodelIF1728;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)RPLACA2(ctx,2,local+1); /*rplaca2*/
	local[1]= w;
	goto irtmodelIF1729;
irtmodelIF1728:
	local[1]= NIL;
irtmodelIF1729:
	w = local[1];
	local[0]= w;
irtmodelBLK1727:
	ctx->vsp=local; return(local[0]);}

/*:calc-weight-from-joint-limit*/
static pointer irtmodelM1730cascaded_link_calc_weight_from_joint_limit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=10) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[315];
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	if (local[2]!=NIL) goto irtmodelIF1732;
	local[3]= argv[0];
	local[4]= fqv[150];
	local[5]= fqv[313];
	local[6]= argv[5];
	local[7]= fqv[3];
	ctx->vsp=local+8;
	w=(*ftab[18])(ctx,2,local+6,&ftab[18],fqv[128]); /*send-all*/
	local[6]= w;
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[313];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[315];
	local[5]= argv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
	goto irtmodelIF1733;
irtmodelIF1732:
	local[3]= NIL;
irtmodelIF1733:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car!=NIL) goto irtmodelIF1734;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= loadglobal(fqv[5]);
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+20);
	ctx->vsp=local+6;
	w=(*ftab[36])(ctx,2,local+4,&ftab[36],fqv[242]); /*fill*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)RPLACA2(ctx,2,local+3); /*rplaca2*/
	local[3]= w;
	goto irtmodelIF1735;
irtmodelIF1734:
	local[3]= NIL;
irtmodelIF1735:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w = local[0];
	local[2]= argv[2];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmodelIF1736;
	local[2]= argv[2];
	local[3]= argv[5];
	local[4]= fqv[198];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[128]); /*send-all*/
	local[3]= w;
	local[4]= argv[9];
	ctx->vsp=local+5;
	w=(pointer)irtmodelF752joint_angle_limit_weight(ctx,2,local+3); /*joint-angle-limit-weight*/
	local[3]= w;
	local[4]= argv[9];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,3,local+2); /*scale*/
	local[1] = w;
	if (argv[6]==NIL) goto irtmodelIF1738;
	local[2]= fqv[202];
	w = argv[6];
	if (memq(local[2],w)!=NIL) goto irtmodelIF1738;
	local[2]= local[0];
	local[3]= fqv[316];
	ctx->vsp=local+4;
	w=(*ftab[33])(ctx,2,local+2,&ftab[33],fqv[233]); /*format-array*/
	local[2]= local[1];
	local[3]= fqv[317];
	ctx->vsp=local+4;
	w=(*ftab[33])(ctx,2,local+2,&ftab[33],fqv[233]); /*format-array*/
	local[2]= w;
	goto irtmodelIF1739;
irtmodelIF1738:
	local[2]= NIL;
irtmodelIF1739:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[3];
irtmodelWHL1740:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtmodelWHX1741;
	local[4]= argv[8];
	local[5]= local[2];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)GREQP(ctx,2,local+6); /*>=*/
	if (w==NIL) goto irtmodelIF1743;
	local[6]= makeflt(1.0000000000000000000000e+00);
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	goto irtmodelIF1744;
irtmodelIF1743:
	local[6]= makeflt(1.0000000000000000000000e+00);
irtmodelIF1744:
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtmodelWHL1740;
irtmodelWHX1741:
	local[4]= NIL;
irtmodelBLK1742:
	w = NIL;
	local[2]= w;
	goto irtmodelIF1737;
irtmodelIF1736:
	local[2]= NIL;
irtmodelIF1737:
	local[2]= argv[2];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)NUMEQUAL(ctx,2,local+2); /*=*/
	if (w==NIL) goto irtmodelIF1745;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[3];
irtmodelWHL1747:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtmodelWHX1748;
	local[4]= argv[8];
	local[5]= local[2];
	local[6]= argv[7];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtmodelWHL1747;
irtmodelWHX1748:
	local[4]= NIL;
irtmodelBLK1749:
	w = NIL;
	local[2]= w;
	goto irtmodelIF1746;
irtmodelIF1745:
	local[2]= NIL;
irtmodelIF1746:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= argv[5];
irtmodelWHL1750:
	if (local[4]==NIL) goto irtmodelWHX1751;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO1753,env,argv,local);
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(*ftab[42])(ctx,2,local+5,&ftab[42],fqv[318]); /*count-if*/
	local[5]= w;
	local[6]= local[3];
	local[7]= fqv[198];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+6); /*calc-target-joint-dimension*/
	local[6]= w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto irtmodelIF1754;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
irtmodelWHL1756:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtmodelWHX1757;
	local[9]= argv[8];
	local[10]= local[2];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[8];
	local[12]= local[2];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtmodelWHL1756;
irtmodelWHX1757:
	local[9]= NIL;
irtmodelBLK1758:
	w = NIL;
	local[7]= w;
	goto irtmodelIF1755;
irtmodelIF1754:
	local[7]= NIL;
irtmodelIF1755:
	local[7]= local[2];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[2] = w;
	w = local[2];
	goto irtmodelWHL1750;
irtmodelWHX1751:
	local[5]= NIL;
irtmodelBLK1752:
	w = NIL;
	w = argv[8];
	local[0]= w;
irtmodelBLK1731:
	ctx->vsp=local; return(local[0]);}

/*:calc-inverse-kinematics-weight-from-link-list*/
static pointer irtmodelM1759cascaded_link_calc_inverse_kinematics_weight_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[319], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1761;
	local[0] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1761:
	if (n & (1<<1)) goto irtmodelKEY1762;
	local[8]= argv[0];
	local[9]= fqv[197];
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[1] = w;
irtmodelKEY1762:
	if (n & (1<<2)) goto irtmodelKEY1763;
	local[8]= argv[0];
	local[9]= fqv[211];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[2] = w;
irtmodelKEY1763:
	if (n & (1<<3)) goto irtmodelKEY1764;
	local[8]= loadglobal(fqv[5]);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[36])(ctx,2,local+8,&ftab[36],fqv[242]); /*fill*/
	local[3] = w;
irtmodelKEY1764:
	if (n & (1<<4)) goto irtmodelKEY1765;
	local[4] = NIL;
irtmodelKEY1765:
	if (n & (1<<5)) goto irtmodelKEY1766;
	local[5] = NIL;
irtmodelKEY1766:
	if (n & (1<<6)) goto irtmodelKEY1767;
	local[8]= loadglobal(fqv[5]);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[6] = w;
irtmodelKEY1767:
	if (n & (1<<7)) goto irtmodelKEY1768;
	local[8]= loadglobal(fqv[5]);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[7] = w;
irtmodelKEY1768:
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[43])(ctx,1,local+8,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelCON1770;
	local[8]= local[3];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,2,local+8); /*funcall*/
	local[3] = w;
	local[8]= local[3];
	goto irtmodelCON1769;
irtmodelCON1770:
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LISTP(ctx,1,local+8); /*listp*/
	if (w==NIL) goto irtmodelCON1771;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)EVAL(ctx,1,local+8); /*eval*/
	local[3] = w;
	local[8]= local[3];
	goto irtmodelCON1769;
irtmodelCON1771:
	local[8]= NIL;
irtmodelCON1769:
	if (local[5]==NIL) goto irtmodelIF1772;
	local[8]= fqv[202];
	w = local[5];
	if (memq(local[8],w)!=NIL) goto irtmodelIF1772;
	local[8]= local[3];
	local[9]= fqv[321];
	ctx->vsp=local+10;
	w=(*ftab[33])(ctx,2,local+8,&ftab[33],fqv[233]); /*format-array*/
	local[8]= w;
	goto irtmodelIF1773;
irtmodelIF1772:
	local[8]= NIL;
irtmodelIF1773:
	local[8]= NIL;
	local[9]= local[4];
irtmodelWHL1774:
	if (local[9]==NIL) goto irtmodelWHX1775;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[1];
	local[12]= fqv[139];
	local[13]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+14;
	w=(*ftab[32])(ctx,4,local+10,&ftab[32],fqv[212]); /*position*/
	local[10]= w;
	if (local[10]==NIL) goto irtmodelIF1777;
	local[11]= (pointer)get_sym_func(fqv[322]);
	local[12]= local[1];
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)SUBSEQ(ctx,3,local+12); /*subseq*/
	local[12]= w;
	local[13]= fqv[198];
	ctx->vsp=local+14;
	w=(*ftab[18])(ctx,2,local+12,&ftab[18],fqv[128]); /*send-all*/
	local[12]= w;
	local[13]= fqv[31];
	ctx->vsp=local+14;
	w=(*ftab[18])(ctx,2,local+12,&ftab[18],fqv[128]); /*send-all*/
	local[12]= w;
	local[13]= fqv[323];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[26])(ctx,4,local+11,&ftab[26],fqv[196]); /*reduce*/
	local[11]= w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	ctx->vsp=local+13;
	w=(*ftab[43])(ctx,1,local+12,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF1779;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	ctx->vsp=local+13;
	w=(pointer)FUNCALL(ctx,1,local+12); /*funcall*/
	local[12]= w;
	goto irtmodelIF1780;
irtmodelIF1779:
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
irtmodelIF1780:
	local[13]= makeint((eusinteger_t)0L);
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= fqv[198];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= fqv[31];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
irtmodelWHL1781:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtmodelWHX1782;
	local[15]= local[3];
	local[16]= local[13];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	local[17]= local[3];
	local[18]= local[13];
	local[19]= local[11];
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(*ftab[0])(ctx,1,local+18,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelIF1784;
	local[18]= local[12];
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	goto irtmodelIF1785;
irtmodelIF1784:
	local[18]= local[12];
irtmodelIF1785:
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SETELT(ctx,3,local+15); /*setelt*/
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtmodelWHL1781;
irtmodelWHX1782:
	local[15]= NIL;
irtmodelBLK1783:
	w = NIL;
	local[11]= w;
	goto irtmodelIF1778;
irtmodelIF1777:
	local[11]= NIL;
irtmodelIF1778:
	w = local[11];
	goto irtmodelWHL1774;
irtmodelWHX1775:
	local[10]= NIL;
irtmodelBLK1776:
	w = NIL;
	if (local[5]==NIL) goto irtmodelIF1786;
	local[8]= fqv[202];
	w = local[5];
	if (memq(local[8],w)!=NIL) goto irtmodelIF1786;
	if (local[4]==NIL) goto irtmodelIF1786;
	local[8]= local[3];
	local[9]= fqv[324];
	ctx->vsp=local+10;
	w=(*ftab[33])(ctx,2,local+8,&ftab[33],fqv[233]); /*format-array*/
	local[8]= w;
	goto irtmodelIF1787;
irtmodelIF1786:
	local[8]= NIL;
irtmodelIF1787:
	local[8]= argv[0];
	local[9]= fqv[325];
	local[10]= local[0];
	local[11]= local[2];
	local[12]= argv[2];
	local[13]= local[1];
	local[14]= local[5];
	local[15]= local[3];
	local[16]= local[6];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,10,local+8); /*send*/
	local[6] = w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[2];
irtmodelWHL1788:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtmodelWHX1789;
	local[10]= local[6];
	local[11]= local[8];
	local[12]= local[3];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[6];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtmodelWHL1788;
irtmodelWHX1789:
	local[10]= NIL;
irtmodelBLK1790:
	w = NIL;
	if (local[5]==NIL) goto irtmodelIF1791;
	local[8]= fqv[202];
	w = local[5];
	if (memq(local[8],w)!=NIL) goto irtmodelIF1791;
	local[8]= local[6];
	local[9]= fqv[326];
	ctx->vsp=local+10;
	w=(*ftab[33])(ctx,2,local+8,&ftab[33],fqv[233]); /*format-array*/
	local[8]= w;
	goto irtmodelIF1792;
irtmodelIF1791:
	local[8]= NIL;
irtmodelIF1792:
	w = local[6];
	local[0]= w;
irtmodelBLK1760:
	ctx->vsp=local; return(local[0]);}

/*:calc-nspace-from-joint-limit*/
static pointer irtmodelM1793cascaded_link_calc_nspace_from_joint_limit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	local[0]= argv[2];
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto irtmodelIF1795;
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= fqv[198];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	local[2]= argv[6];
	ctx->vsp=local+3;
	w=(pointer)irtmodelF753joint_angle_limit_nspace(ctx,2,local+1); /*joint-angle-limit-nspace*/
	local[1]= w;
	local[2]= argv[6];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	argv[6] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
irtmodelWHL1797:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtmodelWHX1798;
	local[2]= argv[6];
	local[3]= local[0];
	local[4]= argv[6];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[4];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtmodelWHL1797;
irtmodelWHX1798:
	local[2]= NIL;
irtmodelBLK1799:
	w = NIL;
	if (argv[5]==NIL) goto irtmodelIF1800;
	local[0]= fqv[202];
	w = argv[5];
	if (memq(local[0],w)!=NIL) goto irtmodelIF1800;
	local[0]= loadglobal(fqv[5]);
	local[1]= (pointer)get_sym_func(fqv[49]);
	local[2]= argv[6];
	ctx->vsp=local+3;
	w=(pointer)MAP(ctx,3,local+0); /*map*/
	local[0]= w;
	local[1]= fqv[327];
	ctx->vsp=local+2;
	w=(*ftab[33])(ctx,2,local+0,&ftab[33],fqv[233]); /*format-array*/
	local[0]= w;
	goto irtmodelIF1801;
irtmodelIF1800:
	local[0]= NIL;
irtmodelIF1801:
	goto irtmodelIF1796;
irtmodelIF1795:
	local[0]= NIL;
irtmodelIF1796:
	w = argv[6];
	local[0]= w;
irtmodelBLK1794:
	ctx->vsp=local; return(local[0]);}

/*:calc-inverse-kinematics-nspace-from-link-list*/
static pointer irtmodelM1802cascaded_link_calc_inverse_kinematics_nspace_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[328], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1804;
	local[0] = makeflt(9.9999999999999950039964e-03);
irtmodelKEY1804:
	if (n & (1<<1)) goto irtmodelKEY1805;
	local[14]= argv[0];
	local[15]= fqv[197];
	local[16]= argv[2];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[1] = w;
irtmodelKEY1805:
	if (n & (1<<2)) goto irtmodelKEY1806;
	local[14]= argv[0];
	local[15]= fqv[211];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[2] = w;
irtmodelKEY1806:
	if (n & (1<<3)) goto irtmodelKEY1807;
	local[3] = NIL;
irtmodelKEY1807:
	if (n & (1<<4)) goto irtmodelKEY1808;
	local[4] = NIL;
irtmodelKEY1808:
	if (n & (1<<5)) goto irtmodelKEY1809;
	local[5] = NIL;
irtmodelKEY1809:
	if (n & (1<<6)) goto irtmodelKEY1810;
	local[6] = makeflt(0.0000000000000000000000e+00);
irtmodelKEY1810:
	if (n & (1<<7)) goto irtmodelKEY1811;
	local[7] = NIL;
irtmodelKEY1811:
	if (n & (1<<8)) goto irtmodelKEY1812;
	local[8] = NIL;
irtmodelKEY1812:
	if (n & (1<<9)) goto irtmodelKEY1813;
	local[9] = fqv[33];
irtmodelKEY1813:
	if (n & (1<<10)) goto irtmodelKEY1814;
	local[10] = NIL;
irtmodelKEY1814:
	if (n & (1<<11)) goto irtmodelKEY1815;
	local[14]= loadglobal(fqv[5]);
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,2,local+14); /*instantiate*/
	local[14]= w;
	local[15]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(*ftab[36])(ctx,2,local+14,&ftab[36],fqv[242]); /*fill*/
	local[11] = w;
irtmodelKEY1815:
	if (n & (1<<12)) goto irtmodelKEY1816;
	local[12] = T;
irtmodelKEY1816:
	if (n & (1<<13)) goto irtmodelKEY1817;
	local[14]= loadglobal(fqv[5]);
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,2,local+14); /*instantiate*/
	local[13] = w;
irtmodelKEY1817:
	local[14]= argv[0];
	local[15]= fqv[329];
	local[16]= local[0];
	local[17]= local[1];
	local[18]= local[11];
	local[19]= local[4];
	local[20]= local[13];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,7,local+14); /*send*/
	local[13] = w;
	if (local[10]==NIL) goto irtmodelIF1818;
	local[14]= local[6];
	local[15]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtmodelIF1820;
	if (local[7]==NIL) goto irtmodelIF1820;
	local[14]= argv[0];
	local[15]= fqv[330];
	local[16]= local[1];
	local[17]= fqv[273];
	local[18]= local[11];
	local[19]= fqv[331];
	local[20]= local[8];
	local[21]= fqv[332];
	local[22]= local[12];
	local[23]= fqv[333];
	local[24]= local[7];
	local[25]= fqv[334];
	local[26]= local[6];
	local[27]= fqv[335];
	local[28]= local[9];
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,15,local+14); /*send*/
	local[14]= w;
	local[15]= local[13];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	local[13] = w;
	local[14]= local[13];
	goto irtmodelIF1821;
irtmodelIF1820:
	local[14]= NIL;
irtmodelIF1821:
	goto irtmodelIF1819;
irtmodelIF1818:
	local[14]= NIL;
irtmodelIF1819:
	local[14]= NIL;
	local[15]= local[5];
irtmodelWHL1822:
	if (local[15]==NIL) goto irtmodelWHX1823;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= local[1];
	local[18]= fqv[139];
	local[19]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+20;
	w=(*ftab[32])(ctx,4,local+16,&ftab[32],fqv[212]); /*position*/
	local[16]= w;
	if (local[16]==NIL) goto irtmodelIF1825;
	local[17]= (pointer)get_sym_func(fqv[322]);
	local[18]= local[1];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)SUBSEQ(ctx,3,local+18); /*subseq*/
	local[18]= w;
	local[19]= fqv[198];
	ctx->vsp=local+20;
	w=(*ftab[18])(ctx,2,local+18,&ftab[18],fqv[128]); /*send-all*/
	local[18]= w;
	local[19]= fqv[31];
	ctx->vsp=local+20;
	w=(*ftab[18])(ctx,2,local+18,&ftab[18],fqv[128]); /*send-all*/
	local[18]= w;
	local[19]= fqv[323];
	local[20]= makeint((eusinteger_t)0L);
	ctx->vsp=local+21;
	w=(*ftab[26])(ctx,4,local+17,&ftab[26],fqv[196]); /*reduce*/
	local[17]= w;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	ctx->vsp=local+19;
	w=(*ftab[43])(ctx,1,local+18,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF1827;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	ctx->vsp=local+19;
	w=(pointer)FUNCALL(ctx,1,local+18); /*funcall*/
	local[18]= w;
	goto irtmodelIF1828;
irtmodelIF1827:
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
irtmodelIF1828:
	local[19]= makeint((eusinteger_t)0L);
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[198];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	local[21]= fqv[31];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
irtmodelWHL1829:
	local[21]= local[19];
	w = local[20];
	if ((eusinteger_t)local[21] >= (eusinteger_t)w) goto irtmodelWHX1830;
	local[21]= local[13];
	local[22]= local[19];
	local[23]= local[17];
	ctx->vsp=local+24;
	w=(pointer)PLUS(ctx,2,local+22); /*+*/
	local[22]= w;
	local[23]= local[13];
	local[24]= local[19];
	local[25]= local[17];
	ctx->vsp=local+26;
	w=(pointer)PLUS(ctx,2,local+24); /*+*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(*ftab[0])(ctx,1,local+24,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelIF1832;
	local[24]= local[18];
	local[25]= local[19];
	ctx->vsp=local+26;
	w=(pointer)ELT(ctx,2,local+24); /*elt*/
	local[24]= w;
	goto irtmodelIF1833;
irtmodelIF1832:
	local[24]= local[18];
irtmodelIF1833:
	local[25]= local[11];
	local[26]= local[19];
	local[27]= local[17];
	ctx->vsp=local+28;
	w=(pointer)PLUS(ctx,2,local+26); /*+*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)TIMES(ctx,2,local+24); /***/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)SETELT(ctx,3,local+21); /*setelt*/
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[19] = w;
	goto irtmodelWHL1829;
irtmodelWHX1830:
	local[21]= NIL;
irtmodelBLK1831:
	w = NIL;
	local[17]= w;
	goto irtmodelIF1826;
irtmodelIF1825:
	local[17]= NIL;
irtmodelIF1826:
	w = local[17];
	goto irtmodelWHL1822;
irtmodelWHX1823:
	local[16]= NIL;
irtmodelBLK1824:
	w = NIL;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,1,local+14,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelCON1835;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)FUNCALL(ctx,1,local+14); /*funcall*/
	local[3] = w;
	local[14]= local[3];
	goto irtmodelCON1834;
irtmodelCON1835:
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)LISTP(ctx,1,local+14); /*listp*/
	if (w==NIL) goto irtmodelCON1836;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)EVAL(ctx,1,local+14); /*eval*/
	local[3] = w;
	local[14]= local[3];
	goto irtmodelCON1834;
irtmodelCON1836:
	local[14]= NIL;
irtmodelCON1834:
	if (local[3]==NIL) goto irtmodelIF1837;
	local[14]= local[3];
	local[15]= local[13];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	local[13] = w;
	local[14]= local[13];
	goto irtmodelIF1838;
irtmodelIF1837:
	local[14]= NIL;
irtmodelIF1838:
	w = local[13];
	local[0]= w;
irtmodelBLK1803:
	ctx->vsp=local; return(local[0]);}

/*:move-joints-avoidance*/
static pointer irtmodelM1839cascaded_link_move_joints_avoidance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1841:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[336], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1842;
	local[1] = NIL;
irtmodelKEY1842:
	if (n & (1<<1)) goto irtmodelKEY1843;
	local[2] = NIL;
irtmodelKEY1843:
	if (n & (1<<2)) goto irtmodelKEY1844;
	local[27]= argv[0];
	local[28]= fqv[211];
	local[29]= local[1];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,3,local+27); /*send*/
	local[3] = w;
irtmodelKEY1844:
	if (n & (1<<3)) goto irtmodelKEY1845;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[27]= w;
	local[28]= makeint((eusinteger_t)1L);
	ctx->vsp=local+29;
	w=(*ftab[36])(ctx,2,local+27,&ftab[36],fqv[242]); /*fill*/
	local[4] = w;
irtmodelKEY1845:
	if (n & (1<<4)) goto irtmodelKEY1846;
	local[5] = NIL;
irtmodelKEY1846:
	if (n & (1<<5)) goto irtmodelKEY1847;
	local[6] = makeflt(9.9999999999999950039964e-03);
irtmodelKEY1847:
	if (n & (1<<6)) goto irtmodelKEY1848;
	local[7] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1848:
	if (n & (1<<7)) goto irtmodelKEY1849;
	local[8] = makeint((eusinteger_t)200L);
irtmodelKEY1849:
	if (n & (1<<8)) goto irtmodelKEY1850;
	local[9] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1850:
	if (n & (1<<9)) goto irtmodelKEY1851;
	local[10] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1851:
	if (n & (1<<10)) goto irtmodelKEY1852;
	local[27]= argv[0];
	local[28]= fqv[337];
	local[29]= local[2];
	local[30]= fqv[338];
	local[31]= fqv[338];
	w = local[0];
	w=memq(local[31],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[31]= (w)->c.cons.car;
	local[32]= fqv[339];
	local[33]= fqv[340];
	w = local[0];
	w=memq(local[33],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[33]= (w)->c.cons.car;
	ctx->vsp=local+34;
	w=(pointer)SEND(ctx,7,local+27); /*send*/
	local[11] = w;
irtmodelKEY1852:
	if (n & (1<<11)) goto irtmodelKEY1853;
	local[12] = makeflt(0.0000000000000000000000e+00);
irtmodelKEY1853:
	if (n & (1<<12)) goto irtmodelKEY1854;
	local[13] = NIL;
irtmodelKEY1854:
	if (n & (1<<13)) goto irtmodelKEY1855;
	local[14] = NIL;
irtmodelKEY1855:
	if (n & (1<<14)) goto irtmodelKEY1856;
	local[15] = fqv[33];
irtmodelKEY1856:
	if (n & (1<<15)) goto irtmodelKEY1857;
	local[16] = NIL;
irtmodelKEY1857:
	if (n & (1<<16)) goto irtmodelKEY1858;
	local[17] = NIL;
irtmodelKEY1858:
	if (n & (1<<17)) goto irtmodelKEY1859;
	local[18] = NIL;
irtmodelKEY1859:
	if (n & (1<<18)) goto irtmodelKEY1860;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[19] = w;
irtmodelKEY1860:
	if (n & (1<<19)) goto irtmodelKEY1861;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[20] = w;
irtmodelKEY1861:
	if (n & (1<<20)) goto irtmodelKEY1862;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[21] = w;
irtmodelKEY1862:
	if (n & (1<<21)) goto irtmodelKEY1863;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[22] = w;
irtmodelKEY1863:
	if (n & (1<<22)) goto irtmodelKEY1864;
	local[27]= local[3];
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(*ftab[23])(ctx,2,local+27,&ftab[23],fqv[166]); /*make-matrix*/
	local[23] = w;
irtmodelKEY1864:
	if (n & (1<<23)) goto irtmodelKEY1865;
	local[27]= local[3];
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(*ftab[23])(ctx,2,local+27,&ftab[23],fqv[166]); /*make-matrix*/
	local[24] = w;
irtmodelKEY1865:
	if (n & (1<<24)) goto irtmodelKEY1866;
	local[25] = NIL;
irtmodelKEY1866:
	if (n & (1<<25)) goto irtmodelKEY1867;
	local[26] = NIL;
irtmodelKEY1867:
	local[27]= NIL;
	local[28]= NIL;
	local[29]= NIL;
	local[30]= NIL;
	local[31]= NIL;
	local[32]= makeflt(0.0000000000000000000000e+00);
	local[33]= NIL;
	local[34]= NIL;
	local[35]= NIL;
	if (local[26]!=NIL) goto irtmodelIF1868;
	local[36]= fqv[341];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	w = T;
	ctx->vsp=local+36;
	local[0]=w;
	goto irtmodelBLK1840;
	goto irtmodelIF1869;
irtmodelIF1868:
	local[36]= NIL;
irtmodelIF1869:
	if (local[25]==NIL) goto irtmodelIF1870;
	w = local[25];
	if (!!iscons(w)) goto irtmodelIF1870;
	local[36]= local[25];
	ctx->vsp=local+37;
	w=(pointer)LIST(ctx,1,local+36); /*list*/
	local[25] = w;
	local[36]= local[25];
	goto irtmodelIF1871;
irtmodelIF1870:
	local[36]= NIL;
irtmodelIF1871:
	if (local[25]==NIL) goto irtmodelIF1872;
	local[36]= fqv[202];
	w = local[25];
	if (memq(local[36],w)!=NIL) goto irtmodelIF1872;
	local[36]= fqv[342];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= NIL;
	local[37]= local[1];
	local[38]= fqv[198];
	ctx->vsp=local+39;
	w=(*ftab[18])(ctx,2,local+37,&ftab[18],fqv[128]); /*send-all*/
	local[37]= w;
irtmodelWHL1874:
	if (local[37]==NIL) goto irtmodelWHX1875;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[38]= (w)->c.cons.car;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[37] = (w)->c.cons.cdr;
	w = local[38];
	local[36] = w;
	local[38]= local[36];
	local[39]= fqv[20];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,2,local+38); /*send*/
	local[38]= w;
	local[39]= local[38];
	ctx->vsp=local+40;
	w=(pointer)VECTORP(ctx,1,local+39); /*vectorp*/
	if (w==NIL) goto irtmodelIF1877;
	local[39]= makeint((eusinteger_t)0L);
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
irtmodelWHL1879:
	local[41]= local[39];
	w = local[40];
	if ((eusinteger_t)local[41] >= (eusinteger_t)w) goto irtmodelWHX1880;
	local[41]= fqv[343];
	local[42]= local[38];
	local[43]= local[39];
	ctx->vsp=local+44;
	w=(pointer)ELT(ctx,2,local+42); /*elt*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,2,local+41,&ftab[2],fqv[15]); /*warn*/
	local[41]= local[39];
	ctx->vsp=local+42;
	w=(pointer)ADD1(ctx,1,local+41); /*1+*/
	local[39] = w;
	goto irtmodelWHL1879;
irtmodelWHX1880:
	local[41]= NIL;
irtmodelBLK1881:
	w = NIL;
	local[39]= w;
	goto irtmodelIF1878;
irtmodelIF1877:
	local[39]= fqv[344];
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,2,local+39,&ftab[2],fqv[15]); /*warn*/
	local[39]= w;
irtmodelIF1878:
	w = local[39];
	goto irtmodelWHL1874;
irtmodelWHX1875:
	local[38]= NIL;
irtmodelBLK1876:
	w = NIL;
	local[36]= fqv[345];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= fqv[346];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= NIL;
	local[37]= local[1];
	local[38]= fqv[198];
	ctx->vsp=local+39;
	w=(*ftab[18])(ctx,2,local+37,&ftab[18],fqv[128]); /*send-all*/
	local[37]= w;
irtmodelWHL1882:
	if (local[37]==NIL) goto irtmodelWHX1883;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[38]= (w)->c.cons.car;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[37] = (w)->c.cons.cdr;
	w = local[38];
	local[36] = w;
	local[38]= local[36];
	local[39]= fqv[22];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,2,local+38); /*send*/
	local[38]= w;
	local[39]= local[38];
	ctx->vsp=local+40;
	w=(pointer)VECTORP(ctx,1,local+39); /*vectorp*/
	if (w==NIL) goto irtmodelIF1885;
	local[39]= makeint((eusinteger_t)0L);
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
irtmodelWHL1887:
	local[41]= local[39];
	w = local[40];
	if ((eusinteger_t)local[41] >= (eusinteger_t)w) goto irtmodelWHX1888;
	local[41]= fqv[347];
	local[42]= local[38];
	local[43]= local[39];
	ctx->vsp=local+44;
	w=(pointer)ELT(ctx,2,local+42); /*elt*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,2,local+41,&ftab[2],fqv[15]); /*warn*/
	local[41]= local[39];
	ctx->vsp=local+42;
	w=(pointer)ADD1(ctx,1,local+41); /*1+*/
	local[39] = w;
	goto irtmodelWHL1887;
irtmodelWHX1888:
	local[41]= NIL;
irtmodelBLK1889:
	w = NIL;
	local[39]= w;
	goto irtmodelIF1886;
irtmodelIF1885:
	local[39]= fqv[348];
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,2,local+39,&ftab[2],fqv[15]); /*warn*/
	local[39]= w;
irtmodelIF1886:
	w = local[39];
	goto irtmodelWHL1882;
irtmodelWHX1883:
	local[38]= NIL;
irtmodelBLK1884:
	w = NIL;
	local[36]= fqv[349];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= fqv[350];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= NIL;
	local[37]= local[1];
	local[38]= fqv[198];
	ctx->vsp=local+39;
	w=(*ftab[18])(ctx,2,local+37,&ftab[18],fqv[128]); /*send-all*/
	local[37]= w;
irtmodelWHL1890:
	if (local[37]==NIL) goto irtmodelWHX1891;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[38]= (w)->c.cons.car;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[37] = (w)->c.cons.cdr;
	w = local[38];
	local[36] = w;
	local[38]= local[36];
	local[39]= fqv[23];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,2,local+38); /*send*/
	local[38]= w;
	local[39]= local[38];
	ctx->vsp=local+40;
	w=(pointer)VECTORP(ctx,1,local+39); /*vectorp*/
	if (w==NIL) goto irtmodelIF1893;
	local[39]= makeint((eusinteger_t)0L);
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
irtmodelWHL1895:
	local[41]= local[39];
	w = local[40];
	if ((eusinteger_t)local[41] >= (eusinteger_t)w) goto irtmodelWHX1896;
	local[41]= fqv[351];
	local[42]= local[38];
	local[43]= local[39];
	ctx->vsp=local+44;
	w=(pointer)ELT(ctx,2,local+42); /*elt*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,2,local+41,&ftab[2],fqv[15]); /*warn*/
	local[41]= local[39];
	ctx->vsp=local+42;
	w=(pointer)ADD1(ctx,1,local+41); /*1+*/
	local[39] = w;
	goto irtmodelWHL1895;
irtmodelWHX1896:
	local[41]= NIL;
irtmodelBLK1897:
	w = NIL;
	local[39]= w;
	goto irtmodelIF1894;
irtmodelIF1893:
	local[39]= fqv[352];
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,2,local+39,&ftab[2],fqv[15]); /*warn*/
	local[39]= w;
irtmodelIF1894:
	w = local[39];
	goto irtmodelWHL1890;
irtmodelWHX1891:
	local[38]= NIL;
irtmodelBLK1892:
	w = NIL;
	local[36]= fqv[353];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= w;
	goto irtmodelIF1873;
irtmodelIF1872:
	local[36]= NIL;
irtmodelIF1873:
	local[36]= argv[0];
	local[37]= fqv[354];
	local[38]= local[2];
	local[39]= fqv[273];
	local[40]= local[4];
	local[41]= fqv[355];
	local[42]= local[3];
	local[43]= fqv[356];
	local[44]= local[7];
	local[45]= fqv[357];
	local[46]= local[1];
	local[47]= fqv[340];
	local[48]= local[25];
	local[49]= fqv[283];
	local[50]= local[19];
	local[51]= fqv[358];
	local[52]= local[21];
	local[53]= fqv[359];
	local[54]= local[17];
	ctx->vsp=local+55;
	w=(pointer)SEND(ctx,19,local+36); /*send*/
	local[4] = w;
	local[36]= (pointer)get_sym_func(fqv[288]);
	local[37]= argv[0];
	local[38]= fqv[360];
	local[39]= local[26];
	local[40]= fqv[273];
	local[41]= local[4];
	local[42]= local[0];
	ctx->vsp=local+43;
	w=(pointer)APPLY(ctx,7,local+36); /*apply*/
	local[34] = w;
	local[36]= local[23]->c.obj.iv[1];
	local[37]= makeint((eusinteger_t)0L);
	ctx->vsp=local+38;
	w=(*ftab[36])(ctx,2,local+36,&ftab[36],fqv[242]); /*fill*/
	local[36]= makeint((eusinteger_t)0L);
	local[37]= local[3];
irtmodelWHL1898:
	local[38]= local[36];
	w = local[37];
	if ((eusinteger_t)local[38] >= (eusinteger_t)w) goto irtmodelWHX1899;
	local[38]= local[23];
	local[39]= local[36];
	local[40]= local[36];
	local[41]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+42;
	w=(pointer)ASET(ctx,4,local+38); /*aset*/
	local[38]= local[36];
	ctx->vsp=local+39;
	w=(pointer)ADD1(ctx,1,local+38); /*1+*/
	local[36] = w;
	goto irtmodelWHL1898;
irtmodelWHX1899:
	local[38]= NIL;
irtmodelBLK1900:
	w = NIL;
	local[36]= local[23];
	local[37]= local[34];
	local[38]= local[26];
	local[39]= local[24];
	ctx->vsp=local+40;
	w=(pointer)MATTIMES(ctx,3,local+37); /*m**/
	local[37]= w;
	local[38]= local[23];
	ctx->vsp=local+39;
	w=(*ftab[44])(ctx,3,local+36,&ftab[44],fqv[361]); /*m-*/
	local[35] = w;
	local[36]= argv[0];
	local[37]= fqv[150];
	local[38]= fqv[302];
	local[39]= NIL;
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,4,local+36); /*send*/
	local[36]= argv[0];
	local[37]= fqv[150];
	local[38]= fqv[303];
	local[39]= NIL;
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,4,local+36); /*send*/
	if (local[11]==NIL) goto irtmodelIF1901;
	local[36]= local[8];
	local[37]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+38;
	w=(pointer)GREATERP(ctx,2,local+36); /*>*/
	if (w==NIL) goto irtmodelIF1901;
	local[36]= local[10];
	local[37]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+38;
	w=(pointer)GREATERP(ctx,2,local+36); /*>*/
	if (w!=NIL) goto irtmodelOR1903;
	local[36]= local[9];
	local[37]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+38;
	w=(pointer)GREATERP(ctx,2,local+36); /*>*/
	if (w!=NIL) goto irtmodelOR1903;
	goto irtmodelIF1901;
irtmodelOR1903:
	local[36]= (pointer)get_sym_func(fqv[288]);
	local[37]= argv[0];
	local[38]= fqv[362];
	local[39]= fqv[363];
	local[40]= local[8];
	local[41]= fqv[364];
	local[42]= local[9];
	local[43]= fqv[365];
	local[44]= local[10];
	local[45]= fqv[273];
	local[46]= local[4];
	local[47]= fqv[366];
	local[48]= local[11];
	local[49]= local[0];
	ctx->vsp=local+50;
	w=(pointer)APPLY(ctx,14,local+36); /*apply*/
	local[31] = w;
	local[36]= argv[0];
	local[37]= fqv[184];
	local[38]= fqv[252];
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,3,local+36); /*send*/
	local[36]= w;
	local[37]= makeint((eusinteger_t)0L);
	ctx->vsp=local+38;
	w=(pointer)ELT(ctx,2,local+36); /*elt*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[33] = (w)->c.cons.car;
	local[36]= local[10];
	local[37]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+38;
	w=(pointer)LSEQP(ctx,2,local+36); /*<=*/
	if (w==NIL) goto irtmodelCON1905;
	local[36]= makeflt(0.0000000000000000000000e+00);
	goto irtmodelCON1904;
irtmodelCON1905:
	local[36]= local[33];
	local[37]= makeflt(9.9999999999999977795540e-02);
	local[38]= local[8];
	ctx->vsp=local+39;
	w=(pointer)TIMES(ctx,2,local+37); /***/
	local[37]= w;
	ctx->vsp=local+38;
	w=(pointer)LESSP(ctx,2,local+36); /*<*/
	if (w==NIL) goto irtmodelCON1906;
	local[36]= makeflt(1.0000000000000000000000e+00);
	goto irtmodelCON1904;
irtmodelCON1906:
	local[36]= local[33];
	local[37]= local[8];
	ctx->vsp=local+38;
	w=(pointer)LESSP(ctx,2,local+36); /*<*/
	if (w==NIL) goto irtmodelCON1907;
	local[36]= local[8];
	local[37]= local[33];
	ctx->vsp=local+38;
	w=(pointer)MINUS(ctx,2,local+36); /*-*/
	local[36]= w;
	local[37]= makeflt(8.9999999999999991118216e-01);
	local[38]= local[8];
	ctx->vsp=local+39;
	w=(pointer)TIMES(ctx,2,local+37); /***/
	local[37]= w;
	ctx->vsp=local+38;
	w=(pointer)QUOTIENT(ctx,2,local+36); /*/*/
	local[36]= w;
	goto irtmodelCON1904;
irtmodelCON1907:
	local[36]= makeflt(0.0000000000000000000000e+00);
	goto irtmodelCON1904;
irtmodelCON1908:
	local[36]= NIL;
irtmodelCON1904:
	local[32] = local[36];
	if (local[25]==NIL) goto irtmodelIF1909;
	local[36]= fqv[202];
	w = local[25];
	if (memq(local[36],w)!=NIL) goto irtmodelIF1909;
	local[36]= loadglobal(fqv[5]);
	local[37]= (pointer)get_sym_func(fqv[49]);
	local[38]= local[31];
	ctx->vsp=local+39;
	w=(pointer)MAP(ctx,3,local+36); /*map*/
	local[36]= w;
	local[37]= fqv[367];
	ctx->vsp=local+38;
	w=(*ftab[33])(ctx,2,local+36,&ftab[33],fqv[233]); /*format-array*/
	local[36]= fqv[368];
	local[37]= local[32];
	ctx->vsp=local+38;
	w=(*ftab[2])(ctx,2,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= w;
	goto irtmodelIF1910;
irtmodelIF1909:
	local[36]= NIL;
irtmodelIF1910:
	goto irtmodelIF1902;
irtmodelIF1901:
	local[36]= NIL;
irtmodelIF1902:
	local[36]= argv[0];
	local[37]= fqv[369];
	local[38]= local[2];
	local[39]= fqv[357];
	local[40]= local[1];
	local[41]= fqv[370];
	local[42]= local[6];
	local[43]= fqv[340];
	local[44]= local[25];
	local[45]= fqv[334];
	local[46]= local[12];
	local[47]= fqv[333];
	local[48]= local[13];
	local[49]= fqv[331];
	local[50]= local[14];
	local[51]= fqv[371];
	local[52]= local[16];
	local[53]= fqv[332];
	local[54]= NIL;
	local[55]= fqv[372];
	local[56]= local[15];
	local[57]= fqv[273];
	local[58]= local[4];
	local[59]= fqv[355];
	local[60]= local[3];
	local[61]= fqv[373];
	local[62]= local[5];
	local[63]= fqv[374];
	local[64]= local[22];
	local[65]= fqv[375];
	local[66]= local[18];
	ctx->vsp=local+67;
	w=(pointer)SEND(ctx,31,local+36); /*send*/
	local[22] = w;
	local[36]= argv[0];
	local[37]= fqv[184];
	local[38]= fqv[302];
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,3,local+36); /*send*/
	if (w==NIL) goto irtmodelIF1911;
	local[36]= local[22];
	local[37]= argv[0];
	local[38]= fqv[184];
	local[39]= fqv[302];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,3,local+37); /*send*/
	local[37]= w;
	local[38]= local[22];
	ctx->vsp=local+39;
	w=(pointer)VPLUS(ctx,3,local+36); /*v+*/
	local[36]= w;
	goto irtmodelIF1912;
irtmodelIF1911:
	local[36]= NIL;
irtmodelIF1912:
	local[36]= (pointer)get_sym_func(fqv[34]);
	local[37]= argv[0];
	local[38]= loadglobal(fqv[376]);
	local[39]= fqv[377];
	local[40]= argv[2];
	local[41]= fqv[357];
	local[42]= local[1];
	local[43]= fqv[373];
	local[44]= local[22];
	local[45]= fqv[378];
	local[46]= local[31];
	local[47]= fqv[379];
	local[48]= local[32];
	local[49]= fqv[273];
	local[50]= local[4];
	local[51]= fqv[380];
	local[52]= local[34];
	local[53]= fqv[381];
	local[54]= local[35];
	local[55]= local[0];
	ctx->vsp=local+56;
	w=(pointer)APPLY(ctx,20,local+36); /*apply*/
	w = T;
	local[0]= w;
irtmodelBLK1840:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics-args*/
static pointer irtmodelM1913cascaded_link_inverse_kinematics_args(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1915:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[382], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1916;
	local[1] = NIL;
irtmodelKEY1916:
	if (n & (1<<1)) goto irtmodelKEY1917;
	local[2] = NIL;
irtmodelKEY1917:
	if (n & (1<<2)) goto irtmodelKEY1918;
	local[3] = NIL;
irtmodelKEY1918:
	if (n & (1<<3)) goto irtmodelKEY1919;
	local[4] = NIL;
irtmodelKEY1919:
	local[5]= argv[0];
	local[6]= fqv[211];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[210];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[23])(ctx,2,local+7,&ftab[23],fqv[166]); /*make-matrix*/
	local[7]= w;
	local[8]= local[5];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[23])(ctx,2,local+8,&ftab[23],fqv[166]); /*make-matrix*/
	local[8]= w;
	local[9]= local[5];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[23])(ctx,2,local+9,&ftab[23],fqv[166]); /*make-matrix*/
	local[9]= w;
	local[10]= local[5];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(*ftab[23])(ctx,2,local+10,&ftab[23],fqv[166]); /*make-matrix*/
	local[10]= w;
	local[11]= local[6];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,2,local+11,&ftab[23],fqv[166]); /*make-matrix*/
	local[11]= w;
	local[12]= local[6];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[23])(ctx,2,local+12,&ftab[23],fqv[166]); /*make-matrix*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(*ftab[23])(ctx,2,local+13,&ftab[23],fqv[166]); /*make-matrix*/
	local[13]= w;
	local[14]= local[5];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(*ftab[23])(ctx,2,local+14,&ftab[23],fqv[166]); /*make-matrix*/
	local[14]= w;
	local[15]= local[5];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[23])(ctx,2,local+15,&ftab[23],fqv[166]); /*make-matrix*/
	local[15]= w;
	local[16]= local[6];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(*ftab[23])(ctx,2,local+16,&ftab[23],fqv[166]); /*make-matrix*/
	local[16]= w;
	local[17]= local[6];
	local[18]= local[5];
	ctx->vsp=local+19;
	w=(*ftab[23])(ctx,2,local+17,&ftab[23],fqv[166]); /*make-matrix*/
	local[17]= w;
	local[18]= loadglobal(fqv[5]);
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[18]= w;
	local[19]= loadglobal(fqv[5]);
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(pointer)INSTANTIATE(ctx,2,local+19); /*instantiate*/
	local[19]= w;
	local[20]= loadglobal(fqv[5]);
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)INSTANTIATE(ctx,2,local+20); /*instantiate*/
	local[20]= w;
	local[21]= loadglobal(fqv[5]);
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(pointer)INSTANTIATE(ctx,2,local+21); /*instantiate*/
	local[21]= w;
	local[22]= loadglobal(fqv[5]);
	local[23]= makeint((eusinteger_t)3L);
	ctx->vsp=local+24;
	w=(pointer)INSTANTIATE(ctx,2,local+22); /*instantiate*/
	local[22]= w;
	local[23]= loadglobal(fqv[5]);
	local[24]= makeint((eusinteger_t)3L);
	ctx->vsp=local+25;
	w=(pointer)INSTANTIATE(ctx,2,local+23); /*instantiate*/
	local[23]= w;
	local[24]= loadglobal(fqv[5]);
	local[25]= makeint((eusinteger_t)3L);
	ctx->vsp=local+26;
	w=(pointer)INSTANTIATE(ctx,2,local+24); /*instantiate*/
	local[24]= w;
	local[25]= makeint((eusinteger_t)3L);
	local[26]= makeint((eusinteger_t)3L);
	ctx->vsp=local+27;
	w=(*ftab[23])(ctx,2,local+25,&ftab[23],fqv[166]); /*make-matrix*/
	local[25]= w;
	local[26]= loadglobal(fqv[5]);
	local[27]= local[6];
	ctx->vsp=local+28;
	w=(pointer)INSTANTIATE(ctx,2,local+26); /*instantiate*/
	local[26]= w;
	local[27]= NIL;
	local[28]= loadglobal(fqv[5]);
	local[29]= local[5];
	ctx->vsp=local+30;
	w=(pointer)INSTANTIATE(ctx,2,local+28); /*instantiate*/
	local[28]= w;
	local[29]= loadglobal(fqv[5]);
	local[30]= local[5];
	ctx->vsp=local+31;
	w=(pointer)INSTANTIATE(ctx,2,local+29); /*instantiate*/
	local[29]= w;
	local[30]= loadglobal(fqv[5]);
	local[31]= makeint((eusinteger_t)3L);
	ctx->vsp=local+32;
	w=(pointer)INSTANTIATE(ctx,2,local+30); /*instantiate*/
	local[30]= w;
	local[31]= loadglobal(fqv[5]);
	local[32]= makeint((eusinteger_t)3L);
	ctx->vsp=local+33;
	w=(pointer)INSTANTIATE(ctx,2,local+31); /*instantiate*/
	local[31]= w;
	local[32]= makeint((eusinteger_t)0L);
	local[33]= local[2];
	ctx->vsp=local+34;
	w=(pointer)LENGTH(ctx,1,local+33); /*length*/
	local[33]= w;
irtmodelWHL1920:
	local[34]= local[32];
	w = local[33];
	if ((eusinteger_t)local[34] >= (eusinteger_t)w) goto irtmodelWHX1921;
	local[34]= loadglobal(fqv[5]);
	local[35]= argv[0];
	local[36]= fqv[210];
	local[37]= local[2];
	local[38]= local[32];
	ctx->vsp=local+39;
	w=(pointer)ELT(ctx,2,local+37); /*elt*/
	local[37]= w;
	local[38]= local[3];
	local[39]= local[32];
	ctx->vsp=local+40;
	w=(pointer)ELT(ctx,2,local+38); /*elt*/
	local[38]= w;
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,4,local+35); /*send*/
	local[35]= w;
	ctx->vsp=local+36;
	w=(pointer)INSTANTIATE(ctx,2,local+34); /*instantiate*/
	local[34]= w;
	w = local[27];
	ctx->vsp=local+35;
	local[27] = cons(ctx,local[34],w);
	local[34]= local[32];
	ctx->vsp=local+35;
	w=(pointer)ADD1(ctx,1,local+34); /*1+*/
	local[32] = w;
	goto irtmodelWHL1920;
irtmodelWHX1921:
	local[34]= NIL;
irtmodelBLK1922:
	w = NIL;
	local[32]= local[27];
	ctx->vsp=local+33;
	w=(pointer)NREVERSE(ctx,1,local+32); /*nreverse*/
	local[32]= fqv[383];
	local[33]= local[6];
	local[34]= fqv[355];
	local[35]= local[5];
	local[36]= fqv[272];
	local[37]= local[7];
	local[38]= fqv[261];
	local[39]= local[8];
	local[40]= fqv[262];
	local[41]= local[9];
	local[42]= fqv[263];
	local[43]= local[10];
	local[44]= fqv[264];
	local[45]= local[11];
	local[46]= fqv[265];
	local[47]= local[12];
	local[48]= fqv[266];
	local[49]= local[13];
	local[50]= fqv[267];
	local[51]= local[14];
	local[52]= fqv[268];
	local[53]= local[15];
	local[54]= fqv[270];
	local[55]= local[16];
	local[56]= fqv[269];
	local[57]= local[17];
	local[58]= fqv[274];
	local[59]= local[18];
	local[60]= fqv[275];
	local[61]= local[19];
	local[62]= fqv[276];
	local[63]= local[20];
	local[64]= fqv[277];
	local[65]= local[21];
	local[66]= fqv[278];
	local[67]= local[22];
	local[68]= fqv[279];
	local[69]= local[23];
	local[70]= fqv[280];
	local[71]= local[24];
	local[72]= fqv[281];
	local[73]= local[25];
	local[74]= fqv[282];
	local[75]= local[26];
	local[76]= fqv[384];
	local[77]= local[27];
	local[78]= fqv[283];
	local[79]= local[28];
	local[80]= fqv[284];
	local[81]= local[29];
	local[82]= fqv[285];
	local[83]= local[30];
	local[84]= fqv[286];
	local[85]= local[31];
	ctx->vsp=local+86;
	w=(pointer)LIST(ctx,54,local+32); /*list*/
	local[0]= w;
irtmodelBLK1914:
	ctx->vsp=local; return(local[0]);}

/*:draw-collision-debug-view*/
static pointer irtmodelM1923cascaded_link_draw_collision_debug_view(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[184];
	local[2]= fqv[290];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto irtmodelIF1925;
	local[0]= loadglobal(fqv[385]);
	local[1]= fqv[386];
	local[2]= fqv[387];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[385]);
	local[2]= fqv[386];
	local[3]= fqv[388];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= loadglobal(fqv[385]);
	local[3]= fqv[386];
	local[4]= fqv[189];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[184];
	local[5]= fqv[290];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[184];
	local[6]= fqv[252];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= NIL;
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[189];
	local[9]= fqv[389];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[387];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[388];
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
irtmodelWHL1927:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX1928;
	local[8]= argv[0];
	local[9]= fqv[184];
	local[10]= fqv[252];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[5] = w;
	if (local[5]!=NIL) goto irtmodelIF1930;
	local[8]= fqv[390];
	local[9]= local[3];
	local[10]= fqv[3];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[128]); /*send-all*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,2,local+8,&ftab[2],fqv[15]); /*warn*/
	w = NIL;
	ctx->vsp=local+8;
	local[8]=w;
	goto irtmodelBLK1929;
	goto irtmodelIF1931;
irtmodelIF1930:
	local[8]= NIL;
irtmodelIF1931:
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[189];
	local[11]= fqv[391];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[387];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[388];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[392];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[393];
	local[13]= T;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[392];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[393];
	local[13]= T;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[394];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= fqv[393];
	local[14]= T;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,7,local+8); /*send*/
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= makeint((eusinteger_t)200L);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtmodelIF1932;
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[387];
	local[11]= makeint((eusinteger_t)4L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[388];
	local[11]= makeint((eusinteger_t)6L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	goto irtmodelIF1933;
irtmodelIF1932:
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[387];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[388];
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
irtmodelIF1933:
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[189];
	local[11]= local[4];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelIF1934;
	local[11]= fqv[395];
	goto irtmodelIF1935;
irtmodelIF1934:
	local[11]= fqv[396];
irtmodelIF1935:
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[394];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= fqv[393];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,7,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[392];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[393];
	local[13]= NIL;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[392];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[393];
	local[13]= NIL;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)LSEQP(ctx,2,local+8); /*<=*/
	if (w==NIL) goto irtmodelIF1936;
	local[8]= NIL;
	local[9]= local[3];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[38])(ctx,1,local+10,&ftab[38],fqv[291]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
irtmodelWHL1938:
	if (local[9]==NIL) goto irtmodelWHX1939;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= loadglobal(fqv[213]);
	ctx->vsp=local+12;
	w=(pointer)DERIVEDP(ctx,2,local+10); /*derivedp*/
	if (w==NIL) goto irtmodelIF1941;
	local[10]= local[8];
	local[11]= fqv[149];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	if (fqv[120]!=local[10]) goto irtmodelIF1941;
	local[10]= *(ovafptr(local[8],fqv[397]));
	local[11]= fqv[122];
	ctx->vsp=local+12;
	w=(*ftab[18])(ctx,2,local+10,&ftab[18],fqv[128]); /*send-all*/
	local[10]= w;
	goto irtmodelIF1942;
irtmodelIF1941:
	local[10]= NIL;
irtmodelIF1942:
	local[10]= local[8];
	local[11]= loadglobal(fqv[213]);
	ctx->vsp=local+12;
	w=(pointer)DERIVEDP(ctx,2,local+10); /*derivedp*/
	if (w==NIL) goto irtmodelIF1943;
	local[10]= NIL;
	local[11]= local[8];
	local[12]= fqv[127];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
irtmodelWHL1945:
	if (local[11]==NIL) goto irtmodelWHX1946;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= NIL;
	local[13]= local[10];
	local[14]= fqv[398];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
irtmodelWHL1948:
	if (local[13]==NIL) goto irtmodelWHX1949;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= loadglobal(fqv[385]);
	local[15]= fqv[386];
	local[16]= fqv[394];
	local[17]= *(ovafptr(local[12],fqv[399]));
	local[18]= *(ovafptr(local[12],fqv[400]));
	local[19]= fqv[393];
	local[20]= T;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,7,local+14); /*send*/
	goto irtmodelWHL1948;
irtmodelWHX1949:
	local[14]= NIL;
irtmodelBLK1950:
	w = NIL;
	goto irtmodelWHL1945;
irtmodelWHX1946:
	local[12]= NIL;
irtmodelBLK1947:
	w = NIL;
	local[10]= w;
	goto irtmodelIF1944;
irtmodelIF1943:
	local[10]= NIL;
	local[11]= local[8];
	local[12]= fqv[398];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
irtmodelWHL1951:
	if (local[11]==NIL) goto irtmodelWHX1952;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= loadglobal(fqv[385]);
	local[13]= fqv[386];
	local[14]= fqv[394];
	local[15]= *(ovafptr(local[10],fqv[399]));
	local[16]= *(ovafptr(local[10],fqv[400]));
	local[17]= fqv[393];
	local[18]= T;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,7,local+12); /*send*/
	goto irtmodelWHL1951;
irtmodelWHX1952:
	local[12]= NIL;
irtmodelBLK1953:
	w = NIL;
	local[10]= w;
irtmodelIF1944:
	goto irtmodelWHL1938;
irtmodelWHX1939:
	local[10]= NIL;
irtmodelBLK1940:
	w = NIL;
	local[8]= w;
	goto irtmodelIF1937;
irtmodelIF1936:
	local[8]= NIL;
irtmodelIF1937:
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL1927;
irtmodelWHX1928:
	local[8]= NIL;
irtmodelBLK1929:
	w = NIL;
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[387];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[388];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[189];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[0]= w;
	goto irtmodelIF1926;
irtmodelIF1925:
	local[0]= NIL;
irtmodelIF1926:
	w = local[0];
	local[0]= w;
irtmodelBLK1924:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics-loop*/
static pointer irtmodelM1954cascaded_link_inverse_kinematics_loop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtmodelRST1956:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[401], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1957;
	local[1] = makeint((eusinteger_t)1L);
irtmodelKEY1957:
	if (n & (1<<1)) goto irtmodelKEY1958;
	local[2] = makeint((eusinteger_t)0L);
irtmodelKEY1958:
	if (n & (1<<2)) goto irtmodelKEY1959;
	local[3] = NIL;
irtmodelKEY1959:
	if (n & (1<<3)) goto irtmodelKEY1960;
	local[4] = NIL;
irtmodelKEY1960:
	if (n & (1<<4)) goto irtmodelKEY1961;
	w = local[4];
	if (!!iscons(w)) goto irtmodelCON1963;
	local[26]= T;
	goto irtmodelCON1962;
irtmodelCON1963:
	local[26]= local[4];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	local[27]= fqv[209];
	local[28]= T;
	ctx->vsp=local+29;
	w=(*ftab[31])(ctx,3,local+26,&ftab[31],fqv[208]); /*make-list*/
	local[26]= w;
	goto irtmodelCON1962;
irtmodelCON1964:
	local[26]= NIL;
irtmodelCON1962:
	local[5] = local[26];
irtmodelKEY1961:
	if (n & (1<<5)) goto irtmodelKEY1965;
	w = local[4];
	if (!!iscons(w)) goto irtmodelCON1967;
	local[26]= T;
	goto irtmodelCON1966;
irtmodelCON1967:
	local[26]= local[4];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	local[27]= fqv[209];
	local[28]= T;
	ctx->vsp=local+29;
	w=(*ftab[31])(ctx,3,local+26,&ftab[31],fqv[208]); /*make-list*/
	local[26]= w;
	goto irtmodelCON1966;
irtmodelCON1968:
	local[26]= NIL;
irtmodelCON1966:
	local[6] = local[26];
irtmodelKEY1965:
	if (n & (1<<6)) goto irtmodelKEY1969;
	w = local[4];
	if (!!iscons(w)) goto irtmodelCON1971;
	local[26]= makeint((eusinteger_t)1L);
	goto irtmodelCON1970;
irtmodelCON1971:
	local[26]= local[4];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	local[27]= fqv[209];
	local[28]= makeint((eusinteger_t)1L);
	ctx->vsp=local+29;
	w=(*ftab[31])(ctx,3,local+26,&ftab[31],fqv[208]); /*make-list*/
	local[26]= w;
	goto irtmodelCON1970;
irtmodelCON1972:
	local[26]= NIL;
irtmodelCON1970:
	local[7] = local[26];
irtmodelKEY1969:
	if (n & (1<<7)) goto irtmodelKEY1973;
	w = local[4];
	if (!!iscons(w)) goto irtmodelCON1975;
	local[26]= makeint((eusinteger_t)1L);
	ctx->vsp=local+27;
	w=(*ftab[6])(ctx,1,local+26,&ftab[6],fqv[48]); /*deg2rad*/
	local[26]= w;
	goto irtmodelCON1974;
irtmodelCON1975:
	local[26]= local[4];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	local[27]= fqv[209];
	local[28]= makeint((eusinteger_t)1L);
	ctx->vsp=local+29;
	w=(*ftab[6])(ctx,1,local+28,&ftab[6],fqv[48]); /*deg2rad*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(*ftab[31])(ctx,3,local+26,&ftab[31],fqv[208]); /*make-list*/
	local[26]= w;
	goto irtmodelCON1974;
irtmodelCON1976:
	local[26]= NIL;
irtmodelCON1974:
	local[8] = local[26];
irtmodelKEY1973:
	if (n & (1<<8)) goto irtmodelKEY1977;
	local[9] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1977:
	if (n & (1<<9)) goto irtmodelKEY1978;
	local[10] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1978:
	if (n & (1<<10)) goto irtmodelKEY1979;
	local[11] = NIL;
irtmodelKEY1979:
	if (n & (1<<11)) goto irtmodelKEY1980;
	local[12] = NIL;
irtmodelKEY1980:
	if (n & (1<<12)) goto irtmodelKEY1981;
	local[13] = NIL;
irtmodelKEY1981:
	if (n & (1<<13)) goto irtmodelKEY1982;
	local[14] = NIL;
irtmodelKEY1982:
	if (n & (1<<14)) goto irtmodelKEY1983;
	local[15] = NIL;
irtmodelKEY1983:
	if (n & (1<<15)) goto irtmodelKEY1984;
	local[16] = NIL;
irtmodelKEY1984:
	if (n & (1<<16)) goto irtmodelKEY1985;
	local[17] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1985:
	if (n & (1<<17)) goto irtmodelKEY1986;
	local[18] = NIL;
irtmodelKEY1986:
	if (n & (1<<18)) goto irtmodelKEY1987;
	local[19] = NIL;
irtmodelKEY1987:
	if (n & (1<<19)) goto irtmodelKEY1988;
	local[20] = fqv[33];
irtmodelKEY1988:
	if (n & (1<<20)) goto irtmodelKEY1989;
	local[21] = NIL;
irtmodelKEY1989:
	if (n & (1<<21)) goto irtmodelKEY1990;
	local[22] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1990:
	if (n & (1<<22)) goto irtmodelKEY1991;
	local[26]= local[1];
	local[27]= makeint((eusinteger_t)10L);
	ctx->vsp=local+28;
	w=(pointer)QUOTIENT(ctx,2,local+26); /*/*/
	local[23] = w;
irtmodelKEY1991:
	if (n & (1<<23)) goto irtmodelKEY1992;
	local[24] = NIL;
irtmodelKEY1992:
	if (n & (1<<24)) goto irtmodelKEY1993;
	local[25] = NIL;
irtmodelKEY1993:
	if (local[18]==NIL) goto irtmodelIF1994;
	local[26]= argv[0];
	local[27]= fqv[332];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	goto irtmodelIF1995;
irtmodelIF1994:
	local[26]= NIL;
irtmodelIF1995:
	local[26]= NIL;
	local[27]= NIL;
	local[28]= makeint((eusinteger_t)0L);
	local[29]= T;
	local[30]= local[0];
	local[31]= local[25];
	ctx->vsp=local+32;
	w=(pointer)NCONC(ctx,2,local+30); /*nconc*/
	local[30]= w;
	local[31]= fqv[402];
	w = local[0];
	w=memq(local[31],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[31]= (w)->c.cons.car;
	local[32]= fqv[403];
	w = local[0];
	w=memq(local[32],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[32]= (w)->c.cons.car;
	if (local[11]!=NIL) goto irtmodelIF1996;
	local[33]= argv[0];
	local[34]= fqv[197];
	local[35]= local[3];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[11] = w;
	local[33]= local[11];
	ctx->vsp=local+34;
	w=(pointer)LENGTH(ctx,1,local+33); /*length*/
	local[33]= w;
	local[34]= local[3];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(*ftab[24])(ctx,2,local+33,&ftab[24],fqv[171]); /*/=*/
	if (w==NIL) goto irtmodelIF1998;
	local[33]= argv[0];
	local[34]= fqv[404];
	local[35]= local[11];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[33]= w;
	goto irtmodelIF1999;
irtmodelIF1998:
	local[33]= NIL;
irtmodelIF1999:
	goto irtmodelIF1997;
irtmodelIF1996:
	local[33]= NIL;
irtmodelIF1997:
	if (local[24]==NIL) goto irtmodelIF2000;
	w = local[24];
	if (!!iscons(w)) goto irtmodelIF2000;
	local[33]= local[24];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[24] = w;
	local[33]= local[24];
	goto irtmodelIF2001;
irtmodelIF2000:
	local[33]= NIL;
irtmodelIF2001:
	if (local[24]==NIL) goto irtmodelIF2002;
	local[33]= local[24];
	local[34]= fqv[405];
	ctx->vsp=local+35;
	w=(pointer)EQUAL(ctx,2,local+33); /*equal*/
	if (w!=NIL) goto irtmodelIF2002;
	if (loadglobal(fqv[385])==NIL) goto irtmodelIF2002;
	local[33]= loadglobal(fqv[385]);
	local[34]= fqv[386];
	local[35]= fqv[406];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[33]= w;
	goto irtmodelIF2003;
irtmodelIF2002:
	local[33]= NIL;
irtmodelIF2003:
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF2004;
	local[33]= local[3];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[3] = w;
	local[33]= local[3];
	goto irtmodelIF2005;
irtmodelIF2004:
	local[33]= NIL;
irtmodelIF2005:
	w = local[4];
	if (!!iscons(w)) goto irtmodelIF2006;
	local[33]= local[4];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[4] = w;
	local[33]= local[4];
	goto irtmodelIF2007;
irtmodelIF2006:
	local[33]= NIL;
irtmodelIF2007:
	w = local[12];
	if (!iscons(w)) goto irtmodelOR2010;
	local[33]= local[12];
	ctx->vsp=local+34;
	w=(*ftab[43])(ctx,1,local+33,&ftab[43],fqv[320]); /*functionp*/
	if (w!=NIL) goto irtmodelOR2010;
	goto irtmodelIF2008;
irtmodelOR2010:
	local[33]= local[12];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[12] = w;
	local[33]= local[12];
	goto irtmodelIF2009;
irtmodelIF2008:
	local[33]= NIL;
irtmodelIF2009:
	w = argv[2];
	if (!!iscons(w)) goto irtmodelIF2011;
	local[33]= argv[2];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	argv[2] = w;
	local[33]= argv[2];
	goto irtmodelIF2012;
irtmodelIF2011:
	local[33]= NIL;
irtmodelIF2012:
	w = argv[3];
	if (!!iscons(w)) goto irtmodelIF2013;
	local[33]= argv[3];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	argv[3] = w;
	local[33]= argv[3];
	goto irtmodelIF2014;
irtmodelIF2013:
	local[33]= NIL;
irtmodelIF2014:
	w = local[5];
	if (!!iscons(w)) goto irtmodelIF2015;
	local[33]= local[5];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[5] = w;
	local[33]= local[5];
	goto irtmodelIF2016;
irtmodelIF2015:
	local[33]= NIL;
irtmodelIF2016:
	w = local[6];
	if (!!iscons(w)) goto irtmodelIF2017;
	local[33]= local[6];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[6] = w;
	local[33]= local[6];
	goto irtmodelIF2018;
irtmodelIF2017:
	local[33]= NIL;
irtmodelIF2018:
	w = local[7];
	if (!!iscons(w)) goto irtmodelIF2019;
	local[33]= local[7];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[7] = w;
	local[33]= local[7];
	goto irtmodelIF2020;
irtmodelIF2019:
	local[33]= NIL;
irtmodelIF2020:
	w = local[8];
	if (!!iscons(w)) goto irtmodelIF2021;
	local[33]= local[8];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[8] = w;
	local[33]= local[8];
	goto irtmodelIF2022;
irtmodelIF2021:
	local[33]= NIL;
irtmodelIF2022:
	local[33]= local[6];
	ctx->vsp=local+34;
	w=(pointer)LENGTH(ctx,1,local+33); /*length*/
	local[33]= w;
	local[34]= local[5];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
	local[35]= local[4];
	ctx->vsp=local+36;
	w=(pointer)LENGTH(ctx,1,local+35); /*length*/
	local[35]= w;
	local[36]= local[3];
	ctx->vsp=local+37;
	w=(pointer)LENGTH(ctx,1,local+36); /*length*/
	local[36]= w;
	local[37]= argv[2];
	ctx->vsp=local+38;
	w=(pointer)LENGTH(ctx,1,local+37); /*length*/
	local[37]= w;
	local[38]= argv[3];
	ctx->vsp=local+39;
	w=(pointer)LENGTH(ctx,1,local+38); /*length*/
	local[38]= w;
	local[39]= local[7];
	ctx->vsp=local+40;
	w=(pointer)LENGTH(ctx,1,local+39); /*length*/
	local[39]= w;
	local[40]= local[8];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(pointer)NUMEQUAL(ctx,8,local+33); /*=*/
	if (w!=NIL) goto irtmodelIF2023;
	local[33]= fqv[407];
	local[34]= local[6];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
	local[35]= local[5];
	ctx->vsp=local+36;
	w=(pointer)LENGTH(ctx,1,local+35); /*length*/
	local[35]= w;
	local[36]= local[4];
	ctx->vsp=local+37;
	w=(pointer)LENGTH(ctx,1,local+36); /*length*/
	local[36]= w;
	local[37]= local[3];
	ctx->vsp=local+38;
	w=(pointer)LENGTH(ctx,1,local+37); /*length*/
	local[37]= w;
	local[38]= argv[2];
	ctx->vsp=local+39;
	w=(pointer)LENGTH(ctx,1,local+38); /*length*/
	local[38]= w;
	local[39]= argv[3];
	ctx->vsp=local+40;
	w=(pointer)LENGTH(ctx,1,local+39); /*length*/
	local[39]= w;
	local[40]= local[7];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	local[41]= local[8];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,9,local+33,&ftab[2],fqv[15]); /*warn*/
	w = fqv[408];
	ctx->vsp=local+33;
	local[0]=w;
	goto irtmodelBLK1955;
	goto irtmodelIF2024;
irtmodelIF2023:
	local[33]= NIL;
irtmodelIF2024:
	local[33]= fqv[384];
	w = local[25];
	if (memq(local[33],w)==NIL) goto irtmodelIF2025;
	local[33]= fqv[384];
	w = local[25];
	w=memq(local[33],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[27] = (w)->c.cons.car;
	local[33]= local[27];
	goto irtmodelIF2026;
irtmodelIF2025:
	local[33]= makeint((eusinteger_t)0L);
	local[34]= local[5];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
irtmodelWHL2027:
	local[35]= local[33];
	w = local[34];
	if ((eusinteger_t)local[35] >= (eusinteger_t)w) goto irtmodelWHX2028;
	local[35]= loadglobal(fqv[5]);
	local[36]= argv[0];
	local[37]= fqv[210];
	local[38]= local[5];
	local[39]= local[33];
	ctx->vsp=local+40;
	w=(pointer)ELT(ctx,2,local+38); /*elt*/
	local[38]= w;
	local[39]= local[6];
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,4,local+36); /*send*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)INSTANTIATE(ctx,2,local+35); /*instantiate*/
	local[35]= w;
	w = local[27];
	ctx->vsp=local+36;
	local[27] = cons(ctx,local[35],w);
	local[35]= local[33];
	ctx->vsp=local+36;
	w=(pointer)ADD1(ctx,1,local+35); /*1+*/
	local[33] = w;
	goto irtmodelWHL2027;
irtmodelWHX2028:
	local[35]= NIL;
irtmodelBLK2029:
	w = NIL;
	local[33]= local[27];
	ctx->vsp=local+34;
	w=(pointer)NREVERSE(ctx,1,local+33); /*nreverse*/
	local[27] = w;
	local[33]= local[27];
irtmodelIF2026:
	local[33]= fqv[282];
	w = local[25];
	if (memq(local[33],w)==NIL) goto irtmodelIF2030;
	local[33]= fqv[282];
	w = local[25];
	w=memq(local[33],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26] = (w)->c.cons.car;
	local[33]= local[26];
	goto irtmodelIF2031;
irtmodelIF2030:
	local[33]= loadglobal(fqv[5]);
	local[34]= argv[0];
	local[35]= fqv[210];
	local[36]= local[5];
	local[37]= local[6];
	ctx->vsp=local+38;
	w=(pointer)SEND(ctx,4,local+34); /*send*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)INSTANTIATE(ctx,2,local+33); /*instantiate*/
	local[26] = w;
	local[33]= local[26];
irtmodelIF2031:
	local[33]= local[13];
	ctx->vsp=local+34;
	w=(*ftab[43])(ctx,1,local+33,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2032;
	local[33]= local[13];
	local[34]= local[3];
	local[35]= local[4];
	local[36]= local[6];
	local[37]= local[5];
	ctx->vsp=local+38;
	w=(pointer)FUNCALL(ctx,5,local+33); /*funcall*/
	local[13] = w;
	local[33]= local[13];
	goto irtmodelIF2033;
irtmodelIF2032:
	local[33]= NIL;
irtmodelIF2033:
	if (local[13]!=NIL) goto irtmodelIF2034;
	local[33]= (pointer)get_sym_func(fqv[288]);
	local[34]= argv[0];
	local[35]= fqv[299];
	local[36]= local[3];
	local[37]= fqv[335];
	local[38]= local[6];
	local[39]= fqv[409];
	local[40]= local[5];
	local[41]= fqv[300];
	local[42]= local[4];
	local[43]= local[30];
	ctx->vsp=local+44;
	w=(pointer)APPLY(ctx,11,local+33); /*apply*/
	local[13] = w;
	local[33]= local[13];
	goto irtmodelIF2035;
irtmodelIF2034:
	local[33]= NIL;
irtmodelIF2035:
	if (local[24]==NIL) goto irtmodelIF2036;
	local[33]= fqv[202];
	w = local[24];
	if (memq(local[33],w)!=NIL) goto irtmodelIF2036;
	local[33]= fqv[410];
	local[34]= local[2];
	ctx->vsp=local+35;
	w=(*ftab[2])(ctx,2,local+33,&ftab[2],fqv[15]); /*warn*/
	local[33]= fqv[411];
	local[34]= local[11];
	local[35]= fqv[3];
	ctx->vsp=local+36;
	w=(*ftab[18])(ctx,2,local+34,&ftab[18],fqv[128]); /*send-all*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(*ftab[2])(ctx,2,local+33,&ftab[2],fqv[15]); /*warn*/
	local[33]= fqv[412];
	local[34]= local[4];
	ctx->vsp=local+35;
	w=(*ftab[2])(ctx,2,local+33,&ftab[2],fqv[15]); /*warn*/
	local[33]= fqv[413];
	local[34]= local[12];
	ctx->vsp=local+35;
	w=(*ftab[2])(ctx,2,local+33,&ftab[2],fqv[15]); /*warn*/
	local[33]= w;
	goto irtmodelIF2037;
irtmodelIF2036:
	local[33]= NIL;
irtmodelIF2037:
	local[33]= argv[0];
	local[34]= fqv[414];
	if (local[23]==NIL) goto irtmodelIF2038;
	local[35]= local[2];
	local[36]= local[23];
	ctx->vsp=local+37;
	w=(pointer)GREQP(ctx,2,local+35); /*>=*/
	local[35]= w;
	goto irtmodelIF2039;
irtmodelIF2038:
	local[35]= T;
irtmodelIF2039:
	local[36]= argv[2];
	local[37]= argv[3];
	local[38]= local[5];
	local[39]= local[6];
	local[40]= local[7];
	local[41]= local[8];
	local[42]= local[17];
	local[43]= local[18];
	local[44]= local[19];
	local[45]= local[20];
	local[46]= fqv[332];
	local[47]= NIL;
	ctx->vsp=local+48;
	w=(pointer)SEND(ctx,15,local+33); /*send*/
	local[29] = w;
	if (local[14]==NIL) goto irtmodelIF2040;
	local[33]= local[29];
	if (local[33]==NIL) goto irtmodelAND2042;
	local[33]= local[14];
	ctx->vsp=local+34;
	w=(pointer)FUNCALL(ctx,1,local+33); /*funcall*/
	local[33]= w;
irtmodelAND2042:
	local[29] = local[33];
	local[33]= local[29];
	goto irtmodelIF2041;
irtmodelIF2040:
	local[33]= NIL;
irtmodelIF2041:
	local[33]= makeint((eusinteger_t)0L);
	local[34]= local[4];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
irtmodelWHL2043:
	local[35]= local[33];
	w = local[34];
	if ((eusinteger_t)local[35] >= (eusinteger_t)w) goto irtmodelWHX2044;
	local[35]= local[27];
	local[36]= local[33];
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= (pointer)get_sym_func(fqv[288]);
	local[37]= argv[0];
	local[38]= fqv[415];
	local[39]= argv[2];
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[39]= w;
	local[40]= local[6];
	local[41]= local[33];
	ctx->vsp=local+42;
	w=(pointer)ELT(ctx,2,local+40); /*elt*/
	local[40]= w;
	if (local[31]==NIL) goto irtmodelIF2046;
	local[41]= fqv[402];
	local[42]= local[31];
	ctx->vsp=local+43;
	w=(pointer)LIST(ctx,2,local+41); /*list*/
	local[41]= w;
	goto irtmodelIF2047;
irtmodelIF2046:
	local[41]= NIL;
irtmodelIF2047:
	ctx->vsp=local+42;
	w=(pointer)APPLY(ctx,6,local+36); /*apply*/
	local[36]= w;
	local[37]= (pointer)get_sym_func(fqv[288]);
	local[38]= argv[0];
	local[39]= fqv[416];
	local[40]= argv[3];
	local[41]= local[33];
	ctx->vsp=local+42;
	w=(pointer)ELT(ctx,2,local+40); /*elt*/
	local[40]= w;
	local[41]= local[5];
	local[42]= local[33];
	ctx->vsp=local+43;
	w=(pointer)ELT(ctx,2,local+41); /*elt*/
	local[41]= w;
	if (local[32]==NIL) goto irtmodelIF2048;
	local[42]= fqv[403];
	local[43]= local[32];
	ctx->vsp=local+44;
	w=(pointer)LIST(ctx,2,local+42); /*list*/
	local[42]= w;
	goto irtmodelIF2049;
irtmodelIF2048:
	local[42]= NIL;
irtmodelIF2049:
	ctx->vsp=local+43;
	w=(pointer)APPLY(ctx,6,local+37); /*apply*/
	local[37]= w;
	if (local[24]==NIL) goto irtmodelIF2050;
	local[38]= fqv[202];
	w = local[24];
	if (memq(local[38],w)!=NIL) goto irtmodelIF2050;
	local[38]= makeflt(1.0000000000000000000000e+03);
	local[39]= local[36];
	ctx->vsp=local+40;
	w=(pointer)SCALEVEC(ctx,2,local+38); /*scale*/
	local[38]= w;
	local[39]= fqv[417];
	ctx->vsp=local+40;
	w=(*ftab[33])(ctx,2,local+38,&ftab[33],fqv[233]); /*format-array*/
	local[38]= local[37];
	local[39]= fqv[418];
	ctx->vsp=local+40;
	w=(*ftab[33])(ctx,2,local+38,&ftab[33],fqv[233]); /*format-array*/
	local[38]= fqv[419];
	local[39]= makeflt(1.0000000000000000000000e+03);
	local[40]= local[36];
	ctx->vsp=local+41;
	w=(pointer)VNORM(ctx,1,local+40); /*norm*/
	{ double x,y;
		y=fltval(w); x=fltval(local[39]);
		local[39]=(makeflt(x * y));}
	local[40]= local[7];
	local[41]= local[33];
	ctx->vsp=local+42;
	w=(pointer)ELT(ctx,2,local+40); /*elt*/
	local[40]= w;
	local[41]= local[37];
	ctx->vsp=local+42;
	w=(pointer)VNORM(ctx,1,local+41); /*norm*/
	local[41]= w;
	local[42]= local[8];
	local[43]= local[33];
	ctx->vsp=local+44;
	w=(pointer)ELT(ctx,2,local+42); /*elt*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,5,local+38,&ftab[2],fqv[15]); /*warn*/
	local[38]= w;
	goto irtmodelIF2051;
irtmodelIF2050:
	local[38]= NIL;
irtmodelIF2051:
	local[38]= makeint((eusinteger_t)0L);
	local[39]= local[36];
	ctx->vsp=local+40;
	w=(pointer)LENGTH(ctx,1,local+39); /*length*/
	local[39]= w;
irtmodelWHL2052:
	local[40]= local[38];
	w = local[39];
	if ((eusinteger_t)local[40] >= (eusinteger_t)w) goto irtmodelWHX2053;
	local[40]= local[35];
	local[41]= local[38];
	local[42]= local[9];
	local[43]= local[36];
	local[44]= local[38];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)TIMES(ctx,2,local+42); /***/
	local[42]= w;
	ctx->vsp=local+43;
	w=(pointer)SETELT(ctx,3,local+40); /*setelt*/
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)ADD1(ctx,1,local+40); /*1+*/
	local[38] = w;
	goto irtmodelWHL2052;
irtmodelWHX2053:
	local[40]= NIL;
irtmodelBLK2054:
	w = NIL;
	local[38]= makeint((eusinteger_t)0L);
	local[39]= local[37];
	ctx->vsp=local+40;
	w=(pointer)LENGTH(ctx,1,local+39); /*length*/
	local[39]= w;
irtmodelWHL2055:
	local[40]= local[38];
	w = local[39];
	if ((eusinteger_t)local[40] >= (eusinteger_t)w) goto irtmodelWHX2056;
	local[40]= local[35];
	local[41]= local[38];
	local[42]= local[36];
	ctx->vsp=local+43;
	w=(pointer)LENGTH(ctx,1,local+42); /*length*/
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[41]= (pointer)((eusinteger_t)local[41] + (eusinteger_t)w);
	local[42]= local[10];
	local[43]= local[37];
	local[44]= local[38];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)TIMES(ctx,2,local+42); /***/
	local[42]= w;
	ctx->vsp=local+43;
	w=(pointer)SETELT(ctx,3,local+40); /*setelt*/
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)ADD1(ctx,1,local+40); /*1+*/
	local[38] = w;
	goto irtmodelWHL2055;
irtmodelWHX2056:
	local[40]= NIL;
irtmodelBLK2057:
	w = NIL;
	local[38]= argv[0];
	local[39]= fqv[184];
	local[40]= fqv[420];
	ctx->vsp=local+41;
	w=(pointer)SEND(ctx,3,local+38); /*send*/
	if (w==NIL) goto irtmodelIF2058;
	local[38]= NIL;
	local[39]= fqv[421];
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)XFORMAT(ctx,3,local+38); /*format*/
	local[38]= w;
	ctx->vsp=local+39;
	w=(*ftab[45])(ctx,1,local+38,&ftab[45],fqv[422]); /*read-from-string*/
	local[38]= w;
	local[39]= argv[0];
	local[40]= fqv[184];
	local[41]= fqv[420];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,3,local+39); /*send*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(*ftab[41])(ctx,2,local+38,&ftab[41],fqv[314]); /*assoc*/
	local[38]= w;
	local[39]= local[36];
	local[40]= local[37];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,2,local+39); /*list*/
	local[39]= w;
	local[40]= NIL;
	local[41]= fqv[423];
	local[42]= local[33];
	ctx->vsp=local+43;
	w=(pointer)XFORMAT(ctx,3,local+40); /*format*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(*ftab[45])(ctx,1,local+40,&ftab[45],fqv[422]); /*read-from-string*/
	local[40]= w;
	local[41]= argv[0];
	local[42]= fqv[184];
	local[43]= fqv[420];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,3,local+41); /*send*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[41])(ctx,2,local+40,&ftab[41],fqv[314]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+40;
	local[39]= cons(ctx,local[39],w);
	ctx->vsp=local+40;
	w=(pointer)RPLACD2(ctx,2,local+38); /*rplacd2*/
	local[38]= w;
	goto irtmodelIF2059;
irtmodelIF2058:
	local[38]= NIL;
irtmodelIF2059:
	w = local[38];
	local[35]= local[33];
	ctx->vsp=local+36;
	w=(pointer)ADD1(ctx,1,local+35); /*1+*/
	local[33] = w;
	goto irtmodelWHL2043;
irtmodelWHX2044:
	local[35]= NIL;
irtmodelBLK2045:
	w = NIL;
	local[33]= makeint((eusinteger_t)0L);
	local[34]= local[27];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
irtmodelWHL2060:
	local[35]= local[33];
	w = local[34];
	if ((eusinteger_t)local[35] >= (eusinteger_t)w) goto irtmodelWHX2061;
	local[35]= makeint((eusinteger_t)0L);
	local[36]= local[27];
	local[37]= local[33];
	ctx->vsp=local+38;
	w=(pointer)ELT(ctx,2,local+36); /*elt*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)LENGTH(ctx,1,local+36); /*length*/
	local[36]= w;
irtmodelWHL2063:
	local[37]= local[35];
	w = local[36];
	if ((eusinteger_t)local[37] >= (eusinteger_t)w) goto irtmodelWHX2064;
	local[37]= local[26];
	local[38]= local[35];
	local[39]= local[28];
	ctx->vsp=local+40;
	w=(pointer)PLUS(ctx,2,local+38); /*+*/
	local[38]= w;
	local[39]= local[27];
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[39]= w;
	local[40]= local[35];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(pointer)SETELT(ctx,3,local+37); /*setelt*/
	local[37]= local[35];
	ctx->vsp=local+38;
	w=(pointer)ADD1(ctx,1,local+37); /*1+*/
	local[35] = w;
	goto irtmodelWHL2063;
irtmodelWHX2064:
	local[37]= NIL;
irtmodelBLK2065:
	w = NIL;
	local[35]= local[28];
	local[36]= local[27];
	local[37]= local[33];
	ctx->vsp=local+38;
	w=(pointer)ELT(ctx,2,local+36); /*elt*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)LENGTH(ctx,1,local+36); /*length*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)PLUS(ctx,2,local+35); /*+*/
	local[28] = w;
	local[35]= local[33];
	ctx->vsp=local+36;
	w=(pointer)ADD1(ctx,1,local+35); /*1+*/
	local[33] = w;
	goto irtmodelWHL2060;
irtmodelWHX2061:
	local[35]= NIL;
irtmodelBLK2062:
	w = NIL;
	if (local[21]!=NIL) goto irtmodelIF2066;
	if (local[18]==NIL) goto irtmodelIF2066;
	local[33]= argv[0];
	local[34]= fqv[424];
	local[35]= fqv[332];
	local[36]= NIL;
	local[37]= fqv[260];
	local[38]= local[11];
	local[39]= fqv[335];
	local[40]= local[20];
	ctx->vsp=local+41;
	w=(pointer)SEND(ctx,8,local+33); /*send*/
	local[33]= w;
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[33]= w;
	local[34]= local[15];
	ctx->vsp=local+35;
	w=(pointer)APPEND(ctx,2,local+33); /*append*/
	local[15] = w;
	local[33]= local[22];
	local[34]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+35;
	w=(pointer)GREATERP(ctx,2,local+33); /*>*/
	if (w==NIL) goto irtmodelIF2068;
	local[33]= makeflt(1.0000000000000000000000e+00);
	goto irtmodelIF2069;
irtmodelIF2068:
	local[33]= local[22];
irtmodelIF2069:
	local[34]= argv[0];
	local[35]= fqv[425];
	local[36]= local[33];
	local[37]= local[20];
	local[38]= local[18];
	local[39]= fqv[331];
	local[40]= local[19];
	local[41]= fqv[332];
	local[42]= NIL;
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,9,local+34); /*send*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)LIST(ctx,1,local+34); /*list*/
	local[34]= w;
	local[35]= local[16];
	ctx->vsp=local+36;
	w=(pointer)APPEND(ctx,2,local+34); /*append*/
	local[16] = w;
	local[34]= argv[0];
	local[35]= fqv[184];
	local[36]= fqv[420];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,3,local+34); /*send*/
	if (w==NIL) goto irtmodelIF2070;
	local[34]= fqv[257];
	local[35]= argv[0];
	local[36]= fqv[184];
	local[37]= fqv[420];
	ctx->vsp=local+38;
	w=(pointer)SEND(ctx,3,local+35); /*send*/
	local[35]= w;
	ctx->vsp=local+36;
	w=(*ftab[41])(ctx,2,local+34,&ftab[41],fqv[314]); /*assoc*/
	local[34]= w;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[35]= (w)->c.cons.car;
	local[36]= fqv[257];
	local[37]= argv[0];
	local[38]= fqv[184];
	local[39]= fqv[420];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,3,local+37); /*send*/
	local[37]= w;
	ctx->vsp=local+38;
	w=(*ftab[41])(ctx,2,local+36,&ftab[41],fqv[314]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+36;
	local[35]= cons(ctx,local[35],w);
	ctx->vsp=local+36;
	w=(pointer)RPLACD2(ctx,2,local+34); /*rplacd2*/
	local[34]= w;
	goto irtmodelIF2071;
irtmodelIF2070:
	local[34]= NIL;
irtmodelIF2071:
	w = local[34];
	local[33]= w;
	goto irtmodelIF2067;
irtmodelIF2066:
	local[33]= NIL;
irtmodelIF2067:
	local[33]= NIL;
	local[34]= NIL;
	local[35]= NIL;
	local[36]= NIL;
	if (local[15]==NIL) goto irtmodelIF2072;
	ctx->vsp=local+37;
	local[37]= makeclosure(codevec,quotevec,irtmodelCLO2074,env,argv,local);
	local[38]= local[16];
	ctx->vsp=local+39;
	w=(pointer)MAPCAR(ctx,2,local+37); /*mapcar*/
	local[33] = w;
	local[37]= local[26];
	ctx->vsp=local+38;
	w=(pointer)LENGTH(ctx,1,local+37); /*length*/
	local[37]= w;
	local[38]= (pointer)get_sym_func(fqv[322]);
	local[39]= (pointer)get_sym_func(fqv[426]);
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)MAPCAR(ctx,2,local+39); /*mapcar*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(*ftab[26])(ctx,2,local+38,&ftab[26],fqv[196]); /*reduce*/
	local[38]= w;
	ctx->vsp=local+39;
	w=(pointer)MINUS(ctx,2,local+37); /*-*/
	local[34] = w;
	local[37]= makeint((eusinteger_t)0L);
	local[38]= local[15];
	ctx->vsp=local+39;
	w=(pointer)LENGTH(ctx,1,local+38); /*length*/
	local[38]= w;
irtmodelWHL2075:
	local[39]= local[37];
	w = local[38];
	if ((eusinteger_t)local[39] >= (eusinteger_t)w) goto irtmodelWHX2076;
	local[39]= local[15];
	local[40]= local[37];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[36] = w;
	local[39]= local[36];
	ctx->vsp=local+40;
	w=(*ftab[43])(ctx,1,local+39,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2078;
	local[39]= local[36];
	local[40]= local[3];
	ctx->vsp=local+41;
	w=(pointer)FUNCALL(ctx,2,local+39); /*funcall*/
	local[39]= w;
	goto irtmodelIF2079;
irtmodelIF2078:
	local[39]= local[36];
irtmodelIF2079:
	local[36] = local[39];
	local[39]= local[33];
	local[40]= local[37];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[35] = w;
	local[39]= makeint((eusinteger_t)0L);
	local[40]= local[36];
	local[41]= makeint((eusinteger_t)0L);
	ctx->vsp=local+42;
	w=(*ftab[3])(ctx,2,local+40,&ftab[3],fqv[24]); /*array-dimension*/
	local[40]= w;
irtmodelWHL2080:
	local[41]= local[39];
	w = local[40];
	if ((eusinteger_t)local[41] >= (eusinteger_t)w) goto irtmodelWHX2081;
	local[41]= makeint((eusinteger_t)0L);
	local[42]= local[13];
	local[43]= makeint((eusinteger_t)1L);
	ctx->vsp=local+44;
	w=(*ftab[3])(ctx,2,local+42,&ftab[3],fqv[24]); /*array-dimension*/
	local[42]= w;
irtmodelWHL2083:
	local[43]= local[41];
	w = local[42];
	if ((eusinteger_t)local[43] >= (eusinteger_t)w) goto irtmodelWHX2084;
	local[43]= local[13];
	local[44]= local[34];
	local[45]= local[39];
	ctx->vsp=local+46;
	w=(pointer)PLUS(ctx,2,local+44); /*+*/
	local[44]= w;
	local[45]= local[41];
	local[46]= local[36];
	local[47]= local[39];
	local[48]= local[41];
	ctx->vsp=local+49;
	w=(pointer)AREF(ctx,3,local+46); /*aref*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)ASET(ctx,4,local+43); /*aset*/
	local[43]= local[41];
	ctx->vsp=local+44;
	w=(pointer)ADD1(ctx,1,local+43); /*1+*/
	local[41] = w;
	goto irtmodelWHL2083;
irtmodelWHX2084:
	local[43]= NIL;
irtmodelBLK2085:
	w = NIL;
	local[41]= local[26];
	local[42]= local[34];
	local[43]= local[39];
	ctx->vsp=local+44;
	w=(pointer)PLUS(ctx,2,local+42); /*+*/
	local[42]= w;
	local[43]= local[35];
	local[44]= local[39];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)SETELT(ctx,3,local+41); /*setelt*/
	local[41]= local[39];
	ctx->vsp=local+42;
	w=(pointer)ADD1(ctx,1,local+41); /*1+*/
	local[39] = w;
	goto irtmodelWHL2080;
irtmodelWHX2081:
	local[41]= NIL;
irtmodelBLK2082:
	w = NIL;
	local[39]= local[34];
	local[40]= local[35];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(pointer)PLUS(ctx,2,local+39); /*+*/
	local[34] = w;
	if (local[24]==NIL) goto irtmodelIF2086;
	local[39]= fqv[202];
	w = local[24];
	if (memq(local[39],w)!=NIL) goto irtmodelIF2086;
	local[39]= local[36];
	local[40]= NIL;
	local[41]= fqv[427];
	local[42]= local[37];
	ctx->vsp=local+43;
	w=(pointer)XFORMAT(ctx,3,local+40); /*format*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(*ftab[33])(ctx,2,local+39,&ftab[33],fqv[233]); /*format-array*/
	local[39]= local[35];
	local[40]= NIL;
	local[41]= fqv[428];
	local[42]= local[37];
	ctx->vsp=local+43;
	w=(pointer)XFORMAT(ctx,3,local+40); /*format*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(*ftab[33])(ctx,2,local+39,&ftab[33],fqv[233]); /*format-array*/
	local[39]= w;
	goto irtmodelIF2087;
irtmodelIF2086:
	local[39]= NIL;
irtmodelIF2087:
	local[39]= argv[0];
	local[40]= fqv[184];
	local[41]= fqv[420];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,3,local+39); /*send*/
	if (w==NIL) goto irtmodelIF2088;
	if (local[21]!=NIL) goto irtmodelIF2090;
	if (local[18]==NIL) goto irtmodelIF2090;
	local[39]= local[37];
	local[40]= makeint((eusinteger_t)0L);
	ctx->vsp=local+41;
	w=(*ftab[24])(ctx,2,local+39,&ftab[24],fqv[171]); /*/=*/
	if (w==NIL) goto irtmodelIF2090;
	local[39]= NIL;
	local[40]= fqv[429];
	local[41]= local[37];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[41]= (pointer)((eusinteger_t)local[41] - (eusinteger_t)w);
	ctx->vsp=local+42;
	w=(pointer)XFORMAT(ctx,3,local+39); /*format*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(*ftab[45])(ctx,1,local+39,&ftab[45],fqv[422]); /*read-from-string*/
	local[39]= w;
	local[40]= argv[0];
	local[41]= fqv[184];
	local[42]= fqv[420];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,3,local+40); /*send*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(*ftab[41])(ctx,2,local+39,&ftab[41],fqv[314]); /*assoc*/
	local[39]= w;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[40]= (w)->c.cons.car;
	local[41]= NIL;
	local[42]= fqv[430];
	local[43]= local[37];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[43]= (pointer)((eusinteger_t)local[43] - (eusinteger_t)w);
	ctx->vsp=local+44;
	w=(pointer)XFORMAT(ctx,3,local+41); /*format*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[45])(ctx,1,local+41,&ftab[45],fqv[422]); /*read-from-string*/
	local[41]= w;
	local[42]= argv[0];
	local[43]= fqv[184];
	local[44]= fqv[420];
	ctx->vsp=local+45;
	w=(pointer)SEND(ctx,3,local+42); /*send*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[41])(ctx,2,local+41,&ftab[41],fqv[314]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+41;
	local[40]= cons(ctx,local[40],w);
	ctx->vsp=local+41;
	w=(pointer)RPLACD2(ctx,2,local+39); /*rplacd2*/
	local[39]= w;
	goto irtmodelIF2091;
irtmodelIF2090:
	local[39]= NIL;
irtmodelIF2091:
	goto irtmodelIF2089;
irtmodelIF2088:
	local[39]= NIL;
irtmodelIF2089:
	local[39]= local[37];
	ctx->vsp=local+40;
	w=(pointer)ADD1(ctx,1,local+39); /*1+*/
	local[37] = w;
	goto irtmodelWHL2075;
irtmodelWHX2076:
	local[39]= NIL;
irtmodelBLK2077:
	w = NIL;
	local[37]= w;
	goto irtmodelIF2073;
irtmodelIF2072:
	local[37]= NIL;
irtmodelIF2073:
	w = local[37];
	if (local[29]==NIL) goto irtmodelIF2092;
	local[33]= argv[0];
	local[34]= fqv[150];
	local[35]= fqv[431];
	local[36]= NIL;
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,4,local+33); /*send*/
	local[33]= fqv[432];
	goto irtmodelIF2093;
irtmodelIF2092:
	if (local[24]==NIL) goto irtmodelIF2094;
	local[33]= fqv[405];
	w = local[24];
	if (memq(local[33],w)!=NIL) goto irtmodelIF2094;
	if (loadglobal(fqv[385])==NIL) goto irtmodelIF2094;
	local[33]= loadglobal(fqv[385]);
	local[34]= fqv[386];
	local[35]= fqv[406];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[33]= w;
	goto irtmodelIF2095;
irtmodelIF2094:
	local[33]= NIL;
irtmodelIF2095:
	local[33]= argv[0];
	local[34]= fqv[150];
	local[35]= fqv[290];
	local[36]= NIL;
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,4,local+33); /*send*/
	local[33]= (pointer)get_sym_func(fqv[34]);
	local[34]= argv[0];
	local[35]= loadglobal(fqv[376]);
	local[36]= fqv[433];
	local[37]= local[26];
	local[38]= fqv[357];
	local[39]= local[11];
	local[40]= fqv[409];
	local[41]= local[5];
	local[42]= fqv[335];
	local[43]= local[6];
	local[44]= fqv[434];
	local[45]= local[13];
	local[46]= fqv[340];
	local[47]= local[24];
	local[48]= local[30];
	ctx->vsp=local+49;
	w=(pointer)APPLY(ctx,16,local+33); /*apply*/
	if (local[24]==NIL) goto irtmodelIF2096;
	if (loadglobal(fqv[385])==NIL) goto irtmodelIF2096;
	local[33]= loadglobal(fqv[385]);
	local[34]= fqv[435];
	local[35]= fqv[406];
	local[36]= NIL;
	local[37]= fqv[190];
	local[38]= NIL;
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,6,local+33); /*send*/
	local[33]= argv[0];
	local[34]= fqv[436];
	ctx->vsp=local+35;
	w=(pointer)SEND(ctx,2,local+33); /*send*/
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto irtmodelIF2098;
	local[33]= makeint((eusinteger_t)0L);
	local[34]= local[12];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
irtmodelWHL2100:
	local[35]= local[33];
	w = local[34];
	if ((eusinteger_t)local[35] >= (eusinteger_t)w) goto irtmodelWHX2101;
	local[35]= local[4];
	local[36]= local[33];
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= loadglobal(fqv[437]);
	local[37]= fqv[438];
	local[38]= fqv[190];
	local[39]= NIL;
	local[40]= fqv[439];
	local[41]= makeint((eusinteger_t)100L);
	ctx->vsp=local+42;
	w=(pointer)SENDMESSAGE(ctx,7,local+35); /*send-message*/
	local[35]= local[12];
	local[36]= local[33];
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= fqv[438];
	local[37]= fqv[190];
	local[38]= NIL;
	local[39]= fqv[189];
	local[40]= fqv[440];
	ctx->vsp=local+41;
	w=(pointer)SEND(ctx,6,local+35); /*send*/
	local[35]= local[33];
	ctx->vsp=local+36;
	w=(pointer)ADD1(ctx,1,local+35); /*1+*/
	local[33] = w;
	goto irtmodelWHL2100;
irtmodelWHX2101:
	local[35]= NIL;
irtmodelBLK2102:
	w = NIL;
	local[33]= w;
	goto irtmodelIF2099;
irtmodelIF2098:
	local[33]= NIL;
irtmodelIF2099:
	local[33]= NIL;
	local[34]= argv[0];
	local[35]= fqv[184];
	local[36]= fqv[431];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,3,local+34); /*send*/
	local[34]= w;
irtmodelWHL2103:
	if (local[34]==NIL) goto irtmodelWHX2104;
	w=local[34];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[35]= (w)->c.cons.car;
	w=local[34];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[34] = (w)->c.cons.cdr;
	w = local[35];
	local[33] = w;
	local[35]= (pointer)get_sym_func(fqv[288]);
	w=local[33];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[36]= (w)->c.cons.car;
	local[37]= fqv[438];
	local[38]= fqv[190];
	local[39]= NIL;
	w=local[33];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[40]= (w)->c.cons.cdr;
	ctx->vsp=local+41;
	w=(pointer)APPLY(ctx,6,local+35); /*apply*/
	goto irtmodelWHL2103;
irtmodelWHX2104:
	local[35]= NIL;
irtmodelBLK2105:
	w = NIL;
	local[33]= fqv[441];
	w = local[24];
	if (memq(local[33],w)!=NIL) goto irtmodelIF2106;
	local[33]= loadglobal(fqv[385]);
	local[34]= fqv[386];
	local[35]= fqv[190];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[33]= w;
	goto irtmodelIF2107;
irtmodelIF2106:
	local[33]= NIL;
irtmodelIF2107:
	ctx->vsp=local+33;
	w=(*ftab[46])(ctx,0,local+33,&ftab[46],fqv[442]); /*x::window-main-one*/
	local[33]= w;
	goto irtmodelIF2097;
irtmodelIF2096:
	local[33]= NIL;
irtmodelIF2097:
	local[33]= argv[0];
	local[34]= fqv[150];
	local[35]= fqv[431];
	local[36]= NIL;
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,4,local+33); /*send*/
	local[33]= fqv[408];
irtmodelIF2093:
	w = local[33];
	local[0]= w;
irtmodelBLK1955:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics*/
static pointer irtmodelM2108cascaded_link_inverse_kinematics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST2110:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[443], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY2111;
	local[1] = makeint((eusinteger_t)50L);
irtmodelKEY2111:
	if (n & (1<<1)) goto irtmodelKEY2112;
	local[2] = NIL;
irtmodelKEY2112:
	if (n & (1<<2)) goto irtmodelKEY2113;
	local[3] = NIL;
irtmodelKEY2113:
	if (n & (1<<3)) goto irtmodelKEY2114;
	local[4] = NIL;
irtmodelKEY2114:
	if (n & (1<<4)) goto irtmodelKEY2115;
	local[5] = T;
irtmodelKEY2115:
	if (n & (1<<5)) goto irtmodelKEY2116;
	local[6] = T;
irtmodelKEY2116:
	if (n & (1<<6)) goto irtmodelKEY2117;
	w = local[3];
	if (!!iscons(w)) goto irtmodelCON2119;
	local[23]= T;
	goto irtmodelCON2118;
irtmodelCON2119:
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	local[24]= fqv[209];
	local[25]= T;
	ctx->vsp=local+26;
	w=(*ftab[31])(ctx,3,local+23,&ftab[31],fqv[208]); /*make-list*/
	local[23]= w;
	goto irtmodelCON2118;
irtmodelCON2120:
	local[23]= NIL;
irtmodelCON2118:
	local[7] = local[23];
irtmodelKEY2117:
	if (n & (1<<7)) goto irtmodelKEY2121;
	w = local[3];
	if (!!iscons(w)) goto irtmodelCON2123;
	local[23]= T;
	goto irtmodelCON2122;
irtmodelCON2123:
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	local[24]= fqv[209];
	local[25]= T;
	ctx->vsp=local+26;
	w=(*ftab[31])(ctx,3,local+23,&ftab[31],fqv[208]); /*make-list*/
	local[23]= w;
	goto irtmodelCON2122;
irtmodelCON2124:
	local[23]= NIL;
irtmodelCON2122:
	local[8] = local[23];
irtmodelKEY2121:
	if (n & (1<<8)) goto irtmodelKEY2125;
	local[9] = NIL;
irtmodelKEY2125:
	if (n & (1<<9)) goto irtmodelKEY2126;
	w = local[3];
	if (!!iscons(w)) goto irtmodelCON2128;
	local[23]= makeint((eusinteger_t)1L);
	goto irtmodelCON2127;
irtmodelCON2128:
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	local[24]= fqv[209];
	local[25]= makeint((eusinteger_t)1L);
	ctx->vsp=local+26;
	w=(*ftab[31])(ctx,3,local+23,&ftab[31],fqv[208]); /*make-list*/
	local[23]= w;
	goto irtmodelCON2127;
irtmodelCON2129:
	local[23]= NIL;
irtmodelCON2127:
	local[10] = local[23];
irtmodelKEY2126:
	if (n & (1<<10)) goto irtmodelKEY2130;
	w = local[3];
	if (!!iscons(w)) goto irtmodelCON2132;
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(*ftab[6])(ctx,1,local+23,&ftab[6],fqv[48]); /*deg2rad*/
	local[23]= w;
	goto irtmodelCON2131;
irtmodelCON2132:
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	local[24]= fqv[209];
	local[25]= makeint((eusinteger_t)1L);
	ctx->vsp=local+26;
	w=(*ftab[6])(ctx,1,local+25,&ftab[6],fqv[48]); /*deg2rad*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[31])(ctx,3,local+23,&ftab[31],fqv[208]); /*make-list*/
	local[23]= w;
	goto irtmodelCON2131;
irtmodelCON2133:
	local[23]= NIL;
irtmodelCON2131:
	local[11] = local[23];
irtmodelKEY2130:
	if (n & (1<<11)) goto irtmodelKEY2134;
	local[12] = NIL;
irtmodelKEY2134:
	if (n & (1<<12)) goto irtmodelKEY2135;
	local[13] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY2135:
	if (n & (1<<13)) goto irtmodelKEY2136;
	local[14] = NIL;
irtmodelKEY2136:
	if (n & (1<<14)) goto irtmodelKEY2137;
	local[15] = NIL;
irtmodelKEY2137:
	if (n & (1<<15)) goto irtmodelKEY2138;
	local[16] = fqv[33];
irtmodelKEY2138:
	if (n & (1<<16)) goto irtmodelKEY2139;
	local[17] = NIL;
irtmodelKEY2139:
	if (n & (1<<17)) goto irtmodelKEY2140;
	local[18] = fqv[444];
irtmodelKEY2140:
	if (n & (1<<18)) goto irtmodelKEY2141;
	local[19] = makeflt(5.0000000000000000000000e-01);
irtmodelKEY2141:
	if (n & (1<<19)) goto irtmodelKEY2142;
	local[20] = NIL;
irtmodelKEY2142:
	if (n & (1<<20)) goto irtmodelKEY2143;
	local[21] = NIL;
irtmodelKEY2143:
	if (n & (1<<21)) goto irtmodelKEY2144;
	local[22] = NIL;
irtmodelKEY2144:
	w = argv[2];
	if (!iscons(w)) goto irtmodelOR2147;
	local[23]= argv[2];
	ctx->vsp=local+24;
	w=(*ftab[43])(ctx,1,local+23,&ftab[43],fqv[320]); /*functionp*/
	if (w!=NIL) goto irtmodelOR2147;
	goto irtmodelIF2145;
irtmodelOR2147:
	local[23]= argv[2];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	argv[2] = w;
	local[23]= argv[2];
	goto irtmodelIF2146;
irtmodelIF2145:
	local[23]= NIL;
irtmodelIF2146:
	local[23]= makeint((eusinteger_t)0L);
	local[24]= local[12];
	ctx->vsp=local+25;
	w=(*ftab[43])(ctx,1,local+24,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2148;
	local[24]= local[12];
	local[25]= local[2];
	ctx->vsp=local+26;
	w=(pointer)FUNCALL(ctx,2,local+24); /*funcall*/
	local[24]= w;
	goto irtmodelIF2149;
irtmodelIF2148:
	local[24]= argv[0];
	local[25]= fqv[197];
	local[26]= local[2];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
irtmodelIF2149:
	local[25]= local[24];
	local[26]= fqv[198];
	ctx->vsp=local+27;
	w=(*ftab[18])(ctx,2,local+25,&ftab[18],fqv[128]); /*send-all*/
	local[25]= w;
	local[26]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+27;
	w=(pointer)APPEND(ctx,2,local+25); /*append*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[47])(ctx,1,local+25,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[25]= w;
	local[26]= fqv[20];
	ctx->vsp=local+27;
	w=(*ftab[18])(ctx,2,local+25,&ftab[18],fqv[128]); /*send-all*/
	local[25]= w;
	local[26]= argv[0];
	local[27]= fqv[214];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	if (w!=NIL) goto irtmodelIF2150;
	local[26]= argv[0];
	local[27]= fqv[153];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	goto irtmodelIF2151;
irtmodelIF2150:
	local[26]= NIL;
irtmodelIF2151:
	local[27]= argv[2];
	local[28]= NIL;
	local[29]= NIL;
	local[30]= T;
	local[31]= local[24];
	local[32]= fqv[149];
	ctx->vsp=local+33;
	w=(*ftab[18])(ctx,2,local+31,&ftab[18],fqv[128]); /*send-all*/
	local[31]= w;
	local[32]= NIL;
	local[33]= NIL;
	local[34]= NIL;
	local[35]= NIL;
	local[36]= NIL;
	local[37]= NIL;
	local[38]= NIL;
	local[39]= NIL;
	local[40]= local[24];
	local[41]= fqv[149];
	local[42]= fqv[120];
	ctx->vsp=local+43;
	w=(*ftab[18])(ctx,3,local+40,&ftab[18],fqv[128]); /*send-all*/
	if (local[2]==NIL) goto irtmodelOR2154;
	if (local[3]==NIL) goto irtmodelOR2154;
	goto irtmodelIF2152;
irtmodelOR2154:
	local[40]= fqv[446];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,1,local+40,&ftab[2],fqv[15]); /*warn*/
	w = T;
	ctx->vsp=local+40;
	local[0]=w;
	goto irtmodelBLK2109;
	goto irtmodelIF2153;
irtmodelIF2152:
	local[40]= NIL;
irtmodelIF2153:
	if (local[8]!=NIL) goto irtmodelIF2155;
	if (local[7]!=NIL) goto irtmodelIF2155;
	w = T;
	ctx->vsp=local+40;
	local[0]=w;
	goto irtmodelBLK2109;
	goto irtmodelIF2156;
irtmodelIF2155:
	local[40]= NIL;
irtmodelIF2156:
	if (local[18]==NIL) goto irtmodelIF2157;
	local[40]= NIL;
	local[41]= fqv[447];
	if (local[30]==NIL) goto irtmodelIF2159;
	local[42]= fqv[448];
	goto irtmodelIF2160;
irtmodelIF2159:
	local[42]= fqv[449];
irtmodelIF2160:
	local[43]= fqv[450];
	ctx->vsp=local+44;
	w=(pointer)LOCALTIME(ctx,0,local+44); /*unix:localtime*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)ASCTIME(ctx,1,local+44); /*unix:asctime*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(*ftab[48])(ctx,2,local+43,&ftab[48],fqv[451]); /*string-trim*/
	local[43]= w;
	local[44]= loadglobal(fqv[452]);
	ctx->vsp=local+45;
	w=(pointer)XFORMAT(ctx,5,local+40); /*format*/
	local[39] = w;
	local[40]= NIL;
	local[41]= fqv[453];
	local[42]= local[39];
	local[43]= local[2];
	ctx->vsp=local+44;
	w=(pointer)XFORMAT(ctx,4,local+40); /*format*/
	local[39] = w;
	local[40]= NIL;
	local[41]= fqv[454];
	local[42]= local[39];
	local[43]= local[3];
	ctx->vsp=local+44;
	w=(pointer)XFORMAT(ctx,4,local+40); /*format*/
	local[39] = w;
	local[40]= NIL;
	local[41]= fqv[455];
	local[42]= local[39];
	local[43]= local[7];
	local[44]= local[8];
	ctx->vsp=local+45;
	w=(pointer)XFORMAT(ctx,5,local+40); /*format*/
	local[39] = w;
	local[40]= NIL;
	local[41]= fqv[456];
	local[42]= local[39];
	local[43]= local[10];
	local[44]= local[11];
	local[45]= local[1];
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,6,local+40); /*format*/
	local[39] = w;
	local[40]= fqv[457];
	local[41]= fqv[458];
	local[42]= fqv[459];
	ctx->vsp=local+43;
	local[43]= makeclosure(codevec,quotevec,irtmodelCLO2161,env,argv,local);
	local[44]= argv[2];
	ctx->vsp=local+45;
	w=(pointer)MAPCAR(ctx,2,local+43); /*mapcar*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)LIST(ctx,1,local+43); /*list*/
	ctx->vsp=local+43;
	local[42]= cons(ctx,local[42],w);
	ctx->vsp=local+43;
	w=(pointer)LIST(ctx,1,local+42); /*list*/
	ctx->vsp=local+42;
	w = cons(ctx,local[41],w);
	ctx->vsp=local+41;
	local[37] = cons(ctx,local[40],w);
	local[40]= fqv[457];
	local[41]= fqv[460];
	local[42]= argv[0];
	local[43]= fqv[154];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,2,local+42); /*send*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(pointer)LIST(ctx,1,local+42); /*list*/
	ctx->vsp=local+42;
	w = cons(ctx,local[41],w);
	ctx->vsp=local+41;
	local[38] = cons(ctx,local[40],w);
	local[40]= local[38];
	goto irtmodelIF2158;
irtmodelIF2157:
	local[40]= NIL;
irtmodelIF2158:
	if (local[4]==NIL) goto irtmodelIF2162;
	w = local[4];
	if (!!iscons(w)) goto irtmodelIF2164;
	local[40]= local[4];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[4] = w;
	local[40]= local[4];
	goto irtmodelIF2165;
irtmodelIF2164:
	local[40]= NIL;
irtmodelIF2165:
	local[40]= fqv[405];
	w = local[4];
	if (memq(local[40],w)==NIL) goto irtmodelIF2166;
	local[40]= fqv[405];
	w = local[4];
	ctx->vsp=local+41;
	local[4] = cons(ctx,local[40],w);
	local[40]= local[4];
	goto irtmodelIF2167;
irtmodelIF2166:
	local[40]= NIL;
irtmodelIF2167:
	local[40]= fqv[441];
	w = local[4];
	if (memq(local[40],w)==NIL) goto irtmodelIF2168;
	local[40]= fqv[441];
	w = local[4];
	ctx->vsp=local+41;
	local[4] = cons(ctx,local[40],w);
	local[40]= local[4];
	goto irtmodelIF2169;
irtmodelIF2168:
	local[40]= NIL;
irtmodelIF2169:
	goto irtmodelIF2163;
irtmodelIF2162:
	local[40]= NIL;
irtmodelIF2163:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF2170;
	local[40]= local[2];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[2] = w;
	local[40]= local[2];
	goto irtmodelIF2171;
irtmodelIF2170:
	local[40]= NIL;
irtmodelIF2171:
	w = local[3];
	if (!!iscons(w)) goto irtmodelIF2172;
	local[40]= local[3];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[3] = w;
	local[40]= local[3];
	goto irtmodelIF2173;
irtmodelIF2172:
	local[40]= NIL;
irtmodelIF2173:
	w = local[7];
	if (!!iscons(w)) goto irtmodelIF2174;
	local[40]= local[7];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[7] = w;
	local[40]= local[7];
	goto irtmodelIF2175;
irtmodelIF2174:
	local[40]= NIL;
irtmodelIF2175:
	w = local[8];
	if (!!iscons(w)) goto irtmodelIF2176;
	local[40]= local[8];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[8] = w;
	local[40]= local[8];
	goto irtmodelIF2177;
irtmodelIF2176:
	local[40]= NIL;
irtmodelIF2177:
	w = local[10];
	if (!!iscons(w)) goto irtmodelIF2178;
	local[40]= local[10];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[10] = w;
	local[40]= local[10];
	goto irtmodelIF2179;
irtmodelIF2178:
	local[40]= NIL;
irtmodelIF2179:
	w = local[11];
	if (!!iscons(w)) goto irtmodelIF2180;
	local[40]= local[11];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[11] = w;
	local[40]= local[11];
	goto irtmodelIF2181;
irtmodelIF2180:
	local[40]= NIL;
irtmodelIF2181:
	if (local[21]==NIL) goto irtmodelIF2182;
	w = local[21];
	if (!iscons(w)) goto irtmodelOR2184;
	local[40]= local[21];
	ctx->vsp=local+41;
	w=(*ftab[43])(ctx,1,local+40,&ftab[43],fqv[320]); /*functionp*/
	if (w!=NIL) goto irtmodelOR2184;
	goto irtmodelIF2182;
irtmodelOR2184:
	local[40]= local[21];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[21] = w;
	local[40]= local[21];
	goto irtmodelIF2183;
irtmodelIF2182:
	local[40]= NIL;
irtmodelIF2183:
	if (local[22]==NIL) goto irtmodelIF2185;
	w = local[22];
	if (!iscons(w)) goto irtmodelOR2187;
	local[40]= local[22];
	ctx->vsp=local+41;
	w=(*ftab[43])(ctx,1,local+40,&ftab[43],fqv[320]); /*functionp*/
	if (w!=NIL) goto irtmodelOR2187;
	goto irtmodelIF2185;
irtmodelOR2187:
	local[40]= local[22];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[22] = w;
	local[40]= local[22];
	goto irtmodelIF2186;
irtmodelIF2185:
	local[40]= NIL;
irtmodelIF2186:
	local[40]= local[8];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	local[41]= local[7];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
	local[42]= local[3];
	ctx->vsp=local+43;
	w=(pointer)LENGTH(ctx,1,local+42); /*length*/
	local[42]= w;
	local[43]= local[2];
	ctx->vsp=local+44;
	w=(pointer)LENGTH(ctx,1,local+43); /*length*/
	local[43]= w;
	local[44]= argv[2];
	ctx->vsp=local+45;
	w=(pointer)LENGTH(ctx,1,local+44); /*length*/
	local[44]= w;
	local[45]= local[10];
	ctx->vsp=local+46;
	w=(pointer)LENGTH(ctx,1,local+45); /*length*/
	local[45]= w;
	local[46]= local[11];
	ctx->vsp=local+47;
	w=(pointer)LENGTH(ctx,1,local+46); /*length*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)NUMEQUAL(ctx,7,local+40); /*=*/
	if (w!=NIL) goto irtmodelIF2188;
	local[40]= fqv[461];
	local[41]= local[8];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
	local[42]= local[7];
	ctx->vsp=local+43;
	w=(pointer)LENGTH(ctx,1,local+42); /*length*/
	local[42]= w;
	local[43]= local[3];
	ctx->vsp=local+44;
	w=(pointer)LENGTH(ctx,1,local+43); /*length*/
	local[43]= w;
	local[44]= local[2];
	ctx->vsp=local+45;
	w=(pointer)LENGTH(ctx,1,local+44); /*length*/
	local[44]= w;
	local[45]= argv[2];
	ctx->vsp=local+46;
	w=(pointer)LENGTH(ctx,1,local+45); /*length*/
	local[45]= w;
	local[46]= local[10];
	ctx->vsp=local+47;
	w=(pointer)LENGTH(ctx,1,local+46); /*length*/
	local[46]= w;
	local[47]= local[11];
	ctx->vsp=local+48;
	w=(pointer)LENGTH(ctx,1,local+47); /*length*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(*ftab[2])(ctx,8,local+40,&ftab[2],fqv[15]); /*warn*/
	w = T;
	ctx->vsp=local+40;
	local[0]=w;
	goto irtmodelBLK2109;
	goto irtmodelIF2189;
irtmodelIF2188:
	local[40]= NIL;
irtmodelIF2189:
	local[40]= local[21];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	local[41]= local[22];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	if (w==local[40]) goto irtmodelIF2190;
	local[40]= fqv[462];
	local[41]= local[21];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
	local[42]= local[22];
	ctx->vsp=local+43;
	w=(pointer)LENGTH(ctx,1,local+42); /*length*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,3,local+40,&ftab[2],fqv[15]); /*warn*/
	w = T;
	ctx->vsp=local+40;
	local[0]=w;
	goto irtmodelBLK2109;
	goto irtmodelIF2191;
irtmodelIF2190:
	local[40]= NIL;
irtmodelIF2191:
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2192,env,argv,local);
	local[41]= local[21];
	ctx->vsp=local+42;
	w=(pointer)MAPCAR(ctx,2,local+40); /*mapcar*/
	local[40]= w;
	local[41]= (pointer)get_sym_func(fqv[288]);
	local[42]= argv[0];
	local[43]= fqv[463];
	local[44]= fqv[335];
	local[45]= local[8];
	local[46]= fqv[409];
	local[47]= local[7];
	local[48]= fqv[464];
	if (local[17]!=NIL) goto irtmodelIF2193;
	if (local[14]==NIL) goto irtmodelIF2193;
	local[49]= argv[0];
	local[50]= fqv[210];
	local[51]= NIL;
	local[52]= local[16];
	ctx->vsp=local+53;
	w=(pointer)SEND(ctx,4,local+49); /*send*/
	local[49]= w;
	goto irtmodelIF2194;
irtmodelIF2193:
	local[49]= makeint((eusinteger_t)0L);
irtmodelIF2194:
	local[50]= (pointer)get_sym_func(fqv[322]);
	ctx->vsp=local+51;
	local[51]= makeclosure(codevec,quotevec,irtmodelCLO2195,env,argv,local);
	local[52]= local[40];
	ctx->vsp=local+53;
	w=(pointer)MAPCAR(ctx,2,local+51); /*mapcar*/
	local[51]= w;
	ctx->vsp=local+52;
	w=(*ftab[26])(ctx,2,local+50,&ftab[26],fqv[196]); /*reduce*/
	local[50]= w;
	ctx->vsp=local+51;
	w=(pointer)PLUS(ctx,2,local+49); /*+*/
	local[49]= w;
	local[50]= fqv[357];
	local[51]= local[24];
	local[52]= local[0];
	ctx->vsp=local+53;
	w=(pointer)APPLY(ctx,12,local+41); /*apply*/
	local[41]= w;
	local[42]= local[0];
	ctx->vsp=local+43;
	w=(pointer)NCONC(ctx,2,local+41); /*nconc*/
	local[32] = w;
	w = local[32];
	local[40]= argv[0];
	local[41]= fqv[404];
	local[42]= local[24];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,3,local+40); /*send*/
	local[40]= local[18];
	w = fqv[465];
	if (memq(local[40],w)==NIL) goto irtmodelIF2196;
	local[40]= argv[0];
	local[41]= fqv[150];
	local[42]= fqv[420];
	local[43]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+44;
	local[44]= makeclosure(codevec,quotevec,irtmodelCLO2198,env,argv,local);
	local[45]= argv[2];
	ctx->vsp=local+46;
	w=(pointer)LENGTH(ctx,1,local+45); /*length*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(*ftab[31])(ctx,1,local+45,&ftab[31],fqv[208]); /*make-list*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)MAPCAR(ctx,2,local+44); /*mapcar*/
	local[43]= w;
	if (local[14]==NIL) goto irtmodelIF2199;
	local[44]= fqv[257];
	ctx->vsp=local+45;
	w=(pointer)LIST(ctx,1,local+44); /*list*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)LIST(ctx,1,local+44); /*list*/
	local[44]= w;
	goto irtmodelIF2200;
irtmodelIF2199:
	local[44]= NIL;
irtmodelIF2200:
	local[45]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+46;
	local[46]= makeclosure(codevec,quotevec,irtmodelCLO2201,env,argv,local);
	local[47]= local[22];
	ctx->vsp=local+48;
	w=(pointer)LENGTH(ctx,1,local+47); /*length*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(*ftab[31])(ctx,1,local+47,&ftab[31],fqv[208]); /*make-list*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(pointer)MAPCAR(ctx,2,local+46); /*mapcar*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)APPEND(ctx,3,local+43); /*append*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,4,local+40); /*send*/
	local[40]= w;
	goto irtmodelIF2197;
irtmodelIF2196:
	local[40]= NIL;
irtmodelIF2197:
irtmodelWHL2202:
	local[40]= local[23];
	ctx->vsp=local+41;
	w=(pointer)ADD1(ctx,1,local+40); /*1+*/
	local[23] = w;
	local[40]= local[23];
	local[41]= local[1];
	ctx->vsp=local+42;
	w=(pointer)LESSP(ctx,2,local+40); /*<*/
	if (w==NIL) goto irtmodelWHX2203;
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2205,env,argv,local);
	local[41]= argv[2];
	ctx->vsp=local+42;
	w=(pointer)MAPCAR(ctx,2,local+40); /*mapcar*/
	local[40]= w;
	ctx->vsp=local+41;
	local[41]= makeclosure(codevec,quotevec,irtmodelCLO2206,env,argv,local);
	local[42]= local[3];
	local[43]= local[40];
	local[44]= local[8];
	ctx->vsp=local+45;
	w=(pointer)MAPCAR(ctx,4,local+41); /*mapcar*/
	local[41]= w;
	ctx->vsp=local+42;
	local[42]= makeclosure(codevec,quotevec,irtmodelCLO2207,env,argv,local);
	local[43]= local[3];
	local[44]= local[40];
	local[45]= local[7];
	ctx->vsp=local+46;
	w=(pointer)MAPCAR(ctx,4,local+42); /*mapcar*/
	local[42]= w;
	local[43]= (pointer)get_sym_func(fqv[288]);
	local[44]= argv[0];
	local[45]= fqv[466];
	local[46]= local[41];
	local[47]= local[42];
	local[48]= fqv[467];
	local[49]= local[40];
	local[50]= fqv[468];
	local[51]= local[19];
	local[52]= fqv[469];
	local[53]= local[1];
	local[54]= fqv[470];
	local[55]= local[23];
	local[56]= fqv[409];
	local[57]= local[7];
	local[58]= fqv[335];
	local[59]= local[8];
	local[60]= fqv[300];
	local[61]= local[3];
	local[62]= fqv[357];
	local[63]= local[24];
	local[64]= fqv[471];
	local[65]= local[10];
	local[66]= fqv[472];
	local[67]= local[11];
	local[68]= fqv[473];
	local[69]= local[21];
	local[70]= fqv[474];
	local[71]= local[22];
	local[72]= fqv[340];
	local[73]= local[4];
	local[74]= fqv[475];
	local[75]= local[32];
	local[76]= local[0];
	ctx->vsp=local+77;
	w=(pointer)APPLY(ctx,34,local+43); /*apply*/
	local[30] = w;
	local[43]= local[30];
	if (fqv[432]!=local[43]) goto irtmodelIF2208;
	local[30] = T;
	w = NIL;
	ctx->vsp=local+43;
	local[40]=w;
	goto irtmodelBLK2204;
	goto irtmodelIF2209;
irtmodelIF2208:
	local[43]= NIL;
irtmodelIF2209:
	w = local[43];
	goto irtmodelWHL2202;
irtmodelWHX2203:
	local[40]= NIL;
irtmodelBLK2204:
	if (local[14]==NIL) goto irtmodelIF2210;
	local[40]= argv[0];
	local[41]= fqv[332];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,2,local+40); /*send*/
	local[40]= w;
	goto irtmodelIF2211;
irtmodelIF2210:
	local[40]= NIL;
irtmodelIF2211:
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2212,env,argv,local);
	local[41]= argv[2];
	ctx->vsp=local+42;
	w=(pointer)MAPCAR(ctx,2,local+40); /*mapcar*/
	local[40]= w;
	ctx->vsp=local+41;
	local[41]= makeclosure(codevec,quotevec,irtmodelCLO2213,env,argv,local);
	local[42]= local[3];
	local[43]= local[40];
	local[44]= local[8];
	ctx->vsp=local+45;
	w=(pointer)MAPCAR(ctx,4,local+41); /*mapcar*/
	local[28] = w;
	ctx->vsp=local+41;
	local[41]= makeclosure(codevec,quotevec,irtmodelCLO2214,env,argv,local);
	local[42]= local[3];
	local[43]= local[40];
	local[44]= local[7];
	ctx->vsp=local+45;
	w=(pointer)MAPCAR(ctx,4,local+41); /*mapcar*/
	local[29] = w;
	local[41]= argv[0];
	local[42]= fqv[414];
	local[43]= local[30];
	local[44]= local[28];
	local[45]= local[29];
	local[46]= local[7];
	local[47]= local[8];
	local[48]= local[10];
	local[49]= local[11];
	local[50]= local[13];
	local[51]= local[14];
	local[52]= local[15];
	local[53]= local[16];
	local[54]= fqv[332];
	local[55]= NIL;
	ctx->vsp=local+56;
	w=(pointer)SEND(ctx,15,local+41); /*send*/
	local[30] = w;
	w = local[30];
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2215,env,argv,local);
	local[41]= local[24];
	local[42]= local[31];
	ctx->vsp=local+43;
	w=(pointer)MAPCAR(ctx,3,local+40); /*mapcar*/
	local[40]= argv[0];
	local[41]= fqv[404];
	local[42]= local[24];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,3,local+40); /*send*/
	if (local[20]==NIL) goto irtmodelIF2216;
	local[40]= argv[0];
	local[41]= fqv[476];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,2,local+40); /*send*/
	local[33] = w;
	local[40]= local[33];
	goto irtmodelIF2217;
irtmodelIF2216:
	local[40]= NIL;
irtmodelIF2217:
	local[40]= local[30];
	if (local[40]!=NIL) goto irtmodelOR2219;
	local[40]= ((local[6])==NIL?T:NIL);
irtmodelOR2219:
	if (local[40]==NIL) goto irtmodelAND2218;
	local[40]= ((local[33])==NIL?T:NIL);
irtmodelAND2218:
	local[30] = local[40];
	local[40]= local[18];
	w = fqv[477];
	if (memq(local[40],w)!=NIL) goto irtmodelOR2222;
	local[40]= local[18];
	w = fqv[478];
	if (memq(local[40],w)==NIL) goto irtmodelAND2223;
	if (local[30]!=NIL) goto irtmodelAND2223;
	goto irtmodelOR2222;
irtmodelAND2223:
	goto irtmodelIF2220;
irtmodelOR2222:
	local[40]= NIL;
	local[41]= fqv[479];
	ctx->vsp=local+42;
	w=(pointer)GETPID(ctx,0,local+42); /*unix:getpid*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(pointer)XFORMAT(ctx,3,local+40); /*format*/
	local[34] = w;
	ctx->vsp=local+40;
	w=(pointer)LOCALTIME(ctx,0,local+40); /*unix:localtime*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(pointer)GETTIMEOFDAY(ctx,0,local+41); /*unix:gettimeofday*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[41]= (w)->c.cons.car;
	local[42]= makeint((eusinteger_t)48L);
	local[43]= makeint((eusinteger_t)32L);
	local[44]= NIL;
	local[45]= fqv[480];
	local[46]= argv[0];
	ctx->vsp=local+47;
	w=(pointer)GETCLASS(ctx,1,local+46); /*class*/
	local[46]= w;
	local[47]= fqv[3];
	ctx->vsp=local+48;
	w=(pointer)SEND(ctx,2,local+46); /*send*/
	local[46]= w;
	local[47]= makeint((eusinteger_t)1900L);
	local[48]= local[40];
	local[49]= makeint((eusinteger_t)5L);
	ctx->vsp=local+50;
	w=(pointer)ELT(ctx,2,local+48); /*elt*/
	local[48]= w;
	ctx->vsp=local+49;
	w=(pointer)PLUS(ctx,2,local+47); /*+*/
	local[47]= w;
	local[48]= makeint((eusinteger_t)1L);
	local[49]= local[40];
	local[50]= makeint((eusinteger_t)4L);
	ctx->vsp=local+51;
	w=(pointer)ELT(ctx,2,local+49); /*elt*/
	local[49]= w;
	ctx->vsp=local+50;
	w=(pointer)PLUS(ctx,2,local+48); /*+*/
	local[48]= w;
	local[49]= local[40];
	local[50]= makeint((eusinteger_t)3L);
	ctx->vsp=local+51;
	w=(pointer)ELT(ctx,2,local+49); /*elt*/
	local[49]= w;
	local[50]= local[40];
	local[51]= makeint((eusinteger_t)2L);
	ctx->vsp=local+52;
	w=(pointer)ELT(ctx,2,local+50); /*elt*/
	local[50]= w;
	local[51]= local[40];
	local[52]= makeint((eusinteger_t)1L);
	ctx->vsp=local+53;
	w=(pointer)ELT(ctx,2,local+51); /*elt*/
	local[51]= w;
	local[52]= local[40];
	local[53]= makeint((eusinteger_t)0L);
	ctx->vsp=local+54;
	w=(pointer)ELT(ctx,2,local+52); /*elt*/
	local[52]= w;
	local[53]= NIL;
	local[54]= fqv[481];
	local[55]= local[41];
	ctx->vsp=local+56;
	w=(pointer)XFORMAT(ctx,3,local+53); /*format*/
	local[53]= w;
	local[54]= makeint((eusinteger_t)0L);
	local[55]= makeint((eusinteger_t)2L);
	ctx->vsp=local+56;
	w=(pointer)SUBSEQ(ctx,3,local+53); /*subseq*/
	local[53]= w;
	local[54]= NIL;
	local[55]= fqv[482];
	local[56]= local[41];
	ctx->vsp=local+57;
	w=(pointer)XFORMAT(ctx,3,local+54); /*format*/
	local[54]= w;
	local[55]= makeint((eusinteger_t)2L);
	local[56]= makeint((eusinteger_t)4L);
	ctx->vsp=local+57;
	w=(pointer)SUBSEQ(ctx,3,local+54); /*subseq*/
	local[54]= w;
	local[55]= NIL;
	local[56]= fqv[483];
	local[57]= local[41];
	ctx->vsp=local+58;
	w=(pointer)XFORMAT(ctx,3,local+55); /*format*/
	local[55]= w;
	local[56]= makeint((eusinteger_t)4L);
	ctx->vsp=local+57;
	w=(pointer)SUBSEQ(ctx,2,local+55); /*subseq*/
	local[55]= w;
	ctx->vsp=local+56;
	w=(pointer)XFORMAT(ctx,12,local+44); /*format*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(*ftab[49])(ctx,3,local+42,&ftab[49],fqv[484]); /*substitute*/
	local[36] = w;
	local[40]= NIL;
	local[41]= fqv[485];
	local[42]= local[34];
	local[43]= local[36];
	if (local[30]==NIL) goto irtmodelIF2224;
	local[44]= fqv[486];
	goto irtmodelIF2225;
irtmodelIF2224:
	local[44]= fqv[487];
irtmodelIF2225:
	ctx->vsp=local+45;
	w=(pointer)XFORMAT(ctx,5,local+40); /*format*/
	local[35] = w;
	local[40]= local[34];
	ctx->vsp=local+41;
	w=(*ftab[50])(ctx,1,local+40,&ftab[50],fqv[488]); /*unix:mkdir*/
	local[40]= local[35];
	local[41]= fqv[178];
	local[42]= fqv[179];
	ctx->vsp=local+43;
	w=(*ftab[25])(ctx,3,local+40,&ftab[25],fqv[180]); /*open*/
	local[40]= w;
	ctx->vsp=local+41;
	w = makeclosure(codevec,quotevec,irtmodelUWP2226,env,argv,local);
	local[41]=(pointer)(ctx->protfp); local[42]=w;
	ctx->protfp=(struct protectframe *)(local+41);
	local[43]= local[40];
	local[44]= fqv[489];
	local[45]= local[39];
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,3,local+43); /*format*/
	local[43]= local[40];
	local[44]= local[37];
	ctx->vsp=local+45;
	w=(*ftab[51])(ctx,2,local+43,&ftab[51],fqv[490]); /*dump-structure*/
	local[43]= local[40];
	local[44]= local[38];
	ctx->vsp=local+45;
	w=(*ftab[51])(ctx,2,local+43,&ftab[51],fqv[490]); /*dump-structure*/
	ctx->vsp=local+43;
	irtmodelUWP2226(ctx,0,local+43,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[40]= local[18];
	w = fqv[491];
	if (memq(local[40],w)==NIL) goto irtmodelIF2227;
	local[40]= NIL;
	local[41]= fqv[492];
	local[42]= local[34];
	local[43]= local[36];
	if (local[30]==NIL) goto irtmodelIF2229;
	local[44]= fqv[493];
	goto irtmodelIF2230;
irtmodelIF2229:
	local[44]= fqv[494];
irtmodelIF2230:
	ctx->vsp=local+45;
	w=(pointer)XFORMAT(ctx,5,local+40); /*format*/
	local[40]= w;
	local[41]= fqv[178];
	local[42]= fqv[179];
	ctx->vsp=local+43;
	w=(*ftab[25])(ctx,3,local+40,&ftab[25],fqv[180]); /*open*/
	local[40]= w;
	ctx->vsp=local+41;
	w = makeclosure(codevec,quotevec,irtmodelUWP2231,env,argv,local);
	local[41]=(pointer)(ctx->protfp); local[42]=w;
	ctx->protfp=(struct protectframe *)(local+41);
	local[43]= local[40];
	local[44]= fqv[495];
	local[45]= local[23];
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,3,local+43); /*format*/
	local[43]= local[40];
	local[44]= fqv[496];
	ctx->vsp=local+45;
	local[45]= makeclosure(codevec,quotevec,irtmodelCLO2232,env,argv,local);
	local[46]= argv[0];
	local[47]= fqv[184];
	local[48]= fqv[420];
	ctx->vsp=local+49;
	w=(pointer)SEND(ctx,3,local+46); /*send*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)MAPCAR(ctx,2,local+45); /*mapcar*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,3,local+43); /*format*/
	local[43]= local[40];
	local[44]= fqv[497];
	local[45]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+46;
	local[46]= makeclosure(codevec,quotevec,irtmodelCLO2233,env,argv,local);
	local[47]= local[10];
	local[48]= local[11];
	ctx->vsp=local+49;
	w=(pointer)MAPCAR(ctx,3,local+46); /*mapcar*/
	local[45]= w;
	if (local[14]==NIL) goto irtmodelIF2234;
	local[46]= fqv[257];
	local[47]= makeflt(1.0000000000000000208167e-03);
	local[48]= local[13];
	ctx->vsp=local+49;
	w=(pointer)TIMES(ctx,2,local+47); /***/
	local[47]= w;
	ctx->vsp=local+48;
	w=(pointer)LIST(ctx,2,local+46); /*list*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)LIST(ctx,1,local+46); /*list*/
	local[46]= w;
	goto irtmodelIF2235;
irtmodelIF2234:
	local[46]= NIL;
irtmodelIF2235:
	ctx->vsp=local+47;
	w=(pointer)APPEND(ctx,2,local+45); /*append*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,3,local+43); /*format*/
	local[43]= argv[0];
	local[44]= fqv[420];
	ctx->vsp=local+45;
	w=(*ftab[52])(ctx,2,local+43,&ftab[52],fqv[498]); /*remprop*/
	ctx->vsp=local+43;
	irtmodelUWP2231(ctx,0,local+43,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[40]= w;
	goto irtmodelIF2228;
irtmodelIF2227:
	local[40]= NIL;
irtmodelIF2228:
	goto irtmodelIF2221;
irtmodelIF2220:
	local[40]= NIL;
irtmodelIF2221:
	if (local[30]==NIL) goto irtmodelIF2236;
	local[40]= argv[0];
	local[41]= fqv[154];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,2,local+40); /*send*/
	local[40]= w;
	goto irtmodelIF2237;
irtmodelIF2236:
	if (local[5]==NIL) goto irtmodelIF2238;
	local[40]= fqv[499];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,1,local+40,&ftab[2],fqv[15]); /*warn*/
	local[40]= makeint((eusinteger_t)0L);
	local[41]= local[3];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
irtmodelWHL2240:
	local[42]= local[40];
	w = local[41];
	if ((eusinteger_t)local[42] >= (eusinteger_t)w) goto irtmodelWHX2241;
	local[42]= fqv[500];
	local[43]= local[28];
	local[44]= local[40];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	local[44]= local[28];
	local[45]= local[40];
	ctx->vsp=local+46;
	w=(pointer)ELT(ctx,2,local+44); /*elt*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)VNORM(ctx,1,local+44); /*norm*/
	local[44]= w;
	local[45]= local[10];
	local[46]= local[40];
	ctx->vsp=local+47;
	w=(pointer)ELT(ctx,2,local+45); /*elt*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(*ftab[2])(ctx,4,local+42,&ftab[2],fqv[15]); /*warn*/
	local[42]= fqv[501];
	local[43]= local[29];
	local[44]= local[40];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	local[44]= local[29];
	local[45]= local[40];
	ctx->vsp=local+46;
	w=(pointer)ELT(ctx,2,local+44); /*elt*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)VNORM(ctx,1,local+44); /*norm*/
	local[44]= w;
	local[45]= local[11];
	local[46]= local[40];
	ctx->vsp=local+47;
	w=(pointer)ELT(ctx,2,local+45); /*elt*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(*ftab[2])(ctx,4,local+42,&ftab[2],fqv[15]); /*warn*/
	local[42]= local[40];
	ctx->vsp=local+43;
	w=(pointer)ADD1(ctx,1,local+42); /*1+*/
	local[40] = w;
	goto irtmodelWHL2240;
irtmodelWHX2241:
	local[42]= NIL;
irtmodelBLK2242:
	w = NIL;
	if (local[14]==NIL) goto irtmodelIF2243;
	local[40]= argv[0];
	local[41]= fqv[502];
	local[42]= local[14];
	local[43]= fqv[331];
	local[44]= local[15];
	local[45]= fqv[335];
	local[46]= local[16];
	local[47]= fqv[332];
	local[48]= NIL;
	ctx->vsp=local+49;
	w=(pointer)SEND(ctx,9,local+40); /*send*/
	local[40]= w;
	local[41]= fqv[503];
	local[42]= local[40];
	local[43]= local[40];
	ctx->vsp=local+44;
	w=(pointer)VNORM(ctx,1,local+43); /*norm*/
	local[43]= w;
	local[44]= local[13];
	ctx->vsp=local+45;
	w=(*ftab[2])(ctx,4,local+41,&ftab[2],fqv[15]); /*warn*/
	local[40]= w;
	goto irtmodelIF2244;
irtmodelIF2243:
	local[40]= NIL;
irtmodelIF2244:
	local[40]= fqv[504];
	local[41]= argv[0];
irtmodelWHL2245:
	local[42]= local[41];
	local[43]= fqv[214];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,2,local+42); /*send*/
	if (w==NIL) goto irtmodelWHX2246;
	local[42]= local[41];
	local[43]= fqv[214];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,2,local+42); /*send*/
	local[41] = w;
	goto irtmodelWHL2245;
irtmodelWHX2246:
	local[42]= NIL;
irtmodelBLK2247:
	w = local[41];
	local[41]= w;
	local[42]= fqv[122];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,2,local+41); /*send*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,2,local+40,&ftab[2],fqv[15]); /*warn*/
	local[40]= fqv[505];
	local[41]= local[25];
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,2,local+40,&ftab[2],fqv[15]); /*warn*/
	if (local[20]==NIL) goto irtmodelIF2248;
	local[40]= fqv[506];
	local[41]= local[33];
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,2,local+40,&ftab[2],fqv[15]); /*warn*/
	local[40]= w;
	goto irtmodelIF2249;
irtmodelIF2248:
	local[40]= NIL;
irtmodelIF2249:
	local[40]= fqv[507];
	local[41]= argv[2];
	ctx->vsp=local+42;
	w=(pointer)LIST(ctx,1,local+41); /*list*/
	local[41]= w;
	local[42]= local[0];
	ctx->vsp=local+43;
	w=(pointer)APPEND(ctx,2,local+41); /*append*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,2,local+40,&ftab[2],fqv[15]); /*warn*/
	if (local[18]==NIL) goto irtmodelIF2250;
	local[40]= NIL;
	local[41]= NIL;
	local[42]= NIL;
	local[43]= NIL;
	local[44]= NIL;
	ctx->vsp=local+45;
	local[45]= makeclosure(codevec,quotevec,irtmodelFLET2252,env,argv,local);
	ctx->vsp=local+46;
	local[46]= makeclosure(codevec,quotevec,irtmodelFLET2253,env,argv,local);
	ctx->vsp=local+47;
	local[47]= makeclosure(codevec,quotevec,irtmodelFLET2254,env,argv,local);
	ctx->vsp=local+48;
	local[48]= makeclosure(codevec,quotevec,irtmodelFLET2255,env,argv,local);
	ctx->vsp=local+49;
	local[49]= makeclosure(codevec,quotevec,irtmodelFLET2256,env,argv,local);
	ctx->vsp=local+50;
	local[50]= makeclosure(codevec,quotevec,irtmodelFLET2257,env,argv,local);
	local[51]= local[0];
	w = local[50];
	ctx->vsp=local+52;
	w=irtmodelFLET2257(ctx,1,local+51,w);
	local[41] = w;
	local[51]= makeint((eusinteger_t)0L);
	local[52]= local[41];
	ctx->vsp=local+53;
	w=(pointer)LENGTH(ctx,1,local+52); /*length*/
	local[52]= w;
	local[53]= makeint((eusinteger_t)2L);
	ctx->vsp=local+54;
	w=(pointer)QUOTIENT(ctx,2,local+52); /*/*/
	local[52]= w;
irtmodelWHL2258:
	local[53]= local[51];
	w = local[52];
	if ((eusinteger_t)local[53] >= (eusinteger_t)w) goto irtmodelWHX2259;
	local[53]= local[41];
	local[54]= makeint((eusinteger_t)2L);
	{ eusinteger_t i,j;
		j=intval(local[51]); i=intval(local[54]);
		local[54]=(makeint(i * j));}
	ctx->vsp=local+55;
	w=(pointer)ELT(ctx,2,local+53); /*elt*/
	local[53]= w;
	if (fqv[300]==local[53]) goto irtmodelIF2261;
	local[53]= local[41];
	local[54]= makeint((eusinteger_t)1L);
	local[55]= makeint((eusinteger_t)2L);
	{ eusinteger_t i,j;
		j=intval(local[51]); i=intval(local[55]);
		local[55]=(makeint(i * j));}
	w = local[55];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[54]= (pointer)((eusinteger_t)local[54] + (eusinteger_t)w);
	w = local[46];
	ctx->vsp=local+55;
	w=irtmodelFLET2253(ctx,2,local+53,w);
	local[53]= w;
	goto irtmodelIF2262;
irtmodelIF2261:
	local[53]= NIL;
irtmodelIF2262:
	local[53]= local[51];
	ctx->vsp=local+54;
	w=(pointer)ADD1(ctx,1,local+53); /*1+*/
	local[51] = w;
	goto irtmodelWHL2258;
irtmodelWHX2259:
	local[53]= NIL;
irtmodelBLK2260:
	w = NIL;
	local[51]= makeint((eusinteger_t)0L);
	local[52]= local[41];
	ctx->vsp=local+53;
	w=(pointer)LENGTH(ctx,1,local+52); /*length*/
	local[52]= w;
irtmodelWHL2263:
	local[53]= local[51];
	w = local[52];
	if ((eusinteger_t)local[53] >= (eusinteger_t)w) goto irtmodelWHX2264;
	local[53]= local[41];
	local[54]= local[51];
	w = local[47];
	ctx->vsp=local+55;
	w=irtmodelFLET2254(ctx,2,local+53,w);
	local[53]= local[51];
	ctx->vsp=local+54;
	w=(pointer)ADD1(ctx,1,local+53); /*1+*/
	local[51] = w;
	goto irtmodelWHL2263;
irtmodelWHX2264:
	local[53]= NIL;
irtmodelBLK2265:
	w = NIL;
	local[51]= makeint((eusinteger_t)0L);
	local[52]= fqv[300];
	local[53]= local[41];
	ctx->vsp=local+54;
	w=(*ftab[53])(ctx,2,local+52,&ftab[53],fqv[508]); /*count*/
	local[52]= w;
irtmodelWHL2266:
	local[53]= local[51];
	w = local[52];
	if ((eusinteger_t)local[53] >= (eusinteger_t)w) goto irtmodelWHX2267;
	local[53]= fqv[300];
	local[54]= local[41];
	local[55]= fqv[509];
	local[56]= local[51];
	ctx->vsp=local+57;
	w=(pointer)ADD1(ctx,1,local+56); /*1+*/
	local[56]= w;
	ctx->vsp=local+57;
	w=(*ftab[32])(ctx,4,local+53,&ftab[32],fqv[212]); /*position*/
	local[40] = w;
	if (local[40]==NIL) goto irtmodelIF2269;
	local[53]= local[41];
	local[54]= local[40];
	local[55]= makeint((eusinteger_t)1L);
	ctx->vsp=local+56;
	w=(pointer)PLUS(ctx,2,local+54); /*+*/
	local[54]= w;
	ctx->vsp=local+55;
	w=(pointer)ELT(ctx,2,local+53); /*elt*/
	if (!!iscons(w)) goto irtmodelCON2272;
	local[53]= local[41];
	local[54]= local[40];
	local[55]= makeint((eusinteger_t)1L);
	ctx->vsp=local+56;
	w=(pointer)PLUS(ctx,2,local+54); /*+*/
	local[54]= w;
	local[55]= local[41];
	local[56]= local[40];
	local[57]= makeint((eusinteger_t)1L);
	ctx->vsp=local+58;
	w=(pointer)PLUS(ctx,2,local+56); /*+*/
	local[56]= w;
	ctx->vsp=local+57;
	w=(pointer)ELT(ctx,2,local+55); /*elt*/
	local[55]= w;
	w = local[49];
	ctx->vsp=local+56;
	w=irtmodelFLET2256(ctx,1,local+55,w);
	local[55]= w;
	ctx->vsp=local+56;
	w=(pointer)SETELT(ctx,3,local+53); /*setelt*/
	local[53]= w;
	goto irtmodelCON2271;
irtmodelCON2272:
	local[53]= local[41];
	local[54]= local[40];
	local[55]= makeint((eusinteger_t)1L);
	ctx->vsp=local+56;
	w=(pointer)PLUS(ctx,2,local+54); /*+*/
	local[54]= w;
	local[55]= fqv[510];
	ctx->vsp=local+56;
	local[56]= makeclosure(codevec,quotevec,irtmodelCLO2274,env,argv,local);
	local[57]= local[41];
	local[58]= local[40];
	local[59]= makeint((eusinteger_t)1L);
	ctx->vsp=local+60;
	w=(pointer)PLUS(ctx,2,local+58); /*+*/
	local[58]= w;
	ctx->vsp=local+59;
	w=(pointer)ELT(ctx,2,local+57); /*elt*/
	local[57]= w;
	ctx->vsp=local+58;
	w=(pointer)MAPCAR(ctx,2,local+56); /*mapcar*/
	local[56]= w;
	ctx->vsp=local+57;
	w=(pointer)APPEND(ctx,2,local+55); /*append*/
	local[55]= w;
	ctx->vsp=local+56;
	w=(pointer)SETELT(ctx,3,local+53); /*setelt*/
	local[53]= w;
	goto irtmodelCON2271;
irtmodelCON2273:
	local[53]= NIL;
irtmodelCON2271:
	goto irtmodelIF2270;
irtmodelIF2269:
	local[53]= NIL;
irtmodelIF2270:
	local[53]= local[51];
	ctx->vsp=local+54;
	w=(pointer)ADD1(ctx,1,local+53); /*1+*/
	local[51] = w;
	goto irtmodelWHL2266;
irtmodelWHX2267:
	local[53]= NIL;
irtmodelBLK2268:
	w = NIL;
	local[51]= fqv[511];
	local[52]= argv[0];
	ctx->vsp=local+53;
	w=(pointer)GETCLASS(ctx,1,local+52); /*class*/
	local[52]= w;
	local[53]= fqv[3];
	ctx->vsp=local+54;
	w=(pointer)SEND(ctx,2,local+52); /*send*/
	local[52]= w;
	local[53]= fqv[36];
	ctx->vsp=local+54;
	w=(pointer)LIST(ctx,1,local+53); /*list*/
	ctx->vsp=local+53;
	w = cons(ctx,local[52],w);
	ctx->vsp=local+52;
	local[42] = cons(ctx,local[51],w);
	local[51]= fqv[512];
	local[52]= fqv[288];
	local[53]= fqv[513];
	local[54]= fqv[159];
	local[55]= fqv[86];
	local[56]= fqv[514];
	local[57]= argv[0];
	local[58]= fqv[514];
	ctx->vsp=local+59;
	w=(pointer)SEND(ctx,2,local+57); /*send*/
	local[57]= w;
	ctx->vsp=local+58;
	w=(pointer)LIST(ctx,1,local+57); /*list*/
	ctx->vsp=local+57;
	w = cons(ctx,local[56],w);
	ctx->vsp=local+56;
	local[55]= cons(ctx,local[55],w);
	ctx->vsp=local+56;
	w=(pointer)LIST(ctx,1,local+55); /*list*/
	ctx->vsp=local+55;
	w = cons(ctx,local[54],w);
	ctx->vsp=local+54;
	w = cons(ctx,local[53],w);
	ctx->vsp=local+53;
	local[52]= cons(ctx,local[52],w);
	local[53]= fqv[515];
	local[54]= fqv[516];
	local[55]= fqv[517];
	local[56]= fqv[518];
	local[57]= fqv[519];
	ctx->vsp=local+58;
	w=(pointer)LIST(ctx,1,local+57); /*list*/
	ctx->vsp=local+57;
	local[56]= cons(ctx,local[56],w);
	local[57]= fqv[520];
	local[58]= fqv[518];
	local[59]= fqv[20];
	local[60]= fqv[519];
	local[61]= local[9];
	ctx->vsp=local+62;
	w=(pointer)LIST(ctx,1,local+61); /*list*/
	ctx->vsp=local+61;
	w = cons(ctx,local[60],w);
	ctx->vsp=local+60;
	w = cons(ctx,local[59],w);
	ctx->vsp=local+59;
	w = cons(ctx,local[58],w);
	ctx->vsp=local+58;
	local[57]= cons(ctx,local[57],w);
	ctx->vsp=local+58;
	w=(pointer)LIST(ctx,1,local+57); /*list*/
	ctx->vsp=local+57;
	w = cons(ctx,local[56],w);
	ctx->vsp=local+56;
	local[55]= cons(ctx,local[55],w);
	ctx->vsp=local+56;
	w=(pointer)LIST(ctx,1,local+55); /*list*/
	ctx->vsp=local+55;
	local[54]= cons(ctx,local[54],w);
	local[55]= fqv[521];
	ctx->vsp=local+56;
	local[56]= makeclosure(codevec,quotevec,irtmodelCLO2275,env,argv,local);
	local[57]= local[24];
	local[58]= fqv[198];
	ctx->vsp=local+59;
	w=(*ftab[18])(ctx,2,local+57,&ftab[18],fqv[128]); /*send-all*/
	local[57]= w;
	local[58]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+59;
	w=(pointer)APPEND(ctx,2,local+57); /*append*/
	local[57]= w;
	ctx->vsp=local+58;
	w=(*ftab[47])(ctx,1,local+57,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[57]= w;
	local[58]= fqv[3];
	ctx->vsp=local+59;
	w=(*ftab[18])(ctx,2,local+57,&ftab[18],fqv[128]); /*send-all*/
	local[57]= w;
	ctx->vsp=local+58;
	w=(pointer)MAPCAR(ctx,2,local+56); /*mapcar*/
	ctx->vsp=local+56;
	local[55]= cons(ctx,local[55],w);
	local[56]= fqv[459];
	local[57]= local[25];
	ctx->vsp=local+58;
	w=(pointer)LIST(ctx,2,local+56); /*list*/
	local[56]= w;
	ctx->vsp=local+57;
	w=(pointer)LIST(ctx,1,local+56); /*list*/
	ctx->vsp=local+56;
	w = cons(ctx,local[55],w);
	ctx->vsp=local+55;
	w = cons(ctx,local[54],w);
	ctx->vsp=local+54;
	local[53]= cons(ctx,local[53],w);
	local[54]= fqv[522];
	local[55]= fqv[521];
	local[56]= fqv[513];
	ctx->vsp=local+57;
	w=(pointer)LIST(ctx,1,local+56); /*list*/
	ctx->vsp=local+56;
	local[55]= cons(ctx,local[55],w);
	ctx->vsp=local+56;
	w=(pointer)LIST(ctx,1,local+55); /*list*/
	ctx->vsp=local+55;
	local[54]= cons(ctx,local[54],w);
	ctx->vsp=local+55;
	w=(pointer)LIST(ctx,1,local+54); /*list*/
	ctx->vsp=local+54;
	w = cons(ctx,local[53],w);
	ctx->vsp=local+53;
	w = cons(ctx,local[52],w);
	ctx->vsp=local+52;
	local[43] = cons(ctx,local[51],w);
	local[51]= fqv[523];
	ctx->vsp=local+52;
	local[52]= makeclosure(codevec,quotevec,irtmodelCLO2276,env,argv,local);
	local[53]= argv[2];
	ctx->vsp=local+54;
	w=(pointer)MAPCAR(ctx,2,local+52); /*mapcar*/
	local[52]= w;
	local[53]= NIL;
	ctx->vsp=local+54;
	w=(pointer)APPEND(ctx,2,local+52); /*append*/
	local[52]= w;
	ctx->vsp=local+53;
	w=(pointer)LIST(ctx,1,local+52); /*list*/
	local[52]= w;
	local[53]= fqv[524];
	local[54]= NIL;
	local[55]= fqv[340];
	local[56]= T;
	ctx->vsp=local+57;
	w=(pointer)LIST(ctx,4,local+53); /*list*/
	local[53]= w;
	local[54]= local[41];
	ctx->vsp=local+55;
	w=(pointer)APPEND(ctx,4,local+51); /*append*/
	local[44] = w;
	local[51]= local[44];
	local[52]= makeint((eusinteger_t)1L);
	local[53]= fqv[525];
	local[54]= local[44];
	local[55]= makeint((eusinteger_t)1L);
	ctx->vsp=local+56;
	w=(pointer)ELT(ctx,2,local+54); /*elt*/
	local[54]= w;
	ctx->vsp=local+55;
	w=(pointer)APPEND(ctx,2,local+53); /*append*/
	local[53]= w;
	ctx->vsp=local+54;
	w=(pointer)SETELT(ctx,3,local+51); /*setelt*/
	local[45]= fqv[526];
	local[46]= fqv[527];
	local[47]= fqv[513];
	local[48]= local[42];
	ctx->vsp=local+49;
	w=(pointer)LIST(ctx,1,local+48); /*list*/
	ctx->vsp=local+48;
	local[47]= cons(ctx,local[47],w);
	ctx->vsp=local+48;
	w=(pointer)LIST(ctx,1,local+47); /*list*/
	local[47]= w;
	local[48]= local[43];
	local[49]= fqv[520];
	local[50]= fqv[513];
	local[51]= fqv[528];
	local[52]= local[44];
	ctx->vsp=local+53;
	w=(pointer)LIST(ctx,1,local+52); /*list*/
	ctx->vsp=local+52;
	w = cons(ctx,local[51],w);
	ctx->vsp=local+51;
	w = cons(ctx,local[50],w);
	ctx->vsp=local+50;
	local[49]= cons(ctx,local[49],w);
	ctx->vsp=local+50;
	w=(pointer)LIST(ctx,1,local+49); /*list*/
	ctx->vsp=local+49;
	w = cons(ctx,local[48],w);
	ctx->vsp=local+48;
	w = cons(ctx,local[47],w);
	ctx->vsp=local+47;
	local[46]= cons(ctx,local[46],w);
	ctx->vsp=local+47;
	w=(*ftab[2])(ctx,2,local+45,&ftab[2],fqv[15]); /*warn*/
	local[45]= fqv[529];
	local[46]= local[35];
	ctx->vsp=local+47;
	w=(*ftab[2])(ctx,2,local+45,&ftab[2],fqv[15]); /*warn*/
	local[45]= fqv[530];
	local[46]= local[35];
	ctx->vsp=local+47;
	w=(*ftab[2])(ctx,2,local+45,&ftab[2],fqv[15]); /*warn*/
	local[45]= local[35];
	local[46]= fqv[178];
	local[47]= fqv[179];
	local[48]= fqv[531];
	local[49]= fqv[532];
	ctx->vsp=local+50;
	w=(*ftab[25])(ctx,5,local+45,&ftab[25],fqv[180]); /*open*/
	local[45]= w;
	ctx->vsp=local+46;
	w = makeclosure(codevec,quotevec,irtmodelUWP2277,env,argv,local);
	local[46]=(pointer)(ctx->protfp); local[47]=w;
	ctx->protfp=(struct protectframe *)(local+46);
	local[48]= local[45];
	local[49]= fqv[533];
	local[50]= local[36];
	local[51]= local[42];
	local[52]= local[43];
	ctx->vsp=local+53;
	w=(pointer)XFORMAT(ctx,5,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[534];
	local[50]= local[36];
	local[51]= local[44];
	ctx->vsp=local+52;
	w=(pointer)XFORMAT(ctx,4,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[535];
	local[50]= local[36];
	ctx->vsp=local+51;
	w=(pointer)XFORMAT(ctx,3,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[536];
	local[50]= local[36];
	ctx->vsp=local+51;
	w=(pointer)XFORMAT(ctx,3,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[537];
	ctx->vsp=local+50;
	w=(pointer)XFORMAT(ctx,2,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[538];
	local[50]= local[28];
	local[51]= local[29];
	ctx->vsp=local+52;
	w=(pointer)XFORMAT(ctx,4,local+48); /*format*/
	if (local[14]==NIL) goto irtmodelIF2278;
	local[48]= local[45];
	local[49]= fqv[539];
	local[50]= argv[0];
	local[51]= fqv[502];
	local[52]= local[14];
	local[53]= fqv[331];
	local[54]= local[15];
	local[55]= fqv[335];
	local[56]= local[16];
	local[57]= fqv[332];
	local[58]= NIL;
	ctx->vsp=local+59;
	w=(pointer)SEND(ctx,9,local+50); /*send*/
	local[50]= w;
	ctx->vsp=local+51;
	w=(pointer)XFORMAT(ctx,3,local+48); /*format*/
	local[48]= w;
	goto irtmodelIF2279;
irtmodelIF2278:
	local[48]= NIL;
irtmodelIF2279:
	local[48]= local[45];
	local[49]= fqv[540];
	ctx->vsp=local+50;
	w=(pointer)XFORMAT(ctx,2,local+48); /*format*/
	ctx->vsp=local+48;
	irtmodelUWP2277(ctx,0,local+48,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[40]= w;
	goto irtmodelIF2251;
irtmodelIF2250:
	local[40]= NIL;
irtmodelIF2251:
	goto irtmodelIF2239;
irtmodelIF2238:
	local[40]= NIL;
irtmodelIF2239:
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2280,env,argv,local);
	local[41]= local[24];
	local[42]= fqv[198];
	ctx->vsp=local+43;
	w=(*ftab[18])(ctx,2,local+41,&ftab[18],fqv[128]); /*send-all*/
	local[41]= w;
	local[42]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+43;
	w=(pointer)APPEND(ctx,2,local+41); /*append*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[47])(ctx,1,local+41,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[41]= w;
	local[42]= local[25];
	ctx->vsp=local+43;
	w=(pointer)MAPC(ctx,3,local+40); /*mapc*/
	if (local[26]==NIL) goto irtmodelIF2281;
	local[40]= argv[0];
	local[41]= fqv[159];
	local[42]= local[26];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,3,local+40); /*send*/
	local[40]= w;
	goto irtmodelIF2282;
irtmodelIF2281:
	local[40]= NIL;
irtmodelIF2282:
	local[40]= NIL;
irtmodelIF2237:
	w = local[40];
	local[0]= w;
irtmodelBLK2109:
	ctx->vsp=local; return(local[0]);}

/*:ik-convergence-check*/
static pointer irtmodelM2283cascaded_link_ik_convergence_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<13) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[541], &argv[13], n-13, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2285;
	local[0] = T;
irtmodelKEY2285:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
irtmodelWHL2286:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtmodelWHX2287;
	local[3]= argv[2];
	if (local[3]==NIL) goto irtmodelAND2289;
	local[3]= argv[6];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	if (w==NIL) goto irtmodelIF2290;
	local[3]= argv[3];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= argv[7];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	local[3]= w;
	goto irtmodelIF2291;
irtmodelIF2290:
	local[3]= T;
irtmodelIF2291:
	if (local[3]==NIL) goto irtmodelAND2289;
	local[3]= argv[5];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	if (w==NIL) goto irtmodelIF2292;
	local[3]= argv[4];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= argv[8];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	local[3]= w;
	goto irtmodelIF2293;
irtmodelIF2292:
	local[3]= T;
irtmodelIF2293:
irtmodelAND2289:
	argv[2] = local[3];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtmodelWHL2286;
irtmodelWHX2287:
	local[3]= NIL;
irtmodelBLK2288:
	w = NIL;
	if (argv[10]==NIL) goto irtmodelIF2294;
	local[1]= argv[2];
	if (local[1]==NIL) goto irtmodelAND2296;
	local[1]= argv[0];
	local[2]= fqv[542];
	local[3]= argv[9];
	local[4]= argv[10];
	local[5]= fqv[331];
	local[6]= argv[11];
	local[7]= fqv[335];
	local[8]= argv[12];
	local[9]= fqv[332];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,10,local+1); /*send*/
	local[1]= w;
irtmodelAND2296:
	argv[2] = local[1];
	local[1]= argv[2];
	goto irtmodelIF2295;
irtmodelIF2294:
	local[1]= NIL;
irtmodelIF2295:
	w = argv[2];
	local[0]= w;
irtmodelBLK2284:
	ctx->vsp=local; return(local[0]);}

/*:calc-vel-from-pos*/
static pointer irtmodelM2297cascaded_link_calc_vel_from_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtmodelRST2299:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[543], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY2300;
	local[1] = makeflt(1.0000000000000000000000e+02);
irtmodelKEY2300:
	if (n & (1<<1)) goto irtmodelKEY2301;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[2] = w;
irtmodelKEY2301:
	if (n & (1<<2)) goto irtmodelKEY2302;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[3] = w;
irtmodelKEY2302:
	if (n & (1<<3)) goto irtmodelKEY2303;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[4] = w;
irtmodelKEY2303:
	if (n & (1<<4)) goto irtmodelKEY2304;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[5] = w;
irtmodelKEY2304:
	local[6]= NIL;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto irtmodelIF2305;
	local[7]= local[1];
	local[8]= argv[2];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,2,local+8,&ftab[4],fqv[26]); /*normalize-vector*/
	local[8]= w;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	argv[2] = w;
	local[7]= argv[2];
	goto irtmodelIF2306;
irtmodelIF2305:
	local[7]= NIL;
irtmodelIF2306:
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= argv[2];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	argv[2] = w;
	local[7]= argv[2];
	local[8]= argv[3];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)irtmodelF749calc_dif_with_axis(ctx,5,local+7); /*calc-dif-with-axis*/
	local[6] = w;
	w = local[6];
	local[0]= w;
irtmodelBLK2298:
	ctx->vsp=local; return(local[0]);}

/*:calc-vel-from-rot*/
static pointer irtmodelM2307cascaded_link_calc_vel_from_rot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtmodelRST2309:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[544], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY2310;
	local[1] = makeflt(5.0000000000000000000000e-01);
irtmodelKEY2310:
	if (n & (1<<1)) goto irtmodelKEY2311;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[2] = w;
irtmodelKEY2311:
	if (n & (1<<2)) goto irtmodelKEY2312;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[3] = w;
irtmodelKEY2312:
	if (n & (1<<3)) goto irtmodelKEY2313;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[4] = w;
irtmodelKEY2313:
	if (n & (1<<4)) goto irtmodelKEY2314;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[5] = w;
irtmodelKEY2314:
	local[6]= NIL;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto irtmodelIF2315;
	local[7]= local[1];
	local[8]= argv[2];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,2,local+8,&ftab[4],fqv[26]); /*normalize-vector*/
	local[8]= w;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	argv[2] = w;
	local[7]= argv[2];
	goto irtmodelIF2316;
irtmodelIF2315:
	local[7]= NIL;
irtmodelIF2316:
	local[7]= argv[2];
	local[8]= argv[3];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)irtmodelF749calc_dif_with_axis(ctx,5,local+7); /*calc-dif-with-axis*/
	local[6] = w;
	w = local[6];
	local[0]= w;
irtmodelBLK2308:
	ctx->vsp=local; return(local[0]);}

/*:collision-check-pairs*/
static pointer irtmodelM2317cascaded_link_collision_check_pairs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[545], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2319;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)irtmodelF748all_child_links(ctx,1,local+2); /*all-child-links*/
	ctx->vsp=local+2;
	local[0] = cons(ctx,local[1],w);
irtmodelKEY2319:
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
irtmodelWHL2320:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	if (local[2]==NIL) goto irtmodelWHX2321;
	local[4]= NIL;
	local[5]= local[2];
	local[6]= fqv[546];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[2];
	local[7]= fqv[547];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[2];
	local[8]= fqv[133];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[2];
	local[9]= fqv[214];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,3,local+5); /*append*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[54])(ctx,2,local+4,&ftab[54],fqv[548]); /*remove*/
	local[3] = w;
	local[4]= NIL;
	local[5]= local[0];
irtmodelWHL2323:
	if (local[5]==NIL) goto irtmodelWHX2324;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	w = local[3];
	if (memq(local[6],w)!=NIL) goto irtmodelIF2326;
	local[6]= local[2];
	w = local[4];
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	w = local[1];
	ctx->vsp=local+7;
	local[1] = cons(ctx,local[6],w);
	local[6]= local[1];
	goto irtmodelIF2327;
irtmodelIF2326:
	local[6]= NIL;
irtmodelIF2327:
	goto irtmodelWHL2323;
irtmodelWHX2324:
	local[6]= NIL;
irtmodelBLK2325:
	w = NIL;
	goto irtmodelWHL2320;
irtmodelWHX2321:
	local[4]= NIL;
irtmodelBLK2322:
	w = local[1];
	local[0]= w;
irtmodelBLK2318:
	ctx->vsp=local; return(local[0]);}

/*:self-collision-check*/
static pointer irtmodelM2328cascaded_link_self_collision_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[549], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2330;
	local[0] = fqv[550];
irtmodelKEY2330:
	if (n & (1<<1)) goto irtmodelKEY2331;
	local[3]= argv[0];
	local[4]= fqv[551];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[1] = w;
irtmodelKEY2331:
	if (n & (1<<2)) goto irtmodelKEY2332;
	local[2] = fqv[164];
irtmodelKEY2332:
	local[3]= NIL;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[1];
irtmodelWHL2333:
	if (local[7]==NIL) goto irtmodelWHX2334;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[143];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w==NIL) goto irtmodelIF2336;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[143];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w==NIL) goto irtmodelIF2336;
	local[8]= local[2];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	ctx->vsp=local+11;
	w=(pointer)FUNCALL(ctx,3,local+8); /*funcall*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[24])(ctx,2,local+8,&ftab[24],fqv[171]); /*/=*/
	local[8]= w;
	if (local[8]==NIL) goto irtmodelIF2338;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[4] = w;
	local[9]= local[0];
	if (fqv[552]!=local[9]) goto irtmodelIF2340;
	w = local[6];
	ctx->vsp=local+9;
	local[0]=w;
	goto irtmodelBLK2329;
	goto irtmodelIF2341;
irtmodelIF2340:
	local[9]= local[6];
	w = local[3];
	ctx->vsp=local+10;
	local[3] = cons(ctx,local[9],w);
	local[9]= local[3];
irtmodelIF2341:
	goto irtmodelIF2339;
irtmodelIF2338:
	local[9]= NIL;
irtmodelIF2339:
	w = local[9];
	local[8]= w;
	goto irtmodelIF2337;
irtmodelIF2336:
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[143];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w!=NIL) goto irtmodelIF2342;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (w!=NIL) goto irtmodelIF2342;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= fqv[553];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[143];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,4,local+8,&ftab[5],fqv[44]); /*warning-message*/
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w = local[5];
	ctx->vsp=local+9;
	local[5] = cons(ctx,local[8],w);
	local[8]= local[5];
	goto irtmodelIF2343;
irtmodelIF2342:
	local[8]= NIL;
irtmodelIF2343:
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[143];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w!=NIL) goto irtmodelIF2344;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (w!=NIL) goto irtmodelIF2344;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= fqv[554];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	local[11]= fqv[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	local[12]= fqv[143];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,4,local+8,&ftab[5],fqv[44]); /*warning-message*/
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	w = local[5];
	ctx->vsp=local+9;
	local[5] = cons(ctx,local[8],w);
	local[8]= local[5];
	goto irtmodelIF2345;
irtmodelIF2344:
	local[8]= NIL;
irtmodelIF2345:
irtmodelIF2337:
	goto irtmodelWHL2333;
irtmodelWHX2334:
	local[8]= NIL;
irtmodelBLK2335:
	w = NIL;
	w = local[3];
	local[0]= w;
irtmodelBLK2329:
	ctx->vsp=local; return(local[0]);}

/*:calc-grasp-matrix*/
static pointer irtmodelM2346cascaded_link_calc_grasp_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[555], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2348;
	local[2]= makeint((eusinteger_t)6L);
	local[3]= makeint((eusinteger_t)6L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[3]);
		local[3]=(makeint(i * j));}
	ctx->vsp=local+4;
	w=(*ftab[23])(ctx,2,local+2,&ftab[23],fqv[166]); /*make-matrix*/
	local[0] = w;
irtmodelKEY2348:
	if (n & (1<<1)) goto irtmodelKEY2349;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2350,env,argv,local);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[1] = w;
irtmodelKEY2349:
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2351,env,argv,local);
	local[3]= argv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,3,local+2); /*mapcar*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
irtmodelWHL2352:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtmodelWHX2353;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
irtmodelWHL2355:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX2356;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)3L);
irtmodelWHL2358:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtmodelWHX2359;
	local[9]= local[0];
	local[10]= local[5];
	local[11]= local[3];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[11]);
		local[11]=(makeint(i * j));}
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[11]= (pointer)((eusinteger_t)local[11] + (eusinteger_t)w);
	local[12]= local[1];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,3,local+12); /*aref*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[0];
	local[10]= makeint((eusinteger_t)3L);
	w = local[5];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[10]= (pointer)((eusinteger_t)local[10] + (eusinteger_t)w);
	local[11]= local[3];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[11]);
		local[11]=(makeint(i * j));}
	local[12]= makeint((eusinteger_t)3L);
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	w = (pointer)((eusinteger_t)local[12] + (eusinteger_t)w);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[11]= (pointer)((eusinteger_t)local[11] + (eusinteger_t)w);
	local[12]= local[1];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,3,local+12); /*aref*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[0];
	local[10]= makeint((eusinteger_t)3L);
	w = local[5];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[10]= (pointer)((eusinteger_t)local[10] + (eusinteger_t)w);
	local[11]= local[3];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[11]);
		local[11]=(makeint(i * j));}
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[11]= (pointer)((eusinteger_t)local[11] + (eusinteger_t)w);
	local[12]= local[2];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,3,local+12); /*aref*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtmodelWHL2358;
irtmodelWHX2359:
	local[9]= NIL;
irtmodelBLK2360:
	w = NIL;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL2355;
irtmodelWHX2356:
	local[7]= NIL;
irtmodelBLK2357:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtmodelWHL2352;
irtmodelWHX2353:
	local[5]= NIL;
irtmodelBLK2354:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK2347:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics-for-closed-loop-forward-kinematics*/
static pointer irtmodelM2361cascaded_link_inverse_kinematics_for_closed_loop_forward_kinematics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST2363:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[556], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY2364;
	local[1] = NIL;
irtmodelKEY2364:
	if (n & (1<<1)) goto irtmodelKEY2365;
	local[2] = NIL;
irtmodelKEY2365:
	if (n & (1<<2)) goto irtmodelKEY2366;
	local[3] = NIL;
irtmodelKEY2366:
	if (n & (1<<3)) goto irtmodelKEY2367;
	local[4] = NIL;
irtmodelKEY2367:
	if (n & (1<<4)) goto irtmodelKEY2368;
	local[5] = NIL;
irtmodelKEY2368:
	if (n & (1<<5)) goto irtmodelKEY2369;
	local[6] = NIL;
irtmodelKEY2369:
	if (n & (1<<6)) goto irtmodelKEY2370;
	local[7] = makeint((eusinteger_t)2L);
irtmodelKEY2370:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtmodelCLO2371,env,argv,local);
	local[9]= local[5];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,3,local+8); /*mapcar*/
	local[8]= (pointer)get_sym_func(fqv[288]);
	local[9]= argv[0];
	local[10]= fqv[528];
	local[11]= argv[2];
	local[12]= fqv[300];
	local[13]= local[1];
	local[14]= fqv[260];
	local[15]= local[2];
	local[16]= fqv[557];
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtmodelCLO2372,env,argv,local);
	local[18]= fqv[359];
	local[19]= local[4];
	ctx->vsp=local+20;
	local[20]= makeclosure(codevec,quotevec,irtmodelCLO2373,env,argv,local);
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,2,local+20); /*mapcar*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)APPEND(ctx,2,local+19); /*append*/
	local[19]= w;
	local[20]= fqv[558];
	local[21]= local[7];
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(pointer)APPLY(ctx,15,local+8); /*apply*/
	local[0]= w;
irtmodelBLK2362:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian-for-interlocking-joints*/
static pointer irtmodelM2374cascaded_link_calc_jacobian_for_interlocking_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[559], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2376;
	local[1]= argv[0];
	local[2]= fqv[560];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
irtmodelKEY2376:
	local[1]= argv[0];
	local[2]= fqv[197];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[198];
	ctx->vsp=local+4;
	w=(*ftab[18])(ctx,2,local+2,&ftab[18],fqv[128]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtmodelCLO2377,env,argv,local);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[55])(ctx,2,local+3,&ftab[55],fqv[561]); /*remove-if-not*/
	local[3]= w;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[211];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[23])(ctx,2,local+4,&ftab[23],fqv[166]); /*make-matrix*/
	local[4]= w;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO2378,env,argv,local);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	w = local[4];
	local[0]= w;
irtmodelBLK2375:
	ctx->vsp=local; return(local[0]);}

/*:calc-vel-for-interlocking-joints*/
static pointer irtmodelM2379cascaded_link_calc_vel_for_interlocking_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[562], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2381;
	local[1]= argv[0];
	local[2]= fqv[560];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
irtmodelKEY2381:
	local[1]= argv[0];
	local[2]= fqv[197];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[198];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2382,env,argv,local);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[55])(ctx,2,local+2,&ftab[55],fqv[561]); /*remove-if-not*/
	local[2]= w;
	local[3]= loadglobal(fqv[5]);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,2,local+3); /*instantiate*/
	local[3]= w;
	w = local[3];
	local[0]= w;
irtmodelBLK2380:
	ctx->vsp=local; return(local[0]);}

/*:set-midpoint-for-interlocking-joints*/
static pointer irtmodelM2383cascaded_link_set_midpoint_for_interlocking_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[563], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2385;
	local[1]= argv[0];
	local[2]= fqv[560];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
irtmodelKEY2385:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelCLO2386,env,argv,local);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
irtmodelBLK2384:
	ctx->vsp=local; return(local[0]);}

/*:interlocking-joint-pairs*/
static pointer irtmodelM2387cascaded_link_interlocking_joint_pairs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = fqv[564];
	local[0]= w;
irtmodelBLK2388:
	ctx->vsp=local; return(local[0]);}

/*:check-interlocking-joint-angle-validity*/
static pointer irtmodelM2389cascaded_link_check_interlocking_joint_angle_validity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[565], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2391;
	local[0] = makeflt(1.0000000000000000208167e-03);
irtmodelKEY2391:
	if (n & (1<<1)) goto irtmodelKEY2392;
	local[2]= argv[0];
	local[3]= fqv[560];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
irtmodelKEY2392:
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2393,env,argv,local);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= (pointer)get_sym_func(fqv[566]);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[56])(ctx,2,local+3,&ftab[56],fqv[567]); /*every*/
	local[0]= w;
irtmodelBLK2390:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1450(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET1499(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	if (w!=NIL) goto irtmodelOR2396;
	if (argv[0]==NIL) goto irtmodelOR2396;
	goto irtmodelIF2394;
irtmodelOR2396:
	local[0]= argv[0];
	goto irtmodelIF2395;
irtmodelIF2394:
	local[0]= argv[0];
	local[1]= fqv[214];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	w = env->c.clo.env2[33];
	ctx->vsp=local+2;
	w=irtmodelFLET1499(ctx,2,local+0,w);
	local[0]= w;
irtmodelIF2395:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1588(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
irtmodelWHL2397:
	if (local[0]==NIL) goto irtmodelWHX2398;
	local[1]= local[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtmodelWHX2398;
	local[1]= argv[0];
	local[2]= fqv[29];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= fqv[133];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VDISTANCE(ctx,2,local+1); /*distance*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,2,local+1,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelWHX2398;
	local[1]= local[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
	goto irtmodelWHL2397;
irtmodelWHX2398:
	local[1]= NIL;
irtmodelBLK2399:
	local[1]= local[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1601(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[5];
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[212]); /*position*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1652(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1683(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=env->c.clo.env2[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= fqv[139];
	local[3]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,4,local+0,&ftab[16],fqv[124]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET1687(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= fqv[139];
	local[5]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+6;
	w=(*ftab[32])(ctx,4,local+2,&ftab[32],fqv[212]); /*position*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
	local[1]= fqv[198];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+0); /*calc-target-joint-dimension*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1725(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	local[0]= w;
	if (w==NIL) goto irtmodelAND2400;
	local[0]= (pointer)get_sym_func(fqv[566]);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelCLO2401,env,argv,local);
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,3,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[56])(ctx,2,local+0,&ftab[56],fqv[567]); /*every*/
	local[0]= w;
irtmodelAND2400:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2401(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	if (!issymbol(w)) goto irtmodelCON2403;
	w = argv[1];
	if (!issymbol(w)) goto irtmodelCON2403;
	local[0]= argv[0];
	local[0]= ((argv[1])==(local[0])?T:NIL);
	goto irtmodelCON2402;
irtmodelCON2403:
	w = argv[0];
	if (!isstring(w)) goto irtmodelCON2404;
	w = argv[1];
	if (!isstring(w)) goto irtmodelCON2404;
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(*ftab[57])(ctx,2,local+0,&ftab[57],fqv[568]); /*string=*/
	local[0]= w;
	goto irtmodelCON2402;
irtmodelCON2404:
	local[0]= T;
	if (local[0]!=NIL) goto irtmodelCON2402;
irtmodelCON2405:
	local[0]= NIL;
irtmodelCON2402:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1753(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[3];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[124]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2074(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2406;
	local[0]= argv[0];
	local[1]= env->c.clo.env2[3];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2407;
irtmodelIF2406:
	local[0]= argv[0];
irtmodelIF2407:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2161(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2192(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2408;
	local[0]= argv[0];
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2409;
irtmodelIF2408:
	local[0]= argv[0];
irtmodelIF2409:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2195(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2410;
	local[0]= argv[0];
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2411;
irtmodelIF2410:
	local[0]= argv[0];
irtmodelIF2411:
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[24]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2198(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[569];
	local[2]= env->c.clo.env2[43];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	env->c.clo.env2[43] = w;
	local[2]= env->c.clo.env2[43];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[45])(ctx,1,local+0,&ftab[45],fqv[422]); /*read-from-string*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2201(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[570];
	local[2]= env->c.clo.env2[45];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	env->c.clo.env2[45] = w;
	local[2]= env->c.clo.env2[45];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[45])(ctx,1,local+0,&ftab[45],fqv[422]); /*read-from-string*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2205(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2412;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FUNCALL(ctx,1,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2413;
irtmodelIF2412:
	local[0]= argv[0];
irtmodelIF2413:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2206(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[571];
	local[2]= argv[1];
	local[3]= fqv[335];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2207(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[572];
	local[2]= argv[1];
	local[3]= fqv[409];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2212(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2414;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FUNCALL(ctx,1,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2415;
irtmodelIF2414:
	local[0]= argv[0];
irtmodelIF2415:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2213(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[571];
	local[2]= argv[1];
	local[3]= fqv[335];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2214(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[572];
	local[2]= argv[1];
	local[3]= fqv[409];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2215(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[149];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP2226(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[40];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP2231(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[40];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2232(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2233(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= fqv[573];
	local[2]= env->c.clo.env2[45];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	env->c.clo.env2[45] = w;
	local[2]= env->c.clo.env2[45];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[45])(ctx,1,local+0,&ftab[45],fqv[422]); /*read-from-string*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2252(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!isstring(w)) goto irtmodelIF2416;
	local[0]= NIL;
	local[1]= fqv[574];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto irtmodelIF2417;
irtmodelIF2416:
	local[0]= argv[0];
irtmodelIF2417:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2253(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	if (!iscons(w)) goto irtmodelIF2418;
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= fqv[575];
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
irtmodelWHL2420:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtmodelWHX2421;
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= local[0];
	w = env->c.clo.env2[46];
	ctx->vsp=local+4;
	w=irtmodelFLET2253(ctx,2,local+2,w);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtmodelWHL2420;
irtmodelWHX2421:
	local[2]= NIL;
irtmodelBLK2422:
	w = NIL;
	local[0]= w;
	goto irtmodelIF2419;
irtmodelIF2418:
	local[0]= NIL;
irtmodelIF2419:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2254(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	local[1]= loadglobal(fqv[213]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto irtmodelIF2423;
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[576];
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto irtmodelIF2423;
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= fqv[288];
	local[3]= fqv[513];
	local[4]= fqv[576];
	local[5]= argv[0];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= fqv[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	w = env->c.clo.env2[45];
	ctx->vsp=local+6;
	w=irtmodelFLET2252(ctx,1,local+5,w);
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= w;
	goto irtmodelIF2424;
irtmodelIF2423:
	local[0]= NIL;
irtmodelIF2424:
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	if (!iscons(w)) goto irtmodelIF2425;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
irtmodelWHL2427:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtmodelWHX2428;
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= local[0];
	w = env->c.clo.env2[47];
	ctx->vsp=local+4;
	w=irtmodelFLET2254(ctx,2,local+2,w);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtmodelWHL2427;
irtmodelWHX2428:
	local[2]= NIL;
irtmodelBLK2429:
	w = NIL;
	local[0]= w;
	goto irtmodelIF2426;
irtmodelIF2425:
	local[0]= NIL;
irtmodelIF2426:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2255(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[214];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0];
	local[2]= fqv[136];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	if (w==NIL) goto irtmodelIF2430;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtmodelIF2431;
irtmodelIF2430:
	local[0]= argv[0];
	local[1]= fqv[214];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	w = env->c.clo.env2[48];
	ctx->vsp=local+1;
	w=irtmodelFLET2255(ctx,1,local+0,w);
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
irtmodelIF2431:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2256(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[48];
	ctx->vsp=local+1;
	w=irtmodelFLET2255(ctx,1,local+0,w);
	local[0]= w;
	local[1]= fqv[577];
	local[2]= fqv[578];
	local[3]= fqv[288];
	local[4]= fqv[513];
	local[5]= fqv[576];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[214];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	w = env->c.clo.env2[45];
	ctx->vsp=local+7;
	w=irtmodelFLET2252(ctx,1,local+6,w);
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[579];
	local[4]= fqv[297];
	local[5]= fqv[120];
	local[6]= fqv[288];
	local[7]= fqv[288];
	local[8]= fqv[578];
	local[9]= fqv[153];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[84];
	local[9]= fqv[86];
	local[10]= fqv[514];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[214];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[104];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(*ftab[38])(ctx,1,local+13,&ftab[38],fqv[291]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[514];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[288];
	local[4]= fqv[578];
	local[5]= fqv[298];
	local[6]= fqv[579];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[579];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2257(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtmodelCLO2432,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2432(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!iscons(w)) goto irtmodelIF2433;
	local[0]= argv[0];
	w = env->c.clo.env0->c.clo.env2[50];
	ctx->vsp=local+1;
	w=irtmodelFLET2257(ctx,1,local+0,w);
	local[0]= w;
	goto irtmodelIF2434;
irtmodelIF2433:
	local[0]= argv[0];
irtmodelIF2434:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2274(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[49];
	ctx->vsp=local+1;
	w=irtmodelFLET2256(ctx,1,local+0,w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2275(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[288];
	local[1]= fqv[513];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[58])(ctx,1,local+2,&ftab[58],fqv[580]); /*string-upcase*/
	local[2]= w;
	local[3]= loadglobal(fqv[581]);
	ctx->vsp=local+4;
	w=(pointer)INTERN(ctx,2,local+2); /*intern*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2276(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[86];
	local[1]= fqv[105];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[43])(ctx,1,local+2,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2435;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,1,local+2); /*funcall*/
	local[2]= w;
	goto irtmodelIF2436;
irtmodelIF2435:
	local[2]= argv[0];
irtmodelIF2436:
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[85];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[43])(ctx,1,local+4,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2437;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)FUNCALL(ctx,1,local+4); /*funcall*/
	local[4]= w;
	goto irtmodelIF2438;
irtmodelIF2437:
	local[4]= argv[0];
irtmodelIF2438:
	local[5]= fqv[27];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP2277(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[45];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2280(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[288]);
	local[1]= argv[0];
	local[2]= fqv[20];
	local[3]= argv[1];
	local[4]= env->c.clo.env2[9];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,5,local+0); /*apply*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2350(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)3L);
	ctx->vsp=local+1;
	w=(*ftab[15])(ctx,1,local+0,&ftab[15],fqv[118]); /*unit-matrix*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2351(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[59])(ctx,1,local+0,&ftab[59],fqv[582]); /*outer-product-matrix*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2371(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[20];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2372(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtmodelCLO2439,env,argv,local);
	local[1]= env->c.clo.env2[5];
	local[2]= env->c.clo.env2[6];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,3,local+0); /*mapcar*/
	local[0]= env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2440;
	local[0]= env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=(pointer)FUNCALL(ctx,1,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2441;
irtmodelIF2440:
	local[0]= NIL;
irtmodelIF2441:
	w = NIL;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2439(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[20];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2373(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[130];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2377(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
	if (w==NIL) goto irtmodelAND2442;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelAND2442:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2378(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[322]);
	local[1]= env->c.clo.env2[2];
	local[2]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= env->c.clo.env2[2];
	ctx->vsp=local+5;
	w=(*ftab[32])(ctx,2,local+3,&ftab[32],fqv[212]); /*position*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[1]= w;
	local[2]= fqv[31];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,2,local+0,&ftab[26],fqv[196]); /*reduce*/
	local[0]= w;
	local[1]= env->c.clo.env2[4];
	local[2]= argv[0];
	local[3]= env->c.clo.env2[3];
	ctx->vsp=local+4;
	w=(*ftab[32])(ctx,2,local+2,&ftab[32],fqv[212]); /*position*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[0]= (pointer)get_sym_func(fqv[322]);
	local[1]= env->c.clo.env2[2];
	local[2]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= env->c.clo.env2[2];
	ctx->vsp=local+5;
	w=(*ftab[32])(ctx,2,local+3,&ftab[32],fqv[212]); /*position*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[1]= w;
	local[2]= fqv[31];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,2,local+0,&ftab[26],fqv[196]); /*reduce*/
	local[0]= w;
	local[1]= env->c.clo.env2[4];
	local[2]= argv[0];
	local[3]= env->c.clo.env2[3];
	ctx->vsp=local+4;
	w=(*ftab[32])(ctx,2,local+2,&ftab[32],fqv[212]); /*position*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeflt(-1.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2382(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
	if (w==NIL) goto irtmodelAND2443;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelAND2443:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2386(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(5.0000000000000000000000e-01);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[20];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= fqv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2393(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[20];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*all-child-links*/
static pointer irtmodelF748all_child_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmodelENT2446;}
	local[0]= (pointer)get_sym_func(fqv[566]);
irtmodelENT2446:
irtmodelENT2445:
	if (n>2) maerror();
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelCLO2447,env,argv,local);
	local[2]= argv[0];
	local[3]= fqv[547];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2448,env,argv,local);
	local[3]= argv[0];
	local[4]= fqv[547];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAPCAN(ctx,2,local+2); /*mapcan*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	local[0]= w;
irtmodelBLK2444:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2447(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	if (w==NIL) goto irtmodelIF2449;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtmodelIF2450;
irtmodelIF2449:
	local[0]= NIL;
irtmodelIF2450:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2448(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[0];
	ctx->vsp=local+2;
	w=(pointer)irtmodelF748all_child_links(ctx,2,local+0); /*all-child-links*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*calc-dif-with-axis*/
static pointer irtmodelF749calc_dif_with_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT2455;}
	local[0]= NIL;
irtmodelENT2455:
	if (n>=4) { local[1]=(argv[3]); goto irtmodelENT2454;}
	local[1]= NIL;
irtmodelENT2454:
	if (n>=5) { local[2]=(argv[4]); goto irtmodelENT2453;}
	local[2]= NIL;
irtmodelENT2453:
irtmodelENT2452:
	if (n>5) maerror();
	local[3]= argv[1];
	local[4]= local[3];
	w = fqv[583];
	if (memq(local[4],w)==NIL) goto irtmodelIF2456;
	if (local[2]==NIL) goto irtmodelIF2458;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	goto irtmodelIF2459;
irtmodelIF2458:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,2,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2459:
	goto irtmodelIF2457;
irtmodelIF2456:
	local[4]= local[3];
	w = fqv[584];
	if (memq(local[4],w)==NIL) goto irtmodelIF2460;
	if (local[2]==NIL) goto irtmodelIF2462;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	goto irtmodelIF2463;
irtmodelIF2462:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,2,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2463:
	goto irtmodelIF2461;
irtmodelIF2460:
	local[4]= local[3];
	w = fqv[585];
	if (memq(local[4],w)==NIL) goto irtmodelIF2464;
	if (local[2]==NIL) goto irtmodelIF2466;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	goto irtmodelIF2467;
irtmodelIF2466:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,2,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2467:
	goto irtmodelIF2465;
irtmodelIF2464:
	local[4]= local[3];
	w = fqv[586];
	if (memq(local[4],w)==NIL) goto irtmodelIF2468;
	if (local[1]==NIL) goto irtmodelIF2470;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[1];
	goto irtmodelIF2471;
irtmodelIF2470:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,1,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2471:
	goto irtmodelIF2469;
irtmodelIF2468:
	local[4]= local[3];
	w = fqv[587];
	if (memq(local[4],w)==NIL) goto irtmodelIF2472;
	if (local[1]==NIL) goto irtmodelIF2474;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[1];
	goto irtmodelIF2475;
irtmodelIF2474:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,1,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2475:
	goto irtmodelIF2473;
irtmodelIF2472:
	local[4]= local[3];
	w = fqv[588];
	if (memq(local[4],w)==NIL) goto irtmodelIF2476;
	if (local[1]==NIL) goto irtmodelIF2478;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[1];
	goto irtmodelIF2479;
irtmodelIF2478:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,1,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2479:
	goto irtmodelIF2477;
irtmodelIF2476:
	local[4]= local[3];
	if (fqv[194]!=local[4]) goto irtmodelIF2480;
	if (local[0]==NIL) goto irtmodelIF2482;
	local[4]= local[0];
	goto irtmodelIF2483;
irtmodelIF2482:
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,0,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2483:
	goto irtmodelIF2481;
irtmodelIF2480:
	local[4]= local[3];
	w = fqv[589];
	if (memq(local[4],w)==NIL) goto irtmodelIF2484;
	local[4]= argv[0];
	goto irtmodelIF2485;
irtmodelIF2484:
	if (T==NIL) goto irtmodelIF2486;
	local[4]= argv[0];
	goto irtmodelIF2487;
irtmodelIF2486:
	local[4]= NIL;
irtmodelIF2487:
irtmodelIF2485:
irtmodelIF2481:
irtmodelIF2477:
irtmodelIF2473:
irtmodelIF2469:
irtmodelIF2465:
irtmodelIF2461:
irtmodelIF2457:
	w = local[4];
	local[0]= w;
irtmodelBLK2451:
	ctx->vsp=local; return(local[0]);}

/*calc-target-joint-dimension*/
static pointer irtmodelF750calc_target_joint_dimension(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= NIL;
	local[2]= argv[0];
irtmodelWHL2489:
	if (local[2]==NIL) goto irtmodelWHX2490;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[0];
	local[4]= local[1];
	local[5]= fqv[31];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[0] = w;
	goto irtmodelWHL2489;
irtmodelWHX2490:
	local[3]= NIL;
irtmodelBLK2491:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK2488:
	ctx->vsp=local; return(local[0]);}

/*calc-joint-angle-min-max-for-limit-calculation*/
static pointer irtmodelF751calc_joint_angle_min_max_for_limit_calculation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VECTORP(ctx,1,local+0); /*vectorp*/
	if (w==NIL) goto irtmodelCON2494;
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[20];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[23];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)2L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= w;
	goto irtmodelCON2493;
irtmodelCON2494:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[20];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[23];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)2L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= w;
	goto irtmodelCON2493;
irtmodelCON2495:
	local[0]= NIL;
irtmodelCON2493:
	w = argv[2];
	local[0]= w;
irtmodelBLK2492:
	ctx->vsp=local; return(local[0]);}

/*joint-angle-limit-weight*/
static pointer irtmodelF752joint_angle_limit_weight(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmodelENT2498;}
	local[0]= loadglobal(fqv[5]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+1); /*calc-target-joint-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
irtmodelENT2498:
irtmodelENT2497:
	if (n>2) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+5); /*calc-target-joint-dimension*/
	local[5]= w;
irtmodelWHL2499:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtmodelWHX2500;
	local[6]= argv[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)irtmodelF751calc_joint_angle_min_max_for_limit_calculation(ctx,3,local+7); /*calc-joint-angle-min-max-for-limit-calculation*/
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[3];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,1,local+10,&ftab[6],fqv[48]); /*deg2rad*/
	local[10]= w;
	local[11]= local[6];
	local[12]= fqv[20];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VECTORP(ctx,1,local+11); /*vectorp*/
	if (w==NIL) goto irtmodelIF2502;
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[2] = w;
	local[11]= local[2];
	local[12]= local[6];
	local[13]= fqv[20];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto irtmodelIF2504;
	local[2] = makeint((eusinteger_t)0L);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[1] = w;
	local[11]= local[1];
	goto irtmodelIF2505;
irtmodelIF2504:
	local[11]= NIL;
irtmodelIF2505:
	goto irtmodelIF2503;
irtmodelIF2502:
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[1] = w;
	local[11]= local[1];
irtmodelIF2503:
	local[11]= local[7];
	local[12]= local[8];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	local[11]= w;
	if (w==NIL) goto irtmodelAND2508;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	local[11]= w;
irtmodelAND2508:
	if (local[11]!=NIL) goto irtmodelCON2506;
irtmodelCON2507:
	local[11]= local[7];
	local[12]= local[8];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelCON2509;
	local[11]= local[8];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[7] = w;
	local[11]= local[7];
	goto irtmodelCON2506;
irtmodelCON2509:
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelCON2510;
	local[11]= local[9];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[7] = w;
	local[11]= local[7];
	goto irtmodelCON2506;
irtmodelCON2510:
	local[11]= NIL;
irtmodelCON2506:
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	if (fqv[591]==local[11]) goto irtmodelOR2513;
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	if (fqv[592]==local[11]) goto irtmodelOR2513;
	goto irtmodelCON2512;
irtmodelOR2513:
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtmodelCON2515;
	local[11]= local[8];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	goto irtmodelCON2514;
irtmodelCON2515:
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtmodelCON2516;
	local[11]= local[9];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	goto irtmodelCON2514;
irtmodelCON2516:
	local[11]= makeflt(0.0000000000000000000000e+00);
	goto irtmodelCON2514;
irtmodelCON2517:
	local[11]= NIL;
irtmodelCON2514:
	local[12]= local[7];
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmodelIF2518;
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)ABS(ctx,1,local+12); /*abs*/
	local[12]= w;
	goto irtmodelIF2519;
irtmodelIF2518:
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)ABS(ctx,1,local+12); /*abs*/
	local[12]= w;
irtmodelIF2519:
	local[13]= local[0];
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)2L);
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= makeint((eusinteger_t)2L);
	ctx->vsp=local+17;
	w=(*ftab[28])(ctx,2,local+15,&ftab[28],fqv[201]); /*expt*/
	local[15]= w;
	local[16]= makeint((eusinteger_t)2L);
	local[17]= local[7];
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)MINUS(ctx,2,local+17); /*-*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= makeint((eusinteger_t)4L);
	local[17]= local[12];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	local[18]= local[7];
	local[19]= local[7];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MINUS(ctx,2,local+17); /*-*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(*ftab[28])(ctx,2,local+17,&ftab[28],fqv[201]); /*expt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)QUOTIENT(ctx,2,local+15); /*/*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)ABS(ctx,1,local+15); /*abs*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SETELT(ctx,3,local+13); /*setelt*/
	local[11]= w;
	goto irtmodelCON2511;
irtmodelCON2512:
	local[11]= local[7];
	local[12]= local[8];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelCON2520;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelCON2520;
	local[11]= local[0];
	local[12]= local[4];
	local[13]= loadglobal(fqv[64]);
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
	goto irtmodelCON2511;
irtmodelCON2520:
	local[11]= local[8];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[201]); /*expt*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)2L);
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= local[8];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,3,local+12); /*-*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= makeint((eusinteger_t)4L);
	local[13]= local[8];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(*ftab[28])(ctx,2,local+13,&ftab[28],fqv[201]); /*expt*/
	local[13]= w;
	local[14]= local[7];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(*ftab[28])(ctx,2,local+14,&ftab[28],fqv[201]); /*expt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,3,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ABS(ctx,1,local+11); /*abs*/
	local[11]= w;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmodelIF2522;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)LESSP(ctx,2,local+12); /*<*/
	if (w==NIL) goto irtmodelIF2522;
	local[11] = makeflt(0.0000000000000000000000e+00);
	local[12]= local[11];
	goto irtmodelIF2523;
irtmodelIF2522:
	local[12]= NIL;
irtmodelIF2523:
	local[12]= local[0];
	local[13]= local[4];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[11]= w;
	goto irtmodelCON2511;
irtmodelCON2521:
	local[11]= NIL;
irtmodelCON2511:
	w = local[11];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtmodelWHL2499;
irtmodelWHX2500:
	local[6]= NIL;
irtmodelBLK2501:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK2496:
	ctx->vsp=local; return(local[0]);}

/*joint-angle-limit-nspace*/
static pointer irtmodelF753joint_angle_limit_nspace(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmodelENT2526;}
	local[0]= loadglobal(fqv[5]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+1); /*calc-target-joint-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
irtmodelENT2526:
irtmodelENT2525:
	if (n>2) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)irtmodelF750calc_target_joint_dimension(ctx,1,local+5); /*calc-target-joint-dimension*/
	local[5]= w;
irtmodelWHL2527:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtmodelWHX2528;
	local[6]= argv[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)irtmodelF751calc_joint_angle_min_max_for_limit_calculation(ctx,3,local+7); /*calc-joint-angle-min-max-for-limit-calculation*/
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[3];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,1,local+10,&ftab[6],fqv[48]); /*deg2rad*/
	local[10]= w;
	local[11]= local[6];
	local[12]= fqv[20];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VECTORP(ctx,1,local+11); /*vectorp*/
	if (w==NIL) goto irtmodelIF2530;
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[2] = w;
	local[11]= local[2];
	local[12]= local[6];
	local[13]= fqv[20];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto irtmodelIF2532;
	local[2] = makeint((eusinteger_t)0L);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[1] = w;
	local[11]= local[1];
	goto irtmodelIF2533;
irtmodelIF2532:
	local[11]= NIL;
irtmodelIF2533:
	goto irtmodelIF2531;
irtmodelIF2530:
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[1] = w;
	local[11]= local[1];
irtmodelIF2531:
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	if (fqv[591]==local[11]) goto irtmodelOR2536;
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	if (fqv[592]==local[11]) goto irtmodelOR2536;
	goto irtmodelCON2535;
irtmodelOR2536:
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtmodelCON2538;
	local[11]= local[8];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	goto irtmodelCON2537;
irtmodelCON2538:
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtmodelCON2539;
	local[11]= local[9];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	goto irtmodelCON2537;
irtmodelCON2539:
	local[11]= makeflt(0.0000000000000000000000e+00);
	goto irtmodelCON2537;
irtmodelCON2540:
	local[11]= NIL;
irtmodelCON2537:
	local[12]= local[0];
	local[13]= local[4];
	local[14]= local[7];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtmodelIF2541;
	local[14]= local[11];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= local[8];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)MINUS(ctx,2,local+15); /*-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	goto irtmodelIF2542;
irtmodelIF2541:
	local[14]= local[11];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= makeflt(5.0000000000000000000000e+00);
	local[16]= local[11];
	local[17]= local[9];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
irtmodelIF2542:
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[11]= w;
	goto irtmodelCON2534;
irtmodelCON2535:
	local[11]= local[0];
	local[12]= local[4];
	local[13]= local[8];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	local[14]= local[8];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
	goto irtmodelCON2534;
irtmodelCON2543:
	local[11]= NIL;
irtmodelCON2534:
	local[11]= local[0];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[60])(ctx,1,local+11,&ftab[60],fqv[593]); /*plusp*/
	if (w==NIL) goto irtmodelIF2544;
	local[11]= makeint((eusinteger_t)1L);
	goto irtmodelIF2545;
irtmodelIF2544:
	local[11]= makeint((eusinteger_t)-1L);
irtmodelIF2545:
	local[12]= local[0];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[201]); /*expt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmodelAND2549;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)LESSP(ctx,2,local+12); /*<*/
	if (w==NIL) goto irtmodelAND2549;
	goto irtmodelOR2548;
irtmodelAND2549:
	local[12]= local[11];
	if (loadglobal(fqv[64])==local[12]) goto irtmodelOR2548;
	local[12]= local[11];
	if (loadglobal(fqv[63])==local[12]) goto irtmodelOR2548;
	goto irtmodelIF2546;
irtmodelOR2548:
	local[11] = makeflt(0.0000000000000000000000e+00);
	local[12]= local[11];
	goto irtmodelIF2547;
irtmodelIF2546:
	local[12]= NIL;
irtmodelIF2547:
	local[12]= local[0];
	local[13]= local[4];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtmodelWHL2527;
irtmodelWHX2528:
	local[6]= NIL;
irtmodelBLK2529:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK2524:
	ctx->vsp=local; return(local[0]);}

/*calc-jacobian-from-link-list-including-robot-and-obj-virtual-joint*/
static pointer irtmodelF754calc_jacobian_from_link_list_including_robot_and_obj_virtual_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[594], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2551;
	local[0] = fqv[595];
irtmodelKEY2551:
	if (n & (1<<1)) goto irtmodelKEY2552;
	local[1] = fqv[596];
irtmodelKEY2552:
	if (n & (1<<2)) goto irtmodelKEY2553;
	local[3]= argv[3];
	local[4]= fqv[210];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	local[4]= argv[3];
	local[5]= fqv[211];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[23])(ctx,2,local+3,&ftab[23],fqv[166]); /*make-matrix*/
	local[2] = w;
irtmodelKEY2553:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtmodelCLO2554,env,argv,local);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= NIL;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO2555,env,argv,local);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[54])(ctx,2,local+4,&ftab[54],fqv[548]); /*remove*/
	local[4]= w;
	local[5]= argv[3];
	local[6]= fqv[211];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[3];
	local[7]= fqv[299];
	local[8]= local[4];
	local[9]= fqv[597];
	local[10]= local[5];
	local[11]= fqv[272];
	local[12]= local[2];
	local[13]= fqv[598];
	local[14]= argv[1];
	local[15]= fqv[300];
	local[16]= argv[2];
	local[17]= fqv[409];
	local[18]= local[0];
	local[19]= fqv[335];
	local[20]= local[1];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,15,local+6); /*send*/
	local[6]= argv[3];
	local[7]= fqv[299];
	local[8]= local[3];
	local[9]= fqv[300];
	local[10]= argv[1];
	local[11]= fqv[272];
	local[12]= local[2];
	local[13]= fqv[409];
	local[14]= local[0];
	local[15]= fqv[335];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,11,local+6); /*send*/
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(*ftab[29])(ctx,1,local+7,&ftab[29],fqv[204]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
irtmodelWHL2556:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX2557;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[29])(ctx,1,local+9,&ftab[29],fqv[204]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
irtmodelWHL2559:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtmodelWHX2560;
	local[10]= local[2];
	local[11]= local[6];
	local[12]= local[5];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[13]= makeflt(-1.0000000000000000000000e+00);
	local[14]= local[2];
	local[15]= local[6];
	local[16]= local[5];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,3,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ASET(ctx,4,local+10); /*aset*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtmodelWHL2559;
irtmodelWHX2560:
	local[10]= NIL;
irtmodelBLK2561:
	w = NIL;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL2556;
irtmodelWHX2557:
	local[8]= NIL;
irtmodelBLK2558:
	w = NIL;
	w = local[2];
	local[0]= w;
irtmodelBLK2550:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2554(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtmodelCLO2562,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[55])(ctx,2,local+0,&ftab[55],fqv[561]); /*remove-if-not*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2562(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env0->c.clo.env1[3];
	local[2]= fqv[136];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[124]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2555(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtmodelCLO2563,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[599]); /*remove-if*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2563(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env0->c.clo.env1[3];
	local[2]= fqv[136];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[124]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*append-obj-virtual-joint*/
static pointer irtmodelF755append_obj_virtual_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[600], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2565;
	local[0] = loadglobal(fqv[601]);
irtmodelKEY2565:
	if (n & (1<<1)) goto irtmodelKEY2566;
	local[1] = NIL;
irtmodelKEY2566:
	if (n & (1<<2)) goto irtmodelKEY2567;
	local[2] = NIL;
irtmodelKEY2567:
	if (n & (1<<3)) goto irtmodelKEY2568;
	local[3] = NIL;
irtmodelKEY2568:
	if (n & (1<<4)) goto irtmodelKEY2569;
	local[4] = NIL;
irtmodelKEY2569:
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelFLET2570,env,argv,local);
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtmodelCLO2571,env,argv,local);
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	if (local[2]==NIL) goto irtmodelIF2572;
	local[7]= local[2];
	goto irtmodelIF2573;
irtmodelIF2572:
	local[7]= fqv[602];
	if (local[3]==NIL) goto irtmodelIF2574;
	local[8]= local[3];
	goto irtmodelIF2575;
irtmodelIF2574:
	local[8]= makeint((eusinteger_t)1L);
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	if (w!=local[8]) goto irtmodelIF2576;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[153];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	goto irtmodelIF2577;
irtmodelIF2576:
	local[8]= (pointer)get_sym_func(fqv[603]);
	local[9]= makeflt(5.0000000000000000000000e-01);
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,3,local+8); /*apply*/
	local[8]= w;
irtmodelIF2577:
irtmodelIF2575:
	w = local[5];
	ctx->vsp=local+9;
	w=irtmodelFLET2570(ctx,2,local+7,w);
	local[7]= w;
irtmodelIF2573:
	local[8]= fqv[604];
	if (local[4]==NIL) goto irtmodelIF2578;
	local[9]= local[4];
	goto irtmodelIF2579;
irtmodelIF2578:
	local[9]= local[7];
	local[10]= fqv[153];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
irtmodelIF2579:
	w = local[5];
	ctx->vsp=local+10;
	w=irtmodelFLET2570(ctx,2,local+8,w);
	local[8]= w;
	local[9]= NIL;
	local[10]= local[6];
irtmodelWHL2580:
	if (local[10]==NIL) goto irtmodelWHX2581;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[8];
	local[12]= fqv[298];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	goto irtmodelWHL2580;
irtmodelWHX2581:
	local[11]= NIL;
irtmodelBLK2582:
	w = NIL;
	local[9]= local[7];
	local[10]= fqv[298];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= local[8];
	local[10]= loadglobal(fqv[213]);
	local[11]= fqv[131];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,1,local+12); /*instantiate*/
	local[12]= w;
	local[13]= (pointer)get_sym_func(fqv[288]);
	local[14]= local[12];
	local[15]= fqv[36];
	local[16]= fqv[130];
	local[17]= local[8];
	local[18]= fqv[133];
	local[19]= local[7];
	local[20]= local[1];
	ctx->vsp=local+21;
	w=(pointer)APPLY(ctx,8,local+13); /*apply*/
	w = local[12];
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SENDMESSAGE(ctx,4,local+9); /*send-message*/
	local[9]= local[8];
	local[10]= fqv[132];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= local[7];
	local[10]= fqv[134];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtmodelCLO2583,env,argv,local);
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[0]= w;
irtmodelBLK2564:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2570(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[213]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[36];
	local[3]= fqv[120];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(*ftab[40])(ctx,2,local+3,&ftab[40],fqv[297]); /*make-cascoords*/
	local[3]= w;
	local[4]= fqv[127];
	local[5]= makeint((eusinteger_t)10L);
	local[6]= makeint((eusinteger_t)10L);
	local[7]= makeint((eusinteger_t)10L);
	ctx->vsp=local+8;
	w=(*ftab[62])(ctx,3,local+5,&ftab[62],fqv[605]); /*make-cube*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[3];
	local[7]= argv[0];
	local[8]= fqv[273];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= fqv[257];
	local[11]= fqv[606];
	local[12]= fqv[607];
	local[13]= makeint((eusinteger_t)3L);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(*ftab[23])(ctx,2,local+13,&ftab[23],fqv[166]); /*make-matrix*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,13,local+1); /*send*/
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2571(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[120];
	local[1]= argv[0];
	local[2]= fqv[153];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,2,local+0,&ftab[40],fqv[297]); /*make-cascoords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2583(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[8];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*append-multiple-obj-virtual-joint*/
static pointer irtmodelF756append_multiple_obj_virtual_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[608], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2585;
	local[0] = fqv[609];
irtmodelKEY2585:
	if (n & (1<<1)) goto irtmodelKEY2586;
	local[1] = fqv[610];
irtmodelKEY2586:
	if (n & (1<<2)) goto irtmodelKEY2587;
	local[2] = NIL;
irtmodelKEY2587:
	if (n & (1<<3)) goto irtmodelKEY2588;
	local[3] = NIL;
irtmodelKEY2588:
	if (n & (1<<4)) goto irtmodelKEY2589;
	local[4] = NIL;
irtmodelKEY2589:
	local[5]= argv[0];
	local[6]= local[2];
	local[7]= local[3];
	local[8]= NIL;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtmodelCLO2590,env,argv,local);
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,3,local+9); /*mapcar*/
	w = local[8];
	local[0]= w;
irtmodelBLK2584:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2590(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env2[5];
	local[1]= env->c.clo.env1[1];
	local[2]= fqv[611];
	local[3]= argv[0];
	local[4]= fqv[612];
	local[5]= argv[1];
	local[6]= fqv[613];
	local[7]= env->c.clo.env2[6];
	local[8]= fqv[614];
	local[9]= env->c.clo.env2[7];
	local[10]= fqv[615];
	local[11]= env->c.clo.env2[4];
	ctx->vsp=local+12;
	w=(pointer)irtmodelF755append_obj_virtual_joint(ctx,12,local+0); /*append-obj-virtual-joint*/
	env->c.clo.env2[8] = w;
	w=env->c.clo.env2[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	env->c.clo.env2[5] = (w)->c.cons.car;
	w=env->c.clo.env2[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(*ftab[38])(ctx,1,local+0,&ftab[38],fqv[291]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	env->c.clo.env2[6] = (w)->c.cons.car;
	w = env->c.clo.env2[6];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*with-difference-position-and-rotation*/
static pointer irtmodelF2591(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2593:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	local[5]= fqv[527];
	local[6]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= local[2];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[63])(ctx,1,local+8,&ftab[63],fqv[616]); /*cadddr*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[4];
	local[9]= fqv[335];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelIF2594;
	local[9]= fqv[335];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	goto irtmodelIF2595;
irtmodelIF2594:
	local[9]= T;
irtmodelIF2595:
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[3];
	local[10]= fqv[409];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,2,local+10,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelIF2596;
	local[10]= fqv[409];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,2,local+10,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	goto irtmodelIF2597;
irtmodelIF2596:
	local[10]= T;
irtmodelIF2597:
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[288];
	local[10]= local[1];
	local[11]= fqv[571];
	local[12]= local[2];
	local[13]= fqv[335];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[288];
	local[11]= local[1];
	local[12]= fqv[572];
	local[13]= local[2];
	local[14]= fqv[409];
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[0];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	local[0]= w;
irtmodelBLK2592:
	ctx->vsp=local; return(local[0]);}

/*with-difference-positions-and-rotations*/
static pointer irtmodelF2598(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2600:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	local[5]= fqv[577];
	local[6]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= local[2];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[63])(ctx,1,local+8,&ftab[63],fqv[616]); /*cadddr*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[4];
	local[9]= fqv[617];
	local[10]= fqv[335];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,2,local+10,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[335];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(*ftab[16])(ctx,2,local+11,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[208];
	local[13]= fqv[426];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[209];
	local[15]= fqv[618];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[3];
	local[10]= fqv[617];
	local[11]= fqv[409];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(*ftab[16])(ctx,2,local+11,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[409];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(*ftab[16])(ctx,2,local+12,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[208];
	local[14]= fqv[426];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	local[15]= fqv[209];
	local[16]= fqv[618];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[619];
	local[10]= fqv[516];
	local[11]= fqv[517];
	local[12]= fqv[620];
	local[13]= fqv[621];
	local[14]= fqv[622];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[288];
	local[14]= fqv[620];
	local[15]= fqv[571];
	local[16]= fqv[621];
	local[17]= fqv[335];
	local[18]= fqv[622];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[1];
	local[12]= local[2];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[619];
	local[11]= fqv[516];
	local[12]= fqv[517];
	local[13]= fqv[620];
	local[14]= fqv[621];
	local[15]= fqv[623];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[288];
	local[15]= fqv[620];
	local[16]= fqv[572];
	local[17]= fqv[621];
	local[18]= fqv[409];
	local[19]= fqv[623];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[1];
	local[13]= local[2];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[0];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	local[0]= w;
irtmodelBLK2599:
	ctx->vsp=local; return(local[0]);}

/*with-move-target-link-list*/
static pointer irtmodelF2601(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2603:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	local[5]= fqv[577];
	local[6]= local[3];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= local[4];
	local[8]= fqv[617];
	local[9]= fqv[624];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[63])(ctx,1,local+10,&ftab[63],fqv[616]); /*cadddr*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[521];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[63])(ctx,1,local+11,&ftab[63],fqv[616]); /*cadddr*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[63])(ctx,1,local+11,&ftab[63],fqv[616]); /*cadddr*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[1];
	local[9]= fqv[625];
	local[10]= fqv[300];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,2,local+10,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[617];
	local[12]= fqv[624];
	local[13]= fqv[300];
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(*ftab[16])(ctx,2,local+13,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[521];
	local[14]= fqv[300];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(*ftab[16])(ctx,2,local+14,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[300];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(*ftab[16])(ctx,2,local+14,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[618];
	local[12]= fqv[619];
	local[13]= fqv[516];
	local[14]= fqv[517];
	local[15]= fqv[626];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	local[15]= w;
	local[16]= fqv[288];
	local[17]= local[3];
	local[18]= fqv[626];
	local[19]= fqv[627];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[2];
	local[10]= fqv[619];
	local[11]= fqv[516];
	local[12]= fqv[517];
	local[13]= fqv[628];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	local[14]= fqv[288];
	local[15]= local[3];
	local[16]= fqv[260];
	local[17]= fqv[288];
	local[18]= fqv[628];
	local[19]= fqv[214];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[0];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	local[0]= w;
irtmodelBLK2602:
	ctx->vsp=local; return(local[0]);}

/*with-append-root-joint*/
static pointer irtmodelF2604(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2606:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GENSYM(ctx,0,local+5); /*gensym*/
	local[5]= w;
	local[6]= fqv[512];
	local[7]= fqv[527];
	local[8]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[2];
	local[10]= fqv[617];
	local[11]= fqv[567];
	local[12]= fqv[516];
	local[13]= fqv[629];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[521];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= local[5];
	local[11]= fqv[612];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(*ftab[16])(ctx,2,local+11,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[527];
	local[10]= local[3];
	local[11]= fqv[511];
	local[12]= fqv[213];
	local[13]= fqv[36];
	local[14]= fqv[297];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	local[14]= w;
	local[15]= fqv[127];
	local[16]= fqv[521];
	local[17]= fqv[605];
	local[18]= fqv[630];
	local[19]= fqv[631];
	local[20]= fqv[632];
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,1,local+20); /*list*/
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= fqv[3];
	local[18]= fqv[459];
	local[19]= fqv[633];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	local[18]= cons(ctx,local[18],w);
	local[19]= fqv[273];
	local[20]= fqv[634];
	local[21]= fqv[257];
	local[22]= fqv[5];
	local[23]= fqv[635];
	local[24]= fqv[636];
	local[25]= fqv[637];
	ctx->vsp=local+26;
	w=(pointer)LIST(ctx,1,local+25); /*list*/
	ctx->vsp=local+25;
	w = cons(ctx,local[24],w);
	ctx->vsp=local+24;
	w = cons(ctx,local[23],w);
	ctx->vsp=local+23;
	local[22]= cons(ctx,local[22],w);
	local[23]= fqv[607];
	local[24]= fqv[166];
	local[25]= fqv[638];
	local[26]= fqv[639];
	ctx->vsp=local+27;
	w=(pointer)LIST(ctx,1,local+26); /*list*/
	ctx->vsp=local+26;
	w = cons(ctx,local[25],w);
	ctx->vsp=local+25;
	local[24]= cons(ctx,local[24],w);
	ctx->vsp=local+25;
	w=(pointer)LIST(ctx,1,local+24); /*list*/
	ctx->vsp=local+24;
	w = cons(ctx,local[23],w);
	ctx->vsp=local+23;
	w = cons(ctx,local[22],w);
	ctx->vsp=local+22;
	w = cons(ctx,local[21],w);
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[4];
	local[12]= fqv[640];
	local[13]= fqv[288];
	local[14]= local[1];
	local[15]= fqv[136];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[34];
	local[12]= local[4];
	local[13]= fqv[213];
	local[14]= fqv[131];
	local[15]= fqv[641];
	local[16]= fqv[611];
	local[17]= argv[0];
	ctx->vsp=local+18;
	w=(*ftab[16])(ctx,2,local+16,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (local[16]!=NIL) goto irtmodelOR2607;
	local[16]= loadglobal(fqv[601]);
irtmodelOR2607:
	local[17]= fqv[36];
	local[18]= fqv[130];
	local[19]= local[1];
	local[20]= fqv[133];
	local[21]= local[3];
	local[22]= local[5];
	ctx->vsp=local+23;
	w=(pointer)LIST(ctx,1,local+22); /*list*/
	ctx->vsp=local+22;
	w = cons(ctx,local[21],w);
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[288];
	local[13]= local[4];
	local[14]= fqv[132];
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[288];
	local[14]= local[3];
	local[15]= fqv[134];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[642];
	local[15]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[619];
	local[18]= fqv[516];
	local[19]= fqv[517];
	local[20]= fqv[643];
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,1,local+20); /*list*/
	local[20]= w;
	local[21]= fqv[88];
	local[22]= local[4];
	local[23]= fqv[643];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	ctx->vsp=local+23;
	w = cons(ctx,local[22],w);
	ctx->vsp=local+22;
	local[21]= cons(ctx,local[21],w);
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,1,local+21); /*list*/
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	local[19]= cons(ctx,local[19],w);
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	local[18]= cons(ctx,local[18],w);
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	local[16]= w;
	local[17]= local[0];
	local[18]= NIL;
	ctx->vsp=local+19;
	w=(pointer)APPEND(ctx,2,local+17); /*append*/
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	local[16]= fqv[288];
	local[17]= local[4];
	local[18]= fqv[644];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= fqv[288];
	local[18]= local[4];
	local[19]= fqv[645];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	local[18]= fqv[288];
	local[19]= local[3];
	local[20]= fqv[646];
	local[21]= local[4];
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,1,local+21); /*list*/
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	local[18]= cons(ctx,local[18],w);
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	local[0]= w;
irtmodelBLK2605:
	ctx->vsp=local; return(local[0]);}

/*with-assoc-move-target*/
static pointer irtmodelF2608(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2610:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	local[3]= fqv[527];
	local[4]= local[1];
	local[5]= fqv[617];
	local[6]= fqv[624];
	local[7]= fqv[300];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[16])(ctx,2,local+7,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[521];
	local[8]= fqv[300];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[300];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[2];
	local[6]= fqv[617];
	local[7]= fqv[624];
	local[8]= fqv[133];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[521];
	local[9]= fqv[133];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[133];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[457];
	local[6]= local[1];
	local[7]= fqv[619];
	local[8]= fqv[516];
	local[9]= fqv[517];
	local[10]= fqv[647];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	local[11]= fqv[297];
	local[12]= fqv[120];
	local[13]= fqv[288];
	local[14]= fqv[647];
	local[15]= fqv[153];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[619];
	local[7]= fqv[516];
	local[8]= fqv[517];
	local[9]= fqv[648];
	local[10]= fqv[647];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[288];
	local[11]= fqv[648];
	local[12]= fqv[298];
	local[13]= fqv[647];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[2];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[642];
	local[8]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	local[10]= local[0];
	local[11]= NIL;
	ctx->vsp=local+12;
	w=(pointer)APPEND(ctx,2,local+10); /*append*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[619];
	local[10]= fqv[516];
	local[11]= fqv[517];
	local[12]= fqv[649];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	local[13]= fqv[288];
	local[14]= fqv[288];
	local[15]= fqv[649];
	local[16]= fqv[214];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	local[15]= fqv[301];
	local[16]= fqv[649];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
irtmodelBLK2609:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-validity-check-one*/
static pointer irtmodelF757eusmodel_validity_check_one(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[136];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
irtmodelWHL2612:
	local[1]= local[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtmodelWHX2613;
	local[1]= loadglobal(fqv[176]);
	local[2]= NIL;
	local[3]= fqv[650];
	local[4]= local[0];
	local[5]= local[0];
	local[6]= fqv[133];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= loadglobal(fqv[176]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[1]= fqv[651];
	ctx->vsp=local+2;
	w=(*ftab[64])(ctx,1,local+1,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2612;
irtmodelWHX2613:
	local[1]= NIL;
irtmodelBLK2614:
irtmodelWHL2615:
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[214];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)EQUAL(ctx,2,local+1); /*equal*/
	if (w!=NIL) goto irtmodelWHX2616;
	local[1]= loadglobal(fqv[176]);
	local[2]= NIL;
	local[3]= fqv[653];
	local[4]= local[0];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= loadglobal(fqv[176]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[1]= fqv[654];
	ctx->vsp=local+2;
	w=(*ftab[64])(ctx,1,local+1,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2615;
irtmodelWHX2616:
	local[1]= NIL;
irtmodelBLK2617:
	w = local[1];
	local[0]= (pointer)get_sym_func(fqv[655]);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelCLO2618,env,argv,local);
	local[2]= argv[0];
	local[3]= fqv[656];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[55])(ctx,2,local+1,&ftab[55],fqv[561]); /*remove-if-not*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[657];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[47])(ctx,1,local+0,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[655]);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2619,env,argv,local);
	local[3]= argv[0];
	local[4]= fqv[656];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[55])(ctx,2,local+2,&ftab[55],fqv[561]); /*remove-if-not*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[136];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[47])(ctx,1,local+1,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[1]= w;
irtmodelWHL2620:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[2]= (pointer)((eusinteger_t)local[2] + (eusinteger_t)w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	if (w==local[2]) goto irtmodelWHX2621;
	local[2]= loadglobal(fqv[176]);
	local[3]= NIL;
	local[4]= fqv[658];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[2]= loadglobal(fqv[176]);
	ctx->vsp=local+3;
	w=(pointer)FINOUT(ctx,1,local+2); /*finish-output*/
	local[2]= fqv[659];
	ctx->vsp=local+3;
	w=(*ftab[64])(ctx,1,local+2,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2620;
irtmodelWHX2621:
	local[2]= NIL;
irtmodelBLK2622:
	local[2]= NIL;
	local[3]= local[0];
irtmodelWHL2623:
	if (local[3]==NIL) goto irtmodelWHX2624;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
irtmodelWHL2626:
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (w==NIL) goto irtmodelAND2629;
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= loadglobal(fqv[213]);
	ctx->vsp=local+6;
	w=(pointer)DERIVEDP(ctx,2,local+4); /*derivedp*/
	if (w==NIL) goto irtmodelAND2629;
	goto irtmodelWHX2627;
irtmodelAND2629:
	local[4]= loadglobal(fqv[176]);
	local[5]= NIL;
	local[6]= fqv[660];
	local[7]= local[2];
	local[8]= local[2];
	local[9]= fqv[130];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= loadglobal(fqv[176]);
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= fqv[661];
	ctx->vsp=local+5;
	w=(*ftab[64])(ctx,1,local+4,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2626;
irtmodelWHX2627:
	local[4]= NIL;
irtmodelBLK2628:
irtmodelWHL2630:
	local[4]= local[2];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (w==NIL) goto irtmodelAND2633;
	local[4]= local[2];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= loadglobal(fqv[213]);
	ctx->vsp=local+6;
	w=(pointer)DERIVEDP(ctx,2,local+4); /*derivedp*/
	if (w==NIL) goto irtmodelAND2633;
	goto irtmodelWHX2631;
irtmodelAND2633:
	local[4]= loadglobal(fqv[176]);
	local[5]= NIL;
	local[6]= fqv[662];
	local[7]= local[2];
	local[8]= local[2];
	local[9]= fqv[133];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= loadglobal(fqv[176]);
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= fqv[663];
	ctx->vsp=local+5;
	w=(*ftab[64])(ctx,1,local+4,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2630;
irtmodelWHX2631:
	local[4]= NIL;
irtmodelBLK2632:
irtmodelWHL2634:
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[133];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[546];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,2,local+4,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelAND2637;
	local[4]= local[2];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[130];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[214];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)EQUAL(ctx,2,local+4); /*equal*/
	if (w==NIL) goto irtmodelAND2637;
	goto irtmodelWHX2635;
irtmodelAND2637:
	local[4]= loadglobal(fqv[176]);
	local[5]= NIL;
	local[6]= fqv[664];
	local[7]= local[2];
	local[8]= local[2];
	local[9]= fqv[133];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[2];
	local[10]= fqv[130];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,5,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= loadglobal(fqv[176]);
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= fqv[665];
	ctx->vsp=local+5;
	w=(*ftab[64])(ctx,1,local+4,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2634;
irtmodelWHX2635:
	local[4]= NIL;
irtmodelBLK2636:
irtmodelWHL2638:
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[133];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)EQUAL(ctx,2,local+4); /*equal*/
	if (w==NIL) goto irtmodelAND2641;
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[133];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[547];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,2,local+4,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelAND2641;
	goto irtmodelWHX2639;
irtmodelAND2641:
	local[4]= loadglobal(fqv[176]);
	local[5]= NIL;
	local[6]= fqv[666];
	local[7]= local[2];
	local[8]= local[2];
	local[9]= fqv[130];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[2];
	local[10]= fqv[133];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,5,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= loadglobal(fqv[176]);
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= fqv[667];
	ctx->vsp=local+5;
	w=(*ftab[64])(ctx,1,local+4,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2638;
irtmodelWHX2639:
	local[4]= NIL;
irtmodelBLK2640:
	goto irtmodelWHL2623;
irtmodelWHX2624:
	local[4]= NIL;
irtmodelBLK2625:
	w = NIL;
	local[0]= w;
irtmodelBLK2611:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2618(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= loadglobal(fqv[28]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2619(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= loadglobal(fqv[213]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-validity-check*/
static pointer irtmodelF758eusmodel_validity_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[668];
	local[1]= fqv[669];
	ctx->vsp=local+2;
	w=(*ftab[65])(ctx,2,local+0,&ftab[65],fqv[670]); /*require*/
	ctx->vsp=local+0;
	w=(*ftab[66])(ctx,0,local+0,&ftab[66],fqv[671]); /*init-unit-test*/
	local[0]= NIL;
	storeglobal(fqv[672],local[0]);
	local[0]= fqv[673];
	local[1]= fqv[674];
	local[2]= fqv[675];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	ctx->vsp=local+1;
	w=(pointer)EVAL(ctx,1,local+0); /*eval*/
	ctx->vsp=local+0;
	w=(*ftab[67])(ctx,0,local+0,&ftab[67],fqv[676]); /*run-all-tests*/
	local[0]= w;
irtmodelBLK2642:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtmodel(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[677];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtmodelIF2643;
	local[0]= fqv[678];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[679],w);
	goto irtmodelIF2644;
irtmodelIF2643:
	local[0]= fqv[680];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtmodelIF2644:
	local[0]= fqv[681];
	ctx->vsp=local+1;
	w=(*ftab[65])(ctx,1,local+0,&ftab[65],fqv[670]); /*require*/
	local[0]= fqv[682];
	ctx->vsp=local+1;
	w=(*ftab[65])(ctx,1,local+0,&ftab[65],fqv[670]); /*require*/
	local[0]= fqv[683];
	ctx->vsp=local+1;
	w=(*ftab[65])(ctx,1,local+0,&ftab[65],fqv[670]); /*require*/
	local[0]= fqv[28];
	local[1]= fqv[684];
	local[2]= fqv[28];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[686]);
	local[5]= fqv[656];
	local[6]= fqv[687];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM759joint_init,fqv[36],fqv[28],fqv[692]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM780joint_min_angle,fqv[22],fqv[28],fqv[693]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM786joint_max_angle,fqv[23],fqv[28],fqv[694]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM792joint_parent_link,fqv[133],fqv[28],fqv[695]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM795joint_child_link,fqv[130],fqv[28],fqv[696]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM798joint_calc_dav_gain,fqv[697],fqv[28],fqv[698]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM800joint_joint_dof,fqv[31],fqv[28],fqv[699]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM802joint_speed_to_angle,fqv[311],fqv[28],fqv[700]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM805joint_angle_to_speed,fqv[590],fqv[28],fqv[701]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM808joint_calc_jacobian,fqv[229],fqv[28],fqv[702]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM811joint_joint_velocity,fqv[37],fqv[28],fqv[703]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM817joint_joint_acceleration,fqv[38],fqv[28],fqv[704]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM823joint_joint_torque,fqv[39],fqv[28],fqv[705]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM829joint_max_joint_velocity,fqv[8],fqv[28],fqv[706]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM835joint_max_joint_torque,fqv[9],fqv[28],fqv[707]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM841joint_joint_min_max_table,fqv[10],fqv[28],fqv[708]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM847joint_joint_min_max_target,fqv[11],fqv[28],fqv[709]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM853joint_joint_min_max_table_angle_interpolate,fqv[21],fqv[28],fqv[710]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM856joint_joint_min_max_table_min_angle,fqv[41],fqv[28],fqv[711]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM860joint_joint_min_max_table_max_angle,fqv[42],fqv[28],fqv[712]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[713],module,irtmodelF743calc_jacobian_default_rotate_vector,fqv[714]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[50],module,irtmodelF744calc_jacobian_rotational,fqv[715]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[61],module,irtmodelF745calc_jacobian_linear,fqv[716]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[717],module,irtmodelF746calc_angle_speed_gain_scalar,fqv[718]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[719],module,irtmodelF747calc_angle_speed_gain_vector,fqv[720]);
	local[0]= fqv[721];
	local[1]= fqv[684];
	local[2]= fqv[721];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[722];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM896rotational_joint_init,fqv[36],fqv[721],fqv[723]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM906rotational_joint_joint_angle,fqv[20],fqv[721],fqv[724]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM925rotational_joint_joint_dof,fqv[31],fqv[721],fqv[725]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM927rotational_joint_calc_angle_speed_gain,fqv[245],fqv[721],fqv[726]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM929rotational_joint_speed_to_angle,fqv[311],fqv[721],fqv[727]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM931rotational_joint_angle_to_speed,fqv[590],fqv[721],fqv[728]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM933rotational_joint_calc_jacobian,fqv[229],fqv[721],fqv[729]);
	local[0]= fqv[730];
	local[1]= fqv[684];
	local[2]= fqv[730];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[731];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM936linear_joint_init,fqv[36],fqv[730],fqv[732]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM960linear_joint_joint_angle,fqv[20],fqv[730],fqv[733]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM977linear_joint_joint_dof,fqv[31],fqv[730],fqv[734]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM979linear_joint_calc_angle_speed_gain,fqv[245],fqv[730],fqv[735]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM981linear_joint_speed_to_angle,fqv[311],fqv[730],fqv[736]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM983linear_joint_angle_to_speed,fqv[590],fqv[730],fqv[737]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM985linear_joint_calc_jacobian,fqv[229],fqv[730],fqv[738]);
	local[0]= fqv[739];
	local[1]= fqv[684];
	local[2]= fqv[739];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[740];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM988wheel_joint_init,fqv[36],fqv[739],fqv[741]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM995wheel_joint_joint_angle,fqv[20],fqv[739],fqv[742]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1006wheel_joint_joint_dof,fqv[31],fqv[739],fqv[743]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1008wheel_joint_calc_angle_speed_gain,fqv[245],fqv[739],fqv[744]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1010wheel_joint_speed_to_angle,fqv[311],fqv[739],fqv[745]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1012wheel_joint_angle_to_speed,fqv[590],fqv[739],fqv[746]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1014wheel_joint_calc_jacobian,fqv[229],fqv[739],fqv[747]);
	local[0]= fqv[748];
	local[1]= fqv[684];
	local[2]= fqv[748];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[749];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1016omniwheel_joint_init,fqv[36],fqv[748],fqv[750]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1023omniwheel_joint_joint_angle,fqv[20],fqv[748],fqv[751]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1032omniwheel_joint_joint_dof,fqv[31],fqv[748],fqv[752]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1034omniwheel_joint_calc_angle_speed_gain,fqv[245],fqv[748],fqv[753]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1036omniwheel_joint_speed_to_angle,fqv[311],fqv[748],fqv[754]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1038omniwheel_joint_angle_to_speed,fqv[590],fqv[748],fqv[755]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1040omniwheel_joint_calc_jacobian,fqv[229],fqv[748],fqv[756]);
	local[0]= fqv[757];
	local[1]= fqv[684];
	local[2]= fqv[757];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[758];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1042sphere_joint_init,fqv[36],fqv[757],fqv[759]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1049sphere_joint_joint_angle,fqv[20],fqv[757],fqv[760]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1061sphere_joint_joint_angle_rpy,fqv[761],fqv[757],fqv[762]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1070sphere_joint_joint_dof,fqv[31],fqv[757],fqv[763]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1072sphere_joint_calc_angle_speed_gain,fqv[245],fqv[757],fqv[764]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1074sphere_joint_speed_to_angle,fqv[311],fqv[757],fqv[765]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1076sphere_joint_angle_to_speed,fqv[590],fqv[757],fqv[766]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1078sphere_joint_calc_jacobian,fqv[229],fqv[757],fqv[767]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1080sphere_joint_joint_euler_angle,fqv[768],fqv[757],fqv[769]);
	local[0]= fqv[601];
	local[1]= fqv[684];
	local[2]= fqv[601];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[770];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11206dof_joint_init,fqv[36],fqv[601],fqv[771]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11306dof_joint_joint_angle,fqv[20],fqv[601],fqv[772]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11476dof_joint_joint_angle_rpy,fqv[761],fqv[601],fqv[773]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11566dof_joint_joint_dof,fqv[31],fqv[601],fqv[774]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11586dof_joint_calc_angle_speed_gain,fqv[245],fqv[601],fqv[775]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11606dof_joint_speed_to_angle,fqv[311],fqv[601],fqv[776]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11626dof_joint_angle_to_speed,fqv[590],fqv[601],fqv[777]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11646dof_joint_calc_jacobian,fqv[229],fqv[601],fqv[778]);
	local[0]= fqv[213];
	local[1]= fqv[684];
	local[2]= fqv[213];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[779]);
	local[5]= fqv[656];
	local[6]= fqv[780];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1166bodyset_link_init,fqv[36],fqv[213],fqv[781]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1173bodyset_link_worldcoords,fqv[122],fqv[213],fqv[782]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1181bodyset_link_analysis_level,fqv[149],fqv[213],fqv[783]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1187bodyset_link_weight,fqv[273],fqv[213],fqv[784]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1193bodyset_link_centroid,fqv[257],fqv[213],fqv[785]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1199bodyset_link_inertia_tensor,fqv[607],fqv[213],fqv[786]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1205bodyset_link_joint,fqv[198],fqv[213],fqv[787]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1208bodyset_link_add_joint,fqv[131],fqv[213],fqv[788]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1210bodyset_link_del_joint,fqv[644],fqv[213],fqv[789]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1212bodyset_link_parent_link,fqv[133],fqv[213],fqv[790]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1214bodyset_link_child_links,fqv[547],fqv[213],fqv[791]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1216bodyset_link_add_child_links,fqv[134],fqv[213],fqv[792]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1220bodyset_link_add_parent_link,fqv[132],fqv[213],fqv[793]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1222bodyset_link_del_child_link,fqv[646],fqv[213],fqv[794]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1224bodyset_link_del_parent_link,fqv[645],fqv[213],fqv[795]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1226bodyset_link_default_coords,fqv[796],fqv[213],fqv[797]);
	local[0]= fqv[376];
	local[1]= fqv[684];
	local[2]= fqv[376];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[121]);
	local[5]= fqv[656];
	local[6]= fqv[798];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1232cascaded_link_init,fqv[36],fqv[376],fqv[799]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1236cascaded_link_init_ending,fqv[800],fqv[376],fqv[801]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1244cascaded_link_links,fqv[136],fqv[376],fqv[802]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1247cascaded_link_joint_list,fqv[657],fqv[376],fqv[803]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1250cascaded_link_link,fqv[576],fqv[376],fqv[804]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1253cascaded_link_joint,fqv[198],fqv[376],fqv[805]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1256cascaded_link_end_coords,fqv[627],fqv[376],fqv[806]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1259cascaded_link_bodies,fqv[127],fqv[376],fqv[807]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1262cascaded_link_faces,fqv[143],fqv[376],fqv[808]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1264cascaded_link_update_descendants,fqv[135],fqv[376],fqv[809]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1267cascaded_link_angle_vector,fqv[154],fqv[376],fqv[810]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1310cascaded_link_find_link_route,fqv[147],fqv[376],fqv[811]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1318cascaded_link_link_list,fqv[260],fqv[376],fqv[812]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1324cascaded_link_make_joint_min_max_table,fqv[813],fqv[376],fqv[814]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1342cascaded_link_make_min_max_table_using_collision_check,fqv[165],fqv[376],fqv[815]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1368cascaded_link_plot_joint_min_max_table_common,fqv[188],fqv[376],fqv[816]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1382cascaded_link_plot_joint_min_max_table,fqv[817],fqv[376],fqv[818]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1401cascaded_link_calc_target_axis_dimension,fqv[210],fqv[376],fqv[819]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1418cascaded_link_calc_union_link_list,fqv[197],fqv[376],fqv[820]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1424cascaded_link_calc_target_joint_dimension,fqv[211],fqv[376],fqv[821]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1426cascaded_link_calc_inverse_jacobian,fqv[360],fqv[376],fqv[822]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1446cascaded_link_calc_gradh_from_link_list,fqv[823],fqv[376],fqv[824]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1454cascaded_link_calc_jacobian_from_link_list,fqv[299],fqv[376],fqv[825]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1527cascaded_link_calc_joint_angle_speed,fqv[307],fqv[376],fqv[826]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1568cascaded_link_calc_joint_angle_speed_gain,fqv[308],fqv[376],fqv[827]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1577cascaded_link_collision_avoidance_links,fqv[828],fqv[376],fqv[829]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1583cascaded_link_collision_avoidance_link_pair_from_link_list,fqv[337],fqv[376],fqv[830]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1630cascaded_link_collision_avoidance_calc_distance,fqv[289],fqv[376],fqv[831]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1653cascaded_link_collision_avoidance_args,fqv[296],fqv[376],fqv[832]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1659cascaded_link_collision_avoidance,fqv[362],fqv[376],fqv[833]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1696cascaded_link_move_joints,fqv[377],fqv[376],fqv[834]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1723cascaded_link_find_joint_angle_limit_weight_old_from_union_link_list,fqv[315],fqv[376],fqv[835]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1726cascaded_link_reset_joint_angle_limit_weight_old,fqv[404],fqv[376],fqv[836]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1730cascaded_link_calc_weight_from_joint_limit,fqv[325],fqv[376],fqv[837]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1759cascaded_link_calc_inverse_kinematics_weight_from_link_list,fqv[354],fqv[376],fqv[838]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1793cascaded_link_calc_nspace_from_joint_limit,fqv[329],fqv[376],fqv[839]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1802cascaded_link_calc_inverse_kinematics_nspace_from_link_list,fqv[369],fqv[376],fqv[840]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1839cascaded_link_move_joints_avoidance,fqv[433],fqv[376],fqv[841]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1913cascaded_link_inverse_kinematics_args,fqv[463],fqv[376],fqv[842]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1923cascaded_link_draw_collision_debug_view,fqv[436],fqv[376],fqv[843]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1954cascaded_link_inverse_kinematics_loop,fqv[466],fqv[376],fqv[844]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2108cascaded_link_inverse_kinematics,fqv[528],fqv[376],fqv[845]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2283cascaded_link_ik_convergence_check,fqv[414],fqv[376],fqv[846]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2297cascaded_link_calc_vel_from_pos,fqv[415],fqv[376],fqv[847]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2307cascaded_link_calc_vel_from_rot,fqv[416],fqv[376],fqv[848]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2317cascaded_link_collision_check_pairs,fqv[551],fqv[376],fqv[849]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2328cascaded_link_self_collision_check,fqv[476],fqv[376],fqv[850]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2346cascaded_link_calc_grasp_matrix,fqv[851],fqv[376],fqv[852]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2361cascaded_link_inverse_kinematics_for_closed_loop_forward_kinematics,fqv[853],fqv[376],fqv[854]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2374cascaded_link_calc_jacobian_for_interlocking_joints,fqv[855],fqv[376],fqv[856]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2379cascaded_link_calc_vel_for_interlocking_joints,fqv[857],fqv[376],fqv[858]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2383cascaded_link_set_midpoint_for_interlocking_joints,fqv[859],fqv[376],fqv[860]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2387cascaded_link_interlocking_joint_pairs,fqv[560],fqv[376],fqv[861]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2389cascaded_link_check_interlocking_joint_angle_validity,fqv[862],fqv[376],fqv[863]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[864],module,irtmodelF748all_child_links,fqv[865]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[866],module,irtmodelF749calc_dif_with_axis,fqv[867]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[868],module,irtmodelF750calc_target_joint_dimension,fqv[869]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[870],module,irtmodelF751calc_joint_angle_min_max_for_limit_calculation,fqv[871]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[872],module,irtmodelF752joint_angle_limit_weight,fqv[873]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[874],module,irtmodelF753joint_angle_limit_nspace,fqv[875]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[876],module,irtmodelF754calc_jacobian_from_link_list_including_robot_and_obj_virtual_joint,fqv[877]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[878],module,irtmodelF755append_obj_virtual_joint,fqv[879]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[880],module,irtmodelF756append_multiple_obj_virtual_joint,fqv[881]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[882],module,irtmodelF2591,fqv[883]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[884],module,irtmodelF2598,fqv[885]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[886],module,irtmodelF2601,fqv[887]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[888],module,irtmodelF2604,fqv[889]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[890],module,irtmodelF2608,fqv[891]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[675],module,irtmodelF757eusmodel_validity_check_one,fqv[892]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[893],module,irtmodelF758eusmodel_validity_check,fqv[894]);
	local[0]= fqv[895];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtmodelIF2645;
	local[0]= fqv[896];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[679],w);
	goto irtmodelIF2646;
irtmodelIF2645:
	local[0]= fqv[897];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtmodelIF2646:
	local[0]= fqv[898];
	local[1]= fqv[899];
	ctx->vsp=local+2;
	w=(*ftab[69])(ctx,2,local+0,&ftab[69],fqv[900]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<70; i++) ftab[i]=fcallx;
}

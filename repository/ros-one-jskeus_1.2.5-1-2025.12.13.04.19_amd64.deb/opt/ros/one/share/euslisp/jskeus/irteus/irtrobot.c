/* ./irtrobot.c :  entry=irtrobot */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "irtrobot.h"
#pragma init (register_irtrobot)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtrobot();
extern pointer build_quote_vector();
static int register_irtrobot()
  { add_module_initializer("___irtrobot", ___irtrobot);}

static pointer irtrobotF3811make_default_robot_link();

/*make-default-robot-link*/
static pointer irtrobotF3811make_default_robot_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto irtrobotENT3814;}
	local[0]= NIL;
irtrobotENT3814:
irtrobotENT3813:
	if (n>5) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= local[6];
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(*ftab[0])(ctx,2,local+7,&ftab[0],fqv[0]); /*make-cylinder*/
	local[2] = w;
	local[7]= local[6];
	local[8]= local[6];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,3,local+7,&ftab[1],fqv[1]); /*make-cube*/
	local[3] = w;
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,0,local+7,&ftab[2],fqv[2]); /*make-cascoords*/
	local[4] = w;
	local[7]= argv[2];
	local[8]= local[7];
	if (fqv[3]!=local[8]) goto irtrobotIF3815;
	local[5] = fqv[4];
	local[8]= local[5];
	goto irtrobotIF3816;
irtrobotIF3815:
	local[8]= local[7];
	if (fqv[5]!=local[8]) goto irtrobotIF3817;
	local[5] = fqv[6];
	local[8]= local[5];
	goto irtrobotIF3818;
irtrobotIF3817:
	local[8]= local[7];
	if (fqv[7]!=local[8]) goto irtrobotIF3819;
	local[5] = fqv[8];
	local[8]= local[5];
	goto irtrobotIF3820;
irtrobotIF3819:
	local[8]= local[7];
	if (fqv[9]!=local[8]) goto irtrobotIF3821;
	local[5] = fqv[10];
	local[8]= local[5];
	goto irtrobotIF3822;
irtrobotIF3821:
	local[8]= local[7];
	if (fqv[11]!=local[8]) goto irtrobotIF3823;
	local[5] = fqv[12];
	local[8]= local[5];
	goto irtrobotIF3824;
irtrobotIF3823:
	local[8]= local[7];
	if (fqv[13]!=local[8]) goto irtrobotIF3825;
	local[5] = fqv[14];
	local[8]= local[5];
	goto irtrobotIF3826;
irtrobotIF3825:
	if (T==NIL) goto irtrobotIF3827;
	local[5] = argv[2];
	local[8]= local[5];
	goto irtrobotIF3828;
irtrobotIF3827:
	local[8]= NIL;
irtrobotIF3828:
irtrobotIF3826:
irtrobotIF3824:
irtrobotIF3822:
irtrobotIF3820:
irtrobotIF3818:
irtrobotIF3816:
	w = local[8];
	local[7]= local[5];
	local[8]= fqv[15];
	ctx->vsp=local+9;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+7); /*v**/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto irtrobotIF3829;
	local[7]= local[4];
	local[8]= fqv[16];
	local[9]= local[5];
	local[10]= fqv[17];
	ctx->vsp=local+11;
	w=(pointer)VINNERPRODUCT(ctx,2,local+9); /*v.*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[3])(ctx,1,local+9,&ftab[3],fqv[18]); /*acos*/
	local[9]= w;
	local[10]= local[5];
	local[11]= fqv[19];
	ctx->vsp=local+12;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+10); /*v**/
	local[10]= w;
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	goto irtrobotIF3830;
irtrobotIF3829:
	local[7]= NIL;
irtrobotIF3830:
	local[7]= local[2];
	local[8]= fqv[21];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[2];
	local[8]= fqv[22];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,1,local+11); /*-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[3];
	local[8]= fqv[22];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= argv[0];
	local[12]= makeint((eusinteger_t)-2L);
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[9]= w;
	local[10]= fqv[23];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[2];
	local[8]= fqv[24];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[2];
	local[8]= fqv[25];
	local[9]= fqv[26];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[3];
	local[8]= fqv[25];
	local[9]= fqv[27];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[2];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[1] = w;
	if (local[0]==NIL) goto irtrobotIF3831;
	local[7]= NIL;
	local[8]= local[0];
irtrobotWHL3833:
	if (local[8]==NIL) goto irtrobotWHX3834;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[3];
	local[10]= fqv[24];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	goto irtrobotWHL3833;
irtrobotWHX3834:
	local[9]= NIL;
irtrobotBLK3835:
	w = NIL;
	local[7]= local[1];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[1] = w;
	local[7]= local[1];
	goto irtrobotIF3832;
irtrobotIF3831:
	local[7]= NIL;
irtrobotIF3832:
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtrobotCLO3836,env,argv,local);
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[28]); /*remove-if*/
	local[7]= w;
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	if (makeint((eusinteger_t)1L)!=local[8]) goto irtrobotIF3837;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[29];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	goto irtrobotIF3838;
irtrobotIF3837:
	local[8]= makeflt(1.0000000000000000000000e+00);
	local[9]= (pointer)get_sym_func(fqv[30]);
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtrobotCLO3839,env,argv,local);
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,2,local+10); /*mapcar*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[5])(ctx,2,local+9,&ftab[5],fqv[31]); /*reduce*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtrobotCLO3840,env,argv,local);
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,2,local+10); /*mapcar*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[5])(ctx,2,local+9,&ftab[5],fqv[31]); /*reduce*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
irtrobotIF3838:
	local[9]= loadglobal(fqv[33]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[34];
	ctx->vsp=local+12;
	w=(*ftab[2])(ctx,0,local+12,&ftab[2],fqv[2]); /*make-cascoords*/
	local[12]= w;
	local[13]= fqv[35];
	local[14]= local[1];
	local[15]= fqv[36];
	local[16]= argv[3];
	local[17]= fqv[29];
	local[18]= local[8];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,9,local+10); /*send*/
	w = local[9];
	local[0]= w;
irtrobotBLK3812:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3836(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[37];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	local[0]= w;
	if (w==NIL) goto irtrobotAND3841;
	local[0]= argv[0];
	local[1]= fqv[37];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	local[0]= w;
irtrobotAND3841:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3839(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[37];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3840(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[37];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[29];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init-ending*/
static pointer irtrobotM3842robot_model_init_ending(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[38]));
	local[2]= fqv[39];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[40]);
	local[2]= argv[0];
	local[3]= fqv[41];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[42]); /*every*/
	if (w!=NIL) goto irtrobotIF3844;
	local[1]= (pointer)get_sym_func(fqv[40]);
	local[2]= argv[0];
	local[3]= fqv[41];
	local[4]= fqv[43];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[42]); /*every*/
	if (w!=NIL) goto irtrobotIF3844;
	local[1]= argv[0];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtrobotIF3845;
irtrobotIF3844:
	local[1]= NIL;
irtrobotIF3845:
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[12];
	local[3]= argv[0]->c.obj.iv[13];
	local[4]= argv[0]->c.obj.iv[14];
	local[5]= argv[0]->c.obj.iv[15];
	local[6]= argv[0]->c.obj.iv[16];
	local[7]= argv[0]->c.obj.iv[17];
	local[8]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,6,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,2,local+1,&ftab[7],fqv[45]); /*remove*/
	argv[0]->c.obj.iv[12] = w;
	w = local[0];
	local[0]= w;
irtrobotBLK3843:
	ctx->vsp=local; return(local[0]);}

/*:rarm-end-coords*/
static pointer irtrobotM3846robot_model_rarm_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[14];
	local[0]= w;
irtrobotBLK3847:
	ctx->vsp=local; return(local[0]);}

/*:larm-end-coords*/
static pointer irtrobotM3848robot_model_larm_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
irtrobotBLK3849:
	ctx->vsp=local; return(local[0]);}

/*:rleg-end-coords*/
static pointer irtrobotM3850robot_model_rleg_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtrobotBLK3851:
	ctx->vsp=local; return(local[0]);}

/*:lleg-end-coords*/
static pointer irtrobotM3852robot_model_lleg_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[15];
	local[0]= w;
irtrobotBLK3853:
	ctx->vsp=local; return(local[0]);}

/*:head-end-coords*/
static pointer irtrobotM3854robot_model_head_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
irtrobotBLK3855:
	ctx->vsp=local; return(local[0]);}

/*:torso-end-coords*/
static pointer irtrobotM3856robot_model_torso_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[18];
	local[0]= w;
irtrobotBLK3857:
	ctx->vsp=local; return(local[0]);}

/*:rarm-root-link*/
static pointer irtrobotM3858robot_model_rarm_root_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[20];
	local[0]= w;
irtrobotBLK3859:
	ctx->vsp=local; return(local[0]);}

/*:larm-root-link*/
static pointer irtrobotM3860robot_model_larm_root_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[19];
	local[0]= w;
irtrobotBLK3861:
	ctx->vsp=local; return(local[0]);}

/*:rleg-root-link*/
static pointer irtrobotM3862robot_model_rleg_root_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[22];
	local[0]= w;
irtrobotBLK3863:
	ctx->vsp=local; return(local[0]);}

/*:lleg-root-link*/
static pointer irtrobotM3864robot_model_lleg_root_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[21];
	local[0]= w;
irtrobotBLK3865:
	ctx->vsp=local; return(local[0]);}

/*:head-root-link*/
static pointer irtrobotM3866robot_model_head_root_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[23];
	local[0]= w;
irtrobotBLK3867:
	ctx->vsp=local; return(local[0]);}

/*:torso-root-link*/
static pointer irtrobotM3868robot_model_torso_root_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[24];
	local[0]= w;
irtrobotBLK3869:
	ctx->vsp=local; return(local[0]);}

/*:limb*/
static pointer irtrobotM3870robot_model_limb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtrobotRST3872:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	local[1]= NIL;
	local[2]= argv[3];
	local[3]= local[2];
	if (fqv[43]!=local[3]) goto irtrobotIF3873;
	local[3]= argv[0];
	local[4]= NIL;
	local[5]= fqv[46];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[47]); /*read-from-string*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,2,local+3,&ftab[9],fqv[48]); /*forward-message-to*/
	local[3]= w;
	goto irtrobotIF3874;
irtrobotIF3873:
	local[3]= local[2];
	if (fqv[49]!=local[3]) goto irtrobotIF3875;
	local[3]= argv[0];
	local[4]= NIL;
	local[5]= fqv[50];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[47]); /*read-from-string*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,2,local+3,&ftab[9],fqv[48]); /*forward-message-to*/
	local[3]= w;
	goto irtrobotIF3876;
irtrobotIF3875:
	local[3]= local[2];
	if (fqv[51]!=local[3]) goto irtrobotIF3877;
	if (local[0]==NIL) goto irtrobotIF3879;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtrobotCLO3881,env,argv,local);
	local[4]= argv[0];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= loadglobal(fqv[52]);
	ctx->vsp=local+7;
	w=(pointer)COERCE(ctx,2,local+5); /*coerce*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,3,local+3); /*mapcar*/
	local[3]= argv[0];
	local[4]= argv[2];
	local[5]= fqv[51];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtrobotIF3880;
irtrobotIF3879:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtrobotCLO3882,env,argv,local);
	local[4]= argv[0];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= loadglobal(fqv[53]);
	ctx->vsp=local+5;
	w=(pointer)COERCE(ctx,2,local+3); /*coerce*/
	local[3]= w;
irtrobotIF3880:
	goto irtrobotIF3878;
irtrobotIF3877:
	local[3]= local[2];
	if (fqv[54]!=local[3]) goto irtrobotIF3883;
	local[3]= fqv[55];
	w = local[0];
	if (memq(local[3],w)==NIL) goto irtrobotIF3885;
	local[3]= fqv[55];
	w = local[0];
	w=memq(local[3],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	goto irtrobotIF3886;
irtrobotIF3885:
	local[3]= argv[0];
	local[4]= fqv[55];
	local[5]= argv[0];
	local[6]= argv[2];
	local[7]= fqv[43];
	local[8]= fqv[56];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= argv[2];
	local[8]= fqv[49];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
irtrobotIF3886:
	local[4]= fqv[57];
	w = local[0];
	if (memq(local[4],w)==NIL) goto irtrobotIF3887;
	local[4]= fqv[57];
	w = local[0];
	w=memq(local[4],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	goto irtrobotIF3888;
irtrobotIF3887:
	local[4]= argv[0];
	local[5]= fqv[58];
	local[6]= local[3];
	local[7]= fqv[59];
	local[8]= argv[0];
	local[9]= argv[2];
	local[10]= fqv[59];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
irtrobotIF3888:
	local[5]= (pointer)get_sym_func(fqv[60]);
	local[6]= argv[0];
	local[7]= fqv[54];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[61];
	local[10]= fqv[61];
	w = local[0];
	if (memq(local[10],w)==NIL) goto irtrobotIF3889;
	local[10]= fqv[61];
	w = local[0];
	w=memq(local[10],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	goto irtrobotIF3890;
irtrobotIF3889:
	local[10]= argv[0];
	local[11]= argv[2];
	local[12]= fqv[43];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
irtrobotIF3890:
	local[11]= fqv[57];
	local[12]= local[4];
	local[13]= fqv[55];
	local[14]= local[3];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.cdr;
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,11,local+5); /*apply*/
	local[3]= w;
	goto irtrobotIF3884;
irtrobotIF3883:
	local[3]= local[2];
	if (fqv[62]!=local[3]) goto irtrobotIF3891;
	local[3]= (pointer)get_sym_func(fqv[60]);
	local[4]= argv[0];
	local[5]= argv[2];
	local[6]= fqv[54];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	local[3]= w;
	goto irtrobotIF3892;
irtrobotIF3891:
	local[3]= local[2];
	if (fqv[63]!=local[3]) goto irtrobotIF3893;
	local[3]= argv[0];
	local[4]= argv[2];
	local[5]= fqv[43];
	local[6]= fqv[64];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[6];
	local[6]= w;
	if (local[6]!=NIL) goto irtrobotIF3895;
	local[6] = fqv[65];
	local[7]= local[6];
	goto irtrobotIF3896;
irtrobotIF3895:
	local[7]= NIL;
irtrobotIF3896:
	local[7]= (pointer)get_sym_func(fqv[60]);
	local[8]= argv[0];
	local[9]= argv[2];
	local[10]= fqv[62];
	local[11]= local[3];
	local[12]= fqv[66];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(*ftab[10])(ctx,1,local+13,&ftab[10],fqv[67]); /*deg2rad*/
	local[13]= w;
	local[14]= local[5];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,5,local+11); /*send*/
	local[11]= w;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,6,local+7); /*apply*/
	local[3]= w;
	goto irtrobotIF3894;
irtrobotIF3893:
	local[3]= local[2];
	if (fqv[68]!=local[3]) goto irtrobotIF3897;
	local[3]= argv[0];
	local[4]= argv[2];
	local[5]= fqv[43];
	local[6]= fqv[64];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	if (local[5]!=NIL) goto irtrobotIF3899;
	local[5] = fqv[65];
	local[6]= local[5];
	goto irtrobotIF3900;
irtrobotIF3899:
	local[6]= NIL;
irtrobotIF3900:
	local[6]= (pointer)get_sym_func(fqv[60]);
	local[7]= argv[0];
	local[8]= argv[2];
	local[9]= fqv[62];
	local[10]= local[3];
	local[11]= fqv[22];
	local[12]= local[4];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= w;
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)APPLY(ctx,6,local+6); /*apply*/
	local[3]= w;
	goto irtrobotIF3898;
irtrobotIF3897:
	local[3]= local[2];
	if (fqv[69]!=local[3]) goto irtrobotIF3901;
	local[3]= argv[0];
	local[4]= fqv[70];
	local[5]= fqv[71];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	if (w==NIL) goto irtrobotIF3903;
	local[3]= (pointer)get_sym_func(fqv[60]);
	local[4]= argv[0];
	local[5]= fqv[72];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	local[3]= w;
	goto irtrobotIF3904;
irtrobotIF3903:
	local[3]= NIL;
irtrobotIF3904:
	goto irtrobotIF3902;
irtrobotIF3901:
	local[3]= local[2];
	if (fqv[59]!=local[3]) goto irtrobotIF3905;
	local[3]= NIL;
	local[4]= fqv[73];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,1,local+5,&ftab[11],fqv[74]); /*string-upcase*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INTERN(ctx,1,local+3); /*intern*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[75];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,2,local+3,&ftab[12],fqv[76]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,2,local+3,&ftab[9],fqv[48]); /*forward-message-to*/
	local[3]= w;
	goto irtrobotIF3906;
irtrobotIF3905:
	local[3]= local[2];
	if (fqv[71]!=local[3]) goto irtrobotIF3907;
	local[3]= argv[0];
	local[4]= fqv[77];
	local[5]= argv[2];
	local[6]= NIL;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtrobotIF3908;
irtrobotIF3907:
	local[3]= local[2];
	if (fqv[78]!=local[3]) goto irtrobotIF3909;
	local[3]= argv[0];
	local[4]= fqv[77];
	local[5]= argv[2];
	local[6]= fqv[71];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[79];
	ctx->vsp=local+5;
	w=(*ftab[13])(ctx,2,local+3,&ftab[13],fqv[80]); /*send-all*/
	local[3]= w;
	goto irtrobotIF3910;
irtrobotIF3909:
	local[3]= local[2];
	if (fqv[81]!=local[3]) goto irtrobotIF3911;
	local[3]= (pointer)get_sym_func(fqv[60]);
	local[4]= argv[0];
	local[5]= fqv[81];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	local[3]= w;
	goto irtrobotIF3912;
irtrobotIF3911:
	local[3]= local[2];
	if (fqv[82]!=local[3]) goto irtrobotIF3913;
	local[3]= argv[0];
	local[4]= fqv[82];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtrobotIF3914;
irtrobotIF3913:
	local[3]= local[2];
	if (fqv[83]!=local[3]) goto irtrobotIF3915;
	local[3]= argv[0];
	local[4]= fqv[84];
	local[5]= fqv[83];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtrobotIF3916;
irtrobotIF3915:
	local[3]= local[2];
	if (fqv[85]!=local[3]) goto irtrobotIF3917;
	local[3]= argv[0];
	local[4]= fqv[84];
	local[5]= fqv[85];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtrobotIF3918;
irtrobotIF3917:
	local[3]= local[2];
	if (fqv[86]!=local[3]) goto irtrobotIF3919;
	local[3]= argv[0];
	local[4]= fqv[84];
	local[5]= fqv[86];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtrobotIF3920;
irtrobotIF3919:
	if (T==NIL) goto irtrobotIF3921;
	if (argv[3]==NIL) goto irtrobotOR3925;
	local[3]= loadglobal(fqv[33]);
	local[4]= fqv[87];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	if (w!=NIL) goto irtrobotOR3925;
	goto irtrobotCON3924;
irtrobotOR3925:
	if (argv[3]==NIL) goto irtrobotIF3926;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[11])(ctx,1,local+3,&ftab[11],fqv[74]); /*string-upcase*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INTERN(ctx,1,local+3); /*intern*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[75];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,2,local+3,&ftab[12],fqv[76]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(*ftab[13])(ctx,2,local+3,&ftab[13],fqv[80]); /*send-all*/
	local[3]= w;
	goto irtrobotIF3927;
irtrobotIF3926:
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[11])(ctx,1,local+3,&ftab[11],fqv[74]); /*string-upcase*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INTERN(ctx,1,local+3); /*intern*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[75];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,2,local+3,&ftab[12],fqv[76]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
irtrobotIF3927:
	goto irtrobotCON3923;
irtrobotCON3924:
	local[3]= NIL;
	local[4]= fqv[88];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,1,local+5,&ftab[11],fqv[74]); /*string-upcase*/
	local[5]= w;
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(*ftab[11])(ctx,1,local+6,&ftab[11],fqv[74]); /*string-upcase*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= w;
	local[4]= loadglobal(fqv[89]);
	ctx->vsp=local+5;
	w=(pointer)INTERN(ctx,2,local+3); /*intern*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[14])(ctx,2,local+4,&ftab[14],fqv[90]); /*find-method*/
	if (w==NIL) goto irtrobotIF3929;
	local[4]= argv[0];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[9])(ctx,2,local+4,&ftab[9],fqv[48]); /*forward-message-to*/
	local[4]= w;
	goto irtrobotIF3930;
irtrobotIF3929:
	local[4]= fqv[91];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(*ftab[15])(ctx,2,local+4,&ftab[15],fqv[92]); /*warn*/
	local[4]= w;
irtrobotIF3930:
	w = local[4];
	local[3]= w;
	goto irtrobotCON3923;
irtrobotCON3928:
	local[3]= NIL;
irtrobotCON3923:
	goto irtrobotIF3922;
irtrobotIF3921:
	local[3]= NIL;
irtrobotIF3922:
irtrobotIF3920:
irtrobotIF3918:
irtrobotIF3916:
irtrobotIF3914:
irtrobotIF3912:
irtrobotIF3910:
irtrobotIF3908:
irtrobotIF3906:
irtrobotIF3902:
irtrobotIF3898:
irtrobotIF3894:
irtrobotIF3892:
irtrobotIF3884:
irtrobotIF3878:
irtrobotIF3876:
irtrobotIF3874:
	w = local[3];
	local[0]= w;
irtrobotBLK3871:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics-loop-for-look-at*/
static pointer irtrobotM3931robot_model_inverse_kinematics_loop_for_look_at(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtrobotRST3933:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= fqv[61];
	w = local[0];
	if (memq(local[1],w)==NIL) goto irtrobotIF3934;
	local[1]= fqv[61];
	w = local[0];
	w=memq(local[1],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	goto irtrobotIF3935;
irtrobotIF3934:
	local[1]= argv[0];
	local[2]= argv[2];
	local[3]= fqv[43];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
irtrobotIF3935:
	local[2]= fqv[55];
	w = local[0];
	if (memq(local[2],w)==NIL) goto irtrobotIF3936;
	local[2]= fqv[55];
	w = local[0];
	w=memq(local[2],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	goto irtrobotIF3937;
irtrobotIF3936:
	local[2]= argv[0];
	local[3]= fqv[55];
	local[4]= local[1];
	local[5]= fqv[56];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= argv[2];
	local[7]= fqv[49];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
irtrobotIF3937:
	local[3]= fqv[93];
	w = local[0];
	if (memq(local[3],w)==NIL) goto irtrobotIF3938;
	local[3]= fqv[93];
	w = local[0];
	w=memq(local[3],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	goto irtrobotIF3939;
irtrobotIF3938:
	local[3]= makeint((eusinteger_t)100L);
irtrobotIF3939:
	local[4]= fqv[94];
	w = local[0];
	if (memq(local[4],w)==NIL) goto irtrobotIF3940;
	local[4]= fqv[94];
	w = local[0];
	w=memq(local[4],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	goto irtrobotIF3941;
irtrobotIF3940:
	local[4]= T;
irtrobotIF3941:
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= makeint((eusinteger_t)0L);
irtrobotWHL3942:
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[8] = w;
	local[9]= local[8];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto irtrobotWHX3943;
	if (local[7]==NIL) goto irtrobotIF3945;
	local[9]= local[7];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+11;
	w=(pointer)GREATERP(ctx,2,local+9); /*>*/
	local[9]= w;
	goto irtrobotIF3946;
irtrobotIF3945:
	local[9]= T;
irtrobotIF3946:
	if (local[9]==NIL) goto irtrobotWHX3943;
	local[9]= fqv[95];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[96]); /*make-coords*/
	local[9]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[1];
	local[12]= fqv[97];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[17])(ctx,2,local+9,&ftab[17],fqv[98]); /*orient-coords-to-axis*/
	local[9]= w;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[7] = local[6];
	local[17]= local[1];
	local[18]= fqv[99];
	local[19]= local[9];
	local[20]= fqv[100];
	local[21]= NIL;
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,5,local+17); /*send*/
	local[5] = w;
	local[17]= local[1];
	local[18]= fqv[101];
	local[19]= local[9];
	local[20]= fqv[102];
	local[21]= fqv[7];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,5,local+17); /*send*/
	local[6] = w;
	local[17]= loadglobal(fqv[53]);
	local[18]= argv[0];
	local[19]= fqv[103];
	local[20]= local[2];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)INSTANTIATE(ctx,2,local+17); /*instantiate*/
	local[14] = w;
	local[17]= loadglobal(fqv[53]);
	local[18]= argv[0];
	local[19]= fqv[103];
	local[20]= local[2];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)INSTANTIATE(ctx,2,local+17); /*instantiate*/
	local[15] = w;
	local[17]= local[14];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(*ftab[18])(ctx,2,local+17,&ftab[18],fqv[104]); /*fill*/
	local[17]= local[9];
	local[18]= fqv[105];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(*ftab[19])(ctx,2,local+17,&ftab[19],fqv[106]); /*matrix-column*/
	local[10] = w;
	local[17]= local[1];
	local[18]= fqv[105];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(*ftab[19])(ctx,2,local+17,&ftab[19],fqv[106]); /*matrix-column*/
	local[11] = w;
	local[16] = makeint((eusinteger_t)0L);
	local[17]= NIL;
	local[18]= local[2];
	local[19]= fqv[79];
	ctx->vsp=local+20;
	w=(*ftab[13])(ctx,2,local+18,&ftab[13],fqv[80]); /*send-all*/
	local[18]= w;
irtrobotWHL3947:
	if (local[18]==NIL) goto irtrobotWHX3948;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18] = (w)->c.cons.cdr;
	w = local[19];
	local[17] = w;
	local[19]= local[17];
	local[20]= fqv[107];
	local[21]= fqv[108];
	local[22]= *(ovafptr(local[17],fqv[109]));
	local[23]= local[22];
	if (fqv[3]!=local[23]) goto irtrobotIF3950;
	local[23]= fqv[110];
	goto irtrobotIF3951;
irtrobotIF3950:
	local[23]= local[22];
	if (fqv[5]!=local[23]) goto irtrobotIF3952;
	local[23]= fqv[111];
	goto irtrobotIF3953;
irtrobotIF3952:
	local[23]= local[22];
	if (fqv[7]!=local[23]) goto irtrobotIF3954;
	local[23]= fqv[112];
	goto irtrobotIF3955;
irtrobotIF3954:
	local[23]= local[22];
	if (fqv[9]!=local[23]) goto irtrobotIF3956;
	local[23]= fqv[113];
	goto irtrobotIF3957;
irtrobotIF3956:
	local[23]= local[22];
	if (fqv[11]!=local[23]) goto irtrobotIF3958;
	local[23]= fqv[114];
	goto irtrobotIF3959;
irtrobotIF3958:
	local[23]= local[22];
	if (fqv[13]!=local[23]) goto irtrobotIF3960;
	local[23]= fqv[115];
	goto irtrobotIF3961;
irtrobotIF3960:
	if (T==NIL) goto irtrobotIF3962;
	local[23]= *(ovafptr(local[17],fqv[109]));
	goto irtrobotIF3963;
irtrobotIF3962:
	local[23]= NIL;
irtrobotIF3963:
irtrobotIF3961:
irtrobotIF3959:
irtrobotIF3957:
irtrobotIF3955:
irtrobotIF3953:
irtrobotIF3951:
	w = local[23];
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,4,local+19); /*send*/
	local[12] = w;
	local[19]= local[17];
	local[20]= fqv[107];
	local[21]= fqv[108];
	local[22]= fqv[116];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,4,local+19); /*send*/
	local[13] = w;
	local[19]= local[12];
	local[20]= local[11];
	local[21]= local[10];
	ctx->vsp=local+22;
	w=(pointer)SCA3PROD(ctx,3,local+19); /*v.**/
	local[19]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[19]);
	if (left >= right) goto irtrobotAND3967;}
	local[19]= local[12];
	local[20]= local[11];
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)SCA3PROD(ctx,3,local+19); /*v.**/
	local[19]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[19]);
	if (left >= right) goto irtrobotAND3967;}
	local[19]= local[12];
	local[20]= local[13];
	local[21]= local[10];
	ctx->vsp=local+22;
	w=(pointer)SCA3PROD(ctx,3,local+19); /*v.**/
	local[19]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[19]);
	if (left >= right) goto irtrobotAND3967;}
	goto irtrobotOR3966;
irtrobotAND3967:
	local[19]= local[12];
	local[20]= local[11];
	local[21]= local[10];
	ctx->vsp=local+22;
	w=(pointer)SCA3PROD(ctx,3,local+19); /*v.**/
	local[19]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[19]);
	if (left <= right) goto irtrobotAND3968;}
	local[19]= local[12];
	local[20]= local[11];
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)SCA3PROD(ctx,3,local+19); /*v.**/
	local[19]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[19]);
	if (left <= right) goto irtrobotAND3968;}
	local[19]= local[12];
	local[20]= local[13];
	local[21]= local[10];
	ctx->vsp=local+22;
	w=(pointer)SCA3PROD(ctx,3,local+19); /*v.**/
	local[19]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[19]);
	if (left <= right) goto irtrobotAND3968;}
	goto irtrobotOR3966;
irtrobotAND3968:
	goto irtrobotIF3964;
irtrobotOR3966:
	local[19]= local[12];
	local[20]= local[11];
	local[21]= local[10];
	ctx->vsp=local+22;
	w=(pointer)SCA3PROD(ctx,3,local+19); /*v.**/
	local[19]= w;
	local[20]= makeint((eusinteger_t)0L);
	ctx->vsp=local+21;
	w=(pointer)GREATERP(ctx,2,local+19); /*>*/
	if (w==NIL) goto irtrobotIF3969;
	local[19]= local[15];
	local[20]= local[16];
	local[21]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+22;
	w=(pointer)SETELT(ctx,3,local+19); /*setelt*/
	local[19]= w;
	goto irtrobotIF3970;
irtrobotIF3969:
	local[19]= local[15];
	local[20]= local[16];
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)SETELT(ctx,3,local+19); /*setelt*/
	local[19]= w;
irtrobotIF3970:
	local[19]= local[14];
	local[20]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+21;
	w=(*ftab[18])(ctx,2,local+19,&ftab[18],fqv[104]); /*fill*/
	local[19]= local[14];
	local[20]= local[16];
	local[21]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+22;
	w=(pointer)SETELT(ctx,3,local+19); /*setelt*/
	w = NIL;
	ctx->vsp=local+19;
	local[19]=w;
	goto irtrobotBLK3949;
	goto irtrobotIF3965;
irtrobotIF3964:
	local[19]= NIL;
irtrobotIF3965:
	local[19]= local[16];
	ctx->vsp=local+20;
	w=(pointer)ADD1(ctx,1,local+19); /*1+*/
	local[16] = w;
	goto irtrobotWHL3947;
irtrobotWHX3948:
	local[19]= NIL;
irtrobotBLK3949:
	w = NIL;
	local[17]= argv[0];
	local[18]= fqv[117];
	local[19]= local[5];
	local[20]= local[6];
	local[21]= fqv[61];
	local[22]= local[1];
	local[23]= fqv[57];
	local[24]= NIL;
	local[25]= fqv[102];
	local[26]= fqv[7];
	local[27]= fqv[100];
	local[28]= NIL;
	local[29]= fqv[55];
	local[30]= local[2];
	local[31]= fqv[118];
	local[32]= local[8];
	local[33]= fqv[93];
	local[34]= local[3];
	local[35]= fqv[119];
	local[36]= local[9];
	local[37]= fqv[120];
	local[38]= local[15];
	local[39]= fqv[121];
	local[40]= local[14];
	local[41]= fqv[122];
	local[42]= fqv[122];
	w = local[0];
	w=memq(local[42],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[42]= (w)->c.cons.car;
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,26,local+17); /*send*/
	goto irtrobotWHL3942;
irtrobotWHX3943:
	local[9]= NIL;
irtrobotBLK3944:
	if (local[7]==NIL) goto irtrobotIF3971;
	local[9]= local[7];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	local[9]= w;
	{ double left,right;
		right=fltval(makeflt(1.0000000000000000208167e-03)); left=fltval(local[9]);
	if (left > right) goto irtrobotIF3971;}
	local[9]= argv[0];
	local[10]= fqv[51];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	goto irtrobotIF3972;
irtrobotIF3971:
	if (local[4]==NIL) goto irtrobotIF3973;
	local[9]= fqv[123];
	ctx->vsp=local+10;
	w=(*ftab[15])(ctx,1,local+9,&ftab[15],fqv[92]); /*warn*/
	local[9]= fqv[124];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(*ftab[15])(ctx,2,local+9,&ftab[15],fqv[92]); /*warn*/
	if (local[7]==NIL) goto irtrobotIF3975;
	local[9]= fqv[125];
	local[10]= local[7];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)VNORM(ctx,1,local+11); /*norm*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[15])(ctx,3,local+9,&ftab[15],fqv[92]); /*warn*/
	local[9]= fqv[126];
	local[10]= local[6];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)VNORM(ctx,1,local+11); /*norm*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[15])(ctx,3,local+9,&ftab[15],fqv[92]); /*warn*/
	local[9]= fqv[127];
	local[10]= local[7];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VNORM(ctx,1,local+10); /*norm*/
	local[10]= w;
	local[11]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+12;
	w=(*ftab[15])(ctx,3,local+9,&ftab[15],fqv[92]); /*warn*/
	local[9]= w;
	goto irtrobotIF3976;
irtrobotIF3975:
	local[9]= NIL;
irtrobotIF3976:
	goto irtrobotIF3974;
irtrobotIF3973:
	local[9]= NIL;
irtrobotIF3974:
irtrobotIF3972:
	w = local[9];
	local[0]= w;
irtrobotBLK3932:
	ctx->vsp=local; return(local[0]);}

/*:gripper*/
static pointer irtrobotM3977robot_model_gripper(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtrobotRST3979:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= fqv[71];
	w = local[0];
	if (memq(local[1],w)==NIL) goto irtrobotCON3981;
	local[1]= argv[0];
	local[2]= argv[2];
	local[3]= fqv[43];
	local[4]= fqv[56];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,1,local+1,&ftab[20],fqv[128]); /*all-child-links*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO3982,env,argv,local);
	ctx->vsp=local+3;
	w=(pointer)SORT(ctx,2,local+1); /*sort*/
	local[1]= w;
	goto irtrobotCON3980;
irtrobotCON3981:
	local[1]= fqv[78];
	w = local[0];
	if (memq(local[1],w)==NIL) goto irtrobotCON3983;
	local[1]= argv[0];
	local[2]= fqv[81];
	local[3]= argv[2];
	local[4]= fqv[71];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[79];
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[80]); /*send-all*/
	local[1]= w;
	goto irtrobotCON3980;
irtrobotCON3983:
	local[1]= fqv[51];
	w = local[0];
	if (memq(local[1],w)==NIL) goto irtrobotCON3984;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto irtrobotIF3985;
	local[1]= loadglobal(fqv[53]);
	local[2]= argv[0];
	local[3]= fqv[81];
	local[4]= argv[2];
	local[5]= fqv[78];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[129];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,2,local+2,&ftab[13],fqv[80]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)CONCATENATE(ctx,2,local+1); /*concatenate*/
	local[1]= w;
	goto irtrobotIF3986;
irtrobotIF3985:
	local[1]= loadglobal(fqv[53]);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO3987,env,argv,local);
	local[3]= argv[0];
	local[4]= fqv[81];
	local[5]= argv[2];
	local[6]= fqv[78];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,4,local+1); /*map*/
	local[1]= w;
irtrobotIF3986:
	goto irtrobotCON3980;
irtrobotCON3984:
	local[1]= NIL;
irtrobotCON3980:
	w = local[1];
	local[0]= w;
irtrobotBLK3978:
	ctx->vsp=local; return(local[0]);}

/*:camera*/
static pointer irtrobotM3988robot_model_camera(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[130];
	local[2]= fqv[131];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
irtrobotBLK3989:
	ctx->vsp=local; return(local[0]);}

/*:force-sensor*/
static pointer irtrobotM3990robot_model_force_sensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[130];
	local[2]= fqv[132];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
irtrobotBLK3991:
	ctx->vsp=local; return(local[0]);}

/*:imu-sensor*/
static pointer irtrobotM3992robot_model_imu_sensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[130];
	local[2]= fqv[133];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
irtrobotBLK3993:
	ctx->vsp=local; return(local[0]);}

/*:get-sensor-method*/
static pointer irtrobotM3994robot_model_get_sensor_method(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= NIL;
	local[2]= fqv[134];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,1,local+1,&ftab[8],fqv[47]); /*read-from-string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[3];
	local[2]= local[0];
	local[3]= fqv[135];
	local[4]= (pointer)get_sym_func(fqv[136]);
	local[5]= fqv[137];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtrobotCLO3996,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[21])(ctx,6,local+1,&ftab[21],fqv[138]); /*find*/
	local[0]= w;
irtrobotBLK3995:
	ctx->vsp=local; return(local[0]);}

/*:get-sensors-method-by-limb*/
static pointer irtrobotM3997robot_model_get_sensors_method_by_limb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtrobotCLO3999,env,argv,local);
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[139]); /*remove-if-not*/
	local[0]= w;
irtrobotBLK3998:
	ctx->vsp=local; return(local[0]);}

/*:force-sensors*/
static pointer irtrobotM4000robot_model_force_sensors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[33];
	local[0]= w;
irtrobotBLK4001:
	ctx->vsp=local; return(local[0]);}

/*:imu-sensors*/
static pointer irtrobotM4002robot_model_imu_sensors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[34];
	local[0]= w;
irtrobotBLK4003:
	ctx->vsp=local; return(local[0]);}

/*:cameras*/
static pointer irtrobotM4004robot_model_cameras(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[35];
	local[0]= w;
irtrobotBLK4005:
	ctx->vsp=local; return(local[0]);}

/*:larm*/
static pointer irtrobotM4006robot_model_larm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtrobotRST4008:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]!=NIL) goto irtrobotIF4009;
	local[1]= NIL;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto irtrobotIF4010;
irtrobotIF4009:
	local[1]= NIL;
irtrobotIF4010:
	local[1]= (pointer)get_sym_func(fqv[60]);
	local[2]= argv[0];
	local[3]= fqv[77];
	local[4]= fqv[140];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[0]= w;
irtrobotBLK4007:
	ctx->vsp=local; return(local[0]);}

/*:rarm*/
static pointer irtrobotM4011robot_model_rarm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtrobotRST4013:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]!=NIL) goto irtrobotIF4014;
	local[1]= NIL;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto irtrobotIF4015;
irtrobotIF4014:
	local[1]= NIL;
irtrobotIF4015:
	local[1]= (pointer)get_sym_func(fqv[60]);
	local[2]= argv[0];
	local[3]= fqv[77];
	local[4]= fqv[141];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[0]= w;
irtrobotBLK4012:
	ctx->vsp=local; return(local[0]);}

/*:lleg*/
static pointer irtrobotM4016robot_model_lleg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtrobotRST4018:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]!=NIL) goto irtrobotIF4019;
	local[1]= NIL;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto irtrobotIF4020;
irtrobotIF4019:
	local[1]= NIL;
irtrobotIF4020:
	local[1]= (pointer)get_sym_func(fqv[60]);
	local[2]= argv[0];
	local[3]= fqv[77];
	local[4]= fqv[142];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[0]= w;
irtrobotBLK4017:
	ctx->vsp=local; return(local[0]);}

/*:rleg*/
static pointer irtrobotM4021robot_model_rleg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtrobotRST4023:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]!=NIL) goto irtrobotIF4024;
	local[1]= NIL;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto irtrobotIF4025;
irtrobotIF4024:
	local[1]= NIL;
irtrobotIF4025:
	local[1]= (pointer)get_sym_func(fqv[60]);
	local[2]= argv[0];
	local[3]= fqv[77];
	local[4]= fqv[143];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[0]= w;
irtrobotBLK4022:
	ctx->vsp=local; return(local[0]);}

/*:head*/
static pointer irtrobotM4026robot_model_head(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtrobotRST4028:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]!=NIL) goto irtrobotIF4029;
	local[1]= NIL;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto irtrobotIF4030;
irtrobotIF4029:
	local[1]= NIL;
irtrobotIF4030:
	local[1]= (pointer)get_sym_func(fqv[60]);
	local[2]= argv[0];
	local[3]= fqv[77];
	local[4]= fqv[70];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[0]= w;
irtrobotBLK4027:
	ctx->vsp=local; return(local[0]);}

/*:torso*/
static pointer irtrobotM4031robot_model_torso(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtrobotRST4033:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]!=NIL) goto irtrobotIF4034;
	local[1]= NIL;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto irtrobotIF4035;
irtrobotIF4034:
	local[1]= NIL;
irtrobotIF4035:
	local[1]= (pointer)get_sym_func(fqv[60]);
	local[2]= argv[0];
	local[3]= fqv[77];
	local[4]= fqv[144];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[0]= w;
irtrobotBLK4032:
	ctx->vsp=local; return(local[0]);}

/*:arms*/
static pointer irtrobotM4036robot_model_arms(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtrobotRST4038:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[60]);
	local[2]= argv[0];
	local[3]= fqv[140];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[60]);
	local[3]= argv[0];
	local[4]= fqv[141];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,4,local+2); /*apply*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[0]= w;
irtrobotBLK4037:
	ctx->vsp=local; return(local[0]);}

/*:legs*/
static pointer irtrobotM4039robot_model_legs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtrobotRST4041:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[60]);
	local[2]= argv[0];
	local[3]= fqv[142];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[60]);
	local[3]= argv[0];
	local[4]= fqv[143];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,4,local+2); /*apply*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[0]= w;
irtrobotBLK4040:
	ctx->vsp=local; return(local[0]);}

/*:look-at-hand*/
static pointer irtrobotM4042robot_model_look_at_hand(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO4044,env,argv,local);
	w = argv[2];
	if (!iscons(w)) goto irtrobotCON4046;
	local[3]= argv[2];
	goto irtrobotCON4045;
irtrobotCON4046:
	local[3]= argv[2];
	if (fqv[146]!=local[3]) goto irtrobotCON4047;
	local[3]= fqv[147];
	goto irtrobotCON4045;
irtrobotCON4047:
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	goto irtrobotCON4045;
irtrobotCON4048:
	local[3]= NIL;
irtrobotCON4045:
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtrobotBLK4043:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics*/
static pointer irtrobotM4049robot_model_inverse_kinematics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtrobotRST4051:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[148], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtrobotKEY4052;
	local[1] = NIL;
irtrobotKEY4052:
	if (n & (1<<1)) goto irtrobotKEY4053;
	local[2] = NIL;
irtrobotKEY4053:
	if (n & (1<<2)) goto irtrobotKEY4054;
	w = local[2];
	if (!!iscons(w)) goto irtrobotIF4055;
	local[4]= argv[0];
	local[5]= fqv[55];
	local[6]= local[2];
	local[7]= fqv[56];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtrobotIF4056;
irtrobotIF4055:
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtrobotCLO4057,env,argv,local);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
irtrobotIF4056:
	local[3] = local[4];
irtrobotKEY4054:
	w = argv[2];
	if (!iscons(w)) goto irtrobotOR4060;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[23])(ctx,1,local+4,&ftab[23],fqv[149]); /*functionp*/
	if (w!=NIL) goto irtrobotOR4060;
	goto irtrobotIF4058;
irtrobotOR4060:
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	argv[2] = w;
	local[4]= argv[2];
	goto irtrobotIF4059;
irtrobotIF4058:
	local[4]= NIL;
irtrobotIF4059:
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtrobotCLO4063,env,argv,local);
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,2,local+4,&ftab[6],fqv[42]); /*every*/
	if (w!=NIL) goto irtrobotIF4061;
	local[4]= fqv[150];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[15])(ctx,2,local+4,&ftab[15],fqv[92]); /*warn*/
	w = NIL;
	ctx->vsp=local+4;
	local[0]=w;
	goto irtrobotBLK4050;
	goto irtrobotIF4062;
irtrobotIF4061:
	local[4]= NIL;
irtrobotIF4062:
	local[4]= (pointer)get_sym_func(fqv[151]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[38]));
	local[7]= fqv[54];
	local[8]= argv[2];
	local[9]= fqv[61];
	local[10]= local[2];
	local[11]= fqv[55];
	local[12]= local[3];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,10,local+4); /*apply*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[145];
	local[7]= local[1];
	local[8]= fqv[119];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	w = local[4];
	local[0]= w;
irtrobotBLK4050:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics-loop*/
static pointer irtrobotM4064robot_model_inverse_kinematics_loop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtrobotRST4066:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[152], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtrobotKEY4067;
	local[1] = NIL;
irtrobotKEY4067:
	if (n & (1<<1)) goto irtrobotKEY4068;
	local[2] = NIL;
irtrobotKEY4068:
	if (n & (1<<2)) goto irtrobotKEY4069;
	local[3] = NIL;
irtrobotKEY4069:
	if (n & (1<<3)) goto irtrobotKEY4070;
	local[4] = NIL;
irtrobotKEY4070:
	if (n & (1<<4)) goto irtrobotKEY4071;
	w = local[4];
	if (!!iscons(w)) goto irtrobotIF4072;
	local[6]= argv[0];
	local[7]= fqv[55];
	local[8]= local[4];
	local[9]= fqv[56];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtrobotIF4073;
irtrobotIF4072:
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtrobotCLO4074,env,argv,local);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
irtrobotIF4073:
	local[5] = local[6];
irtrobotKEY4071:
	w = local[1];
	if (!iscons(w)) goto irtrobotOR4077;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[23])(ctx,1,local+6,&ftab[23],fqv[149]); /*functionp*/
	if (w!=NIL) goto irtrobotOR4077;
	goto irtrobotIF4075;
irtrobotOR4077:
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[1] = w;
	local[6]= local[1];
	goto irtrobotIF4076;
irtrobotIF4075:
	local[6]= NIL;
irtrobotIF4076:
	local[6]= (pointer)get_sym_func(fqv[151]);
	local[7]= argv[0];
	local[8]= *(ovafptr(argv[1],fqv[38]));
	local[9]= fqv[117];
	local[10]= argv[2];
	local[11]= argv[3];
	local[12]= fqv[55];
	local[13]= local[5];
	local[14]= fqv[61];
	local[15]= local[4];
	local[16]= fqv[119];
	local[17]= local[1];
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,13,local+6); /*apply*/
	local[6]= w;
	if (local[2]==NIL) goto irtrobotIF4078;
	local[7]= argv[0];
	local[8]= fqv[145];
	local[9]= local[3];
	local[10]= fqv[119];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	goto irtrobotIF4079;
irtrobotIF4078:
	local[7]= NIL;
irtrobotIF4079:
	w = local[6];
	local[0]= w;
irtrobotBLK4065:
	ctx->vsp=local; return(local[0]);}

/*:look-at-target*/
static pointer irtrobotM4080robot_model_look_at_target(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[153], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4082;
	local[0] = NIL;
irtrobotKEY4082:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[24])(ctx,1,local+1,&ftab[24],fqv[154]); /*float-vector-p*/
	if (w==NIL) goto irtrobotCON4084;
	local[1]= argv[0];
	local[2]= fqv[70];
	local[3]= fqv[69];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtrobotCON4083;
irtrobotCON4084:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[155]); /*coordinates-p*/
	if (w==NIL) goto irtrobotCON4085;
	local[1]= argv[0];
	local[2]= fqv[70];
	local[3]= fqv[69];
	local[4]= argv[2];
	local[5]= fqv[97];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtrobotCON4083;
irtrobotCON4085:
	w = argv[2];
	if (!iscons(w)) goto irtrobotCON4086;
	local[1]= (pointer)get_sym_func(fqv[156]);
	local[2]= (pointer)get_sym_func(fqv[154]);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[42]); /*every*/
	if (w==NIL) goto irtrobotCON4086;
	local[1]= argv[0];
	local[2]= fqv[70];
	local[3]= fqv[69];
	local[4]= makeflt(1.0000000000000000000000e+00);
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= (pointer)get_sym_func(fqv[32]);
	local[6]= argv[2];
	local[7]= fqv[157];
	local[8]= fqv[158];
	ctx->vsp=local+9;
	w=(*ftab[5])(ctx,4,local+5,&ftab[5],fqv[31]); /*reduce*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtrobotCON4083;
irtrobotCON4086:
	w = argv[2];
	if (!iscons(w)) goto irtrobotCON4087;
	local[1]= (pointer)get_sym_func(fqv[156]);
	local[2]= (pointer)get_sym_func(fqv[155]);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[42]); /*every*/
	if (w==NIL) goto irtrobotCON4087;
	local[1]= argv[0];
	local[2]= fqv[70];
	local[3]= fqv[69];
	local[4]= makeflt(1.0000000000000000000000e+00);
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= (pointer)get_sym_func(fqv[32]);
	local[6]= argv[2];
	local[7]= fqv[97];
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,2,local+6,&ftab[13],fqv[80]); /*send-all*/
	local[6]= w;
	local[7]= fqv[157];
	local[8]= fqv[159];
	ctx->vsp=local+9;
	w=(*ftab[5])(ctx,4,local+5,&ftab[5],fqv[31]); /*reduce*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtrobotCON4083;
irtrobotCON4087:
	local[1]= ((argv[2])==NIL?T:NIL);
	if (local[1]!=NIL) goto irtrobotCON4083;
irtrobotCON4088:
	local[1]= argv[0];
	local[2]= fqv[70];
	local[3]= fqv[69];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[97];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtrobotCON4083;
irtrobotCON4089:
	local[1]= NIL;
irtrobotCON4083:
	w = local[1];
	local[0]= w;
irtrobotBLK4081:
	ctx->vsp=local; return(local[0]);}

/*:init-pose*/
static pointer irtrobotM4090robot_model_init_pose(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[51];
	local[2]= loadglobal(fqv[53]);
	local[3]= argv[0];
	local[4]= fqv[103];
	local[5]= argv[0];
	local[6]= fqv[71];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtrobotBLK4091:
	ctx->vsp=local; return(local[0]);}

/*:torque-vector*/
static pointer irtrobotM4092robot_model_torque_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[160], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4094;
	local[0] = NIL;
irtrobotKEY4094:
	if (n & (1<<1)) goto irtrobotKEY4095;
	local[1] = NIL;
irtrobotKEY4095:
	if (n & (1<<2)) goto irtrobotKEY4096;
	local[2] = NIL;
irtrobotKEY4096:
	if (n & (1<<3)) goto irtrobotKEY4097;
	local[3] = NIL;
irtrobotKEY4097:
	if (n & (1<<4)) goto irtrobotKEY4098;
	local[4] = T;
irtrobotKEY4098:
	if (n & (1<<5)) goto irtrobotKEY4099;
	local[5] = makeflt(4.9999999999999975019982e-03);
irtrobotKEY4099:
	if (n & (1<<6)) goto irtrobotKEY4100;
	local[10]= argv[0];
	local[11]= fqv[51];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[6] = w;
irtrobotKEY4100:
	if (n & (1<<7)) goto irtrobotKEY4101;
	local[10]= argv[0];
	local[11]= fqv[71];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[64];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[7] = w;
irtrobotKEY4101:
	if (n & (1<<8)) goto irtrobotKEY4102;
	local[10]= argv[0];
	local[11]= fqv[161];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[8] = w;
irtrobotKEY4102:
	if (n & (1<<9)) goto irtrobotKEY4103;
	local[10]= (pointer)get_sym_func(fqv[40]);
	local[11]= argv[0];
	local[12]= fqv[41];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[6])(ctx,2,local+10,&ftab[6],fqv[42]); /*every*/
	if (w!=NIL) goto irtrobotIF4104;
	if (local[0]==NIL) goto irtrobotAND4106;
	if (local[1]==NIL) goto irtrobotAND4106;
	if (local[2]==NIL) goto irtrobotAND4106;
	goto irtrobotIF4104;
irtrobotAND4106:
	local[10]= fqv[162];
	goto irtrobotIF4105;
irtrobotIF4104:
	local[10]= NIL;
irtrobotIF4105:
	local[9] = local[10];
irtrobotKEY4103:
	local[10]= argv[0];
	local[11]= fqv[163];
	local[12]= fqv[122];
	local[13]= local[3];
	local[14]= fqv[164];
	local[15]= local[4];
	local[16]= fqv[165];
	local[17]= local[6];
	local[18]= fqv[166];
	local[19]= local[7];
	local[20]= fqv[167];
	local[21]= local[5];
	local[22]= fqv[168];
	local[23]= local[0];
	local[24]= fqv[169];
	local[25]= local[1];
	local[26]= fqv[119];
	local[27]= local[2];
	local[28]= fqv[161];
	local[29]= local[8];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,20,local+10); /*send*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(*ftab[14])(ctx,2,local+11,&ftab[14],fqv[90]); /*find-method*/
	if (w==NIL) goto irtrobotIF4107;
	local[11]= argv[0];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
irtrobotWHL4109:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtrobotWHX4110;
	local[14]= local[10];
	local[15]= local[12];
	local[16]= local[10];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[11];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SETELT(ctx,3,local+14); /*setelt*/
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= fqv[170];
	local[16]= local[10];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtrobotWHL4109;
irtrobotWHX4110:
	local[14]= NIL;
irtrobotBLK4111:
	w = NIL;
	local[11]= w;
	goto irtrobotIF4108;
irtrobotIF4107:
	local[11]= NIL;
irtrobotIF4108:
	w = local[10];
	local[0]= w;
irtrobotBLK4093:
	ctx->vsp=local; return(local[0]);}

/*:distribute-total-wrench-to-torque-method-default*/
static pointer irtrobotM4112robot_model_distribute_total_wrench_to_torque_method_default(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= fqv[171];
irtrobotWHL4114:
	if (local[2]==NIL) goto irtrobotWHX4115;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (w==NIL) goto irtrobotIF4117;
	local[3]= argv[0];
	local[4]= local[1];
	local[5]= fqv[43];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[0];
	goto irtrobotIF4118;
irtrobotIF4117:
	local[3]= NIL;
irtrobotIF4118:
	goto irtrobotWHL4114;
irtrobotWHX4115:
	local[3]= NIL;
irtrobotBLK4116:
	w = NIL;
	local[1]= argv[0];
	local[2]= fqv[172];
	local[3]= local[0];
	local[4]= fqv[97];
	ctx->vsp=local+5;
	w=(*ftab[13])(ctx,2,local+3,&ftab[13],fqv[80]); /*send-all*/
	local[3]= w;
	local[4]= fqv[173];
	local[5]= loadglobal(fqv[53]);
	local[6]= argv[0];
	local[7]= fqv[71];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[174];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[71];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[175];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,3,local+5); /*concatenate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[176];
	local[4]= fqv[168];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[169];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[119];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,8,local+2); /*send*/
	local[0]= w;
irtrobotBLK4113:
	ctx->vsp=local; return(local[0]);}

/*:calc-force-from-joint-torque*/
static pointer irtrobotM4119robot_model_calc_force_from_joint_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[177], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4121;
	local[2]= argv[0];
	local[3]= argv[2];
	local[4]= fqv[43];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0] = w;
irtrobotKEY4121:
	if (n & (1<<1)) goto irtrobotKEY4122;
	local[1] = NIL;
irtrobotKEY4122:
	local[2]= argv[0];
	local[3]= fqv[55];
	local[4]= local[0];
	local[5]= fqv[56];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	if (local[1]!=NIL) goto irtrobotIF4123;
	local[5]= argv[0];
	local[6]= argv[2];
	local[7]= fqv[71];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	goto irtrobotIF4124;
irtrobotIF4123:
	local[5]= NIL;
irtrobotIF4124:
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[178];
	local[5]= local[2];
	local[6]= fqv[61];
	local[7]= local[0];
	local[8]= fqv[102];
	local[9]= T;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	local[10]= fqv[100];
	local[11]= T;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,9,local+3); /*send*/
	local[3]= w;
	local[4]= loadglobal(fqv[53]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtrobotWHL4125:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtrobotWHX4126;
	local[7]= local[4];
	local[8]= local[5];
	local[9]= argv[3];
	local[10]= local[2];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= fqv[79];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[78];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[26])(ctx,2,local+10,&ftab[26],fqv[179]); /*position*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtrobotWHL4125;
irtrobotWHX4126:
	local[7]= NIL;
irtrobotBLK4127:
	w = NIL;
	local[5]= argv[0];
	local[6]= fqv[180];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)TRANSFORM(ctx,2,local+5); /*transform*/
	local[0]= w;
irtrobotBLK4120:
	ctx->vsp=local; return(local[0]);}

/*:fullbody-inverse-kinematics*/
static pointer irtrobotM4128robot_model_fullbody_inverse_kinematics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtrobotRST4130:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[181], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtrobotKEY4131;
	local[1] = NIL;
irtrobotKEY4131:
	if (n & (1<<1)) goto irtrobotKEY4132;
	local[2] = NIL;
irtrobotKEY4132:
	if (n & (1<<2)) goto irtrobotKEY4133;
	local[15]= makeint((eusinteger_t)-500L);
	local[16]= makeint((eusinteger_t)-500L);
	local[17]= makeint((eusinteger_t)-500L);
	local[18]= makeint((eusinteger_t)-20L);
	local[19]= makeint((eusinteger_t)-20L);
	local[20]= makeint((eusinteger_t)-10L);
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,6,local+15); /*float-vector*/
	local[3] = w;
irtrobotKEY4133:
	if (n & (1<<3)) goto irtrobotKEY4134;
	local[15]= makeint((eusinteger_t)500L);
	local[16]= makeint((eusinteger_t)500L);
	local[17]= makeint((eusinteger_t)25L);
	local[18]= makeint((eusinteger_t)20L);
	local[19]= makeint((eusinteger_t)20L);
	local[20]= makeint((eusinteger_t)10L);
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,6,local+15); /*float-vector*/
	local[4] = w;
irtrobotKEY4134:
	if (n & (1<<4)) goto irtrobotKEY4135;
	local[5] = fqv[182];
irtrobotKEY4135:
	if (n & (1<<5)) goto irtrobotKEY4136;
	local[15]= (pointer)get_sym_func(fqv[183]);
	local[16]= makeflt(5.0000000000000000000000e-01);
	local[17]= argv[0];
	local[18]= fqv[41];
	local[19]= fqv[43];
	local[20]= fqv[97];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,3,local+15); /*apply*/
	local[6] = w;
irtrobotKEY4136:
	if (n & (1<<6)) goto irtrobotKEY4137;
	local[7] = makeflt(1.0000000000000000000000e+00);
irtrobotKEY4137:
	if (n & (1<<7)) goto irtrobotKEY4138;
	local[8] = fqv[7];
irtrobotKEY4138:
	if (n & (1<<8)) goto irtrobotKEY4139;
	local[9] = NIL;
irtrobotKEY4139:
	if (n & (1<<9)) goto irtrobotKEY4140;
	local[10] = makeflt(5.0000000000000000000000e+00);
irtrobotKEY4140:
	if (n & (1<<10)) goto irtrobotKEY4141;
	local[11] = NIL;
irtrobotKEY4141:
	if (n & (1<<11)) goto irtrobotKEY4142;
	local[12] = NIL;
irtrobotKEY4142:
	if (n & (1<<12)) goto irtrobotKEY4143;
	local[13] = NIL;
irtrobotKEY4143:
	if (n & (1<<13)) goto irtrobotKEY4144;
	local[14] = makeint((eusinteger_t)2L);
irtrobotKEY4144:
	local[15]= argv[0];
	local[16]= (pointer)get_sym_func(fqv[184]);
	local[17]= local[2];
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,2,local+16,&ftab[6],fqv[42]); /*every*/
	if (w==NIL) goto irtrobotIF4145;
	local[16]= local[2];
	goto irtrobotIF4146;
irtrobotIF4145:
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	local[16]= w;
irtrobotIF4146:
	local[17]= fqv[185];
	local[18]= local[3];
	local[19]= fqv[186];
	local[20]= local[4];
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,4,local+17); /*list*/
	local[17]= w;
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)APPEND(ctx,2,local+17); /*append*/
	local[17]= w;
	local[18]= loadglobal(fqv[33]);
	ctx->vsp=local+19;
	w=(pointer)INSTANTIATE(ctx,1,local+18); /*instantiate*/
	local[18]= w;
	local[19]= local[18];
	local[20]= fqv[34];
	ctx->vsp=local+21;
	w=(*ftab[2])(ctx,0,local+21,&ftab[2],fqv[2]); /*make-cascoords*/
	local[21]= w;
	local[22]= fqv[35];
	local[23]= makeint((eusinteger_t)150L);
	local[24]= makeint((eusinteger_t)10L);
	local[25]= makeint((eusinteger_t)400L);
	ctx->vsp=local+26;
	w=(*ftab[1])(ctx,3,local+23,&ftab[1],fqv[1]); /*make-cube*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[23]= w;
	local[24]= fqv[36];
	local[25]= fqv[187];
	local[26]= fqv[121];
	local[27]= makeint((eusinteger_t)0L);
	local[28]= fqv[29];
	local[29]= makeint((eusinteger_t)0L);
	local[30]= makeint((eusinteger_t)0L);
	local[31]= makeint((eusinteger_t)0L);
	ctx->vsp=local+32;
	w=(pointer)MKFLTVEC(ctx,3,local+29); /*float-vector*/
	local[29]= w;
	local[30]= fqv[188];
	local[31]= makeint((eusinteger_t)3L);
	local[32]= makeint((eusinteger_t)3L);
	ctx->vsp=local+33;
	w=(*ftab[27])(ctx,2,local+31,&ftab[27],fqv[189]); /*make-matrix*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)SEND(ctx,13,local+19); /*send*/
	w = local[18];
	local[18]= w;
	local[19]= local[15];
	local[20]= fqv[71];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	local[20]= local[19];
	local[21]= loadglobal(fqv[33]);
	local[22]= fqv[190];
	local[23]= loadglobal(fqv[191]);
	ctx->vsp=local+24;
	w=(pointer)INSTANTIATE(ctx,1,local+23); /*instantiate*/
	local[23]= w;
	local[24]= (pointer)get_sym_func(fqv[60]);
	local[25]= local[23];
	local[26]= fqv[34];
	local[27]= fqv[192];
	local[28]= local[15];
	local[29]= fqv[107];
	local[30]= local[18];
	local[31]= local[17];
	ctx->vsp=local+32;
	w=(pointer)APPLY(ctx,8,local+24); /*apply*/
	w = local[23];
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)SENDMESSAGE(ctx,4,local+20); /*send-message*/
	local[20]= local[19];
	local[21]= fqv[193];
	local[22]= local[18];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= local[18];
	local[21]= fqv[194];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	ctx->vsp=local+20;
	w = makeclosure(codevec,quotevec,irtrobotUWP4147,env,argv,local);
	local[20]=(pointer)(ctx->protfp); local[21]=w;
	ctx->protfp=(struct protectframe *)(local+20);
	ctx->vsp=local+22;
	local[22]= makeclosure(codevec,quotevec,irtrobotCLO4148,env,argv,local);
	local[23]= local[16];
	ctx->vsp=local+24;
	w=(pointer)MAPCAR(ctx,2,local+22); /*mapcar*/
	local[22]= w;
	local[23]= (pointer)get_sym_func(fqv[60]);
	local[24]= argv[0];
	local[25]= fqv[54];
	local[26]= argv[2];
	local[27]= fqv[61];
	local[28]= local[1];
	local[29]= fqv[55];
	local[30]= local[22];
	local[31]= fqv[195];
	local[32]= local[7];
	local[33]= fqv[196];
	local[34]= local[10];
	local[35]= fqv[197];
	local[36]= local[6];
	local[37]= fqv[198];
	local[38]= local[8];
	local[39]= fqv[199];
	local[40]= local[9];
	local[41]= fqv[200];
	local[42]= local[13];
	local[43]= fqv[201];
	local[44]= local[14];
	local[45]= fqv[202];
	local[46]= local[11];
	local[47]= argv[0];
	local[48]= fqv[71];
	ctx->vsp=local+49;
	w=(pointer)SEND(ctx,2,local+47); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[47]= (w)->c.cons.car;
	local[48]= local[5];
	ctx->vsp=local+49;
	w=(pointer)LIST(ctx,2,local+47); /*list*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(pointer)LIST(ctx,1,local+47); /*list*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(pointer)APPEND(ctx,2,local+46); /*append*/
	local[46]= w;
	local[47]= local[0];
	ctx->vsp=local+48;
	w=(pointer)APPLY(ctx,25,local+23); /*apply*/
	ctx->vsp=local+22;
	irtrobotUWP4147(ctx,0,local+22,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
irtrobotBLK4129:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-limit-nspace-for-6dof*/
static pointer irtrobotM4149robot_model_joint_angle_limit_nspace_for_6dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[203], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4151;
	local[0] = makeflt(9.9999999999999950039964e-03);
irtrobotKEY4151:
	if (n & (1<<1)) goto irtrobotKEY4152;
	local[1] = fqv[204];
irtrobotKEY4152:
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO4153,env,argv,local);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[178];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtrobotCLO4154,env,argv,local);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	local[6]= fqv[61];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtrobotCLO4155,env,argv,local);
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	local[8]= fqv[100];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	local[10]= fqv[205];
	local[11]= T;
	ctx->vsp=local+12;
	w=(*ftab[28])(ctx,3,local+9,&ftab[28],fqv[206]); /*make-list*/
	local[9]= w;
	local[10]= fqv[102];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	local[12]= fqv[205];
	local[13]= T;
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,3,local+11,&ftab[28],fqv[206]); /*make-list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,9,local+3); /*send*/
	local[3]= w;
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(*ftab[29])(ctx,2,local+4,&ftab[29],fqv[207]); /*array-dimension*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)6L);
	ctx->vsp=local+6;
	w=(*ftab[27])(ctx,2,local+4,&ftab[27],fqv[189]); /*make-matrix*/
	local[4]= w;
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[29])(ctx,2,local+5,&ftab[29],fqv[207]); /*array-dimension*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[103];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[27])(ctx,2,local+5,&ftab[27],fqv[189]); /*make-matrix*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[29])(ctx,2,local+7,&ftab[29],fqv[207]); /*array-dimension*/
	local[7]= w;
irtrobotWHL4156:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtrobotWHX4157;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(*ftab[29])(ctx,2,local+9,&ftab[29],fqv[207]); /*array-dimension*/
	local[9]= w;
irtrobotWHL4159:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtrobotWHX4160;
	local[10]= local[4];
	local[11]= local[6];
	local[12]= local[8];
	local[13]= local[3];
	local[14]= local[6];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,3,local+13); /*aref*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ASET(ctx,4,local+10); /*aset*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtrobotWHL4159;
irtrobotWHX4160:
	local[10]= NIL;
irtrobotBLK4161:
	w = NIL;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtrobotWHL4156;
irtrobotWHX4157:
	local[8]= NIL;
irtrobotBLK4158:
	w = NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[29])(ctx,2,local+7,&ftab[29],fqv[207]); /*array-dimension*/
	local[7]= w;
irtrobotWHL4162:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtrobotWHX4163;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[5];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(*ftab[29])(ctx,2,local+9,&ftab[29],fqv[207]); /*array-dimension*/
	local[9]= w;
irtrobotWHL4165:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtrobotWHX4166;
	local[10]= local[5];
	local[11]= local[6];
	local[12]= local[8];
	local[13]= local[3];
	local[14]= local[6];
	local[15]= makeint((eusinteger_t)6L);
	w = local[8];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[15]= (pointer)((eusinteger_t)local[15] + (eusinteger_t)w);
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,3,local+13); /*aref*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ASET(ctx,4,local+10); /*aset*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtrobotWHL4165;
irtrobotWHX4166:
	local[10]= NIL;
irtrobotBLK4167:
	w = NIL;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtrobotWHL4162;
irtrobotWHX4163:
	local[8]= NIL;
irtrobotBLK4164:
	w = NIL;
	local[6]= argv[0];
	local[7]= fqv[180];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	local[7]= makeint((eusinteger_t)-1L);
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[208];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[79];
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[80]); /*send-all*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[30])(ctx,1,local+8,&ftab[30],fqv[209]); /*joint-angle-limit-nspace*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRANSFORM(ctx,2,local+6); /*transform*/
	local[6]= w;
	local[7]= local[6];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[6];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	w = local[6];
	local[0]= w;
irtrobotBLK4150:
	ctx->vsp=local; return(local[0]);}

/*:joint-order*/
static pointer irtrobotM4168robot_model_joint_order(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtrobotENT4171;}
	local[0]= NIL;
irtrobotENT4171:
irtrobotENT4170:
	if (n>4) maerror();
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtrobotCLO4172,env,argv,local);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO4173,env,argv,local);
	local[3]= argv[0];
	local[4]= fqv[210];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAPCAN(ctx,2,local+2); /*mapcan*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	if (local[0]!=NIL) goto irtrobotIF4174;
	local[5]= argv[2];
	local[6]= local[5];
	w = fqv[211];
	if (memq(local[6],w)==NIL) goto irtrobotIF4176;
	local[6]= fqv[212];
	goto irtrobotIF4177;
irtrobotIF4176:
	local[6]= local[5];
	w = fqv[213];
	if (memq(local[6],w)==NIL) goto irtrobotIF4178;
	local[6]= fqv[214];
	goto irtrobotIF4179;
irtrobotIF4178:
	local[6]= local[5];
	w = fqv[215];
	if (memq(local[6],w)==NIL) goto irtrobotIF4180;
	local[6]= fqv[216];
	goto irtrobotIF4181;
irtrobotIF4180:
	local[6]= local[5];
	w = fqv[217];
	if (memq(local[6],w)==NIL) goto irtrobotIF4182;
	local[6]= fqv[218];
	goto irtrobotIF4183;
irtrobotIF4182:
	local[6]= NIL;
irtrobotIF4183:
irtrobotIF4181:
irtrobotIF4179:
irtrobotIF4177:
	w = local[6];
	local[0] = w;
	local[5]= local[0];
	goto irtrobotIF4175;
irtrobotIF4174:
	local[5]= NIL;
irtrobotIF4175:
	local[5]= NIL;
	local[6]= local[0];
irtrobotWHL4184:
	if (local[6]==NIL) goto irtrobotWHX4185;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
irtrobotWHL4187:
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(*ftab[11])(ctx,1,local+7,&ftab[11],fqv[74]); /*string-upcase*/
	local[7]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,1,local+8,&ftab[31],fqv[219]); /*symbol-name*/
	local[4] = w;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,2,local+7,&ftab[32],fqv[220]); /*substringp*/
	if (w==NIL) goto irtrobotWHX4188;
	local[7]= NIL;
	local[8]= fqv[221];
	local[9]= local[4];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SUB1(ctx,1,local+10); /*1-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,2,local+9); /*subseq*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,1,local+7,&ftab[8],fqv[47]); /*read-from-string*/
	local[7]= w;
	w = local[2];
	ctx->vsp=local+8;
	local[2] = cons(ctx,local[7],w);
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[7];
	goto irtrobotWHL4187;
irtrobotWHX4188:
	local[7]= NIL;
irtrobotBLK4189:
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	local[7]= local[2];
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	local[2] = NIL;
	goto irtrobotWHL4184;
irtrobotWHX4185:
	local[7]= NIL;
irtrobotBLK4186:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)NREVERSE(ctx,1,local+5); /*nreverse*/
	local[0]= w;
irtrobotBLK4169:
	ctx->vsp=local; return(local[0]);}

/*:print-vector-for-robot-limb*/
static pointer irtrobotM4190robot_model_print_vector_for_robot_limb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtrobotCLO4192,env,argv,local);
	local[1]= argv[0];
	local[2]= fqv[78];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[192];
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[80]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[222]); /*remove-duplicates*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[78];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= T;
	local[3]= fqv[223];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[2]= NIL;
	local[3]= local[0];
irtrobotWHL4193:
	if (local[3]==NIL) goto irtrobotWHX4194;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= NIL;
	local[5]= argv[0];
	local[6]= local[2];
	local[7]= fqv[78];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
irtrobotWHL4196:
	if (local[5]==NIL) goto irtrobotWHX4197;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= T;
	local[7]= fqv[224];
	local[8]= argv[2];
	local[9]= local[4];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[26])(ctx,2,local+9,&ftab[26],fqv[179]); /*position*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	goto irtrobotWHL4196;
irtrobotWHX4197:
	local[6]= NIL;
irtrobotBLK4198:
	w = NIL;
	local[4]= T;
	local[5]= fqv[225];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	goto irtrobotWHL4193;
irtrobotWHX4194:
	local[4]= NIL;
irtrobotBLK4195:
	w = NIL;
	local[2]= T;
	local[3]= fqv[226];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	w = argv[2];
	local[0]= w;
irtrobotBLK4191:
	ctx->vsp=local; return(local[0]);}

/*:calc-zmp-from-forces-moments*/
static pointer irtrobotM4199robot_model_calc_zmp_from_forces_moments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[227], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4201;
	local[0] = fqv[20];
irtrobotKEY4201:
	if (n & (1<<1)) goto irtrobotKEY4202;
	local[6]= argv[0];
	local[7]= fqv[86];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (w==NIL) goto irtrobotIF4203;
	local[6]= NIL;
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtrobotCLO4205,env,argv,local);
	local[8]= argv[0];
	local[9]= fqv[86];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,2,local+6,&ftab[7],fqv[45]); /*remove*/
	local[6]= w;
	goto irtrobotIF4204;
irtrobotIF4203:
	local[6]= fqv[228];
irtrobotIF4204:
	local[1] = local[6];
irtrobotKEY4202:
	if (n & (1<<2)) goto irtrobotKEY4206;
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtrobotCLO4207,env,argv,local);
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[2] = w;
irtrobotKEY4206:
	if (n & (1<<3)) goto irtrobotKEY4208;
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtrobotCLO4209,env,argv,local);
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[3] = w;
irtrobotKEY4208:
	if (n & (1<<4)) goto irtrobotKEY4210;
	local[4] = makeflt(1.0000000000000000208167e-03);
irtrobotKEY4210:
	if (n & (1<<5)) goto irtrobotKEY4211;
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtrobotCLO4212,env,argv,local);
	local[7]= local[2];
	local[8]= argv[2];
	local[9]= argv[3];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,5,local+6); /*mapcar*/
	local[5] = w;
irtrobotKEY4211:
	local[6]= NIL;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,2,local+6,&ftab[7],fqv[45]); /*remove*/
	local[6]= w;
	local[7]= (pointer)get_sym_func(fqv[30]);
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtrobotCLO4213,env,argv,local);
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[8]= w;
	local[9]= fqv[157];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[5])(ctx,4,local+7,&ftab[5],fqv[31]); /*reduce*/
	local[7]= w;
	local[8]= local[7];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtrobotIF4214;
	local[8]= NIL;
	goto irtrobotIF4215;
irtrobotIF4214:
	local[8]= makeflt(1.0000000000000000000000e+00);
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtrobotCLO4216,env,argv,local);
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,2,local+10); /*mapcar*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[5])(ctx,2,local+9,&ftab[5],fqv[31]); /*reduce*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	local[9]= local[0];
	if (fqv[20]!=local[9]) goto irtrobotCON4218;
	local[9]= local[8];
	goto irtrobotCON4217;
irtrobotCON4218:
	local[9]= local[0];
	if (fqv[65]!=local[9]) goto irtrobotCON4219;
	local[9]= argv[0];
	local[10]= fqv[71];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[229];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	goto irtrobotCON4217;
irtrobotCON4219:
	local[9]= T;
	if (local[9]!=NIL) goto irtrobotCON4217;
irtrobotCON4220:
	local[9]= NIL;
irtrobotCON4217:
	w = local[9];
	local[8]= w;
irtrobotIF4215:
	w = local[8];
	local[0]= w;
irtrobotBLK4200:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3881(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[79];
	local[2]= fqv[129];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3882(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[79];
	local[2]= fqv[129];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3982(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[36];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[230]); /*string*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= fqv[36];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,1,local+1,&ftab[34],fqv[230]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)STR_LT(ctx,2,local+0); /*string<*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3987(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[129];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3996(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[36];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO3999(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[56];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0];
	local[2]= env->c.clo.env1[3];
	local[3]= fqv[49];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,1,local+1,&ftab[20],fqv[128]); /*all-child-links*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[35])(ctx,2,local+0,&ftab[35],fqv[231]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4044(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4057(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[55];
	local[2]= argv[0];
	local[3]= fqv[56];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4063(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[25])(ctx,1,local+0,&ftab[25],fqv[155]); /*coordinates-p*/
	local[0]= w;
	if (w!=NIL) goto irtrobotOR4221;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[23])(ctx,1,local+0,&ftab[23],fqv[149]); /*functionp*/
	local[0]= w;
irtrobotOR4221:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4074(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[55];
	local[2]= argv[0];
	local[3]= fqv[56];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotUWP4147(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[19];
	local[1]= fqv[232];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= env->c.clo.env2[19];
	local[1]= fqv[233];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= env->c.clo.env2[18];
	local[1]= fqv[234];
	local[2]= env->c.clo.env2[19];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4148(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[19];
	w = argv[0];
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4153(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[71];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4154(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4155(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4172(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtrobotCLO4222,env,argv,local);
	local[2]= env->c.clo.env1[0];
	local[3]= env->c.clo.env1[2];
	local[4]= fqv[78];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[36])(ctx,2,local+1,&ftab[36],fqv[235]); /*find-if*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4222(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env0->c.clo.env1[0];
	local[2]= env->c.clo.env1[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = ((w)==(local[0])?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4173(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[236];
	local[2]= env->c.clo.env1[2];
	ctx->vsp=local+3;
	w=(*ftab[31])(ctx,1,local+2,&ftab[31],fqv[219]); /*symbol-name*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,1,local+1,&ftab[34],fqv[230]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[220]); /*substringp*/
	if (w==NIL) goto irtrobotIF4223;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtrobotIF4224;
irtrobotIF4223:
	local[0]= NIL;
irtrobotIF4224:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4192(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtrobotCLO4225,env,argv,local);
	local[1]= fqv[237];
	ctx->vsp=local+2;
	w=(*ftab[36])(ctx,2,local+0,&ftab[36],fqv[235]); /*find-if*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4225(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= env->c.clo.env0->c.clo.env1[0];
	local[2]= argv[0];
	local[3]= fqv[71];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[35])(ctx,2,local+0,&ftab[35],fqv[231]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4205(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtrobotCLO4226,env,argv,local);
	local[1]= fqv[238];
	ctx->vsp=local+2;
	w=(*ftab[36])(ctx,2,local+0,&ftab[36],fqv[235]); /*find-if*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4226(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= env->c.clo.env0->c.clo.env1[0];
	local[2]= argv[0];
	local[3]= fqv[86];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4207(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[132];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4209(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4212(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[0];
	local[2]= fqv[97];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[108];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[108];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= env->c.clo.env1[0];
	local[4]= fqv[239];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= argv[0];
	local[8]= argv[3];
	local[9]= fqv[240];
	local[10]= env->c.clo.env2[4];
	local[11]= fqv[241];
	local[12]= T;
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,10,local+3); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4213(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[242];
	w = argv[0];
	w=memq(local[0],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4216(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[242];
	w = argv[0];
	w=memq(local[0],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[243];
	w = argv[0];
	w=memq(local[1],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:foot-midcoords*/
static pointer irtrobotM4227robot_model_foot_midcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtrobotENT4230;}
	local[0]= makeflt(5.0000000000000000000000e-01);
irtrobotENT4230:
irtrobotENT4229:
	if (n>3) maerror();
	local[1]= (pointer)get_sym_func(fqv[244]);
	local[2]= local[0];
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= fqv[43];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[0]= w;
irtrobotBLK4228:
	ctx->vsp=local; return(local[0]);}

/*:fix-leg-to-coords*/
static pointer irtrobotM4231robot_model_fix_leg_to_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtrobotENT4234;}
	local[0]= fqv[245];
irtrobotENT4234:
irtrobotENT4233:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[246], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtrobotKEY4235;
	local[1] = makeflt(5.0000000000000000000000e-01);
irtrobotKEY4235:
	local[2]= (pointer)get_sym_func(fqv[40]);
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= fqv[71];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[37])(ctx,2,local+2,&ftab[37],fqv[247]); /*some*/
	if (w==NIL) goto irtrobotIF4236;
	w = NIL;
	ctx->vsp=local+2;
	local[0]=w;
	goto irtrobotBLK4232;
	goto irtrobotIF4237;
irtrobotIF4236:
	local[2]= NIL;
irtrobotIF4237:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[0];
	if (fqv[248]==local[8]) goto irtrobotOR4240;
	local[8]= local[0];
	if (fqv[142]==local[8]) goto irtrobotOR4240;
	goto irtrobotCON4239;
irtrobotOR4240:
	local[8]= argv[0];
	local[9]= fqv[142];
	local[10]= fqv[43];
	local[11]= fqv[64];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[2] = w;
	local[8]= local[2];
	goto irtrobotCON4238;
irtrobotCON4239:
	local[8]= local[0];
	if (fqv[249]==local[8]) goto irtrobotOR4242;
	local[8]= local[0];
	if (fqv[143]==local[8]) goto irtrobotOR4242;
	goto irtrobotCON4241;
irtrobotOR4242:
	local[8]= argv[0];
	local[9]= fqv[143];
	local[10]= fqv[43];
	local[11]= fqv[64];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[2] = w;
	local[8]= local[2];
	goto irtrobotCON4238;
irtrobotCON4241:
	local[8]= local[1];
	local[9]= argv[0];
	local[10]= fqv[142];
	local[11]= fqv[43];
	local[12]= fqv[64];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= fqv[143];
	local[12]= fqv[43];
	local[13]= fqv[64];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[38])(ctx,3,local+8,&ftab[38],fqv[244]); /*midcoords*/
	local[2] = w;
	local[8]= local[2];
	goto irtrobotCON4238;
irtrobotCON4243:
	local[8]= NIL;
irtrobotCON4238:
	local[8]= argv[2];
	local[9]= fqv[64];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[3] = w;
	local[8]= local[2];
	local[9]= fqv[250];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[4] = w;
	local[8]= local[3];
	local[9]= fqv[21];
	local[10]= local[4];
	local[11]= fqv[65];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[251];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[252];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	w = local[3];
	local[0]= w;
irtrobotBLK4232:
	ctx->vsp=local; return(local[0]);}

/*:move-centroid-on-foot*/
static pointer irtrobotM4244robot_model_move_centroid_on_foot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtrobotRST4246:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[253], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtrobotKEY4247;
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtrobotCLO4248,env,argv,local);
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[1] = w;
irtrobotKEY4247:
	if (n & (1<<1)) goto irtrobotKEY4249;
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtrobotCLO4250,env,argv,local);
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[2] = w;
irtrobotKEY4249:
	if (n & (1<<2)) goto irtrobotKEY4251;
	local[3] = makeflt(5.0000000000000000000000e-01);
irtrobotKEY4251:
	if (n & (1<<3)) goto irtrobotKEY4252;
	local[7]= argv[2];
	if (fqv[245]!=local[7]) goto irtrobotIF4253;
	local[7]= (pointer)get_sym_func(fqv[183]);
	local[8]= local[3];
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtrobotCLO4255,env,argv,local);
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtrobotCLO4256,env,argv,local);
	local[11]= argv[3];
	ctx->vsp=local+12;
	w=(*ftab[22])(ctx,2,local+10,&ftab[22],fqv[139]); /*remove-if-not*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,3,local+7); /*apply*/
	local[7]= w;
	goto irtrobotIF4254;
irtrobotIF4253:
	local[7]= argv[0];
	local[8]= argv[2];
	local[9]= fqv[43];
	local[10]= fqv[97];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= w;
irtrobotIF4254:
	local[4] = local[7];
irtrobotKEY4252:
	if (n & (1<<4)) goto irtrobotKEY4257;
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtrobotCLO4258,env,argv,local);
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[5] = w;
irtrobotKEY4257:
	if (n & (1<<5)) goto irtrobotKEY4259;
	local[6] = fqv[254];
irtrobotKEY4259:
	local[7]= argv[0];
	w = argv[3];
	if (!!iscons(w)) goto irtrobotIF4260;
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	local[8]= w;
	goto irtrobotIF4261;
irtrobotIF4260:
	local[8]= argv[3];
irtrobotIF4261:
	if (NIL==NIL) goto irtrobotCON4263;
	w = NIL;
	if (!!iscons(w)) goto irtrobotIF4264;
	local[9]= NIL;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	goto irtrobotIF4265;
irtrobotIF4264:
	local[9]= NIL;
irtrobotIF4265:
	goto irtrobotCON4262;
irtrobotCON4263:
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtrobotCLO4267,env,argv,local);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	goto irtrobotCON4262;
irtrobotCON4266:
	local[9]= NIL;
irtrobotCON4262:
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtrobotCLO4268,env,argv,local);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,2,local+10); /*mapcar*/
	local[10]= w;
	local[11]= local[9];
	local[12]= local[10];
	local[13]= (pointer)get_sym_func(fqv[60]);
	local[14]= argv[0];
	local[15]= fqv[255];
	local[16]= local[5];
	local[17]= fqv[61];
	local[18]= local[11];
	local[19]= fqv[55];
	local[20]= local[12];
	local[21]= fqv[256];
	ctx->vsp=local+22;
	local[22]= makeclosure(codevec,quotevec,irtrobotCLO4269,env,argv,local);
	local[23]= argv[3];
	ctx->vsp=local+24;
	w=(*ftab[22])(ctx,2,local+22,&ftab[22],fqv[139]); /*remove-if-not*/
	local[22]= w;
	local[23]= fqv[257];
	local[24]= local[6];
	local[25]= fqv[258];
	local[26]= local[1];
	local[27]= fqv[259];
	local[28]= local[2];
	local[29]= fqv[197];
	local[30]= local[4];
	local[31]= local[0];
	ctx->vsp=local+32;
	w=(pointer)APPLY(ctx,19,local+13); /*apply*/
	local[0]= w;
irtrobotBLK4245:
	ctx->vsp=local; return(local[0]);}

/*:calc-walk-pattern-from-footstep-list*/
static pointer irtrobotM4270robot_model_calc_walk_pattern_from_footstep_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[260], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4272;
	local[0] = makeint((eusinteger_t)50L);
irtrobotKEY4272:
	if (n & (1<<1)) goto irtrobotKEY4273;
	local[1] = makeflt(9.9999999999999977795540e-02);
irtrobotKEY4273:
	if (n & (1<<2)) goto irtrobotKEY4274;
	local[2] = makeflt(1.0000000000000000000000e+00);
irtrobotKEY4274:
	if (n & (1<<3)) goto irtrobotKEY4275;
	local[3] = NIL;
irtrobotKEY4275:
	if (n & (1<<4)) goto irtrobotKEY4276;
	local[4] = NIL;
irtrobotKEY4276:
	if (n & (1<<5)) goto irtrobotKEY4277;
	local[15]= argv[0];
	local[16]= fqv[86];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	if (w==NIL) goto irtrobotIF4278;
	local[15]= NIL;
	ctx->vsp=local+16;
	local[16]= makeclosure(codevec,quotevec,irtrobotCLO4280,env,argv,local);
	local[17]= argv[0];
	local[18]= fqv[86];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)MAPCAR(ctx,2,local+16); /*mapcar*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[7])(ctx,2,local+15,&ftab[7],fqv[45]); /*remove*/
	local[15]= w;
	goto irtrobotIF4279;
irtrobotIF4278:
	local[15]= fqv[261];
irtrobotIF4279:
	local[5] = local[15];
irtrobotKEY4277:
	if (n & (1<<6)) goto irtrobotKEY4281;
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtrobotCLO4282,env,argv,local);
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)MAPCAN(ctx,2,local+15); /*mapcan*/
	local[6] = w;
irtrobotKEY4281:
	if (n & (1<<7)) goto irtrobotKEY4283;
	ctx->vsp=local+15;
	local[7] = makeclosure(codevec,quotevec,irtrobotCLO4284,env,argv,local);
irtrobotKEY4283:
	if (n & (1<<8)) goto irtrobotKEY4285;
	local[8] = T;
irtrobotKEY4285:
	if (n & (1<<9)) goto irtrobotKEY4286;
	local[9] = T;
irtrobotKEY4286:
	if (n & (1<<10)) goto irtrobotKEY4287;
	local[10] = makeint((eusinteger_t)1L);
irtrobotKEY4287:
	if (n & (1<<11)) goto irtrobotKEY4288;
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(*ftab[10])(ctx,1,local+15,&ftab[10],fqv[67]); /*deg2rad*/
	local[11] = w;
irtrobotKEY4288:
	if (n & (1<<12)) goto irtrobotKEY4289;
	local[12] = makeflt(1.0000000000000000000000e+00);
irtrobotKEY4289:
	if (n & (1<<13)) goto irtrobotKEY4290;
	local[13] = makeflt(9.9999999999999974298988e-07);
irtrobotKEY4290:
	if (n & (1<<14)) goto irtrobotKEY4291;
	local[14] = T;
irtrobotKEY4291:
	local[15]= NIL;
	local[16]= NIL;
	local[17]= makeint((eusinteger_t)0L);
	local[18]= loadglobal(fqv[262]);
	ctx->vsp=local+19;
	w=(pointer)INSTANTIATE(ctx,1,local+18); /*instantiate*/
	local[18]= w;
	local[19]= local[18];
	local[20]= fqv[34];
	local[21]= argv[0];
	local[22]= local[1];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,4,local+19); /*send*/
	w = local[18];
	local[18]= w;
	local[19]= local[7];
	ctx->vsp=local+20;
	w=(pointer)FUNCALL(ctx,1,local+19); /*funcall*/
	local[19]= local[18];
	local[20]= fqv[263];
	local[21]= argv[2];
	local[22]= local[2];
	local[23]= argv[0];
	local[24]= fqv[29];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,2,local+23); /*send*/
	local[23]= w;
	local[24]= fqv[264];
	local[25]= local[0];
	local[26]= fqv[265];
	local[27]= makeflt(1.9999999999999995559108e-01);
	local[28]= fqv[266];
	local[29]= local[6];
	local[30]= fqv[267];
	local[31]= local[5];
	local[32]= fqv[258];
	local[33]= local[10];
	local[34]= fqv[259];
	local[35]= local[11];
	local[36]= fqv[268];
	local[37]= local[8];
	local[38]= fqv[269];
	local[39]= local[9];
	local[40]= fqv[270];
	local[41]= local[12];
	local[42]= fqv[271];
	local[43]= local[13];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,25,local+19); /*send*/
irtrobotWHL4292:
	local[19]= local[18];
	local[20]= fqv[272];
	local[21]= fqv[273];
	local[22]= fqv[274];
	local[23]= fqv[275];
	local[24]= T;
	local[25]= fqv[276];
	local[26]= local[3];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,8,local+19); /*send*/
	local[16] = w;
	if (local[16]!=NIL) goto irtrobotWHX4293;
	goto irtrobotWHL4292;
irtrobotWHX4293:
	local[19]= NIL;
irtrobotBLK4294:
	if (local[14]==NIL) goto irtrobotIF4295;
	local[19]= makeint((eusinteger_t)0L);
	local[20]= makeint((eusinteger_t)2L);
irtrobotWHL4297:
	local[21]= local[19];
	w = local[20];
	if ((eusinteger_t)local[21] >= (eusinteger_t)w) goto irtrobotWHX4298;
	local[21]= argv[0];
	local[22]= fqv[277];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[19] = w;
	goto irtrobotWHL4297;
irtrobotWHX4298:
	local[21]= NIL;
irtrobotBLK4299:
	w = NIL;
	local[19]= w;
	goto irtrobotIF4296;
irtrobotIF4295:
	local[19]= NIL;
irtrobotIF4296:
irtrobotWHL4300:
	local[19]= local[18];
	local[20]= fqv[272];
	local[21]= fqv[273];
	local[22]= fqv[274];
	local[23]= fqv[275];
	local[24]= T;
	local[25]= fqv[276];
	local[26]= local[3];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,8,local+19); /*send*/
	local[16] = w;
	if (local[16]==NIL) goto irtrobotWHX4301;
	if (local[14]==NIL) goto irtrobotIF4303;
	local[19]= argv[0];
	local[20]= fqv[277];
	local[21]= argv[0];
	local[22]= fqv[51];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= w;
	local[22]= argv[0];
	local[23]= fqv[71];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	local[23]= fqv[64];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	local[23]= fqv[167];
	local[24]= local[1];
	local[25]= fqv[278];
	local[26]= local[16];
	local[27]= makeint((eusinteger_t)5L);
	ctx->vsp=local+28;
	w=(pointer)ELT(ctx,2,local+26); /*elt*/
	local[26]= w;
	local[27]= makeint((eusinteger_t)2L);
	ctx->vsp=local+28;
	w=(pointer)ELT(ctx,2,local+26); /*elt*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,8,local+19); /*send*/
	local[19]= w;
	goto irtrobotIF4304;
irtrobotIF4303:
	local[19]= NIL;
irtrobotIF4304:
	ctx->vsp=local+20;
	local[20]= makeclosure(codevec,quotevec,irtrobotCLO4305,env,argv,local);
	local[21]= *(ovafptr(local[18],fqv[279]));
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,2,local+20); /*mapcar*/
	local[20]= w;
	local[21]= local[16];
	local[22]= makeint((eusinteger_t)8L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	if (local[4]==NIL) goto irtrobotIF4306;
	local[22]= argv[0];
	local[23]= fqv[280];
	local[24]= local[20];
	local[25]= local[21];
	local[26]= local[16];
	local[27]= makeint((eusinteger_t)5L);
	ctx->vsp=local+28;
	w=(pointer)ELT(ctx,2,local+26); /*elt*/
	local[26]= w;
	local[27]= local[16];
	local[28]= makeint((eusinteger_t)6L);
	ctx->vsp=local+29;
	w=(pointer)ELT(ctx,2,local+27); /*elt*/
	local[27]= w;
	local[28]= local[16];
	local[29]= makeint((eusinteger_t)7L);
	ctx->vsp=local+30;
	w=(pointer)ELT(ctx,2,local+28); /*elt*/
	local[28]= w;
	local[29]= local[19];
	local[30]= local[1];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,9,local+22); /*send*/
	ctx->vsp=local+22;
	w=(*ftab[39])(ctx,0,local+22,&ftab[39],fqv[281]); /*x::window-main-one*/
	local[22]= w;
	goto irtrobotIF4307;
irtrobotIF4306:
	local[22]= NIL;
irtrobotIF4307:
	local[22]= fqv[51];
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	local[24]= fqv[166];
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25]= (w)->c.cons.car;
	local[26]= fqv[282];
	local[27]= local[19];
	local[28]= fqv[283];
	local[29]= local[16];
	local[30]= makeint((eusinteger_t)5L);
	ctx->vsp=local+31;
	w=(pointer)ELT(ctx,2,local+29); /*elt*/
	local[29]= w;
	local[30]= fqv[284];
	local[31]= local[16];
	local[32]= makeint((eusinteger_t)6L);
	ctx->vsp=local+33;
	w=(pointer)ELT(ctx,2,local+31); /*elt*/
	local[31]= w;
	local[32]= fqv[285];
	local[33]= local[17];
	local[34]= fqv[286];
	local[35]= local[16];
	local[36]= makeint((eusinteger_t)7L);
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= fqv[267];
	local[37]= local[5];
	local[38]= fqv[287];
	local[39]= local[21];
	local[40]= fqv[288];
	local[41]= local[20];
	ctx->vsp=local+42;
	w=(pointer)LIST(ctx,20,local+22); /*list*/
	local[22]= w;
	w = local[15];
	ctx->vsp=local+23;
	local[15] = cons(ctx,local[22],w);
	local[22]= local[17];
	local[23]= local[1];
	ctx->vsp=local+24;
	w=(pointer)PLUS(ctx,2,local+22); /*+*/
	local[17] = w;
	w = local[17];
	goto irtrobotWHL4300;
irtrobotWHX4301:
	local[19]= NIL;
irtrobotBLK4302:
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)REVERSE(ctx,1,local+19); /*reverse*/
	local[0]= w;
irtrobotBLK4271:
	ctx->vsp=local; return(local[0]);}

/*:draw-gg-debug-view*/
static pointer irtrobotM4308robot_model_draw_gg_debug_view(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=9) maerror();
	local[0]= loadglobal(fqv[289]);
	local[1]= fqv[290];
	local[2]= fqv[291];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtrobotFLET4310,env,argv,local);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtrobotCLO4311,env,argv,local);
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,3,local+1); /*mapcar*/
	local[1]= argv[4];
	local[2]= fqv[292];
	local[3]= fqv[291];
	local[4]= NIL;
	local[5]= fqv[293];
	local[6]= makeint((eusinteger_t)300L);
	local[7]= fqv[294];
	local[8]= fqv[295];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	if (argv[7]==NIL) goto irtrobotIF4312;
	local[1]= argv[7];
	local[2]= fqv[292];
	local[3]= fqv[291];
	local[4]= NIL;
	local[5]= fqv[293];
	local[6]= makeint((eusinteger_t)200L);
	local[7]= fqv[296];
	local[8]= makeint((eusinteger_t)5L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	local[1]= w;
	goto irtrobotIF4313;
irtrobotIF4312:
	local[1]= NIL;
irtrobotIF4313:
	local[1]= fqv[297];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO4314,env,argv,local);
	w = local[0];
	ctx->vsp=local+3;
	w=irtrobotFLET4310(ctx,2,local+1,w);
	local[1]= fqv[298];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO4315,env,argv,local);
	w = local[0];
	ctx->vsp=local+3;
	w=irtrobotFLET4310(ctx,2,local+1,w);
	local[1]= fqv[299];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO4316,env,argv,local);
	w = local[0];
	ctx->vsp=local+3;
	w=irtrobotFLET4310(ctx,2,local+1,w);
	local[1]= fqv[300];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO4317,env,argv,local);
	w = local[0];
	ctx->vsp=local+3;
	w=irtrobotFLET4310(ctx,2,local+1,w);
	local[0]= loadglobal(fqv[289]);
	local[1]= fqv[301];
	local[2]= fqv[291];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtrobotBLK4309:
	ctx->vsp=local; return(local[0]);}

/*:gen-footstep-parameter*/
static pointer irtrobotM4318robot_model_gen_footstep_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[302], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4320;
	local[1]= makeflt(1.0000000000000000000000e+00);
	goto irtrobotKEY4321;
irtrobotKEY4320:
	local[1]= local[0];
irtrobotKEY4321:
	w = local[1];
	ctx->vsp=local+1;
	bindspecial(ctx,fqv[303],w);
	local[4]= fqv[304];
	ctx->vsp=local+5;
	w=(*ftab[15])(ctx,1,local+4,&ftab[15],fqv[92]); /*warn*/
	local[4]= argv[0];
	local[5]= fqv[51];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[64];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[305];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[306];
	ctx->vsp=local+8;
	w=(*ftab[16])(ctx,0,local+8,&ftab[16],fqv[96]); /*make-coords*/
	local[8]= w;
	local[9]= fqv[307];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= (pointer)get_sym_func(fqv[308]);
	local[7]= argv[0];
	local[8]= fqv[41];
	local[9]= fqv[43];
	local[10]= fqv[97];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,2,local+6); /*apply*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtrobotFLET4322,env,argv,local);
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtrobotCLO4323,env,argv,local);
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtrobotCLO4324,env,argv,local);
	w = local[7];
	ctx->vsp=local+10;
	w=irtrobotFLET4322(ctx,2,local+8,w);
	local[8]= w;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtrobotCLO4325,env,argv,local);
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtrobotCLO4326,env,argv,local);
	w = local[7];
	ctx->vsp=local+11;
	w=irtrobotFLET4322(ctx,2,local+9,w);
	local[9]= w;
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtrobotCLO4327,env,argv,local);
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtrobotCLO4328,env,argv,local);
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,irtrobotCLO4329,env,argv,local);
	w = local[7];
	ctx->vsp=local+13;
	w=irtrobotFLET4322(ctx,3,local+10,w);
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[251];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= argv[0];
	local[12]= fqv[51];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= fqv[309];
	ctx->vsp=local+12;
	w=(*ftab[15])(ctx,1,local+11,&ftab[15],fqv[92]); /*warn*/
	local[11]= argv[0];
	local[12]= fqv[310];
	local[13]= fqv[311];
	local[14]= fqv[312];
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeflt(5.0000000000000000000000e-01);
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)MKFLTVEC(ctx,3,local+15); /*float-vector*/
	local[15]= w;
	local[16]= fqv[313];
	local[17]= local[8];
	local[18]= makeflt(5.0000000000000000000000e-01);
	local[19]= loadglobal(fqv[303]);
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,3,local+17); /***/
	local[17]= w;
	local[18]= fqv[314];
	local[19]= local[9];
	local[20]= makeflt(5.0000000000000000000000e-01);
	local[21]= loadglobal(fqv[303]);
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,3,local+19); /***/
	local[19]= w;
	local[20]= fqv[315];
	local[21]= local[10];
	local[22]= makeflt(5.0000000000000000000000e-01);
	local[23]= loadglobal(fqv[303]);
	ctx->vsp=local+24;
	w=(pointer)TIMES(ctx,3,local+21); /***/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[10])(ctx,1,local+21,&ftab[10],fqv[67]); /*deg2rad*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,8,local+14); /*list*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
irtrobotBLK4319:
	ctx->vsp=local; return(local[0]);}

/*:footstep-parameter*/
static pointer irtrobotM4330robot_model_footstep_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[316];
	local[2]= fqv[311];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w!=NIL) goto irtrobotIF4332;
	local[0]= argv[0];
	local[1]= fqv[317];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtrobotIF4333;
irtrobotIF4332:
	local[0]= NIL;
irtrobotIF4333:
	local[0]= argv[0];
	local[1]= fqv[316];
	local[2]= fqv[311];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtrobotBLK4331:
	ctx->vsp=local; return(local[0]);}

/*:go-pos-params->footstep-list*/
static pointer irtrobotM4334robot_model_go_pos_params__footstep_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[318], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4336;
	local[6]= argv[0];
	local[7]= fqv[311];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[0] = w;
irtrobotKEY4336:
	if (n & (1<<1)) goto irtrobotKEY4337;
	local[6]= fqv[312];
	w = local[0];
	w=memq(local[6],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
irtrobotKEY4337:
	if (n & (1<<2)) goto irtrobotKEY4338;
	local[6]= fqv[313];
	w = local[0];
	w=memq(local[6],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
irtrobotKEY4338:
	if (n & (1<<3)) goto irtrobotKEY4339;
	local[6]= fqv[314];
	w = local[0];
	w=memq(local[6],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
irtrobotKEY4339:
	if (n & (1<<4)) goto irtrobotKEY4340;
	local[6]= fqv[315];
	w = local[0];
	w=memq(local[6],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(*ftab[40])(ctx,1,local+6,&ftab[40],fqv[319]); /*rad2deg*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[4] = w;
irtrobotKEY4340:
	if (n & (1<<5)) goto irtrobotKEY4341;
	ctx->vsp=local+6;
	local[5] = makeclosure(codevec,quotevec,irtrobotCLO4342,env,argv,local);
irtrobotKEY4341:
	local[6]= argv[2];
	local[7]= argv[3];
	local[8]= argv[4];
	local[9]= argv[3];
	ctx->vsp=local+10;
	w=(pointer)EUSFLOAT(ctx,1,local+9); /*float*/
	local[9]= w;
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(*ftab[41])(ctx,2,local+9,&ftab[41],fqv[320]); /*eps=*/
	if (w==NIL) goto irtrobotIF4343;
	local[9]= argv[4];
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)GREATERP(ctx,2,local+9); /*>*/
	if (w==NIL) goto irtrobotIF4345;
	local[9]= fqv[142];
	goto irtrobotIF4346;
irtrobotIF4345:
	local[9]= fqv[143];
irtrobotIF4346:
	goto irtrobotIF4344;
irtrobotIF4343:
	local[9]= argv[3];
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)GREATERP(ctx,2,local+9); /*>*/
	if (w==NIL) goto irtrobotIF4347;
	local[9]= fqv[142];
	goto irtrobotIF4348;
irtrobotIF4347:
	local[9]= fqv[143];
irtrobotIF4348:
irtrobotIF4344:
	local[10]= (pointer)get_sym_func(fqv[244]);
	local[11]= makeflt(5.0000000000000000000000e-01);
	local[12]= argv[0];
	local[13]= fqv[41];
	local[14]= fqv[43];
	local[15]= fqv[64];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,4,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,3,local+10); /*apply*/
	local[10]= w;
	local[11]= fqv[95];
	local[12]= argv[2];
	local[13]= argv[3];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	local[13]= fqv[321];
	local[14]= argv[4];
	ctx->vsp=local+15;
	w=(*ftab[10])(ctx,1,local+14,&ftab[10],fqv[67]); /*deg2rad*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[16])(ctx,4,local+11,&ftab[16],fqv[96]); /*make-coords*/
	local[11]= w;
	local[12]= fqv[21];
	local[13]= local[10];
	local[14]= fqv[20];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,irtrobotCLO4349,env,argv,local);
	local[13]= fqv[322];
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[10];
	local[15]= local[9];
	local[16]= local[15];
	if (fqv[142]!=local[16]) goto irtrobotIF4350;
	local[16]= fqv[143];
	goto irtrobotIF4351;
irtrobotIF4350:
	local[16]= local[15];
	if (fqv[143]!=local[16]) goto irtrobotIF4352;
	local[16]= fqv[142];
	goto irtrobotIF4353;
irtrobotIF4352:
	local[16]= NIL;
irtrobotIF4353:
irtrobotIF4351:
	w = local[16];
	local[15]= w;
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)FUNCALL(ctx,4,local+13); /*funcall*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,irtrobotFLET4354,env,argv,local);
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtrobotCLO4355,env,argv,local);
	ctx->vsp=local+16;
	local[16]= makeclosure(codevec,quotevec,irtrobotCLO4356,env,argv,local);
	w = local[14];
	ctx->vsp=local+17;
	w=irtrobotFLET4354(ctx,2,local+15,w);
	local[15]= local[5];
	local[16]= local[10];
	local[17]= local[9];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)FUNCALL(ctx,4,local+15); /*funcall*/
	local[15]= w;
	w = local[13];
	ctx->vsp=local+16;
	local[13] = cons(ctx,local[15],w);
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)REVERSE(ctx,1,local+15); /*reverse*/
	local[0]= w;
irtrobotBLK4335:
	ctx->vsp=local; return(local[0]);}

/*:go-pos-quadruped-params->footstep-list*/
static pointer irtrobotM4357robot_model_go_pos_quadruped_params__footstep_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[323], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4359;
	local[0] = fqv[324];
irtrobotKEY4359:
	local[1]= argv[0];
	local[2]= fqv[325];
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= fqv[313];
	local[7]= makeint((eusinteger_t)100L);
	local[8]= fqv[315];
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,9,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[1];
irtrobotWHL4360:
	if (local[4]==NIL) goto irtrobotWHX4361;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[36];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= local[5];
	local[8]= fqv[43];
	local[9]= fqv[64];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[250];
	local[8]= local[3];
	local[9]= fqv[20];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	local[7]= NIL;
	local[8]= local[0];
	local[9]= local[8];
	if (fqv[324]!=local[9]) goto irtrobotIF4363;
	local[9]= NIL;
	local[10]= local[5];
	local[11]= local[5];
	local[12]= local[11];
	if (fqv[142]!=local[12]) goto irtrobotIF4365;
	local[12]= fqv[140];
	goto irtrobotIF4366;
irtrobotIF4365:
	local[12]= local[11];
	if (fqv[143]!=local[12]) goto irtrobotIF4367;
	local[12]= fqv[141];
	goto irtrobotIF4368;
irtrobotIF4367:
	local[12]= NIL;
irtrobotIF4368:
irtrobotIF4366:
	w = local[12];
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[10]= w;
irtrobotWHL4369:
	if (local[10]==NIL) goto irtrobotWHX4370;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= fqv[326];
	local[12]= argv[0];
	local[13]= local[9];
	local[14]= fqv[43];
	local[15]= fqv[64];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,4,local+12); /*send*/
	local[12]= w;
	local[13]= fqv[21];
	local[14]= local[6];
	local[15]= fqv[20];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,4,local+12); /*send*/
	local[12]= w;
	local[13]= fqv[36];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(*ftab[16])(ctx,4,local+11,&ftab[16],fqv[96]); /*make-coords*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	w = local[2];
	ctx->vsp=local+12;
	local[2] = cons(ctx,local[11],w);
	goto irtrobotWHL4369;
irtrobotWHX4370:
	local[11]= NIL;
irtrobotBLK4371:
	w = NIL;
	local[9]= w;
	goto irtrobotIF4364;
irtrobotIF4363:
	local[9]= local[8];
	if (fqv[327]!=local[9]) goto irtrobotIF4372;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtrobotCLO4374,env,argv,local);
	local[10]= local[5];
	local[11]= local[5];
	local[12]= local[11];
	if (fqv[142]!=local[12]) goto irtrobotIF4375;
	local[12]= fqv[141];
	goto irtrobotIF4376;
irtrobotIF4375:
	local[12]= local[11];
	if (fqv[143]!=local[12]) goto irtrobotIF4377;
	local[12]= fqv[140];
	goto irtrobotIF4378;
irtrobotIF4377:
	local[12]= NIL;
irtrobotIF4378:
irtrobotIF4376:
	w = local[12];
	local[7] = w;
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	w = local[2];
	ctx->vsp=local+10;
	local[2] = cons(ctx,local[9],w);
	local[9]= local[2];
	goto irtrobotIF4373;
irtrobotIF4372:
	local[9]= local[8];
	if (fqv[328]!=local[9]) goto irtrobotIF4379;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtrobotCLO4381,env,argv,local);
	local[10]= local[5];
	local[11]= local[5];
	local[12]= local[11];
	if (fqv[142]!=local[12]) goto irtrobotIF4382;
	local[12]= fqv[140];
	goto irtrobotIF4383;
irtrobotIF4382:
	local[12]= local[11];
	if (fqv[143]!=local[12]) goto irtrobotIF4384;
	local[12]= fqv[141];
	goto irtrobotIF4385;
irtrobotIF4384:
	local[12]= NIL;
irtrobotIF4385:
irtrobotIF4383:
	w = local[12];
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	w = local[2];
	ctx->vsp=local+10;
	local[2] = cons(ctx,local[9],w);
	local[9]= local[2];
	goto irtrobotIF4380;
irtrobotIF4379:
	local[9]= local[8];
	if (fqv[329]!=local[9]) goto irtrobotIF4386;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtrobotCLO4388,env,argv,local);
	local[10]= local[5];
	local[11]= local[10];
	if (fqv[143]!=local[11]) goto irtrobotIF4389;
	local[11]= fqv[143];
	goto irtrobotIF4390;
irtrobotIF4389:
	local[11]= local[10];
	if (fqv[142]!=local[11]) goto irtrobotIF4391;
	local[11]= fqv[141];
	goto irtrobotIF4392;
irtrobotIF4391:
	local[11]= NIL;
irtrobotIF4392:
irtrobotIF4390:
	w = local[11];
	local[10]= w;
	local[11]= local[5];
	local[12]= local[11];
	if (fqv[143]!=local[12]) goto irtrobotIF4393;
	local[12]= fqv[142];
	goto irtrobotIF4394;
irtrobotIF4393:
	local[12]= local[11];
	if (fqv[142]!=local[12]) goto irtrobotIF4395;
	local[12]= fqv[140];
	goto irtrobotIF4396;
irtrobotIF4395:
	local[12]= NIL;
irtrobotIF4396:
irtrobotIF4394:
	w = local[12];
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	w = local[2];
	ctx->vsp=local+10;
	local[2] = cons(ctx,local[9],w);
	local[9]= local[2];
	goto irtrobotIF4387;
irtrobotIF4386:
	local[9]= NIL;
irtrobotIF4387:
irtrobotIF4380:
irtrobotIF4373:
irtrobotIF4364:
	w = local[9];
	goto irtrobotWHL4360;
irtrobotWHX4361:
	local[5]= NIL;
irtrobotBLK4362:
	w = NIL;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)REVERSE(ctx,1,local+3); /*reverse*/
	local[0]= w;
irtrobotBLK4358:
	ctx->vsp=local; return(local[0]);}

/*:support-polygons*/
static pointer irtrobotM4397robot_model_support_polygons(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[36];
	local[1]= fqv[330];
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[80]); /*send-all*/
	local[0]= w;
	local[1]= fqv[252];
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[80]); /*send-all*/
	w = argv[0]->c.obj.iv[36];
	local[0]= w;
irtrobotBLK4398:
	ctx->vsp=local; return(local[0]);}

/*:support-polygon*/
static pointer irtrobotM4399robot_model_support_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!iscons(w)) goto irtrobotIF4401;
	local[0]= loadglobal(fqv[331]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[34];
	local[3]= fqv[332];
	local[4]= (pointer)get_sym_func(fqv[333]);
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtrobotCLO4403,env,argv,local);
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[42])(ctx,1,local+4,&ftab[42],fqv[334]); /*quickhull*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
	goto irtrobotIF4402;
irtrobotIF4401:
	local[0]= argv[2];
	local[1]= argv[0];
	local[2]= fqv[335];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[135];
	local[3]= (pointer)get_sym_func(fqv[136]);
	local[4]= fqv[137];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtrobotCLO4404,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,6,local+0,&ftab[21],fqv[138]); /*find*/
	local[0]= w;
irtrobotIF4402:
	w = local[0];
	local[0]= w;
irtrobotBLK4400:
	ctx->vsp=local; return(local[0]);}

/*:make-support-polygons*/
static pointer irtrobotM4405robot_model_make_support_polygons(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[336];
	local[3]= fqv[143];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[336];
	local[4]= fqv[142];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,2,local+0,&ftab[7],fqv[45]); /*remove*/
	argv[0]->c.obj.iv[36] = w;
	w = argv[0]->c.obj.iv[36];
	local[0]= w;
irtrobotBLK4406:
	ctx->vsp=local; return(local[0]);}

/*:make-sole-polygon*/
static pointer irtrobotM4407robot_model_make_sole_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtrobotFLET4409,env,argv,local);
	local[1]= argv[0];
	local[2]= argv[2];
	local[3]= fqv[71];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (w!=NIL) goto irtrobotIF4410;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto irtrobotBLK4408;
	goto irtrobotIF4411;
irtrobotIF4410:
	local[1]= NIL;
irtrobotIF4411:
	local[1]= argv[0];
	local[2]= argv[2];
	local[3]= fqv[71];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w = local[0];
	ctx->vsp=local+2;
	w=irtrobotFLET4409(ctx,1,local+1,w);
	local[1]= w;
	local[2]= fqv[252];
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[80]); /*send-all*/
	local[1]= NIL;
	local[2]= fqv[337];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,1,local+1,&ftab[8],fqv[47]); /*read-from-string*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= argv[2];
	local[4]= fqv[71];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w = local[0];
	ctx->vsp=local+3;
	w=irtrobotFLET4409(ctx,1,local+2,w);
	local[2]= w;
	local[3]= fqv[35];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,2,local+2,&ftab[13],fqv[80]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[43])(ctx,1,local+2,&ftab[43],fqv[338]); /*flatten*/
	local[2]= w;
	local[3]= fqv[332];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,2,local+2,&ftab[13],fqv[80]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[43])(ctx,1,local+2,&ftab[43],fqv[338]); /*flatten*/
	local[2]= w;
	local[3]= fqv[135];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtrobotCLO4412,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[33])(ctx,3,local+2,&ftab[33],fqv[222]); /*remove-duplicates*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtrobotCLO4413,env,argv,local);
	local[5]= (pointer)get_sym_func(fqv[339]);
	ctx->vsp=local+6;
	w=(*ftab[44])(ctx,3,local+3,&ftab[44],fqv[340]); /*find-extream*/
	local[3]= w;
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtrobotCLO4414,env,argv,local);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[28]); /*remove-if*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[45])(ctx,1,local+4,&ftab[45],fqv[341]); /*make-bounding-box*/
	local[4]= w;
	local[5]= fqv[330];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= argv[2];
	local[7]= fqv[43];
	local[8]= fqv[56];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[24];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[310];
	local[7]= local[1];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= local[4];
	local[6]= fqv[252];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtrobotCLO4415,env,argv,local);
	local[6]= local[4];
	local[7]= fqv[342];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[36])(ctx,2,local+5,&ftab[36],fqv[235]); /*find-if*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[36];
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = local[5];
	local[0]= w;
irtrobotBLK4408:
	ctx->vsp=local; return(local[0]);}

/*:make-default-linear-link-joint-between-attach-coords*/
static pointer irtrobotM4416robot_model_make_default_linear_link_joint_between_attach_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[3];
	local[7]= fqv[97];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= fqv[97];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VDISTANCE(ctx,2,local+6); /*distance*/
	local[6]= w;
	local[7]= loadglobal(fqv[33]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[34];
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,0,local+10,&ftab[2],fqv[2]); /*make-cascoords*/
	local[10]= w;
	local[11]= fqv[35];
	local[12]= makeint((eusinteger_t)5L);
	local[13]= makeflt(5.0000000000000000000000e-01);
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[0])(ctx,2,local+12,&ftab[0],fqv[0]); /*make-cylinder*/
	local[12]= w;
	local[13]= local[12];
	local[14]= fqv[25];
	local[15]= fqv[26];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	w = local[12];
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	w = local[7];
	local[0] = w;
	local[7]= local[0];
	local[8]= fqv[251];
	local[9]= argv[2];
	local[10]= fqv[64];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[0];
	local[8]= argv[3];
	local[9]= fqv[97];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= fqv[97];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VMINUS(ctx,2,local+8); /*v-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[46])(ctx,1,local+8,&ftab[46],fqv[343]); /*normalize-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[98]); /*orient-coords-to-axis*/
	local[7]= loadglobal(fqv[33]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[34];
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,0,local+10,&ftab[2],fqv[2]); /*make-cascoords*/
	local[10]= w;
	local[11]= fqv[35];
	local[12]= makeint((eusinteger_t)5L);
	local[13]= makeflt(5.0000000000000000000000e-01);
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[0])(ctx,2,local+12,&ftab[0],fqv[0]); /*make-cylinder*/
	local[12]= w;
	local[13]= local[12];
	local[14]= fqv[25];
	local[15]= fqv[26];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= local[12];
	local[14]= fqv[22];
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	local[17]= makeflt(-5.0000000000000000000000e-01);
	local[18]= local[6];
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)MKFLTVEC(ctx,3,local+15); /*float-vector*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	w = local[12];
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	w = local[7];
	local[1] = w;
	local[7]= local[1];
	local[8]= fqv[251];
	local[9]= argv[3];
	local[10]= fqv[64];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[1];
	local[8]= argv[3];
	local[9]= fqv[97];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= fqv[97];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VMINUS(ctx,2,local+8); /*v-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[46])(ctx,1,local+8,&ftab[46],fqv[343]); /*normalize-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[98]); /*orient-coords-to-axis*/
	local[7]= loadglobal(fqv[33]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[34];
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,0,local+10,&ftab[2],fqv[2]); /*make-cascoords*/
	local[10]= w;
	local[11]= fqv[35];
	local[12]= makeint((eusinteger_t)5L);
	local[13]= makeint((eusinteger_t)5L);
	local[14]= makeint((eusinteger_t)5L);
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,3,local+12,&ftab[1],fqv[1]); /*make-cube*/
	local[12]= w;
	local[13]= local[12];
	local[14]= fqv[25];
	local[15]= fqv[26];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	w = local[12];
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	w = local[7];
	local[2] = w;
	local[7]= local[2];
	local[8]= fqv[251];
	local[9]= argv[3];
	local[10]= fqv[64];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= fqv[326];
	local[8]= argv[3];
	local[9]= fqv[64];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[36];
	local[10]= argv[4];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,4,local+7,&ftab[2],fqv[2]); /*make-cascoords*/
	local[7]= w;
	w = argv[0]->c.obj.iv[12];
	ctx->vsp=local+8;
	argv[0]->c.obj.iv[12] = cons(ctx,local[7],w);
	local[7]= argv[2];
	local[8]= fqv[56];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[24];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[24];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[1];
	local[8]= fqv[24];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[2];
	local[8]= fqv[24];
	w=argv[0]->c.obj.iv[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[1];
	local[8]= fqv[22];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)-1L);
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= loadglobal(fqv[344]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[34];
	local[10]= fqv[107];
	local[11]= local[0];
	local[12]= fqv[56];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[192];
	local[13]= local[0];
	local[14]= fqv[185];
	local[15]= makeint((eusinteger_t)-360L);
	local[16]= makeint((eusinteger_t)-360L);
	local[17]= makeint((eusinteger_t)-360L);
	ctx->vsp=local+18;
	w=(pointer)MKFLTVEC(ctx,3,local+15); /*float-vector*/
	local[15]= w;
	local[16]= fqv[186];
	local[17]= makeint((eusinteger_t)360L);
	local[18]= makeint((eusinteger_t)360L);
	local[19]= makeint((eusinteger_t)360L);
	ctx->vsp=local+20;
	w=(pointer)MKFLTVEC(ctx,3,local+17); /*float-vector*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,10,local+8); /*send*/
	w = local[7];
	local[3] = w;
	local[7]= loadglobal(fqv[345]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[34];
	local[10]= fqv[107];
	local[11]= local[1];
	local[12]= fqv[56];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[192];
	local[13]= local[1];
	local[14]= fqv[36];
	local[15]= argv[5];
	local[16]= fqv[346];
	local[17]= fqv[7];
	local[18]= fqv[185];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= fqv[186];
	local[21]= makeint((eusinteger_t)1000L);
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,14,local+8); /*send*/
	w = local[7];
	local[4] = w;
	local[7]= loadglobal(fqv[344]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[34];
	local[10]= fqv[107];
	local[11]= local[2];
	local[12]= fqv[56];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[192];
	local[13]= local[2];
	local[14]= fqv[185];
	local[15]= makeint((eusinteger_t)-360L);
	local[16]= makeint((eusinteger_t)-360L);
	local[17]= makeint((eusinteger_t)-360L);
	ctx->vsp=local+18;
	w=(pointer)MKFLTVEC(ctx,3,local+15); /*float-vector*/
	local[15]= w;
	local[16]= fqv[186];
	local[17]= makeint((eusinteger_t)360L);
	local[18]= makeint((eusinteger_t)360L);
	local[19]= makeint((eusinteger_t)360L);
	ctx->vsp=local+20;
	w=(pointer)MKFLTVEC(ctx,3,local+17); /*float-vector*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,10,local+8); /*send*/
	w = local[7];
	local[5] = w;
	local[7]= local[4];
	local[8]= fqv[129];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,3,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	argv[0]->c.obj.iv[8] = w;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= local[3];
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,3,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	argv[0]->c.obj.iv[9] = w;
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtrobotBLK4417:
	ctx->vsp=local; return(local[0]);}

/*:calc-static-balance-point*/
static pointer irtrobotM4418robot_model_calc_static_balance_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[347], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtrobotKEY4420;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtrobotCLO4421,env,argv,local);
	local[6]= fqv[348];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[0] = w;
irtrobotKEY4420:
	if (n & (1<<1)) goto irtrobotKEY4422;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= fqv[205];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[28])(ctx,3,local+5,&ftab[28],fqv[206]); /*make-list*/
	local[1] = w;
irtrobotKEY4422:
	if (n & (1<<2)) goto irtrobotKEY4423;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= fqv[205];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[28])(ctx,3,local+5,&ftab[28],fqv[206]); /*make-list*/
	local[2] = w;
irtrobotKEY4423:
	if (n & (1<<3)) goto irtrobotKEY4424;
	local[5]= (pointer)get_sym_func(fqv[183]);
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= argv[0];
	local[8]= fqv[41];
	local[9]= fqv[43];
	local[10]= fqv[97];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,3,local+5); /*apply*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[3] = w;
irtrobotKEY4424:
	if (n & (1<<4)) goto irtrobotKEY4425;
	local[4] = T;
irtrobotKEY4425:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= makeflt(9.9999999999999974298988e-07);
	local[7]= argv[0];
	local[8]= fqv[121];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	local[8]= loadglobal(fqv[349]);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,3,local+6); /***/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
irtrobotWHL4426:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtrobotWHX4427;
	local[9]= local[6];
	local[10]= local[6];
	local[11]= argv[0];
	local[12]= fqv[29];
	local[13]= NIL;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtrobotCLO4429,env,argv,local);
	local[12]= local[1];
	local[13]= local[2];
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)MAPCAR(ctx,4,local+11); /*mapcar*/
	local[11]= local[5];
	local[12]= local[7];
	local[13]= local[10];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtrobotWHL4426;
irtrobotWHX4427:
	local[9]= NIL;
irtrobotBLK4428:
	w = NIL;
	w = local[5];
	local[0]= w;
irtrobotBLK4419:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4248(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[350];
	if (memq(local[0],w)==NIL) goto irtrobotIF4430;
	local[0]= makeint((eusinteger_t)1L);
	goto irtrobotIF4431;
irtrobotIF4430:
	local[0]= makeint((eusinteger_t)5L);
irtrobotIF4431:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4250(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[351];
	if (memq(local[0],w)==NIL) goto irtrobotIF4432;
	local[0]= makeint((eusinteger_t)1L);
	goto irtrobotIF4433;
irtrobotIF4432:
	local[0]= makeint((eusinteger_t)5L);
irtrobotIF4433:
	ctx->vsp=local+1;
	w=(*ftab[10])(ctx,1,local+0,&ftab[10],fqv[67]); /*deg2rad*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4255(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[43];
	local[3]= fqv[97];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4256(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[352];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4258(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[43];
	local[3]= fqv[64];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4267(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[7];
	local[1]= argv[0];
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4268(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[7];
	local[1]= fqv[55];
	local[2]= argv[0];
	local[3]= fqv[56];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4269(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[353];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4280(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtrobotCLO4434,env,argv,local);
	local[1]= fqv[354];
	ctx->vsp=local+2;
	w=(*ftab[36])(ctx,2,local+0,&ftab[36],fqv[235]); /*find-if*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4434(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= env->c.clo.env0->c.clo.env1[0];
	local[2]= argv[0];
	local[3]= fqv[86];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4282(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4284(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[355];
	local[2]= fqv[245];
	local[3]= fqv[356];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4305(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[43];
	local[3]= fqv[64];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotFLET4310(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[289]);
	local[1]= fqv[301];
	local[2]= fqv[294];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[289]);
	local[2]= fqv[301];
	local[3]= fqv[294];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,1,local+1); /*funcall*/
	local[1]= loadglobal(fqv[289]);
	local[2]= fqv[301];
	local[3]= fqv[294];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4311(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[292];
	local[2]= fqv[291];
	local[3]= NIL;
	local[4]= fqv[293];
	local[5]= makeint((eusinteger_t)300L);
	local[6]= fqv[294];
	local[7]= fqv[357];
	if (argv[1]!=local[7]) goto irtrobotIF4435;
	local[7]= fqv[358];
	goto irtrobotIF4436;
irtrobotIF4435:
	local[7]= fqv[359];
irtrobotIF4436:
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,8,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4314(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[289]);
	local[1]= fqv[301];
	local[2]= fqv[360];
	local[3]= makeint((eusinteger_t)20L);
	local[4]= makeint((eusinteger_t)20L);
	local[5]= fqv[361];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4315(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[289]);
	local[1]= fqv[301];
	local[2]= fqv[360];
	local[3]= makeint((eusinteger_t)20L);
	local[4]= makeint((eusinteger_t)50L);
	local[5]= fqv[362];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4316(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[289]);
	local[1]= fqv[301];
	local[2]= fqv[360];
	local[3]= makeint((eusinteger_t)20L);
	local[4]= makeint((eusinteger_t)80L);
	local[5]= fqv[363];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4317(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[289]);
	local[1]= fqv[301];
	local[2]= fqv[360];
	local[3]= makeint((eusinteger_t)20L);
	local[4]= makeint((eusinteger_t)110L);
	local[5]= fqv[364];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotFLET4322(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtrobotENT4438;}
	local[0]= NIL;
irtrobotENT4438:
irtrobotENT4437:
	if (n>3) maerror();
	local[1]= env->c.clo.env1[0];
	local[2]= fqv[305];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= env->c.clo.env1[0];
	local[2]= fqv[306];
	ctx->vsp=local+3;
	w=(*ftab[16])(ctx,0,local+3,&ftab[16],fqv[96]); /*make-coords*/
	local[3]= w;
	local[4]= fqv[365];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= env->c.clo.env1[0];
	local[2]= fqv[143];
	local[3]= fqv[43];
	local[4]= fqv[64];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[64];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
irtrobotWHL4439:
	local[3]= env->c.clo.env1[0];
	local[4]= fqv[54];
	local[5]= argv[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)FUNCALL(ctx,2,local+5); /*funcall*/
	local[5]= w;
	local[6]= fqv[55];
	local[7]= env->c.clo.env1[0];
	local[8]= fqv[55];
	local[9]= env->c.clo.env1[0];
	local[10]= fqv[143];
	local[11]= fqv[43];
	local[12]= fqv[56];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[61];
	local[9]= env->c.clo.env1[0];
	local[10]= fqv[143];
	local[11]= fqv[43];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[94];
	local[11]= NIL;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,9,local+3); /*send*/
	if (w==NIL) goto irtrobotWHX4440;
	if (local[0]==NIL) goto irtrobotIF4442;
	local[3]= local[0];
	local[4]= local[1];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,3,local+3); /*funcall*/
	local[3]= w;
	goto irtrobotIF4443;
irtrobotIF4442:
	local[3]= T;
irtrobotIF4443:
	if (local[3]==NIL) goto irtrobotWHX4440;
	goto irtrobotWHL4439;
irtrobotWHX4440:
	local[3]= NIL;
irtrobotBLK4441:
	local[3]= argv[1];
	local[4]= local[1];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,3,local+3); /*funcall*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4323(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[22];
	local[2]= fqv[366];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4324(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[97];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= fqv[97];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4325(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[22];
	local[2]= fqv[367];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4326(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[97];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= fqv[97];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4327(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[66];
	local[2]= makeflt(-2.5000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(*ftab[10])(ctx,1,local+2,&ftab[10],fqv[67]); /*deg2rad*/
	local[2]= w;
	local[3]= fqv[7];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4328(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[368];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[1];
	local[2]= fqv[368];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[40])(ctx,1,local+0,&ftab[40],fqv[319]); /*rad2deg*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4329(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)90L);
	local[1]= argv[0];
	local[2]= fqv[368];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[1];
	local[3]= fqv[368];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,1,local+1,&ftab[40],fqv[319]); /*rad2deg*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4342(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[22];
	local[2]= argv[1];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,2,local+2,&ftab[12],fqv[76]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[36];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4349(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= local[1];
	if (fqv[143]!=local[2]) goto irtrobotIF4444;
	local[2]= makeint((eusinteger_t)-1L);
	goto irtrobotIF4445;
irtrobotIF4444:
	local[2]= local[1];
	if (fqv[142]!=local[2]) goto irtrobotIF4446;
	local[2]= makeint((eusinteger_t)1L);
	goto irtrobotIF4447;
irtrobotIF4446:
	local[2]= NIL;
irtrobotIF4447:
irtrobotIF4445:
	w = local[2];
	local[1]= w;
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,2,local+1); /*scale*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotFLET4354(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
irtrobotWHL4448:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FUNCALL(ctx,1,local+0); /*funcall*/
	if (w!=NIL) goto irtrobotWHX4449;
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)FUNCALL(ctx,1,local+0); /*funcall*/
	local[0]= env->c.clo.env2[5];
	local[1]= env->c.clo.env2[10];
	local[2]= env->c.clo.env2[9];
	local[3]= env->c.clo.env2[12];
	ctx->vsp=local+4;
	w=(pointer)FUNCALL(ctx,4,local+0); /*funcall*/
	local[0]= w;
	w = env->c.clo.env2[13];
	ctx->vsp=local+1;
	env->c.clo.env2[13] = cons(ctx,local[0],w);
	local[0]= env->c.clo.env2[9];
	local[1]= local[0];
	if (fqv[142]!=local[1]) goto irtrobotIF4451;
	local[1]= fqv[143];
	goto irtrobotIF4452;
irtrobotIF4451:
	local[1]= local[0];
	if (fqv[143]!=local[1]) goto irtrobotIF4453;
	local[1]= fqv[142];
	goto irtrobotIF4454;
irtrobotIF4453:
	local[1]= NIL;
irtrobotIF4454:
irtrobotIF4452:
	w = local[1];
	env->c.clo.env2[9] = w;
	goto irtrobotWHL4448;
irtrobotWHX4449:
	local[0]= NIL;
irtrobotBLK4450:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4355(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[6];
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[41])(ctx,2,local+0,&ftab[41],fqv[320]); /*eps=*/
	local[0]= w;
	if (w==NIL) goto irtrobotAND4455;
	local[0]= env->c.clo.env2[7];
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[41])(ctx,2,local+0,&ftab[41],fqv[320]); /*eps=*/
	local[0]= w;
	if (w==NIL) goto irtrobotAND4455;
	local[0]= env->c.clo.env2[8];
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[41])(ctx,2,local+0,&ftab[41],fqv[320]); /*eps=*/
	local[0]= w;
irtrobotAND4455:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4356(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[2];
	local[1]= env->c.clo.env2[6];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto irtrobotCON4457;
	local[0]= env->c.clo.env2[2];
	goto irtrobotCON4456;
irtrobotCON4457:
	local[0]= env->c.clo.env2[2];
	ctx->vsp=local+1;
	w=(pointer)MINUS(ctx,1,local+0); /*-*/
	local[0]= w;
	local[1]= env->c.clo.env2[6];
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto irtrobotCON4458;
	local[0]= env->c.clo.env2[2];
	ctx->vsp=local+1;
	w=(pointer)MINUS(ctx,1,local+0); /*-*/
	local[0]= w;
	goto irtrobotCON4456;
irtrobotCON4458:
	local[0]= env->c.clo.env2[6];
	goto irtrobotCON4456;
irtrobotCON4459:
	local[0]= NIL;
irtrobotCON4456:
	local[1]= env->c.clo.env2[9];
	local[2]= local[1];
	if (fqv[143]!=local[2]) goto irtrobotIF4460;
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= env->c.clo.env2[7];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtrobotCON4463;
	local[2]= makeflt(0.0000000000000000000000e+00);
	goto irtrobotCON4462;
irtrobotCON4463:
	local[2]= env->c.clo.env2[3];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,1,local+2); /*-*/
	local[2]= w;
	local[3]= env->c.clo.env2[7];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtrobotCON4464;
	local[2]= env->c.clo.env2[3];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,1,local+2); /*-*/
	local[2]= w;
	goto irtrobotCON4462;
irtrobotCON4464:
	local[2]= env->c.clo.env2[7];
	goto irtrobotCON4462;
irtrobotCON4465:
	local[2]= NIL;
irtrobotCON4462:
	goto irtrobotIF4461;
irtrobotIF4460:
	local[2]= local[1];
	if (fqv[142]!=local[2]) goto irtrobotIF4466;
	local[2]= env->c.clo.env2[3];
	local[3]= env->c.clo.env2[7];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtrobotCON4469;
	local[2]= env->c.clo.env2[3];
	goto irtrobotCON4468;
irtrobotCON4469:
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= env->c.clo.env2[7];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtrobotCON4470;
	local[2]= makeflt(0.0000000000000000000000e+00);
	goto irtrobotCON4468;
irtrobotCON4470:
	local[2]= env->c.clo.env2[7];
	goto irtrobotCON4468;
irtrobotCON4471:
	local[2]= NIL;
irtrobotCON4468:
	goto irtrobotIF4467;
irtrobotIF4466:
	local[2]= NIL;
irtrobotIF4467:
irtrobotIF4461:
	w = local[2];
	local[1]= w;
	local[2]= env->c.clo.env2[4];
	local[3]= env->c.clo.env2[8];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtrobotCON4473;
	local[2]= env->c.clo.env2[4];
	goto irtrobotCON4472;
irtrobotCON4473:
	local[2]= env->c.clo.env2[4];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,1,local+2); /*-*/
	local[2]= w;
	local[3]= env->c.clo.env2[8];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtrobotCON4474;
	local[2]= env->c.clo.env2[4];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,1,local+2); /*-*/
	local[2]= w;
	goto irtrobotCON4472;
irtrobotCON4474:
	local[2]= env->c.clo.env2[8];
	goto irtrobotCON4472;
irtrobotCON4475:
	local[2]= NIL;
irtrobotCON4472:
	local[3]= env->c.clo.env2[10];
	local[4]= fqv[22];
	local[5]= local[0];
	local[6]= local[1];
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= env->c.clo.env2[10];
	local[4]= fqv[66];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[10])(ctx,1,local+5,&ftab[10],fqv[67]); /*deg2rad*/
	local[5]= w;
	local[6]= fqv[7];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= env->c.clo.env2[10];
	local[4]= fqv[250];
	local[5]= env->c.clo.env2[11];
	local[6]= fqv[65];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[95];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	env->c.clo.env2[6] = w;
	local[4]= local[3];
	local[5]= fqv[95];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	env->c.clo.env2[7] = w;
	local[4]= local[3];
	local[5]= fqv[369];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INV_RPY(ctx,1,local+4); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[40])(ctx,1,local+4,&ftab[40],fqv[319]); /*rad2deg*/
	env->c.clo.env2[8] = w;
	w = env->c.clo.env2[8];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4374(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[326];
	local[1]= env->c.clo.env1[0];
	local[2]= argv[0];
	local[3]= fqv[43];
	local[4]= fqv[64];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[21];
	local[3]= env->c.clo.env2[6];
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[36];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,4,local+0,&ftab[16],fqv[96]); /*make-coords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4381(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[326];
	local[1]= env->c.clo.env1[0];
	local[2]= argv[0];
	local[3]= fqv[43];
	local[4]= fqv[64];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[21];
	local[3]= env->c.clo.env2[6];
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[36];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,4,local+0,&ftab[16],fqv[96]); /*make-coords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4388(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[326];
	local[1]= env->c.clo.env1[0];
	local[2]= argv[0];
	local[3]= fqv[43];
	local[4]= fqv[64];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[21];
	local[3]= env->c.clo.env2[6];
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[36];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,4,local+0,&ftab[16],fqv[96]); /*make-coords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4403(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[370];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[332];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4404(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[36];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotFLET4409(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	if (argv[0]==NIL) goto irtrobotIF4476;
	local[0]= argv[0];
	local[1]= fqv[371];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (w==NIL) goto irtrobotIF4476;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	local[1]= env->c.clo.env2[0];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtrobotCLO4478,env,argv,local);
	local[3]= argv[0];
	local[4]= fqv[371];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[22])(ctx,2,local+2,&ftab[22],fqv[139]); /*remove-if-not*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[43])(ctx,1,local+1,&ftab[43],fqv[338]); /*flatten*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	goto irtrobotIF4477;
irtrobotIF4476:
	local[0]= NIL;
irtrobotIF4477:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4478(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[33]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4412(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= loadglobal(fqv[372]);
	ctx->vsp=local+3;
	w=(*ftab[47])(ctx,3,local+0,&ftab[47],fqv[373]); /*eps-v=*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4413(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4414(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(5.0000000000000000000000e+00);
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= env->c.clo.env2[3];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4415(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[374];
	local[1]= argv[0];
	local[2]= fqv[375];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4421(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[97];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtrobotCLO4429(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= env->c.clo.env2[10];
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= env->c.clo.env2[3];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= env->c.clo.env2[7];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[2];
	local[3]= env->c.clo.env2[7];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000000000e+03);
	local[3]= env->c.clo.env2[7];
	local[4]= local[3];
	if (fqv[376]!=local[4]) goto irtrobotIF4479;
	local[4]= argv[1];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	goto irtrobotIF4480;
irtrobotIF4479:
	local[4]= local[3];
	if (fqv[377]!=local[4]) goto irtrobotIF4481;
	local[4]= argv[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,1,local+4); /*-*/
	local[4]= w;
	goto irtrobotIF4482;
irtrobotIF4481:
	local[4]= NIL;
irtrobotIF4482:
irtrobotIF4480:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,3,local+0); /*+*/
	env->c.clo.env2[10] = w;
	local[0]= env->c.clo.env2[9];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	env->c.clo.env2[9] = w;
	w = env->c.clo.env2[9];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtrobot(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[378];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtrobotIF4483;
	local[0]= fqv[379];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[380],w);
	goto irtrobotIF4484;
irtrobotIF4483:
	local[0]= fqv[381];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtrobotIF4484:
	local[0]= fqv[382];
	ctx->vsp=local+1;
	w=(*ftab[48])(ctx,1,local+0,&ftab[48],fqv[383]); /*require*/
	local[0]= fqv[384];
	ctx->vsp=local+1;
	w=(*ftab[48])(ctx,1,local+0,&ftab[48],fqv[383]); /*require*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[385],module,irtrobotF3811make_default_robot_link,fqv[386]);
	local[0]= fqv[387];
	local[1]= fqv[388];
	local[2]= fqv[387];
	local[3]= fqv[389];
	local[4]= loadglobal(fqv[390]);
	local[5]= fqv[75];
	local[6]= fqv[391];
	local[7]= fqv[392];
	local[8]= NIL;
	local[9]= fqv[393];
	local[10]= NIL;
	local[11]= fqv[293];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[394];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[49])(ctx,13,local+2,&ftab[49],fqv[395]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3842robot_model_init_ending,fqv[39],fqv[387],fqv[396]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3846robot_model_rarm_end_coords,fqv[397],fqv[387],fqv[398]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3848robot_model_larm_end_coords,fqv[399],fqv[387],fqv[400]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3850robot_model_rleg_end_coords,fqv[401],fqv[387],fqv[402]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3852robot_model_lleg_end_coords,fqv[403],fqv[387],fqv[404]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3854robot_model_head_end_coords,fqv[405],fqv[387],fqv[406]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3856robot_model_torso_end_coords,fqv[407],fqv[387],fqv[408]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3858robot_model_rarm_root_link,fqv[409],fqv[387],fqv[410]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3860robot_model_larm_root_link,fqv[411],fqv[387],fqv[412]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3862robot_model_rleg_root_link,fqv[413],fqv[387],fqv[414]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3864robot_model_lleg_root_link,fqv[415],fqv[387],fqv[416]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3866robot_model_head_root_link,fqv[417],fqv[387],fqv[418]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3868robot_model_torso_root_link,fqv[419],fqv[387],fqv[420]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3870robot_model_limb,fqv[77],fqv[387],fqv[421]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3931robot_model_inverse_kinematics_loop_for_look_at,fqv[72],fqv[387],fqv[422]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3977robot_model_gripper,fqv[81],fqv[387],fqv[423]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3988robot_model_camera,fqv[131],fqv[387],fqv[424]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3990robot_model_force_sensor,fqv[132],fqv[387],fqv[425]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3992robot_model_imu_sensor,fqv[133],fqv[387],fqv[426]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3994robot_model_get_sensor_method,fqv[130],fqv[387],fqv[427]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM3997robot_model_get_sensors_method_by_limb,fqv[84],fqv[387],fqv[428]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4000robot_model_force_sensors,fqv[86],fqv[387],fqv[429]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4002robot_model_imu_sensors,fqv[85],fqv[387],fqv[430]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4004robot_model_cameras,fqv[83],fqv[387],fqv[431]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4006robot_model_larm,fqv[140],fqv[387],fqv[432]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4011robot_model_rarm,fqv[141],fqv[387],fqv[433]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4016robot_model_lleg,fqv[142],fqv[387],fqv[434]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4021robot_model_rleg,fqv[143],fqv[387],fqv[435]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4026robot_model_head,fqv[70],fqv[387],fqv[436]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4031robot_model_torso,fqv[144],fqv[387],fqv[437]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4036robot_model_arms,fqv[146],fqv[387],fqv[438]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4039robot_model_legs,fqv[41],fqv[387],fqv[439]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4042robot_model_look_at_hand,fqv[440],fqv[387],fqv[441]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4049robot_model_inverse_kinematics,fqv[54],fqv[387],fqv[442]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4064robot_model_inverse_kinematics_loop,fqv[117],fqv[387],fqv[443]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4080robot_model_look_at_target,fqv[145],fqv[387],fqv[444]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4090robot_model_init_pose,fqv[445],fqv[387],fqv[446]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4092robot_model_torque_vector,fqv[447],fqv[387],fqv[448]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4112robot_model_distribute_total_wrench_to_torque_method_default,fqv[162],fqv[387],fqv[449]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4119robot_model_calc_force_from_joint_torque,fqv[450],fqv[387],fqv[451]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4128robot_model_fullbody_inverse_kinematics,fqv[255],fqv[387],fqv[452]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4149robot_model_joint_angle_limit_nspace_for_6dof,fqv[453],fqv[387],fqv[454]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4168robot_model_joint_order,fqv[82],fqv[387],fqv[455]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4190robot_model_print_vector_for_robot_limb,fqv[456],fqv[387],fqv[457]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4199robot_model_calc_zmp_from_forces_moments,fqv[458],fqv[387],fqv[459]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4227robot_model_foot_midcoords,fqv[460],fqv[387],fqv[461]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4231robot_model_fix_leg_to_coords,fqv[306],fqv[387],fqv[462]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4244robot_model_move_centroid_on_foot,fqv[355],fqv[387],fqv[463]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4270robot_model_calc_walk_pattern_from_footstep_list,fqv[464],fqv[387],fqv[465]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4308robot_model_draw_gg_debug_view,fqv[280],fqv[387],fqv[466]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4318robot_model_gen_footstep_parameter,fqv[317],fqv[387],fqv[467]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4330robot_model_footstep_parameter,fqv[311],fqv[387],fqv[468]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4334robot_model_go_pos_params__footstep_list,fqv[325],fqv[387],fqv[469]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4357robot_model_go_pos_quadruped_params__footstep_list,fqv[470],fqv[387],fqv[471]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4397robot_model_support_polygons,fqv[335],fqv[387],fqv[472]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4399robot_model_support_polygon,fqv[370],fqv[387],fqv[473]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4405robot_model_make_support_polygons,fqv[44],fqv[387],fqv[474]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4407robot_model_make_sole_polygon,fqv[336],fqv[387],fqv[475]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4416robot_model_make_default_linear_link_joint_between_attach_coords,fqv[476],fqv[387],fqv[477]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtrobotM4418robot_model_calc_static_balance_point,fqv[478],fqv[387],fqv[479]);
	local[0]= fqv[480];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtrobotIF4485;
	local[0]= fqv[481];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[380],w);
	goto irtrobotIF4486;
irtrobotIF4485:
	local[0]= fqv[482];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtrobotIF4486:
	local[0]= fqv[483];
	local[1]= fqv[484];
	ctx->vsp=local+2;
	w=(*ftab[50])(ctx,2,local+0,&ftab[50],fqv[485]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<51; i++) ftab[i]=fcallx;
}

/* ./gnuplotlib.c :  entry=gnuplotlib */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "gnuplotlib.h"
#pragma init (register_gnuplotlib)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___gnuplotlib();
extern pointer build_quote_vector();
static int register_gnuplotlib()
  { add_module_initializer("___gnuplotlib", ___gnuplotlib);}

static pointer gnuplotlF1148gnuplot();
static pointer gnuplotlF1149graph_view();

/*:init*/
static pointer gnuplotlM1150gnuplot_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[0], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto gnuplotlKEY1152;
	local[0] = T;
gnuplotlKEY1152:
	if (n & (1<<1)) goto gnuplotlKEY1153;
	local[1] = NIL;
gnuplotlKEY1153:
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)SYSTEM(ctx,1,local+2); /*unix:system*/
	local[2]= w;
	if (makeint((eusinteger_t)256L)!=local[2]) goto gnuplotlIF1154;
	local[2]= fqv[2];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto gnuplotlIF1155;
gnuplotlIF1154:
	local[2]= NIL;
gnuplotlIF1155:
	ctx->vsp=local+2;
	w=(pointer)GETHOSTNAME(ctx,0,local+2); /*unix:gethostname*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,2,local+2,&ftab[0],fqv[3]); /*string=*/
	if (w==NIL) goto gnuplotlCON1157;
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,1,local+2,&ftab[1],fqv[5]); /*piped-fork*/
	local[2]= w;
	goto gnuplotlCON1156;
gnuplotlCON1157:
	local[2]= fqv[6];
	local[3]= argv[2];
	local[4]= NIL;
	local[5]= fqv[7];
	ctx->vsp=local+6;
	w=(pointer)GETHOSTNAME(ctx,0,local+6); /*unix:gethostname*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,0,local+7,&ftab[2],fqv[8]); /*pwd*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,4,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,3,local+2,&ftab[1],fqv[5]); /*piped-fork*/
	local[2]= w;
	goto gnuplotlCON1156;
gnuplotlCON1158:
	local[2]= NIL;
gnuplotlCON1156:
	argv[0]->c.obj.iv[1] = local[2];
	argv[0]->c.obj.iv[3] = makeint((eusinteger_t)10L);
	if (local[0]==NIL) goto gnuplotlIF1159;
	local[2]= argv[0];
	local[3]= fqv[9];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto gnuplotlIF1160;
gnuplotlIF1159:
	local[2]= NIL;
gnuplotlIF1160:
	argv[0]->c.obj.iv[5] = local[1];
	w = argv[0];
	local[0]= w;
gnuplotlBLK1151:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer gnuplotlM1161gnuplot_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[10];
	ctx->vsp=local+1;
	w=(pointer)FBOUNDP(ctx,1,local+0); /*fboundp*/
	if (w==NIL) goto gnuplotlIF1163;
	ctx->vsp=local+0;
	w=(*ftab[3])(ctx,0,local+0,&ftab[3],fqv[10]); /*x::query-window-title-list*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= fqv[11];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,2,local+3); /*format*/
gnuplotlWHL1165:
	if (local[2]!=NIL) goto gnuplotlWHX1166;
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,0,local+3,&ftab[3],fqv[10]); /*x::query-window-title-list*/
	local[1] = w;
	local[3]= local[1];
	local[4]= local[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,gnuplotlCLO1168,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,4,local+3,&ftab[4],fqv[13]); /*set-difference*/
	local[2] = w;
	goto gnuplotlWHL1165;
gnuplotlWHX1166:
	local[3]= NIL;
gnuplotlBLK1167:
	local[3]= argv[0];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	local[5]= fqv[14];
	ctx->vsp=local+6;
	w=(pointer)PUTPROP(ctx,3,local+3); /*putprop*/
	local[0]= w;
	goto gnuplotlIF1164;
gnuplotlIF1163:
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[15];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
gnuplotlIF1164:
	w = local[0];
	local[0]= w;
gnuplotlBLK1162:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer gnuplotlM1169gnuplot_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
gnuplotlRST1171:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	argv[0]->c.obj.iv[4] = local[0];
	if (argv[0]->c.obj.iv[5]==NIL) goto gnuplotlIF1172;
	local[1]= fqv[16];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[17]); /*warn*/
	local[1]= w;
	goto gnuplotlIF1173;
gnuplotlIF1172:
	local[1]= NIL;
gnuplotlIF1173:
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= makeint((eusinteger_t)1L);
	local[8]= fqv[18];
	local[9]= NIL;
	local[10]= NIL;
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= makeflt(0.0000000000000000000000e+00);
	local[13]= fqv[19];
	local[14]= makeint((eusinteger_t)0L);
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
gnuplotlWHL1174:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto gnuplotlWHX1175;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[20]!=local[16]) goto gnuplotlIF1177;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[2] = w;
	local[16]= local[2];
	goto gnuplotlIF1178;
gnuplotlIF1177:
	local[16]= NIL;
gnuplotlIF1178:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[21]!=local[16]) goto gnuplotlIF1179;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[3] = w;
	local[16]= local[3];
	goto gnuplotlIF1180;
gnuplotlIF1179:
	local[16]= NIL;
gnuplotlIF1180:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[22]!=local[16]) goto gnuplotlIF1181;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[4] = w;
	local[16]= local[4];
	goto gnuplotlIF1182;
gnuplotlIF1181:
	local[16]= NIL;
gnuplotlIF1182:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[23]!=local[16]) goto gnuplotlIF1183;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[5] = w;
	local[16]= local[5];
	goto gnuplotlIF1184;
gnuplotlIF1183:
	local[16]= NIL;
gnuplotlIF1184:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[9]!=local[16]) goto gnuplotlIF1185;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[6] = w;
	local[16]= local[6];
	goto gnuplotlIF1186;
gnuplotlIF1185:
	local[16]= NIL;
gnuplotlIF1186:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[24]!=local[16]) goto gnuplotlIF1187;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[7] = w;
	local[16]= local[7];
	goto gnuplotlIF1188;
gnuplotlIF1187:
	local[16]= NIL;
gnuplotlIF1188:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[25]!=local[16]) goto gnuplotlIF1189;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[8] = w;
	local[16]= local[8];
	goto gnuplotlIF1190;
gnuplotlIF1189:
	local[16]= NIL;
gnuplotlIF1190:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[26]!=local[16]) goto gnuplotlIF1191;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[11] = w;
	local[16]= local[11];
	goto gnuplotlIF1192;
gnuplotlIF1191:
	local[16]= NIL;
gnuplotlIF1192:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[27]!=local[16]) goto gnuplotlIF1193;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[12] = w;
	local[16]= local[12];
	goto gnuplotlIF1194;
gnuplotlIF1193:
	local[16]= NIL;
gnuplotlIF1194:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[28]!=local[16]) goto gnuplotlIF1195;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[9] = w;
	local[16]= local[9];
	goto gnuplotlIF1196;
gnuplotlIF1195:
	local[16]= NIL;
gnuplotlIF1196:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[29]!=local[16]) goto gnuplotlIF1197;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[10] = w;
	local[16]= local[10];
	goto gnuplotlIF1198;
gnuplotlIF1197:
	local[16]= NIL;
gnuplotlIF1198:
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	if (fqv[30]!=local[16]) goto gnuplotlIF1199;
	local[16]= local[0];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[13] = w;
	local[16]= local[13];
	goto gnuplotlIF1200;
gnuplotlIF1199:
	local[16]= NIL;
gnuplotlIF1200:
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto gnuplotlWHL1174;
gnuplotlWHX1175:
	local[16]= NIL;
gnuplotlBLK1176:
	w = NIL;
	local[14]= fqv[20];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[2];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[21];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[3];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[22];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[4];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[23];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[5];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[9];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[6];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[24];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[7];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[25];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[8];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[26];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[11];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[27];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[12];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[28];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[9];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[29];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[10];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= fqv[30];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,2,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	local[14]= local[13];
	local[15]= local[0];
	local[16]= fqv[12];
	local[17]= (pointer)get_sym_func(fqv[32]);
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,4,local+14,&ftab[6],fqv[31]); /*remove*/
	local[0] = w;
	if (local[6]==NIL) goto gnuplotlIF1201;
	local[14]= argv[0];
	local[15]= fqv[9];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	goto gnuplotlIF1202;
gnuplotlIF1201:
	local[14]= NIL;
gnuplotlIF1202:
	local[14]= local[13];
	local[15]= local[14];
	if (fqv[19]!=local[15]) goto gnuplotlIF1203;
	if (local[9]==NIL) goto gnuplotlIF1205;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[33];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	if (local[10]==NIL) goto gnuplotlIF1207;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[34];
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,4,local+15); /*format*/
	local[15]= w;
	goto gnuplotlIF1208;
gnuplotlIF1207:
	local[15]= NIL;
gnuplotlIF1208:
	goto gnuplotlIF1206;
gnuplotlIF1205:
	local[15]= NIL;
gnuplotlIF1206:
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[35];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	local[15]= local[2];
	if (local[15]!=NIL) goto gnuplotlOR1211;
	local[15]= local[3];
gnuplotlOR1211:
	local[2] = local[15];
	if (local[2]==NIL) goto gnuplotlIF1209;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[36];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,4,local+15); /*format*/
	local[15]= w;
	goto gnuplotlIF1210;
gnuplotlIF1209:
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[37];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	local[15]= w;
gnuplotlIF1210:
	if (local[4]==NIL) goto gnuplotlIF1212;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[38];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,4,local+15); /*format*/
	local[15]= w;
	goto gnuplotlIF1213;
gnuplotlIF1212:
	local[15]= NIL;
gnuplotlIF1213:
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[39];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	if (local[5]==NIL) goto gnuplotlIF1214;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[40];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[17];
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,3,local+15); /*format*/
	local[15]= w;
	goto gnuplotlIF1215;
gnuplotlIF1214:
	local[15]= NIL;
gnuplotlIF1215:
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[41];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,3,local+15); /*format*/
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[15];
	if (w==NIL) goto gnuplotlIF1216;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[42];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	local[15]= w;
	goto gnuplotlIF1217;
gnuplotlIF1216:
	local[15]= NIL;
gnuplotlIF1217:
	local[15]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.cdr;
gnuplotlWHL1218:
	if (local[16]==NIL) goto gnuplotlWHX1219;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16] = (w)->c.cons.cdr;
	w = local[17];
	local[15] = w;
	local[17]= argv[0]->c.obj.iv[1];
	local[18]= fqv[43];
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,2,local+17); /*format*/
	if (local[5]==NIL) goto gnuplotlIF1221;
	local[17]= argv[0]->c.obj.iv[1];
	local[18]= fqv[44];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[19];
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)XFORMAT(ctx,3,local+17); /*format*/
	local[17]= w;
	goto gnuplotlIF1222;
gnuplotlIF1221:
	local[17]= NIL;
gnuplotlIF1222:
	local[17]= argv[0]->c.obj.iv[1];
	local[18]= fqv[45];
	local[19]= local[7];
	ctx->vsp=local+20;
	w=(pointer)XFORMAT(ctx,3,local+17); /*format*/
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[17];
	if (w==NIL) goto gnuplotlIF1223;
	local[17]= argv[0]->c.obj.iv[1];
	local[18]= fqv[46];
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,2,local+17); /*format*/
	local[17]= w;
	goto gnuplotlIF1224;
gnuplotlIF1223:
	local[17]= NIL;
gnuplotlIF1224:
	goto gnuplotlWHL1218;
gnuplotlWHX1219:
	local[17]= NIL;
gnuplotlBLK1220:
	w = NIL;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[47];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	local[15]= NIL;
	local[16]= local[0];
gnuplotlWHL1225:
	if (local[16]==NIL) goto gnuplotlWHX1226;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16] = (w)->c.cons.cdr;
	w = local[17];
	local[15] = w;
	local[17]= makeint((eusinteger_t)0L);
	local[18]= local[15];
	ctx->vsp=local+19;
	w=(pointer)LENGTH(ctx,1,local+18); /*length*/
	local[18]= w;
gnuplotlWHL1228:
	local[19]= local[17];
	w = local[18];
	if ((eusinteger_t)local[19] >= (eusinteger_t)w) goto gnuplotlWHX1229;
	local[19]= local[8];
	if (fqv[48]!=local[19]) goto gnuplotlIF1231;
	local[19]= argv[0]->c.obj.iv[1];
	local[20]= fqv[49];
	local[21]= local[17];
	local[22]= local[11];
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	local[22]= local[12];
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,2,local+21); /*+*/
	local[21]= w;
	local[22]= local[15];
	local[23]= local[15];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	w = local[17];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[23]= (pointer)((eusinteger_t)local[23] - (eusinteger_t)w);
	ctx->vsp=local+24;
	w=(pointer)SUB1(ctx,1,local+23); /*1-*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)XFORMAT(ctx,4,local+19); /*format*/
	local[19]= w;
	goto gnuplotlIF1232;
gnuplotlIF1231:
	local[19]= argv[0]->c.obj.iv[1];
	local[20]= fqv[50];
	local[21]= local[17];
	local[22]= local[11];
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	local[22]= local[12];
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,2,local+21); /*+*/
	local[21]= w;
	local[22]= local[15];
	local[23]= local[17];
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)XFORMAT(ctx,4,local+19); /*format*/
	local[19]= w;
gnuplotlIF1232:
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)ADD1(ctx,1,local+19); /*1+*/
	local[17] = w;
	goto gnuplotlWHL1228;
gnuplotlWHX1229:
	local[19]= NIL;
gnuplotlBLK1230:
	w = NIL;
	local[17]= argv[0]->c.obj.iv[1];
	local[18]= fqv[51];
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,2,local+17); /*format*/
	goto gnuplotlWHL1225;
gnuplotlWHX1226:
	local[17]= NIL;
gnuplotlBLK1227:
	w = NIL;
	local[15]= w;
	goto gnuplotlIF1204;
gnuplotlIF1203:
	local[15]= local[14];
	if (fqv[52]!=local[15]) goto gnuplotlIF1233;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[53];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[54];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	if (local[4]==NIL) goto gnuplotlIF1235;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[55];
	local[17]= local[4];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[4];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,4,local+15); /*format*/
	local[15]= w;
	goto gnuplotlIF1236;
gnuplotlIF1235:
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[56];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	local[15]= w;
gnuplotlIF1236:
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[57];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	local[15]= makeint((eusinteger_t)0L);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
gnuplotlWHL1237:
	local[17]= local[15];
	w = local[16];
	if ((eusinteger_t)local[17] >= (eusinteger_t)w) goto gnuplotlWHX1238;
	local[17]= makeint((eusinteger_t)0L);
	local[18]= makeint((eusinteger_t)2L);
gnuplotlWHL1240:
	local[19]= local[17];
	w = local[18];
	if ((eusinteger_t)local[19] >= (eusinteger_t)w) goto gnuplotlWHX1241;
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[0];
	ctx->vsp=local+21;
	w=(pointer)LENGTH(ctx,1,local+20); /*length*/
	local[20]= w;
gnuplotlWHL1243:
	local[21]= local[19];
	w = local[20];
	if ((eusinteger_t)local[21] >= (eusinteger_t)w) goto gnuplotlWHX1244;
	local[21]= makeint((eusinteger_t)0L);
	local[22]= makeint((eusinteger_t)2L);
gnuplotlWHL1246:
	local[23]= local[21];
	w = local[22];
	if ((eusinteger_t)local[23] >= (eusinteger_t)w) goto gnuplotlWHX1247;
	local[23]= local[15];
	w = local[17];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[23]= (pointer)((eusinteger_t)local[23] + (eusinteger_t)w);
	local[24]= local[11];
	ctx->vsp=local+25;
	w=(pointer)TIMES(ctx,2,local+23); /***/
	local[23]= w;
	local[24]= local[12];
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	local[24]= local[19];
	w = local[21];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[24]= (pointer)((eusinteger_t)local[24] + (eusinteger_t)w);
	local[25]= local[8];
	if (fqv[48]!=local[25]) goto gnuplotlIF1249;
	local[25]= local[0];
	local[26]= local[19];
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	w = local[15];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[26]= (pointer)((eusinteger_t)local[26] - (eusinteger_t)w);
	ctx->vsp=local+27;
	w=(pointer)SUB1(ctx,1,local+26); /*1-*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
	goto gnuplotlIF1250;
gnuplotlIF1249:
	local[25]= local[0];
	local[26]= local[19];
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
	local[26]= local[15];
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
gnuplotlIF1250:
	local[26]= argv[0]->c.obj.iv[1];
	local[27]= fqv[58];
	local[28]= local[23];
	local[29]= local[24];
	local[30]= local[25];
	ctx->vsp=local+31;
	w=(pointer)XFORMAT(ctx,5,local+26); /*format*/
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(pointer)ADD1(ctx,1,local+23); /*1+*/
	local[21] = w;
	goto gnuplotlWHL1246;
gnuplotlWHX1247:
	local[23]= NIL;
gnuplotlBLK1248:
	w = NIL;
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[19] = w;
	goto gnuplotlWHL1243;
gnuplotlWHX1244:
	local[21]= NIL;
gnuplotlBLK1245:
	w = NIL;
	local[19]= argv[0]->c.obj.iv[1];
	local[20]= fqv[59];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)ADD1(ctx,1,local+19); /*1+*/
	local[17] = w;
	goto gnuplotlWHL1240;
gnuplotlWHX1241:
	local[19]= NIL;
gnuplotlBLK1242:
	w = NIL;
	local[17]= local[15];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[15] = w;
	goto gnuplotlWHL1237;
gnuplotlWHX1238:
	local[17]= NIL;
gnuplotlBLK1239:
	w = NIL;
	local[15]= argv[0]->c.obj.iv[1];
	local[16]= fqv[60];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,2,local+15); /*format*/
	local[15]= w;
	goto gnuplotlIF1234;
gnuplotlIF1233:
	if (T==NIL) goto gnuplotlIF1251;
	local[15]= fqv[61];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(*ftab[5])(ctx,2,local+15,&ftab[5],fqv[17]); /*warn*/
	local[15]= w;
	goto gnuplotlIF1252;
gnuplotlIF1251:
	local[15]= NIL;
gnuplotlIF1252:
gnuplotlIF1234:
gnuplotlIF1204:
	w = local[15];
	local[0]= w;
gnuplotlBLK1170:
	ctx->vsp=local; return(local[0]);}

/*:save*/
static pointer gnuplotlM1253gnuplot_save(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[62], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto gnuplotlKEY1255;
	local[0] = fqv[63];
gnuplotlKEY1255:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[64];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[65];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	if (argv[0]->c.obj.iv[4]==NIL) goto gnuplotlIF1256;
	local[1]= (pointer)get_sym_func(fqv[66]);
	local[2]= argv[0];
	local[3]= fqv[67];
	local[4]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto gnuplotlIF1257;
gnuplotlIF1256:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[68];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= w;
gnuplotlIF1257:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[69];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[70];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	if (argv[0]->c.obj.iv[4]==NIL) goto gnuplotlIF1258;
	local[1]= (pointer)get_sym_func(fqv[66]);
	local[2]= argv[0];
	local[3]= fqv[67];
	local[4]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto gnuplotlIF1259;
gnuplotlIF1258:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[71];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= w;
gnuplotlIF1259:
	w = local[1];
	local[0]= w;
gnuplotlBLK1254:
	ctx->vsp=local; return(local[0]);}

/*:replot*/
static pointer gnuplotlM1260gnuplot_replot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[72];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
gnuplotlBLK1261:
	ctx->vsp=local; return(local[0]);}

/*:reset*/
static pointer gnuplotlM1262gnuplot_reset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[73];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
gnuplotlBLK1263:
	ctx->vsp=local; return(local[0]);}

/*:command*/
static pointer gnuplotlM1264gnuplot_command(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[74];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
gnuplotlBLK1265:
	ctx->vsp=local; return(local[0]);}

/*:quit*/
static pointer gnuplotlM1266gnuplot_quit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[75];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
gnuplotlBLK1267:
	ctx->vsp=local; return(local[0]);}

/*:proc-length*/
static pointer gnuplotlM1268gnuplot_proc_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto gnuplotlENT1271;}
	local[0]= NIL;
gnuplotlENT1271:
gnuplotlENT1270:
	if (n>3) maerror();
	if (local[0]==NIL) goto gnuplotlIF1272;
	argv[0]->c.obj.iv[3] = local[0];
	local[1]= argv[0]->c.obj.iv[3];
	goto gnuplotlIF1273;
gnuplotlIF1272:
	local[1]= NIL;
gnuplotlIF1273:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
gnuplotlBLK1269:
	ctx->vsp=local; return(local[0]);}

/*:proc-clear*/
static pointer gnuplotlM1274gnuplot_proc_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[2] = NIL;
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
gnuplotlBLK1275:
	ctx->vsp=local; return(local[0]);}

/*:proc-one*/
static pointer gnuplotlM1276gnuplot_proc_one(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
gnuplotlRST1278:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	if ((eusinteger_t)local[1] >= (eusinteger_t)w) goto gnuplotlIF1279;
gnuplotlWHL1281:
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	if ((eusinteger_t)local[1] >= (eusinteger_t)w) goto gnuplotlWHX1282;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	argv[0]->c.obj.iv[2] = w;
	goto gnuplotlWHL1281;
gnuplotlWHX1282:
	local[1]= NIL;
gnuplotlBLK1283:
	goto gnuplotlIF1280;
gnuplotlIF1279:
	local[1]= NIL;
gnuplotlIF1280:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
gnuplotlWHL1284:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto gnuplotlWHX1285;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	local[5]= argv[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto gnuplotlWHL1284;
gnuplotlWHX1285:
	local[3]= NIL;
gnuplotlBLK1286:
	w = NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
gnuplotlWHL1287:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto gnuplotlWHX1288;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	if (w==NIL) goto gnuplotlIF1290;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)BUTLAST(ctx,2,local+5); /*butlast*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= w;
	goto gnuplotlIF1291;
gnuplotlIF1290:
	local[3]= NIL;
gnuplotlIF1291:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto gnuplotlWHL1287;
gnuplotlWHX1288:
	local[3]= NIL;
gnuplotlBLK1289:
	w = NIL;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	argv[0]->c.obj.iv[4] = w;
	local[1]= (pointer)get_sym_func(fqv[66]);
	local[2]= argv[0];
	local[3]= fqv[67];
	local[4]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
gnuplotlBLK1277:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer gnuplotlCLO1168(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*gnuplot*/
static pointer gnuplotlF1148gnuplot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[76], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto gnuplotlKEY1293;
	ctx->vsp=local+1;
	w=(pointer)GETHOSTNAME(ctx,0,local+1); /*unix:gethostname*/
	local[0] = w;
gnuplotlKEY1293:
	local[1]= loadglobal(fqv[77]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[78];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w = local[1];
	local[0]= w;
gnuplotlBLK1292:
	ctx->vsp=local; return(local[0]);}

/*graph-view*/
static pointer gnuplotlF1149graph_view(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto gnuplotlENT1296;}
	local[0]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,gnuplotlCLO1297,env,argv,local);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,1,local+2,&ftab[7],fqv[79]); /*make-list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
gnuplotlENT1296:
gnuplotlENT1295:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[80], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto gnuplotlKEY1298;
	local[1] = fqv[81];
gnuplotlKEY1298:
	if (n & (1<<1)) goto gnuplotlKEY1299;
	local[2] = fqv[82];
gnuplotlKEY1299:
	if (n & (1<<2)) goto gnuplotlKEY1300;
	local[3] = fqv[83];
gnuplotlKEY1300:
	if (n & (1<<3)) goto gnuplotlKEY1301;
	local[4] = fqv[84];
gnuplotlKEY1301:
	if (n & (1<<4)) goto gnuplotlKEY1302;
	local[5] = NIL;
gnuplotlKEY1302:
	if (n & (1<<5)) goto gnuplotlKEY1303;
	local[17]= NIL;
	local[18]= fqv[85];
	local[19]= makeint((eusinteger_t)95L);
	local[20]= fqv[86];
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)ELT(ctx,2,local+20); /*elt*/
	local[20]= w;
	local[21]= local[1];
	ctx->vsp=local+22;
	w=(*ftab[8])(ctx,3,local+19,&ftab[8],fqv[87]); /*substitute*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)XFORMAT(ctx,3,local+17); /*format*/
	local[6] = w;
gnuplotlKEY1303:
	if (n & (1<<6)) goto gnuplotlKEY1304;
	local[7] = fqv[88];
gnuplotlKEY1304:
	if (n & (1<<7)) goto gnuplotlKEY1305;
	local[8] = NIL;
gnuplotlKEY1305:
	if (n & (1<<8)) goto gnuplotlKEY1306;
	local[9] = NIL;
gnuplotlKEY1306:
	if (n & (1<<9)) goto gnuplotlKEY1307;
	local[10] = NIL;
gnuplotlKEY1307:
	if (n & (1<<10)) goto gnuplotlKEY1308;
	local[11] = NIL;
gnuplotlKEY1308:
	if (n & (1<<11)) goto gnuplotlKEY1309;
	local[12] = NIL;
gnuplotlKEY1309:
	if (n & (1<<12)) goto gnuplotlKEY1310;
	local[13] = NIL;
gnuplotlKEY1310:
	if (n & (1<<13)) goto gnuplotlKEY1311;
	local[14] = NIL;
gnuplotlKEY1311:
	if (n & (1<<14)) goto gnuplotlKEY1312;
	local[17]= fqv[89];
	ctx->vsp=local+18;
	w=(pointer)BOUNDP(ctx,1,local+17); /*boundp*/
	if (w==NIL) goto gnuplotlIF1313;
	local[17]= loadglobal(fqv[89]);
	goto gnuplotlIF1314;
gnuplotlIF1313:
	ctx->vsp=local+17;
	w=(pointer)gnuplotlF1148gnuplot(ctx,0,local+17); /*gnuplot*/
	local[17]= w;
	storeglobal(fqv[89],w);
gnuplotlIF1314:
	local[15] = local[17];
gnuplotlKEY1312:
	if (n & (1<<15)) goto gnuplotlKEY1315;
	local[17]= NIL;
	local[18]= fqv[90];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)ADDRESS(ctx,1,local+19); /*system:address*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)XFORMAT(ctx,3,local+17); /*format*/
	local[16] = w;
gnuplotlKEY1315:
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,gnuplotlFLET1316,env,argv,local);
	ctx->vsp=local+18;
	local[18]= makeclosure(codevec,quotevec,gnuplotlFLET1317,env,argv,local);
	if (local[8]!=NIL) goto gnuplotlIF1318;
	local[19]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+20;
	local[20]= makeclosure(codevec,quotevec,gnuplotlCLO1320,env,argv,local);
	local[21]= argv[0];
	ctx->vsp=local+22;
	w=(pointer)LENGTH(ctx,1,local+21); /*length*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[7])(ctx,1,local+21,&ftab[7],fqv[79]); /*make-list*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,2,local+20); /*mapcar*/
	local[8] = w;
	local[19]= local[8];
	goto gnuplotlIF1319;
gnuplotlIF1318:
	local[19]= NIL;
gnuplotlIF1319:
	if (local[14]!=NIL) goto gnuplotlIF1321;
	local[19]= NIL;
	local[20]= fqv[91];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,3,local+19); /*format*/
	local[19]= w;
	local[20]= fqv[25];
	local[21]= fqv[92];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,3,local+19,&ftab[9],fqv[93]); /*open*/
	local[19]= w;
	ctx->vsp=local+20;
	w = makeclosure(codevec,quotevec,gnuplotlUWP1323,env,argv,local);
	local[20]=(pointer)(ctx->protfp); local[21]=w;
	ctx->protfp=(struct protectframe *)(local+20);
	local[22]= local[19];
	local[23]= fqv[94];
	local[24]= fqv[95];
	w = local[18];
	ctx->vsp=local+25;
	w=gnuplotlFLET1317(ctx,2,local+23,w);
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,2,local+22); /*format*/
	local[22]= makeint((eusinteger_t)0L);
	local[23]= local[0];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
gnuplotlWHL1324:
	local[24]= local[22];
	w = local[23];
	if ((eusinteger_t)local[24] >= (eusinteger_t)w) goto gnuplotlWHX1325;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto gnuplotlIF1327;
	local[24]= local[19];
	local[25]= fqv[96];
	local[26]= local[0];
	local[27]= local[22];
	ctx->vsp=local+28;
	w=(pointer)ELT(ctx,2,local+26); /*elt*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)XFORMAT(ctx,3,local+24); /*format*/
	local[24]= w;
	goto gnuplotlIF1328;
gnuplotlIF1327:
	local[24]= local[19];
	local[25]= fqv[97];
	local[26]= local[0];
	local[27]= local[22];
	ctx->vsp=local+28;
	w=(pointer)ELT(ctx,2,local+26); /*elt*/
	local[26]= w;
	local[27]= makeint((eusinteger_t)0L);
	ctx->vsp=local+28;
	w=(pointer)ELT(ctx,2,local+26); /*elt*/
	local[26]= w;
	local[27]= local[0];
	local[28]= local[22];
	ctx->vsp=local+29;
	w=(pointer)ELT(ctx,2,local+27); /*elt*/
	local[27]= w;
	local[28]= makeint((eusinteger_t)1L);
	ctx->vsp=local+29;
	w=(pointer)ELT(ctx,2,local+27); /*elt*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)XFORMAT(ctx,4,local+24); /*format*/
	local[24]= w;
gnuplotlIF1328:
	local[24]= NIL;
	local[25]= argv[0];
gnuplotlWHL1329:
	if (local[25]==NIL) goto gnuplotlWHX1330;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25] = (w)->c.cons.cdr;
	w = local[26];
	local[24] = w;
	local[26]= local[22];
	local[27]= local[24];
	ctx->vsp=local+28;
	w=(pointer)LENGTH(ctx,1,local+27); /*length*/
	if ((eusinteger_t)local[26] >= (eusinteger_t)w) goto gnuplotlIF1332;
	local[26]= local[19];
	local[27]= fqv[98];
	local[28]= local[24];
	local[29]= local[22];
	ctx->vsp=local+30;
	w=(pointer)ELT(ctx,2,local+28); /*elt*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)XFORMAT(ctx,3,local+26); /*format*/
	local[26]= w;
	goto gnuplotlIF1333;
gnuplotlIF1332:
	local[26]= NIL;
gnuplotlIF1333:
	goto gnuplotlWHL1329;
gnuplotlWHX1330:
	local[26]= NIL;
gnuplotlBLK1331:
	w = NIL;
	local[24]= local[19];
	local[25]= fqv[99];
	ctx->vsp=local+26;
	w=(pointer)XFORMAT(ctx,2,local+24); /*format*/
	local[24]= local[22];
	ctx->vsp=local+25;
	w=(pointer)ADD1(ctx,1,local+24); /*1+*/
	local[22] = w;
	goto gnuplotlWHL1324;
gnuplotlWHX1325:
	local[24]= NIL;
gnuplotlBLK1326:
	w = NIL;
	ctx->vsp=local+22;
	gnuplotlUWP1323(ctx,0,local+22,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[19]= w;
	goto gnuplotlIF1322;
gnuplotlIF1321:
	local[19]= NIL;
gnuplotlIF1322:
	ctx->vsp=local+19;
	local[19]= makeclosure(codevec,quotevec,gnuplotlCLO1334,env,argv,local);
	local[20]= fqv[100];
	local[21]= local[1];
	local[22]= local[2];
	local[23]= local[3];
	local[24]= local[4];
	ctx->vsp=local+25;
	w=(pointer)LIST(ctx,4,local+21); /*list*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,3,local+19); /*mapcar*/
	if (local[13]==NIL) goto gnuplotlIF1335;
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)FUNCALL(ctx,1,local+19); /*funcall*/
	local[19]= w;
	goto gnuplotlIF1336;
gnuplotlIF1335:
	local[19]= NIL;
gnuplotlIF1336:
	local[19]= makeint((eusinteger_t)0L);
	local[20]= argv[0];
	ctx->vsp=local+21;
	w=(pointer)LENGTH(ctx,1,local+20); /*length*/
	local[20]= w;
gnuplotlWHL1337:
	local[21]= local[19];
	w = local[20];
	if ((eusinteger_t)local[21] >= (eusinteger_t)w) goto gnuplotlWHX1338;
	local[21]= local[15];
	local[22]= fqv[101];
	local[23]= NIL;
	local[24]= fqv[102];
	local[25]= local[19];
	local[26]= local[25];
	if (fqv[103]!=local[26]) goto gnuplotlIF1340;
	local[26]= (pointer)get_sym_func(fqv[104]);
	local[27]= NIL;
	local[28]= fqv[105];
	local[29]= fqv[106];
	w = local[18];
	ctx->vsp=local+30;
	w=gnuplotlFLET1317(ctx,2,local+28,w);
	local[28]= w;
	local[29]= local[9];
	w = local[17];
	ctx->vsp=local+30;
	w=gnuplotlFLET1316(ctx,1,local+29,w);
	local[29]= w;
	local[30]= local[10];
	w = local[17];
	ctx->vsp=local+31;
	w=gnuplotlFLET1316(ctx,1,local+30,w);
	local[30]= w;
	local[31]= NIL;
	local[32]= local[11];
	w = local[17];
	ctx->vsp=local+33;
	w=gnuplotlFLET1316(ctx,1,local+32,w);
	local[32]= w;
	w = local[18];
	ctx->vsp=local+33;
	w=gnuplotlFLET1317(ctx,2,local+31,w);
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)LIST(ctx,5,local+27); /*list*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)APPLY(ctx,2,local+26); /*apply*/
	local[26]= w;
	goto gnuplotlIF1341;
gnuplotlIF1340:
	if (T==NIL) goto gnuplotlIF1342;
	local[26]= fqv[107];
	goto gnuplotlIF1343;
gnuplotlIF1342:
	local[26]= NIL;
gnuplotlIF1343:
gnuplotlIF1341:
	w = local[26];
	local[25]= w;
	local[26]= local[16];
	local[27]= NIL;
	local[28]= fqv[108];
	local[29]= fqv[109];
	local[30]= fqv[110];
	w = local[18];
	ctx->vsp=local+31;
	w=gnuplotlFLET1317(ctx,2,local+29,w);
	local[29]= w;
	local[30]= local[19];
	local[31]= makeint((eusinteger_t)2L);
	local[32]= makeint((eusinteger_t)3L);
	w = local[18];
	ctx->vsp=local+33;
	w=gnuplotlFLET1317(ctx,2,local+31,w);
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)PLUS(ctx,2,local+30); /*+*/
	local[30]= w;
	ctx->vsp=local+31;
	w=(pointer)XFORMAT(ctx,4,local+27); /*format*/
	local[27]= w;
	local[28]= local[8];
	local[29]= local[19];
	ctx->vsp=local+30;
	w=(pointer)ELT(ctx,2,local+28); /*elt*/
	local[28]= w;
	local[29]= local[7];
	ctx->vsp=local+30;
	w=(pointer)XFORMAT(ctx,7,local+23); /*format*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,3,local+21); /*send*/
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[19] = w;
	goto gnuplotlWHL1337;
gnuplotlWHX1338:
	local[21]= NIL;
gnuplotlBLK1339:
	w = NIL;
	if (local[12]==NIL) goto gnuplotlIF1344;
	local[19]= local[15];
	local[20]= fqv[101];
	local[21]= fqv[111];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	goto gnuplotlIF1345;
gnuplotlIF1344:
	local[19]= NIL;
gnuplotlIF1345:
	if (local[5]==NIL) goto gnuplotlIF1346;
	local[19]= makeint((eusinteger_t)200000L);
	ctx->vsp=local+20;
	w=(*ftab[10])(ctx,1,local+19,&ftab[10],fqv[112]); /*unix:usleep*/
	local[19]= local[15];
	local[20]= fqv[113];
	local[21]= local[6];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= makeint((eusinteger_t)200000L);
	ctx->vsp=local+20;
	w=(*ftab[10])(ctx,1,local+19,&ftab[10],fqv[112]); /*unix:usleep*/
	local[19]= w;
	goto gnuplotlIF1347;
gnuplotlIF1346:
	local[19]= NIL;
gnuplotlIF1347:
	w = local[19];
	local[0]= w;
gnuplotlBLK1294:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer gnuplotlCLO1297(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	env->c.clo.env2[0] = w;
	w = env->c.clo.env2[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer gnuplotlFLET1316(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	if (argv[0]==NIL) goto gnuplotlIF1348;
	local[0]= NIL;
	local[1]= fqv[114];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	goto gnuplotlIF1349;
gnuplotlIF1348:
	local[0]= fqv[115];
gnuplotlIF1349:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer gnuplotlFLET1317(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=env->c.clo.env2[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto gnuplotlIF1350;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)EVAL(ctx,1,local+0); /*eval*/
	local[0]= w;
	goto gnuplotlIF1351;
gnuplotlIF1350:
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)EVAL(ctx,1,local+0); /*eval*/
	local[0]= w;
gnuplotlIF1351:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer gnuplotlCLO1320(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[19];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	env->c.clo.env2[19] = w;
	w = env->c.clo.env2[19];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer gnuplotlUWP1323(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[19];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer gnuplotlCLO1334(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env2[15];
	local[1]= fqv[101];
	local[2]= NIL;
	local[3]= fqv[116];
	local[4]= argv[0];
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___gnuplotlib(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[77];
	local[1]= fqv[117];
	local[2]= fqv[77];
	local[3]= fqv[118];
	local[4]= loadglobal(fqv[119]);
	local[5]= fqv[120];
	local[6]= fqv[121];
	local[7]= fqv[122];
	local[8]= NIL;
	local[9]= fqv[123];
	local[10]= NIL;
	local[11]= fqv[124];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[125];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[11])(ctx,13,local+2,&ftab[11],fqv[126]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1150gnuplot_init,fqv[78],fqv[77],fqv[127]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1161gnuplot_clear,fqv[9],fqv[77],fqv[128]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1169gnuplot_draw,fqv[67],fqv[77],fqv[129]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1253gnuplot_save,fqv[113],fqv[77],fqv[130]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1260gnuplot_replot,fqv[131],fqv[77],fqv[132]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1262gnuplot_reset,fqv[133],fqv[77],fqv[134]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1264gnuplot_command,fqv[101],fqv[77],fqv[135]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1266gnuplot_quit,fqv[136],fqv[77],fqv[137]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1268gnuplot_proc_length,fqv[138],fqv[77],fqv[139]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1274gnuplot_proc_clear,fqv[140],fqv[77],fqv[141]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,gnuplotlM1276gnuplot_proc_one,fqv[142],fqv[77],fqv[143]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[77],module,gnuplotlF1148gnuplot,fqv[144]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[145],module,gnuplotlF1149graph_view,fqv[146]);
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<12; i++) ftab[i]=fcallx;
}

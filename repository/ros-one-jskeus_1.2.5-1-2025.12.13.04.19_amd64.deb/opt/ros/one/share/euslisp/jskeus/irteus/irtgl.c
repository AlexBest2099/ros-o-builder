/* ./irtgl.c :  entry=irtgl */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "irtgl.h"
#pragma init (register_irtgl)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtgl();
extern pointer build_quote_vector();
static int register_irtgl()
  { add_module_initializer("___irtgl", ___irtgl);}

static pointer irtglF1set_stereo_gl_attribute();
static pointer irtglF2reset_gl_attribute();
static pointer irtglF3delete_displaylist_id();
static pointer irtglF4transpose_image_rows();
static pointer irtglF5draw_globjects();
static pointer irtglF6draw_glbody();
static pointer irtglF7find_color();
static pointer irtglF8transparent();
static pointer irtglF9make_glvertices_from_faceset();
static pointer irtglF10make_glvertices_from_faces();
static pointer irtglF11_dump_wrl_shape();
static pointer irtglF12write_wrl_from_glvertices();

/*set-stereo-gl-attribute*/
static pointer irtglF1set_stereo_gl_attribute(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	ctx->vsp=local+0;
	w=(pointer)irtglF2reset_gl_attribute(ctx,0,local+0); /*reset-gl-attribute*/
	local[0]= loadglobal(fqv[0]);
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	local[0]= w;
	local[1]= fqv[1];
	local[2]= fqv[2];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,3,local+0,&ftab[0],fqv[3]); /*make-array*/
	local[0]= w;
	local[1]= local[0];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)VECREPLACE(ctx,2,local+1); /*system::vector-replace*/
	local[1]= local[0];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)6L);
	ctx->vsp=local+4;
	w=(pointer)SETELT(ctx,3,local+1); /*setelt*/
	local[1]= local[0];
	storeglobal(fqv[0],local[1]);
	w = local[1];
	local[0]= w;
irtglBLK13:
	ctx->vsp=local; return(local[0]);}

/*reset-gl-attribute*/
static pointer irtglF2reset_gl_attribute(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= makeint((eusinteger_t)4L);
	local[1]= makeint((eusinteger_t)8L);
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)9L);
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)10L);
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)5L);
	local[8]= makeint((eusinteger_t)12L);
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKINTVECTOR(ctx,11,local+0); /*integer-vector*/
	local[0]= w;
	storeglobal(fqv[0],w);
	w = local[0];
	local[0]= w;
irtglBLK14:
	ctx->vsp=local; return(local[0]);}

/*delete-displaylist-id*/
static pointer irtglF3delete_displaylist_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!numberp(w)) goto irtglCON17;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[4]); /*gldeletelists*/
	local[0]= w;
	goto irtglCON16;
irtglCON17:
	local[0]= NIL;
	local[1]= argv[0];
irtglWHL19:
	if (local[1]==NIL) goto irtglWHX20;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[6];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtglCLO22,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,4,local+2,&ftab[2],fqv[7]); /*find*/
	local[2]= w;
	if (local[2]==NIL) goto irtglIF23;
	local[3]= local[2];
	local[4]= fqv[8];
	local[5]= fqv[9];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,1,local+3,&ftab[3],fqv[10]); /*glislist*/
	if (w==NIL) goto irtglCON26;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[4]); /*gldeletelists*/
	local[3]= w;
	goto irtglCON25;
irtglCON26:
	local[3]= fqv[11];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,2,local+3); /*error*/
	local[3]= w;
	goto irtglCON25;
irtglCON27:
	local[3]= NIL;
irtglCON25:
	goto irtglIF24;
irtglIF23:
	local[3]= fqv[12];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,2,local+3); /*error*/
	local[3]= w;
irtglIF24:
	w = local[3];
	goto irtglWHL19;
irtglWHX20:
	local[2]= NIL;
irtglBLK21:
	w = NIL;
	local[0]= w;
	goto irtglCON16;
irtglCON18:
	local[0]= NIL;
irtglCON16:
	w = local[0];
	local[0]= w;
irtglBLK15:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO22(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[8];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = *(ovafptr(w,fqv[13]));
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*transpose-image-rows*/
static pointer irtglF4transpose_image_rows(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtglENT30;}
	local[0]= NIL;
irtglENT30:
irtglENT29:
	if (n>2) maerror();
	local[1]= argv[0];
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[16];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[17];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	if (local[0]==NIL) goto irtglCON32;
	local[4]= argv[0];
	local[5]= fqv[14];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[14];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w!=local[4]) goto irtglAND35;
	local[4]= argv[0];
	local[5]= fqv[15];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[15];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w!=local[4]) goto irtglAND35;
	local[4]= argv[0];
	local[5]= fqv[16];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[16];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w!=local[4]) goto irtglAND35;
	goto irtglIF33;
irtglAND35:
	local[4]= fqv[18];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto irtglIF34;
irtglIF33:
	local[4]= NIL;
irtglIF34:
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[3];
	local[7]= local[0];
	local[8]= fqv[17];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,4,local+4,&ftab[4],fqv[19]); /*ctranspose-image-rows*/
	local[4]= local[0];
	goto irtglCON31;
irtglCON32:
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,3,local+4,&ftab[4],fqv[19]); /*ctranspose-image-rows*/
	local[4]= argv[0];
	goto irtglCON31;
irtglCON36:
	local[4]= NIL;
irtglCON31:
	w = local[4];
	local[0]= w;
irtglBLK28:
	ctx->vsp=local; return(local[0]);}

/*draw-globjects*/
static pointer irtglF5draw_globjects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[20], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY38;
	local[0] = T;
irtglKEY38:
	if (n & (1<<1)) goto irtglKEY39;
	local[1] = T;
irtglKEY39:
	if (n & (1<<2)) goto irtglKEY40;
	local[2] = makeint((eusinteger_t)150L);
irtglKEY40:
	if (n & (1<<3)) goto irtglKEY41;
	local[3] = NIL;
irtglKEY41:
	if (n & (1<<4)) goto irtglKEY42;
	local[4] = fqv[21];
irtglKEY42:
	local[5]= NIL;
	local[6]= argv[0];
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[8];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[23]); /*resetperspective*/
	if (local[0]==NIL) goto irtglIF43;
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= fqv[24];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtglIF44;
irtglIF43:
	local[6]= NIL;
irtglIF44:
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[5] = w;
	if (local[2]==NIL) goto irtglIF45;
	w = local[2];
	if (!numberp(w)) goto irtglIF47;
	local[6]= local[2];
	goto irtglIF48;
irtglIF47:
	local[6]= makeint((eusinteger_t)150L);
irtglIF48:
	local[7]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+8;
	w=(*ftab[6])(ctx,1,local+7,&ftab[6],fqv[26]); /*gldisable*/
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,1,local+7,&ftab[7],fqv[27]); /*glbegin*/
	local[7]= fqv[28];
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,1,local+7,&ftab[8],fqv[29]); /*glcolor3fv*/
	local[7]= fqv[30];
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[7]= local[6];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,1,local+7,&ftab[8],fqv[29]); /*glcolor3fv*/
	local[7]= fqv[33];
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[7]= fqv[34];
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,1,local+7,&ftab[8],fqv[29]); /*glcolor3fv*/
	local[7]= fqv[35];
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[36]); /*glend*/
	local[7]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+8;
	w=(*ftab[11])(ctx,1,local+7,&ftab[11],fqv[37]); /*glenable*/
	local[6]= w;
	goto irtglIF46;
irtglIF45:
	local[6]= NIL;
irtglIF46:
	if (local[3]==NIL) goto irtglIF49;
	w = local[3];
	if (!numberp(w)) goto irtglIF51;
	local[6]= local[3];
	goto irtglIF52;
irtglIF51:
	local[6]= makeint((eusinteger_t)1000L);
irtglIF52:
	local[7]= makeint((eusinteger_t)5000L);
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,1,local+9,&ftab[6],fqv[26]); /*gldisable*/
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,1,local+9,&ftab[7],fqv[27]); /*glbegin*/
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(*ftab[8])(ctx,1,local+9,&ftab[8],fqv[29]); /*glcolor3fv*/
	local[9]= local[8];
irtglTAG54:
	local[10]= local[9];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)GREATERP(ctx,2,local+10); /*>*/
	if (w==NIL) goto irtglIF55;
	w = NIL;
	ctx->vsp=local+10;
	local[9]=w;
	goto irtglBLK53;
	goto irtglIF56;
irtglIF55:
	local[10]= NIL;
irtglIF56:
	local[10]= local[8];
irtglTAG58:
	local[11]= local[10];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtglIF59;
	w = NIL;
	ctx->vsp=local+11;
	local[10]=w;
	goto irtglBLK57;
	goto irtglIF60;
irtglIF59:
	local[11]= NIL;
irtglIF60:
	local[11]= local[10];
	local[12]= local[8];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,1,local+11,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[11]= local[10];
	local[12]= local[7];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,1,local+11,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[11]= local[8];
	local[12]= local[9];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,1,local+11,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[11]= local[7];
	local[12]= local[9];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,1,local+11,&ftab[9],fqv[31]); /*glvertex3fv*/
	local[11]= local[10];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[10] = local[11];
	w = NIL;
	ctx->vsp=local+11;
	goto irtglTAG58;
	w = NIL;
	local[10]= w;
irtglBLK57:
	local[10]= local[9];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[9] = local[10];
	w = NIL;
	ctx->vsp=local+10;
	goto irtglTAG54;
	w = NIL;
	local[9]= w;
irtglBLK53:
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,1,local+9,&ftab[10],fqv[36]); /*glend*/
	local[9]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,1,local+9,&ftab[11],fqv[37]); /*glenable*/
	local[6]= w;
	goto irtglIF50;
irtglIF49:
	local[6]= NIL;
irtglIF50:
	local[6]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,1,local+6,&ftab[6],fqv[26]); /*gldisable*/
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= fqv[25];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= NIL;
	local[7]= argv[1];
irtglWHL61:
	if (local[7]==NIL) goto irtglWHX62;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[38];
	ctx->vsp=local+10;
	w=(*ftab[12])(ctx,2,local+8,&ftab[12],fqv[39]); /*find-method*/
	if (w==NIL) goto irtglCON65;
	local[8]= local[6];
	local[9]= fqv[38];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtglCON64;
irtglCON65:
	local[8]= local[6];
	local[9]= loadglobal(fqv[40]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtglCON66;
	local[8]= argv[0];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)irtglF6draw_glbody(ctx,2,local+8); /*draw-glbody*/
	local[8]= w;
	goto irtglCON64;
irtglCON66:
	local[8]= local[6];
	local[9]= fqv[41];
	ctx->vsp=local+10;
	w=(*ftab[12])(ctx,2,local+8,&ftab[12],fqv[39]); /*find-method*/
	if (w==NIL) goto irtglCON67;
	local[8]= local[6];
	local[9]= fqv[41];
	local[10]= fqv[42];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	goto irtglCON64;
irtglCON67:
	local[8]= fqv[43];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[44]); /*warn*/
	local[8]= w;
	goto irtglCON64;
irtglCON68:
	local[8]= NIL;
irtglCON64:
	goto irtglWHL61;
irtglWHX62:
	local[8]= NIL;
irtglBLK63:
	w = NIL;
	if (local[1]==NIL) goto irtglIF69;
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= fqv[45];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtglIF70;
irtglIF69:
	local[6]= NIL;
irtglIF70:
	w = local[6];
	local[0]= w;
irtglBLK37:
	ctx->vsp=local; return(local[0]);}

/*draw-glbody*/
static pointer irtglF6draw_glbody(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[8];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= *(ovafptr(w,fqv[13]));
	local[1]= local[0];
	local[2]= argv[1];
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASSQ(ctx,2,local+1); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= local[0];
	local[3]= argv[1];
	local[4]= fqv[47];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ASSQ(ctx,2,local+2); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= argv[1];
	local[4]= fqv[48];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	if (local[3]!=NIL) goto irtglIF72;
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[3] = w;
	local[4]= local[3];
	goto irtglIF73;
irtglIF72:
	local[4]= NIL;
irtglIF73:
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)VECTORP(ctx,1,local+4); /*vectorp*/
	if (w!=NIL) goto irtglIF74;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)irtglF7find_color(ctx,1,local+4); /*find-color*/
	local[3] = w;
	local[4]= argv[1];
	local[5]= local[3];
	local[6]= fqv[48];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= w;
	goto irtglIF75;
irtglIF74:
	local[4]= NIL;
irtglIF75:
	if (local[1]==NIL) goto irtglCON77;
	local[4]= argv[1];
	local[5]= fqv[49];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[50];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[14])(ctx,0,local+5,&ftab[14],fqv[51]); /*glpushmatrix*/
	local[5]= local[4];
	local[6]= loadglobal(fqv[52]);
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,2,local+5); /*transpose*/
	local[5]= w->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(*ftab[15])(ctx,1,local+5,&ftab[15],fqv[53]); /*glmultmatrixf*/
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,1,local+5,&ftab[16],fqv[54]); /*glcalllist*/
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,0,local+5,&ftab[17],fqv[55]); /*glpopmatrix*/
	local[4]= w;
	goto irtglCON76;
irtglCON77:
	if (local[2]==NIL) goto irtglCON78;
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,1,local+4,&ftab[18],fqv[56]); /*glgenlists*/
	local[4]= w;
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)4864L);
	ctx->vsp=local+7;
	w=(*ftab[19])(ctx,2,local+5,&ftab[19],fqv[57]); /*glnewlist*/
	local[5]= makeint((eusinteger_t)4294967295L);
	ctx->vsp=local+6;
	w=(*ftab[20])(ctx,1,local+5,&ftab[20],fqv[58]); /*glpushattrib*/
	local[5]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,1,local+5,&ftab[21],fqv[59]); /*gldepthfunc*/
	local[5]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,1,local+5,&ftab[6],fqv[26]); /*gldisable*/
	local[5]= fqv[60];
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,1,local+5,&ftab[8],fqv[29]); /*glcolor3fv*/
	local[5]= NIL;
	local[6]= argv[1];
	local[7]= fqv[61];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
irtglWHL79:
	if (local[6]==NIL) goto irtglWHX80;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,1,local+7,&ftab[7],fqv[27]); /*glbegin*/
	local[7]= NIL;
	local[8]= local[5];
	local[9]= fqv[62];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
irtglWHL82:
	if (local[8]==NIL) goto irtglWHX83;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= argv[1];
	local[10]= fqv[63];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[9])(ctx,1,local+9,&ftab[9],fqv[31]); /*glvertex3fv*/
	goto irtglWHL82;
irtglWHX83:
	local[9]= NIL;
irtglBLK84:
	w = NIL;
	ctx->vsp=local+7;
	w=(*ftab[10])(ctx,0,local+7,&ftab[10],fqv[36]); /*glend*/
	goto irtglWHL79;
irtglWHX80:
	local[7]= NIL;
irtglBLK81:
	w = NIL;
	local[5]= makeint((eusinteger_t)32823L);
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,1,local+5,&ftab[11],fqv[37]); /*glenable*/
	local[5]= makeint((eusinteger_t)1032L);
	local[6]= makeint((eusinteger_t)6914L);
	ctx->vsp=local+7;
	w=(*ftab[22])(ctx,2,local+5,&ftab[22],fqv[64]); /*glpolygonmode*/
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(*ftab[23])(ctx,2,local+5,&ftab[23],fqv[65]); /*glpolygonoffset*/
	local[5]= fqv[66];
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,1,local+5,&ftab[8],fqv[29]); /*glcolor3fv*/
	local[5]= makeint((eusinteger_t)2884L);
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,1,local+5,&ftab[11],fqv[37]); /*glenable*/
	local[5]= makeint((eusinteger_t)1028L);
	ctx->vsp=local+6;
	w=(*ftab[24])(ctx,1,local+5,&ftab[24],fqv[67]); /*glcullface*/
	local[5]= NIL;
	local[6]= argv[1];
	local[7]= fqv[61];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
irtglWHL85:
	if (local[6]==NIL) goto irtglWHX86;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= makeint((eusinteger_t)9L);
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,1,local+7,&ftab[7],fqv[27]); /*glbegin*/
	local[7]= argv[1];
	local[8]= fqv[68];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= local[5];
	local[9]= fqv[69];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRANSFORM(ctx,2,local+7); /*transform*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[25])(ctx,1,local+7,&ftab[25],fqv[70]); /*glnormal3fv*/
	local[7]= NIL;
	local[8]= local[5];
	local[9]= fqv[71];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
irtglWHL88:
	if (local[8]==NIL) goto irtglWHX89;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= argv[1];
	local[10]= fqv[63];
	local[11]= local[7];
	local[12]= fqv[72];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[9])(ctx,1,local+9,&ftab[9],fqv[31]); /*glvertex3fv*/
	goto irtglWHL88;
irtglWHX89:
	local[9]= NIL;
irtglBLK90:
	w = NIL;
	ctx->vsp=local+7;
	w=(*ftab[10])(ctx,0,local+7,&ftab[10],fqv[36]); /*glend*/
	goto irtglWHL85;
irtglWHX86:
	local[7]= NIL;
irtglBLK87:
	w = NIL;
	local[5]= makeint((eusinteger_t)2884L);
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,1,local+5,&ftab[6],fqv[26]); /*gldisable*/
	local[5]= makeint((eusinteger_t)32823L);
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,1,local+5,&ftab[6],fqv[26]); /*gldisable*/
	local[5]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,1,local+5,&ftab[11],fqv[37]); /*glenable*/
	ctx->vsp=local+5;
	w=(*ftab[26])(ctx,0,local+5,&ftab[26],fqv[73]); /*glpopattrib*/
	ctx->vsp=local+5;
	w=(*ftab[27])(ctx,0,local+5,&ftab[27],fqv[74]); /*glendlist*/
	local[5]= argv[1];
	local[6]= local[0];
	w = local[4];
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= argv[1];
	local[8]= fqv[46];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[46];
	ctx->vsp=local+8;
	w=(pointer)PUTPROP(ctx,3,local+5); /*putprop*/
	local[5]= argv[0];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)irtglF6draw_glbody(ctx,2,local+5); /*draw-glbody*/
	local[4]= w;
	goto irtglCON76;
irtglCON78:
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,1,local+4,&ftab[18],fqv[56]); /*glgenlists*/
	local[4]= w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	local[5]= w;
	if (w==NIL) goto irtglAND92;
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	local[5]= w;
irtglAND92:
	local[6]= argv[1];
	local[7]= fqv[75];
	ctx->vsp=local+8;
	w=(pointer)GETPROP(ctx,2,local+6); /*get*/
	if (w==NIL) goto irtglIF93;
	local[6]= loadglobal(fqv[76]);
	local[7]= argv[1];
	local[8]= fqv[75];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[6]= w;
	goto irtglIF94;
irtglIF93:
	local[6]= NIL;
irtglIF94:
	local[7]= NIL;
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)4864L);
	ctx->vsp=local+10;
	w=(*ftab[19])(ctx,2,local+8,&ftab[19],fqv[57]); /*glnewlist*/
	if (local[5]==NIL) goto irtglIF95;
	local[8]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+9;
	w=(*ftab[11])(ctx,1,local+8,&ftab[11],fqv[37]); /*glenable*/
	local[8]= makeint((eusinteger_t)770L);
	local[9]= makeint((eusinteger_t)771L);
	ctx->vsp=local+10;
	w=(*ftab[28])(ctx,2,local+8,&ftab[28],fqv[77]); /*glblendfunc*/
	local[8]= w;
	goto irtglIF96;
irtglIF95:
	local[8]= NIL;
irtglIF96:
	local[8]= makeint((eusinteger_t)1032L);
	local[9]= makeint((eusinteger_t)5634L);
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[29])(ctx,3,local+8,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[8] <= (eusinteger_t)w) goto irtglIF97;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[30])(ctx,2,local+8,&ftab[30],fqv[79]); /*glgentexturesext*/
	local[8]= w;
	goto irtglIF98;
irtglIF97:
	local[8]= NIL;
irtglIF98:
	local[8]= NIL;
	local[9]= argv[1];
	local[10]= fqv[61];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
irtglWHL99:
	if (local[9]==NIL) goto irtglWHX100;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= fqv[80];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (w==NIL) goto irtglCON103;
	local[10]= local[8];
	local[11]= fqv[81];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (w!=NIL) goto irtglCON103;
	local[10]= local[8];
	local[11]= fqv[75];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= local[8];
	local[12]= fqv[82];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	local[12]= local[10];
	local[13]= loadglobal(fqv[83]);
	ctx->vsp=local+14;
	w=(pointer)DERIVEDP(ctx,2,local+12); /*derivedp*/
	if (w==NIL) goto irtglCON105;
	local[12]= makeint((eusinteger_t)6407L);
	goto irtglCON104;
irtglCON105:
	local[12]= local[10];
	local[13]= loadglobal(fqv[84]);
	ctx->vsp=local+14;
	w=(pointer)DERIVEDP(ctx,2,local+12); /*derivedp*/
	if (w==NIL) goto irtglCON106;
	local[12]= makeint((eusinteger_t)6409L);
	goto irtglCON104;
irtglCON106:
	local[12]= NIL;
irtglCON104:
	if (local[10]==NIL) goto irtglIF107;
	local[13]= local[10];
	local[14]= fqv[85];
	ctx->vsp=local+15;
	w=(pointer)GETPROP(ctx,2,local+13); /*get*/
	if (w!=NIL) goto irtglIF109;
	local[13]= local[6];
	local[14]= local[10];
	local[15]= argv[1];
	local[16]= fqv[75];
	ctx->vsp=local+17;
	w=(pointer)GETPROP(ctx,2,local+15); /*get*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[31])(ctx,2,local+14,&ftab[31],fqv[86]); /*position*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[10];
	local[15]= fqv[15];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= local[10];
	local[16]= fqv[14];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= local[10];
	local[17]= fqv[87];
	ctx->vsp=local+18;
	w=(pointer)GETPROP(ctx,2,local+16); /*get*/
	local[16]= w;
	if (w!=NIL) goto irtglOR111;
	local[16]= makeint((eusinteger_t)256L);
irtglOR111:
	local[17]= local[10];
	local[18]= fqv[88];
	ctx->vsp=local+19;
	w=(pointer)GETPROP(ctx,2,local+17); /*get*/
	local[17]= w;
	if (w!=NIL) goto irtglOR112;
	local[17]= makeint((eusinteger_t)256L);
irtglOR112:
	local[18]= makeint((eusinteger_t)1L);
	local[19]= local[14];
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)LOG(ctx,2,local+19); /*log*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)CEILING(ctx,1,local+19); /*ceiling*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ASH(ctx,2,local+18); /*ash*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)1L);
	local[20]= local[15];
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)LOG(ctx,2,local+20); /*log*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)CEILING(ctx,1,local+20); /*ceiling*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ASH(ctx,2,local+19); /*ash*/
	local[19]= w;
	local[20]= local[10];
	local[21]= local[14];
	local[22]= local[18];
	ctx->vsp=local+23;
	w=(pointer)NUMEQUAL(ctx,2,local+21); /*=*/
	if (w==NIL) goto irtglAND115;
	local[21]= local[15];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(pointer)NUMEQUAL(ctx,2,local+21); /*=*/
	if (w==NIL) goto irtglAND115;
	goto irtglIF113;
irtglAND115:
	local[21]= NIL;
	local[22]= NIL;
	local[23]= local[20];
	local[24]= fqv[89];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,2,local+23); /*send*/
	local[23]= w;
	local[24]= NIL;
	local[25]= local[12];
	local[26]= makeint((eusinteger_t)6407L);
	ctx->vsp=local+27;
	w=(pointer)NUMEQUAL(ctx,2,local+25); /*=*/
	if (w==NIL) goto irtglCON117;
	local[25]= local[20];
	local[26]= fqv[90];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)8L);
	ctx->vsp=local+27;
	w=(pointer)QUOTIENT(ctx,2,local+25); /*/*/
	local[22] = w;
	local[25]= local[22];
	local[26]= makeint((eusinteger_t)3L);
	ctx->vsp=local+27;
	w=(pointer)NUMEQUAL(ctx,2,local+25); /*=*/
	if (w!=NIL) goto irtglIF118;
	local[25]= fqv[91];
	ctx->vsp=local+26;
	w=(pointer)SIGERROR(ctx,1,local+25); /*error*/
	local[25]= w;
	goto irtglIF119;
irtglIF118:
	local[25]= NIL;
irtglIF119:
	goto irtglCON116;
irtglCON117:
	local[25]= local[12];
	local[26]= makeint((eusinteger_t)6409L);
	ctx->vsp=local+27;
	w=(pointer)NUMEQUAL(ctx,2,local+25); /*=*/
	if (w==NIL) goto irtglCON120;
	local[22] = makeint((eusinteger_t)1L);
	local[25]= local[22];
	goto irtglCON116;
irtglCON120:
	local[25]= fqv[92];
	local[26]= local[12];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)SIGERROR(ctx,3,local+25); /*error*/
	local[25]= w;
	goto irtglCON116;
irtglCON121:
	local[25]= NIL;
irtglCON116:
	local[25]= local[18];
	local[26]= local[19];
	ctx->vsp=local+27;
	w=(pointer)TIMES(ctx,2,local+25); /***/
	local[25]= w;
	local[26]= local[16];
	local[27]= local[17];
	ctx->vsp=local+28;
	w=(pointer)TIMES(ctx,2,local+26); /***/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)QUOTIENT(ctx,2,local+25); /*/*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)SQRT(ctx,1,local+25); /*sqrt*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ROUND(ctx,1,local+25); /*round*/
	local[24] = w;
	local[25]= local[24];
	w = makeint((eusinteger_t)1L);
	if ((eusinteger_t)local[25] <= (eusinteger_t)w) goto irtglIF122;
	local[25]= makeint((eusinteger_t)1L);
	local[26]= local[18];
	local[27]= local[24];
	ctx->vsp=local+28;
	w=(pointer)QUOTIENT(ctx,2,local+26); /*/*/
	local[26]= w;
	local[27]= makeint((eusinteger_t)2L);
	ctx->vsp=local+28;
	w=(pointer)LOG(ctx,2,local+26); /*log*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)CEILING(ctx,1,local+26); /*ceiling*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)ASH(ctx,2,local+25); /*ash*/
	local[18] = w;
	local[25]= makeint((eusinteger_t)1L);
	local[26]= local[19];
	local[27]= local[24];
	ctx->vsp=local+28;
	w=(pointer)QUOTIENT(ctx,2,local+26); /*/*/
	local[26]= w;
	local[27]= makeint((eusinteger_t)2L);
	ctx->vsp=local+28;
	w=(pointer)LOG(ctx,2,local+26); /*log*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)CEILING(ctx,1,local+26); /*ceiling*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)ASH(ctx,2,local+25); /*ash*/
	local[19] = w;
	local[25]= local[19];
	goto irtglIF123;
irtglIF122:
	local[25]= NIL;
irtglIF123:
	local[25]= local[18];
	local[26]= local[19];
	local[27]= local[22];
	ctx->vsp=local+28;
	w=(pointer)TIMES(ctx,3,local+25); /***/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[32])(ctx,1,local+25,&ftab[32],fqv[93]); /*make-string*/
	local[21] = w;
	local[25]= local[12];
	local[26]= local[14];
	local[27]= local[15];
	local[28]= makeint((eusinteger_t)5121L);
	local[29]= local[20];
	local[30]= fqv[17];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,2,local+29); /*send*/
	local[29]= w;
	local[30]= local[18];
	local[31]= local[19];
	local[32]= makeint((eusinteger_t)5121L);
	local[33]= local[21];
	ctx->vsp=local+34;
	w=(*ftab[33])(ctx,9,local+25,&ftab[33],fqv[94]); /*gluscaleimage*/
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)GETCLASS(ctx,1,local+25); /*class*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)INSTANTIATE(ctx,1,local+25); /*instantiate*/
	local[25]= w;
	local[26]= local[25];
	local[27]= fqv[95];
	local[28]= local[18];
	local[29]= local[19];
	local[30]= local[21];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,5,local+26); /*send*/
	w = local[25];
	local[20] = w;
	local[25]= local[20];
	local[26]= fqv[89];
	local[27]= local[23];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[21]= w;
	goto irtglIF114;
irtglIF113:
	local[21]= NIL;
irtglIF114:
	local[21]= makeint((eusinteger_t)3553L);
	local[22]= local[13];
	ctx->vsp=local+23;
	w=(*ftab[34])(ctx,2,local+21,&ftab[34],fqv[96]); /*glbindtextureext*/
	local[21]= makeint((eusinteger_t)3553L);
	local[22]= makeint((eusinteger_t)0L);
	local[23]= makeint((eusinteger_t)6407L);
	local[24]= local[20];
	local[25]= fqv[15];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[24]= w;
	local[25]= local[20];
	local[26]= fqv[14];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)0L);
	local[27]= local[12];
	local[28]= makeint((eusinteger_t)5121L);
	local[29]= local[20];
	local[30]= fqv[17];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,2,local+29); /*send*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(*ftab[35])(ctx,9,local+21,&ftab[35],fqv[97]); /*glteximage2d*/
	local[21]= local[10];
	local[22]= local[13];
	local[23]= fqv[85];
	ctx->vsp=local+24;
	w=(pointer)PUTPROP(ctx,3,local+21); /*putprop*/
	local[13]= w;
	goto irtglIF110;
irtglIF109:
	local[13]= NIL;
irtglIF110:
	local[13]= makeint((eusinteger_t)3317L);
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(*ftab[36])(ctx,2,local+13,&ftab[36],fqv[98]); /*glpixelstorei*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)10242L);
	local[15]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+16;
	w=(*ftab[37])(ctx,3,local+13,&ftab[37],fqv[99]); /*gltexparameteri*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)10243L);
	local[15]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+16;
	w=(*ftab[37])(ctx,3,local+13,&ftab[37],fqv[99]); /*gltexparameteri*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)10241L);
	local[15]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+16;
	w=(*ftab[37])(ctx,3,local+13,&ftab[37],fqv[99]); /*gltexparameteri*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)10240L);
	local[15]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+16;
	w=(*ftab[37])(ctx,3,local+13,&ftab[37],fqv[99]); /*gltexparameteri*/
	local[13]= makeint((eusinteger_t)8960L);
	local[14]= makeint((eusinteger_t)8704L);
	local[15]= makeint((eusinteger_t)8449L);
	ctx->vsp=local+16;
	w=(*ftab[38])(ctx,3,local+13,&ftab[38],fqv[100]); /*gltexenvi*/
	local[13]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+14;
	w=(*ftab[11])(ctx,1,local+13,&ftab[11],fqv[37]); /*glenable*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= local[10];
	local[15]= fqv[85];
	ctx->vsp=local+16;
	w=(pointer)GETPROP(ctx,2,local+14); /*get*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,2,local+13,&ftab[34],fqv[96]); /*glbindtextureext*/
	local[13]= w;
	goto irtglIF108;
irtglIF107:
	local[13]= NIL;
irtglIF108:
	local[13]= makeint((eusinteger_t)9L);
	ctx->vsp=local+14;
	w=(*ftab[7])(ctx,1,local+13,&ftab[7],fqv[27]); /*glbegin*/
	local[13]= argv[1];
	local[14]= fqv[68];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TRANSPOSE(ctx,1,local+13); /*transpose*/
	local[13]= w;
	local[14]= local[8];
	local[15]= fqv[69];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TRANSFORM(ctx,2,local+13); /*transform*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[25])(ctx,1,local+13,&ftab[25],fqv[70]); /*glnormal3fv*/
	local[13]= NIL;
	local[14]= local[8];
	local[15]= fqv[71];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
irtglWHL124:
	if (local[14]==NIL) goto irtglWHX125;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14] = (w)->c.cons.cdr;
	w = local[15];
	local[13] = w;
	if (local[11]==NIL) goto irtglIF127;
	local[15]= local[13];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(*ftab[39])(ctx,2,local+15,&ftab[39],fqv[101]); /*gethash*/
	local[7] = w;
	if (local[7]==NIL) goto irtglIF127;
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(*ftab[40])(ctx,1,local+15,&ftab[40],fqv[102]); /*gltexcoord2fv*/
	local[15]= w;
	goto irtglIF128;
irtglIF127:
	local[15]= NIL;
irtglIF128:
	local[15]= argv[1];
	local[16]= fqv[63];
	local[17]= local[13];
	local[18]= fqv[72];
	local[19]= local[8];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,3,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[9])(ctx,1,local+15,&ftab[9],fqv[31]); /*glvertex3fv*/
	goto irtglWHL124;
irtglWHX125:
	local[15]= NIL;
irtglBLK126:
	w = NIL;
	ctx->vsp=local+13;
	w=(*ftab[10])(ctx,0,local+13,&ftab[10],fqv[36]); /*glend*/
	if (local[10]==NIL) goto irtglIF129;
	local[13]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+14;
	w=(*ftab[6])(ctx,1,local+13,&ftab[6],fqv[26]); /*gldisable*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,2,local+13,&ftab[34],fqv[96]); /*glbindtextureext*/
	local[13]= w;
	goto irtglIF130;
irtglIF129:
	local[13]= NIL;
irtglIF130:
	w = local[13];
	local[10]= w;
	goto irtglCON102;
irtglCON103:
	local[10]= local[8];
	local[11]= fqv[81];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= NIL;
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,irtglCLO132,env,argv,local);
	local[13]= local[8];
	local[14]= fqv[62];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[11] = w;
	local[12]= loadglobal(fqv[103]);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[41])(ctx,2,local+12,&ftab[41],fqv[104]); /*glutessbeginpolygon*/
	local[12]= loadglobal(fqv[103]);
	ctx->vsp=local+13;
	w=(*ftab[42])(ctx,1,local+12,&ftab[42],fqv[105]); /*glutessbegincontour*/
	local[12]= local[8];
	local[13]= fqv[69];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[25])(ctx,1,local+12,&ftab[25],fqv[70]); /*glnormal3fv*/
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,irtglCLO133,env,argv,local);
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)MAPC(ctx,2,local+12); /*mapc*/
	local[12]= loadglobal(fqv[103]);
	ctx->vsp=local+13;
	w=(*ftab[43])(ctx,1,local+12,&ftab[43],fqv[106]); /*glutessendcontour*/
	local[12]= loadglobal(fqv[103]);
	ctx->vsp=local+13;
	w=(*ftab[42])(ctx,1,local+12,&ftab[42],fqv[105]); /*glutessbegincontour*/
	if (local[10]==NIL) goto irtglIF134;
	local[12]= NIL;
	local[13]= local[10];
	w = local[12];
	ctx->vsp=local+14;
	bindspecial(ctx,fqv[107],w);
irtglWHL136:
	if (local[13]==NIL) goto irtglWHX137;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[17];
	local[17]= w;
	storeglobal(fqv[107],w);
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtglCLO139,env,argv,local);
	local[18]= loadglobal(fqv[107]);
	local[19]= fqv[62];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	local[17]= w;
	local[18]= loadglobal(fqv[103]);
	local[19]= makeint((eusinteger_t)100122L);
	ctx->vsp=local+20;
	w=(*ftab[44])(ctx,2,local+18,&ftab[44],fqv[108]); /*glunextcontour*/
	ctx->vsp=local+18;
	local[18]= makeclosure(codevec,quotevec,irtglCLO140,env,argv,local);
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)MAPC(ctx,2,local+18); /*mapc*/
	local[18]= local[11];
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)NCONC(ctx,2,local+18); /*nconc*/
	goto irtglWHL136;
irtglWHX137:
	local[17]= NIL;
irtglBLK138:
	local[17]= NIL;
	ctx->vsp=local+18;
	unbindx(ctx,1);
	w = local[17];
	local[12]= w;
	goto irtglIF135;
irtglIF134:
	local[12]= NIL;
irtglIF135:
	local[12]= loadglobal(fqv[103]);
	ctx->vsp=local+13;
	w=(*ftab[43])(ctx,1,local+12,&ftab[43],fqv[106]); /*glutessendcontour*/
	local[12]= loadglobal(fqv[103]);
	ctx->vsp=local+13;
	w=(*ftab[45])(ctx,1,local+12,&ftab[45],fqv[109]); /*glutessendpolygon*/
	local[12]= (pointer)get_sym_func(fqv[110]);
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)MAPC(ctx,2,local+12); /*mapc*/
	local[10]= w;
	goto irtglCON102;
irtglCON131:
	local[10]= NIL;
irtglCON102:
	goto irtglWHL99;
irtglWHX100:
	local[10]= NIL;
irtglBLK101:
	w = NIL;
	if (local[5]==NIL) goto irtglIF141;
	local[8]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,1,local+8,&ftab[6],fqv[26]); /*gldisable*/
	local[8]= w;
	goto irtglIF142;
irtglIF141:
	local[8]= NIL;
irtglIF142:
	ctx->vsp=local+8;
	w=(*ftab[27])(ctx,0,local+8,&ftab[27],fqv[74]); /*glendlist*/
	local[8]= argv[1];
	local[9]= local[0];
	w = local[4];
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= argv[1];
	local[11]= fqv[46];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[46];
	ctx->vsp=local+11;
	w=(pointer)PUTPROP(ctx,3,local+8); /*putprop*/
	local[8]= argv[0];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)irtglF6draw_glbody(ctx,2,local+8); /*draw-glbody*/
	local[4]= w;
	goto irtglCON76;
irtglCON91:
	local[4]= NIL;
irtglCON76:
	w = local[4];
	local[0]= w;
irtglBLK71:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO132(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[1];
	local[1]= fqv[63];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[0] = w;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(*ftab[46])(ctx,5,local+0,&ftab[46],fqv[111]); /*alloctessinfo*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO133(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[103]);
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[47])(ctx,3,local+0,&ftab[47],fqv[112]); /*glutessvertex*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO139(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[1];
	local[1]= fqv[63];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[0] = w;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(*ftab[46])(ctx,5,local+0,&ftab[46],fqv[111]); /*alloctessinfo*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO140(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[103]);
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[47])(ctx,3,local+0,&ftab[47],fqv[112]); /*glutessvertex*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-color*/
static pointer irtglF7find_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	if (argv[0]!=NIL) goto irtglCON145;
	local[2]= NIL;
	goto irtglCON144;
irtglCON145:
	local[2]= argv[0];
	local[3]= loadglobal(fqv[113]);
	ctx->vsp=local+4;
	w=(pointer)DERIVEDP(ctx,2,local+2); /*derivedp*/
	if (w==NIL) goto irtglCON146;
	local[2]= argv[0];
	local[3]= fqv[114];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto irtglCON144;
irtglCON146:
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)VECTORP(ctx,1,local+2); /*vectorp*/
	if (w==NIL) goto irtglCON147;
	local[2]= argv[0];
	goto irtglCON144;
irtglCON147:
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LISTP(ctx,1,local+2); /*listp*/
	if (w==NIL) goto irtglCON148;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	goto irtglCON144;
irtglCON148:
	w = argv[0];
	if (!issymbol(w)) goto irtglCON149;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtglCLO150,env,argv,local);
	local[3]= loadglobal(fqv[115]);
	ctx->vsp=local+4;
	w=(*ftab[48])(ctx,2,local+2,&ftab[48],fqv[116]); /*find-if*/
	local[1] = w;
	if (local[1]==NIL) goto irtglIF151;
	local[2]= local[1];
	local[3]= fqv[114];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto irtglIF152;
irtglIF151:
	local[2]= fqv[117];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,2,local+2,&ftab[13],fqv[44]); /*warn*/
	local[2]= w;
irtglIF152:
	goto irtglCON144;
irtglCON149:
	local[2]= argv[0];
	goto irtglCON144;
irtglCON153:
	local[2]= NIL;
irtglCON144:
	local[0] = local[2];
	if (local[0]!=NIL) goto irtglIF154;
	local[2]= makeflt(5.0000000000000000000000e-01);
	local[3]= makeflt(5.0000000000000000000000e-01);
	local[4]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[0] = w;
	local[2]= local[0];
	goto irtglIF155;
irtglIF154:
	local[2]= NIL;
irtglIF155:
	w = local[0];
	local[0]= w;
irtglBLK143:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO150(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	w = ((env->c.clo.env1[0])==(local[0])?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*transparent*/
static pointer irtglF8transparent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[48];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[0] = w;
	if (local[0]==NIL) goto irtglIF157;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)VECTORP(ctx,1,local+2); /*vectorp*/
	if (w!=NIL) goto irtglIF159;
	local[2]= fqv[118];
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,4,local+2,&ftab[13],fqv[44]); /*warn*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)irtglF7find_color(ctx,1,local+2); /*find-color*/
	local[0] = w;
	local[2]= local[0];
	goto irtglIF160;
irtglIF159:
	local[2]= NIL;
irtglIF160:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	if (makeint((eusinteger_t)3L)!=local[2]) goto irtglIF161;
	local[2]= loadglobal(fqv[119]);
	local[3]= local[0];
	local[4]= fqv[120];
	ctx->vsp=local+5;
	w=(pointer)CONCATENATE(ctx,3,local+2); /*concatenate*/
	local[0] = w;
	local[2]= local[0];
	goto irtglIF162;
irtglIF161:
	local[2]= NIL;
irtglIF162:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)3L);
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= fqv[48];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	local[2]= argv[0];
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtglF3delete_displaylist_id(ctx,1,local+2); /*delete-displaylist-id*/
	local[2]= argv[0];
	local[3]= NIL;
	local[4]= fqv[46];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	local[2]= local[0];
	goto irtglIF158;
irtglIF157:
	local[2]= NIL;
irtglIF158:
	w = local[2];
	local[0]= w;
irtglBLK156:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM163polygon_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[121], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY165;
	local[0] = loadglobal(fqv[122]);
irtglKEY165:
	if (n & (1<<1)) goto irtglKEY166;
	local[1] = NIL;
irtglKEY166:
	if (n & (1<<2)) goto irtglKEY167;
	local[2] = makeint((eusinteger_t)1L);
irtglKEY167:
	if (n & (1<<3)) goto irtglKEY168;
	local[3] = fqv[123];
irtglKEY168:
	if (local[1]==NIL) goto irtglIF169;
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[9];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtglIF170;
irtglIF169:
	local[4]= NIL;
irtglIF170:
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[124];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[124];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[25];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[125];
	local[10]= argv[0];
	local[11]= fqv[62];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[124];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[25];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	if (local[1]==NIL) goto irtglIF171;
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[45];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtglIF172;
irtglIF171:
	local[7]= NIL;
irtglIF172:
	w = local[7];
	local[0]= w;
irtglBLK164:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM173line_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[126], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY175;
	local[0] = loadglobal(fqv[122]);
irtglKEY175:
	if (n & (1<<1)) goto irtglKEY176;
	local[1] = NIL;
irtglKEY176:
	if (n & (1<<2)) goto irtglKEY177;
	local[2] = makeint((eusinteger_t)1L);
irtglKEY177:
	if (n & (1<<3)) goto irtglKEY178;
	local[3] = fqv[127];
irtglKEY178:
	if (local[1]==NIL) goto irtglIF179;
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[9];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtglIF180;
irtglIF179:
	local[4]= NIL;
irtglIF180:
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[124];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[124];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[25];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[128];
	local[10]= argv[0]->c.obj.iv[1];
	local[11]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[124];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[25];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	if (local[1]==NIL) goto irtglIF181;
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[45];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtglIF182;
irtglIF181:
	local[7]= NIL;
irtglIF182:
	w = local[7];
	local[0]= w;
irtglBLK174:
	ctx->vsp=local; return(local[0]);}

/*:set-color*/
static pointer irtglM183faceset_set_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtglENT186;}
	local[0]= NIL;
irtglENT186:
irtglENT185:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[46];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtglF3delete_displaylist_id(ctx,1,local+1); /*delete-displaylist-id*/
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	if (local[0]==NIL) goto irtglCON188;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)irtglF7find_color(ctx,1,local+1); /*find-color*/
	local[1]= w;
	local[2]= loadglobal(fqv[119]);
	local[3]= local[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,1,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)CONCATENATE(ctx,3,local+2); /*concatenate*/
	local[1] = w;
	local[2]= argv[0];
	local[3]= local[1];
	local[4]= fqv[48];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	local[1]= w;
	goto irtglCON187;
irtglCON188:
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)irtglF7find_color(ctx,1,local+2); /*find-color*/
	local[2]= w;
	local[3]= fqv[48];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto irtglCON187;
irtglCON189:
	local[1]= NIL;
irtglCON187:
	w = local[1];
	local[0]= w;
irtglBLK184:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM190faceset_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[129], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY192;
	local[0] = loadglobal(fqv[122]);
irtglKEY192:
	if (n & (1<<1)) goto irtglKEY193;
	local[1] = NIL;
irtglKEY193:
	if (n & (1<<2)) goto irtglKEY194;
	local[2] = makeint((eusinteger_t)1L);
irtglKEY194:
	if (n & (1<<3)) goto irtglKEY195;
	local[3] = fqv[130];
irtglKEY195:
	if (local[1]==NIL) goto irtglIF196;
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[9];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtglIF197;
irtglIF196:
	local[4]= NIL;
irtglIF197:
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[124];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[124];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[25];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= NIL;
	local[7]= argv[0];
	local[8]= fqv[61];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
irtglWHL198:
	if (local[7]==NIL) goto irtglWHX199;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[125];
	local[11]= local[6];
	local[12]= fqv[62];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	goto irtglWHL198;
irtglWHX199:
	local[8]= NIL;
irtglBLK200:
	w = NIL;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[124];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[25];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	if (local[1]==NIL) goto irtglIF201;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[45];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtglIF202;
irtglIF201:
	local[6]= NIL;
irtglIF202:
	w = local[6];
	local[0]= w;
irtglBLK191:
	ctx->vsp=local; return(local[0]);}

/*:paste-texture-to-face*/
static pointer irtglM203faceset_paste_texture_to_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[131], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtglKEY205;
	local[0] = NIL;
irtglKEY205:
	if (n & (1<<1)) goto irtglKEY206;
	local[1] = NIL;
irtglKEY206:
	if (n & (1<<2)) goto irtglKEY207;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,2,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,2,local+4); /*float-vector*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,2,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,4,local+3); /*list*/
	local[2] = w;
irtglKEY207:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	if (local[1]==NIL) goto irtglCON209;
	local[3] = local[1];
	local[9]= local[3];
	goto irtglCON208;
irtglCON209:
	local[9]= local[0];
	local[10]= argv[0];
	local[11]= fqv[75];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= fqv[89];
	ctx->vsp=local+12;
	w=(*ftab[49])(ctx,2,local+10,&ftab[49],fqv[132]); /*send-all*/
	local[10]= w;
	local[11]= fqv[133];
	local[12]= (pointer)get_sym_func(fqv[134]);
	ctx->vsp=local+13;
	w=(*ftab[50])(ctx,4,local+9,&ftab[50],fqv[135]); /*member*/
	if (w==NIL) goto irtglCON210;
	local[9]= local[0];
	local[10]= argv[0];
	local[11]= fqv[75];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= fqv[133];
	local[12]= (pointer)get_sym_func(fqv[134]);
	local[13]= fqv[6];
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,irtglCLO211,env,argv,local);
	ctx->vsp=local+15;
	w=(*ftab[50])(ctx,6,local+9,&ftab[50],fqv[135]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[9]= local[3];
	goto irtglCON208;
irtglCON210:
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[51])(ctx,1,local+9,&ftab[51],fqv[136]); /*probe-file*/
	if (w==NIL) goto irtglCON212;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[52])(ctx,1,local+9,&ftab[52],fqv[137]); /*user::read-image-file*/
	local[3] = w;
	local[9]= local[3];
	goto irtglCON208;
irtglCON212:
	local[9]= NIL;
	local[10]= fqv[138];
	local[11]= loadglobal(fqv[139]);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[51])(ctx,1,local+9,&ftab[51],fqv[136]); /*probe-file*/
	if (w==NIL) goto irtglCON213;
	local[9]= NIL;
	local[10]= fqv[140];
	local[11]= loadglobal(fqv[139]);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[52])(ctx,1,local+9,&ftab[52],fqv[137]); /*user::read-image-file*/
	local[3] = w;
	local[9]= local[3];
	goto irtglCON208;
irtglCON213:
	local[9]= NIL;
	local[10]= fqv[141];
	local[11]= loadglobal(fqv[139]);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[51])(ctx,1,local+9,&ftab[51],fqv[136]); /*probe-file*/
	if (w==NIL) goto irtglCON214;
	local[9]= NIL;
	local[10]= fqv[142];
	local[11]= loadglobal(fqv[139]);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[52])(ctx,1,local+9,&ftab[52],fqv[137]); /*user::read-image-file*/
	local[3] = w;
	local[9]= local[3];
	goto irtglCON208;
irtglCON214:
	local[9]= fqv[143];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(*ftab[13])(ctx,2,local+9,&ftab[13],fqv[44]); /*warn*/
	w = NIL;
	ctx->vsp=local+9;
	local[0]=w;
	goto irtglBLK204;
	goto irtglCON208;
irtglCON215:
	local[9]= NIL;
irtglCON208:
	local[9]= argv[2];
	local[10]= local[3];
	local[11]= fqv[75];
	ctx->vsp=local+12;
	w=(pointer)PUTPROP(ctx,3,local+9); /*putprop*/
	local[9]= local[3];
	local[10]= argv[0];
	local[11]= fqv[75];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	if (memq(local[9],w)!=NIL) goto irtglIF216;
	local[9]= argv[0];
	local[10]= argv[0];
	local[11]= fqv[75];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)APPEND(ctx,2,local+10); /*append*/
	local[10]= w;
	local[11]= fqv[75];
	ctx->vsp=local+12;
	w=(pointer)PUTPROP(ctx,3,local+9); /*putprop*/
	local[9]= w;
	goto irtglIF217;
irtglIF216:
	local[9]= NIL;
irtglIF217:
	local[9]= argv[2];
	local[10]= fqv[133];
	local[11]= (pointer)get_sym_func(fqv[134]);
	ctx->vsp=local+12;
	w=(*ftab[53])(ctx,2,local+10,&ftab[53],fqv[144]); /*make-hash-table*/
	local[10]= w;
	local[11]= fqv[82];
	ctx->vsp=local+12;
	w=(pointer)PUTPROP(ctx,3,local+9); /*putprop*/
	local[9]= argv[0];
	local[10]= fqv[46];
	ctx->vsp=local+11;
	w=(pointer)GETPROP(ctx,2,local+9); /*get*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)irtglF3delete_displaylist_id(ctx,1,local+9); /*delete-displaylist-id*/
	local[9]= argv[0];
	local[10]= NIL;
	local[11]= fqv[46];
	ctx->vsp=local+12;
	w=(pointer)PUTPROP(ctx,3,local+9); /*putprop*/
	local[9]= NIL;
	local[10]= argv[2];
	local[11]= fqv[71];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
irtglWHL218:
	if (local[10]==NIL) goto irtglWHX219;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[9];
	local[12]= argv[2];
	local[13]= fqv[82];
	ctx->vsp=local+14;
	w=(pointer)GETPROP(ctx,2,local+12); /*get*/
	local[12]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[13];
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[54])(ctx,3,local+11,&ftab[54],fqv[145]); /*sethash*/
	goto irtglWHL218;
irtglWHX219:
	local[11]= NIL;
irtglBLK220:
	w = NIL;
	local[0]= w;
irtglBLK204:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO211(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer irtglM221coordinates_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[146];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
irtglBLK222:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM223coordinates_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[147], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY225;
	local[0] = loadglobal(fqv[122]);
irtglKEY225:
	if (n & (1<<1)) goto irtglKEY226;
	local[1] = NIL;
irtglKEY226:
	if (n & (1<<2)) goto irtglKEY227;
	local[5]= argv[0];
	local[6]= fqv[15];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[2] = w;
irtglKEY227:
	if (n & (1<<3)) goto irtglKEY228;
	local[5]= argv[0];
	local[6]= fqv[25];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[3] = w;
irtglKEY228:
	if (n & (1<<4)) goto irtglKEY229;
	local[5]= argv[0];
	local[6]= fqv[148];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[4] = w;
irtglKEY229:
	if (local[1]==NIL) goto irtglIF230;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[9];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto irtglIF231;
irtglIF230:
	local[5]= NIL;
irtglIF231:
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[124];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	local[8]= NIL;
	if (local[2]!=NIL) goto irtglIF232;
	local[2] = makeint((eusinteger_t)1L);
	local[9]= local[2];
	goto irtglIF233;
irtglIF232:
	local[9]= NIL;
irtglIF233:
	if (local[3]!=NIL) goto irtglIF234;
	local[3] = fqv[149];
	local[9]= local[3];
	goto irtglIF235;
irtglIF234:
	local[9]= NIL;
irtglIF235:
	if (local[4]!=NIL) goto irtglIF236;
	local[4] = makeint((eusinteger_t)50L);
	local[9]= local[4];
	goto irtglIF237;
irtglIF236:
	local[9]= NIL;
irtglIF237:
	local[9]= makeflt(2.9999999999999982236432e-01);
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeflt(6.9999999999999973354647e-01);
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[8] = w;
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[124];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[25];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)3L);
irtglWHL238:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtglWHX239;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[0];
	local[12]= fqv[8];
	local[13]= fqv[128];
	local[14]= argv[0];
	local[15]= fqv[146];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= argv[0];
	local[16]= fqv[150];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,5,local+11); /*send*/
	local[11]= local[7];
	local[12]= local[9];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtglWHL238;
irtglWHX239:
	local[11]= NIL;
irtglBLK240:
	w = NIL;
	local[9]= local[7];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[128];
	local[12]= argv[0];
	local[13]= fqv[150];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[150];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= local[8];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= local[8];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[8];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[128];
	local[12]= argv[0];
	local[13]= fqv[150];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[150];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[124];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[25];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	if (local[1]==NIL) goto irtglIF241;
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[45];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	goto irtglIF242;
irtglIF241:
	local[9]= NIL;
irtglIF242:
	w = local[9];
	local[0]= w;
irtglBLK224:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer irtglM243float_vector_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
irtglBLK244:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM245float_vector_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[151], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY247;
	local[0] = loadglobal(fqv[122]);
irtglKEY247:
	if (n & (1<<1)) goto irtglKEY248;
	local[1] = NIL;
irtglKEY248:
	if (n & (1<<2)) goto irtglKEY249;
	local[2] = makeint((eusinteger_t)1L);
irtglKEY249:
	if (n & (1<<3)) goto irtglKEY250;
	local[3] = fqv[152];
irtglKEY250:
	if (n & (1<<4)) goto irtglKEY251;
	local[4] = makeint((eusinteger_t)50L);
irtglKEY251:
	if (local[1]==NIL) goto irtglIF252;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[9];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto irtglIF253;
irtglIF252:
	local[5]= NIL;
irtglIF253:
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[124];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[124];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[25];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)3L);
irtglWHL254:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtglWHX255;
	local[10]= local[7];
	local[11]= local[8];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[0];
	local[11]= fqv[8];
	local[12]= fqv[128];
	local[13]= argv[0];
	local[14]= argv[0];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)VPLUS(ctx,2,local+14); /*v+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,5,local+10); /*send*/
	local[10]= local[7];
	local[11]= local[8];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtglWHL254;
irtglWHX255:
	local[10]= NIL;
irtglBLK256:
	w = NIL;
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[124];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[25];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	if (local[1]==NIL) goto irtglIF257;
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[45];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtglIF258;
irtglIF257:
	local[8]= NIL;
irtglIF258:
	w = local[8];
	local[0]= w;
irtglBLK246:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtglM259glvertices_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtglRST261:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[153], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtglKEY262;
	local[1] = NIL;
irtglKEY262:
	argv[0]->c.obj.iv[8] = argv[2];
	argv[0]->c.obj.iv[9] = local[1];
	local[2]= (pointer)get_sym_func(fqv[154]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[155]));
	local[5]= fqv[95];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,5,local+2); /*apply*/
	w = argv[0];
	local[0]= w;
irtglBLK260:
	ctx->vsp=local; return(local[0]);}

/*:filename*/
static pointer irtglM263glvertices_filename(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT266;}
	local[0]= NIL;
irtglENT266:
irtglENT265:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtglIF267;
	argv[0]->c.obj.iv[9] = local[0];
	local[1]= argv[0]->c.obj.iv[9];
	goto irtglIF268;
irtglIF267:
	local[1]= NIL;
irtglIF268:
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtglBLK264:
	ctx->vsp=local; return(local[0]);}

/*:set-color*/
static pointer irtglM269glvertices_set_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtglENT272;}
	local[0]= NIL;
irtglENT272:
irtglENT271:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[46];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtglF3delete_displaylist_id(ctx,1,local+1); /*delete-displaylist-id*/
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[156];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	if (argv[2]==NIL) goto irtglIF273;
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)irtglF7find_color(ctx,1,local+2); /*find-color*/
	local[2]= w;
	local[3]= fqv[48];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto irtglIF274;
irtglIF273:
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= fqv[48];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
irtglIF274:
	w = local[1];
	local[0]= w;
irtglBLK270:
	ctx->vsp=local; return(local[0]);}

/*:get-meshinfo*/
static pointer irtglM275glvertices_get_meshinfo(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtglENT278;}
	local[0]= makeint((eusinteger_t)-1L);
irtglENT278:
irtglENT277:
	if (n>4) maerror();
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtglIF279;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtglCLO281,env,argv,local);
	local[2]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	ctx->vsp=local+1;
	local[0]=w;
	goto irtglBLK276;
	goto irtglIF280;
irtglIF279:
	local[1]= NIL;
irtglIF280:
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[55])(ctx,2,local+1,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtglBLK276:
	ctx->vsp=local; return(local[0]);}

/*:set-meshinfo*/
static pointer irtglM282glvertices_set_meshinfo(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto irtglENT285;}
	local[0]= makeint((eusinteger_t)-1L);
irtglENT285:
irtglENT284:
	if (n>5) maerror();
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtglIF286;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[8];
irtglWHL288:
	if (local[2]==NIL) goto irtglWHX289;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[55])(ctx,2,local+3,&ftab[55],fqv[157]); /*assoc*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[56])(ctx,2,local+3,&ftab[56],fqv[158]); /*delete*/
	local[3]= local[1];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)NCONC(ctx,2,local+3); /*nconc*/
	goto irtglWHL288;
irtglWHX289:
	local[3]= NIL;
irtglBLK290:
	w = NIL;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto irtglBLK283;
	goto irtglIF287;
irtglIF286:
	local[1]= NIL;
irtglIF287:
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[55])(ctx,2,local+2,&ftab[55],fqv[157]); /*assoc*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[56])(ctx,2,local+2,&ftab[56],fqv[158]); /*delete*/
	local[2]= local[1];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)NCONC(ctx,2,local+2); /*nconc*/
	local[2]= argv[0];
	local[3]= fqv[159];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0]= w;
irtglBLK283:
	ctx->vsp=local; return(local[0]);}

/*:get-material*/
static pointer irtglM291glvertices_get_material(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT294;}
	local[0]= makeint((eusinteger_t)-1L);
irtglENT294:
irtglENT293:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[159];
	local[3]= fqv[160];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtglBLK292:
	ctx->vsp=local; return(local[0]);}

/*:set-material*/
static pointer irtglM295glvertices_set_material(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtglENT298;}
	local[0]= makeint((eusinteger_t)-1L);
irtglENT298:
irtglENT297:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[161];
	local[3]= fqv[160];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
irtglBLK296:
	ctx->vsp=local; return(local[0]);}

/*:actual-vertices*/
static pointer irtglM299glvertices_actual_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[8];
irtglWHL301:
	if (local[2]==NIL) goto irtglWHX302;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= fqv[62];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[55])(ctx,2,local+3,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	if (local[3]==NIL) goto irtglIF304;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[57])(ctx,2,local+5,&ftab[57],fqv[162]); /*array-dimension*/
	local[5]= w;
irtglWHL306:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtglWHX307;
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[58])(ctx,2,local+6,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[6]= w;
	w = local[0];
	ctx->vsp=local+7;
	local[0] = cons(ctx,local[6],w);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtglWHL306;
irtglWHX307:
	local[6]= NIL;
irtglBLK308:
	w = NIL;
	local[4]= w;
	goto irtglIF305;
irtglIF304:
	local[4]= NIL;
irtglIF305:
	w = local[4];
	goto irtglWHL301;
irtglWHX302:
	local[3]= NIL;
irtglBLK303:
	w = NIL;
	w = local[0];
	local[0]= w;
irtglBLK300:
	ctx->vsp=local; return(local[0]);}

/*:calc-bounding-box*/
static pointer irtglM309glvertices_calc_bounding_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[164];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[59])(ctx,2,local+0,&ftab[59],fqv[165]); /*make-bounding-box*/
	argv[0]->c.obj.iv[10] = w;
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtglBLK310:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer irtglM311glvertices_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[10]!=NIL) goto irtglIF313;
	local[0]= argv[0];
	local[1]= fqv[166];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtglIF314;
irtglIF313:
	local[0]= NIL;
irtglIF314:
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[167];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtglBLK312:
	ctx->vsp=local; return(local[0]);}

/*:reset-offset-from-parent*/
static pointer irtglM315glvertices_reset_offset_from_parent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[168];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[169];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[170];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtglBLK316:
	ctx->vsp=local; return(local[0]);}

/*:expand-vertices*/
static pointer irtglM317glvertices_expand_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[8];
irtglWHL319:
	if (local[2]==NIL) goto irtglWHX320;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= fqv[171];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	goto irtglWHL319;
irtglWHX320:
	local[3]= NIL;
irtglBLK321:
	w = NIL;
	argv[0]->c.obj.iv[8] = local[0];
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
irtglBLK318:
	ctx->vsp=local; return(local[0]);}

/*:expand-vertices-info*/
static pointer irtglM322glvertices_expand_vertices_info(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[172];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[55])(ctx,2,local+0,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[62];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[55])(ctx,2,local+1,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= loadglobal(fqv[119]);
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(*ftab[57])(ctx,2,local+4,&ftab[57],fqv[162]); /*array-dimension*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto irtglIF324;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[60])(ctx,2,local+3,&ftab[60],fqv[173]); /*make-matrix*/
	local[3]= w;
	local[4]= loadglobal(fqv[76]);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= fqv[62];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[55])(ctx,2,local+5,&ftab[55],fqv[157]); /*assoc*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[56])(ctx,2,local+5,&ftab[56],fqv[158]); /*delete*/
	argv[2] = w;
	local[5]= fqv[172];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[55])(ctx,2,local+5,&ftab[55],fqv[157]); /*assoc*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[56])(ctx,2,local+5,&ftab[56],fqv[158]); /*delete*/
	argv[2] = w;
	local[5]= fqv[174];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[55])(ctx,2,local+5,&ftab[55],fqv[157]); /*assoc*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[56])(ctx,2,local+5,&ftab[56],fqv[158]); /*delete*/
	argv[2] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtglWHL326:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtglWHX327;
	local[7]= local[4];
	local[8]= local[5];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[1];
	local[8]= local[0];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[58])(ctx,3,local+7,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[7]= local[3];
	local[8]= local[5];
	local[9]= local[2];
	local[10]= T;
	ctx->vsp=local+11;
	w=(*ftab[58])(ctx,4,local+7,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtglWHL326;
irtglWHX327:
	local[7]= NIL;
irtglBLK328:
	w = NIL;
	local[5]= argv[2];
	local[6]= fqv[62];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	local[7]= fqv[172];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)NCONC(ctx,2,local+5); /*nconc*/
	argv[2] = w;
	w = argv[2];
	local[3]= w;
	goto irtglIF325;
irtglIF324:
	local[3]= argv[2];
irtglIF325:
	w = local[3];
	local[0]= w;
irtglBLK323:
	ctx->vsp=local; return(local[0]);}

/*:use-flat-shader*/
static pointer irtglM329glvertices_use_flat_shader(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[8];
irtglWHL331:
	if (local[1]==NIL) goto irtglWHX332;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[175];
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)NCONC(ctx,2,local+2); /*nconc*/
	goto irtglWHL331;
irtglWHX332:
	local[2]= NIL;
irtglBLK333:
	w = NIL;
	local[0]= w;
irtglBLK330:
	ctx->vsp=local; return(local[0]);}

/*:use-smooth-shader*/
static pointer irtglM334glvertices_use_smooth_shader(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[8];
irtglWHL336:
	if (local[1]==NIL) goto irtglWHX337;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= fqv[175];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[55])(ctx,2,local+2,&ftab[55],fqv[157]); /*assoc*/
	local[2]= w;
	if (local[2]==NIL) goto irtglIF339;
	local[3]= local[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[56])(ctx,2,local+3,&ftab[56],fqv[158]); /*delete*/
	local[3]= w;
	goto irtglIF340;
irtglIF339:
	local[3]= NIL;
irtglIF340:
	w = local[3];
	goto irtglWHL336;
irtglWHX337:
	local[2]= NIL;
irtglBLK338:
	w = NIL;
	local[0]= w;
irtglBLK335:
	ctx->vsp=local; return(local[0]);}

/*:calc-normals*/
static pointer irtglM341glvertices_calc_normals(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT346;}
	local[0]= NIL;
irtglENT346:
	if (n>=4) { local[1]=(argv[3]); goto irtglENT345;}
	local[1]= T;
irtglENT345:
	if (n>=5) { local[2]=(argv[4]); goto irtglENT344;}
	local[2]= T;
irtglENT344:
irtglENT343:
	if (n>5) maerror();
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[8];
irtglWHL347:
	if (local[4]==NIL) goto irtglWHX348;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= fqv[174];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[55])(ctx,2,local+5,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[176];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[55])(ctx,2,local+6,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[172];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[55])(ctx,2,local+7,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[62];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[55])(ctx,2,local+8,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= loadglobal(fqv[119]);
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,2,local+9); /*instantiate*/
	local[9]= w;
	local[10]= loadglobal(fqv[119]);
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[10]= w;
	local[11]= loadglobal(fqv[119]);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,2,local+11); /*instantiate*/
	local[11]= w;
	local[12]= loadglobal(fqv[119]);
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[12]= w;
	local[13]= loadglobal(fqv[119]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[13]= w;
	local[14]= loadglobal(fqv[119]);
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,2,local+14); /*instantiate*/
	local[14]= w;
	local[15]= local[6];
	local[16]= local[15];
	if (fqv[177]!=local[16]) goto irtglIF350;
	local[6] = makeint((eusinteger_t)3L);
	local[16]= local[6];
	goto irtglIF351;
irtglIF350:
	local[16]= local[15];
	if (fqv[178]!=local[16]) goto irtglIF352;
	local[6] = makeint((eusinteger_t)4L);
	local[16]= local[6];
	goto irtglIF353;
irtglIF352:
	local[16]= local[15];
	if (fqv[179]!=local[16]) goto irtglIF354;
	local[6] = makeint((eusinteger_t)2L);
	local[16]= local[6];
	goto irtglIF355;
irtglIF354:
	local[16]= local[15];
	if (fqv[180]!=local[16]) goto irtglIF356;
	local[6] = makeint((eusinteger_t)3L);
	local[16]= fqv[181];
	ctx->vsp=local+17;
	w=(*ftab[13])(ctx,1,local+16,&ftab[13],fqv[44]); /*warn*/
	local[16]= w;
	goto irtglIF357;
irtglIF356:
	if (T==NIL) goto irtglIF358;
	local[16]= fqv[182];
	ctx->vsp=local+17;
	w=(*ftab[13])(ctx,1,local+16,&ftab[13],fqv[44]); /*warn*/
	w = NIL;
	ctx->vsp=local+16;
	local[0]=w;
	goto irtglBLK342;
	goto irtglIF359;
irtglIF358:
	local[16]= NIL;
irtglIF359:
irtglIF357:
irtglIF355:
irtglIF353:
irtglIF351:
	w = local[16];
	if (local[5]==NIL) goto irtglAND362;
	if (local[0]!=NIL) goto irtglAND362;
	goto irtglIF360;
irtglAND362:
	if (local[1]==NIL) goto irtglIF363;
	local[15]= argv[0];
	local[16]= fqv[171];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= fqv[172];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[55])(ctx,2,local+15,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.car;
	local[15]= fqv[62];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[55])(ctx,2,local+15,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.car;
	local[15]= local[8];
	goto irtglIF364;
irtglIF363:
	local[15]= NIL;
irtglIF364:
	if (local[5]==NIL) goto irtglIF365;
	local[15]= fqv[174];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[55])(ctx,2,local+15,&ftab[55],fqv[157]); /*assoc*/
	local[15]= w;
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[56])(ctx,2,local+15,&ftab[56],fqv[158]); /*delete*/
	local[15]= w;
	goto irtglIF366;
irtglIF365:
	local[15]= NIL;
irtglIF366:
	local[15]= local[8];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(*ftab[57])(ctx,2,local+15,&ftab[57],fqv[162]); /*array-dimension*/
	local[15]= w;
	local[16]= local[15];
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(*ftab[60])(ctx,2,local+16,&ftab[60],fqv[173]); /*make-matrix*/
	local[5] = w;
	if (local[7]==NIL) goto irtglCON368;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)LENGTH(ctx,1,local+17); /*length*/
	local[17]= w;
	local[18]= local[6];
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
irtglWHL369:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtglWHX370;
	local[18]= local[8];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[9];
	ctx->vsp=local+21;
	w=(*ftab[58])(ctx,3,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[8];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[10];
	ctx->vsp=local+21;
	w=(*ftab[58])(ctx,3,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[8];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[11];
	ctx->vsp=local+21;
	w=(*ftab[58])(ctx,3,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[10];
	local[19]= local[9];
	local[20]= local[12];
	ctx->vsp=local+21;
	w=(pointer)VMINUS(ctx,3,local+18); /*v-*/
	local[18]= w;
	local[19]= local[11];
	local[20]= local[9];
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)VMINUS(ctx,3,local+19); /*v-*/
	local[19]= w;
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+18); /*v**/
	local[18]= local[14];
	local[19]= local[14];
	ctx->vsp=local+20;
	w=(pointer)VNORMALIZE(ctx,2,local+18); /*normalize-vector*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[58])(ctx,4,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[58])(ctx,4,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[58])(ctx,4,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtglWHL369;
irtglWHX370:
	local[18]= NIL;
irtglBLK371:
	w = NIL;
	local[16]= w;
	goto irtglCON367;
irtglCON368:
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[15];
	local[18]= local[6];
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
irtglWHL373:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtglWHX374;
	local[18]= local[8];
	local[19]= local[6];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	local[20]= makeint((eusinteger_t)0L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	local[20]= local[9];
	ctx->vsp=local+21;
	w=(*ftab[58])(ctx,3,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[8];
	local[19]= local[6];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	local[20]= local[10];
	ctx->vsp=local+21;
	w=(*ftab[58])(ctx,3,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[8];
	local[19]= local[6];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	local[20]= local[11];
	ctx->vsp=local+21;
	w=(*ftab[58])(ctx,3,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[10];
	local[19]= local[9];
	local[20]= local[12];
	ctx->vsp=local+21;
	w=(pointer)VMINUS(ctx,3,local+18); /*v-*/
	local[18]= w;
	local[19]= local[11];
	local[20]= local[9];
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)VMINUS(ctx,3,local+19); /*v-*/
	local[19]= w;
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+18); /*v**/
	local[18]= local[14];
	local[19]= local[14];
	ctx->vsp=local+20;
	w=(pointer)VNORMALIZE(ctx,2,local+18); /*normalize-vector*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[58])(ctx,4,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[58])(ctx,4,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[58])(ctx,4,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtglWHL373;
irtglWHX374:
	local[18]= NIL;
irtglBLK375:
	w = NIL;
	local[16]= w;
	goto irtglCON367;
irtglCON372:
	local[16]= NIL;
irtglCON367:
	local[16]= local[3];
	local[17]= fqv[174];
	local[18]= local[5];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,2,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)NCONC(ctx,2,local+16); /*nconc*/
	if (local[2]==NIL) goto irtglIF376;
	local[16]= local[3];
	local[17]= fqv[175];
	local[18]= T;
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,2,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)NCONC(ctx,2,local+16); /*nconc*/
	local[16]= w;
	goto irtglIF377;
irtglIF376:
	local[16]= NIL;
irtglIF377:
	w = local[16];
	local[15]= w;
	goto irtglIF361;
irtglIF360:
	local[15]= NIL;
irtglIF361:
	w = local[15];
	goto irtglWHL347;
irtglWHX348:
	local[5]= NIL;
irtglBLK349:
	w = NIL;
	local[0]= w;
irtglBLK342:
	ctx->vsp=local; return(local[0]);}

/*:mirror-axis*/
static pointer irtglM378glvertices_mirror_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[183], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY380;
	local[0] = T;
irtglKEY380:
	if (n & (1<<1)) goto irtglKEY381;
	local[1] = T;
irtglKEY381:
	if (n & (1<<2)) goto irtglKEY382;
	local[2] = fqv[184];
irtglKEY382:
	local[3]= local[2];
	local[4]= local[3];
	if (fqv[185]!=local[4]) goto irtglIF383;
	local[2] = makeint((eusinteger_t)0L);
	local[4]= local[2];
	goto irtglIF384;
irtglIF383:
	local[4]= local[3];
	if (fqv[184]!=local[4]) goto irtglIF385;
	local[2] = makeint((eusinteger_t)1L);
	local[4]= local[2];
	goto irtglIF386;
irtglIF385:
	local[4]= local[3];
	if (fqv[186]!=local[4]) goto irtglIF387;
	local[2] = makeint((eusinteger_t)2L);
	local[4]= local[2];
	goto irtglIF388;
irtglIF387:
	local[4]= NIL;
irtglIF388:
irtglIF386:
irtglIF384:
	w = local[4];
	local[3]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+4;
	w=(pointer)COPYOBJ(ctx,1,local+3); /*copy-object*/
	local[3]= w;
	local[4]= loadglobal(fqv[119]);
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= NIL;
	local[6]= local[3];
irtglWHL389:
	if (local[6]==NIL) goto irtglWHX390;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= fqv[62];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[55])(ctx,2,local+7,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= local[7];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[57])(ctx,2,local+8,&ftab[57],fqv[162]); /*array-dimension*/
	local[8]= w;
	if (local[8]==NIL) goto irtglIF392;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[8];
irtglWHL394:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtglWHX395;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(*ftab[58])(ctx,3,local+11,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[11]= local[4];
	local[12]= local[2];
	local[13]= local[4];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,1,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[4];
	local[14]= T;
	ctx->vsp=local+15;
	w=(*ftab[58])(ctx,4,local+11,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtglWHL394;
irtglWHX395:
	local[11]= NIL;
irtglBLK396:
	w = NIL;
	if (local[1]==NIL) goto irtglIF397;
	local[9]= fqv[172];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[55])(ctx,2,local+9,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[9];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= local[10];
irtglWHL399:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto irtglWHX400;
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[11] = w;
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[12] = w;
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[13] = w;
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	local[18]= local[13];
	ctx->vsp=local+19;
	w=(pointer)SETELT(ctx,3,local+16); /*setelt*/
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)SETELT(ctx,3,local+16); /*setelt*/
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)SETELT(ctx,3,local+16); /*setelt*/
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto irtglWHL399;
irtglWHX400:
	local[16]= NIL;
irtglBLK401:
	w = NIL;
	local[9]= w;
	goto irtglIF398;
irtglIF397:
	local[9]= NIL;
irtglIF398:
	goto irtglIF393;
irtglIF392:
	local[9]= NIL;
irtglIF393:
	w = local[9];
	goto irtglWHL389;
irtglWHX390:
	local[7]= NIL;
irtglBLK391:
	w = NIL;
	if (local[0]==NIL) goto irtglIF402;
	local[5]= loadglobal(fqv[187]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[95];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = local[5];
	local[5]= w;
	goto irtglIF403;
irtglIF402:
	argv[0]->c.obj.iv[8] = local[3];
	local[5]= argv[0];
irtglIF403:
	w = local[5];
	local[0]= w;
irtglBLK379:
	ctx->vsp=local; return(local[0]);}

/*:convert-to-faces*/
static pointer irtglM404glvertices_convert_to_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST406:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[188], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtglKEY407;
	local[1] = fqv[189];
irtglKEY407:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[8];
irtglWHL408:
	if (local[4]==NIL) goto irtglWHX409;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= fqv[62];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[55])(ctx,2,local+5,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[174];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[55])(ctx,2,local+6,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[172];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[55])(ctx,2,local+7,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	local[9]= fqv[176];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[55])(ctx,2,local+9,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= local[9];
	local[13]= local[12];
	if (fqv[177]!=local[13]) goto irtglIF411;
	local[10] = makeint((eusinteger_t)3L);
	local[13]= local[10];
	goto irtglIF412;
irtglIF411:
	local[13]= local[12];
	if (fqv[178]!=local[13]) goto irtglIF413;
	local[10] = makeint((eusinteger_t)4L);
	local[13]= local[10];
	goto irtglIF414;
irtglIF413:
	if (T==NIL) goto irtglIF415;
	local[13]= fqv[190];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(*ftab[13])(ctx,2,local+13,&ftab[13],fqv[44]); /*warn*/
	w = NIL;
	ctx->vsp=local+13;
	local[0]=w;
	goto irtglBLK405;
	goto irtglIF416;
irtglIF415:
	local[13]= NIL;
irtglIF416:
irtglIF414:
irtglIF412:
	w = local[13];
	local[12]= local[8];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[8] = w;
	if (local[7]==NIL) goto irtglCON418;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
irtglTAG420:
	local[14]= local[13];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)GREQP(ctx,2,local+14); /*>=*/
	if (w==NIL) goto irtglIF421;
	w = NIL;
	ctx->vsp=local+14;
	local[12]=w;
	goto irtglBLK419;
	goto irtglIF422;
irtglIF421:
	local[14]= NIL;
irtglIF422:
	local[14]= NIL;
	local[15]= NIL;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[10];
irtglWHL423:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtglWHX424;
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[13];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[58])(ctx,2,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= w;
	w = local[14];
	ctx->vsp=local+19;
	local[14] = cons(ctx,local[18],w);
	if (local[6]==NIL) goto irtglIF426;
	local[18]= local[6];
	local[19]= local[7];
	local[20]= local[13];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[58])(ctx,2,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= w;
	w = local[15];
	ctx->vsp=local+19;
	local[15] = cons(ctx,local[18],w);
	local[18]= local[15];
	goto irtglIF427;
irtglIF426:
	local[18]= NIL;
irtglIF427:
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtglWHL423;
irtglWHX424:
	local[18]= NIL;
irtglBLK425:
	w = NIL;
	local[16]= local[1];
	local[17]= local[16];
	if (fqv[191]!=local[17]) goto irtglIF428;
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtglCLO430,env,argv,local);
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)NREVERSE(ctx,1,local+18); /*nreverse*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	local[17]= w;
	goto irtglIF429;
irtglIF428:
	local[17]= local[16];
	if (fqv[189]!=local[17]) goto irtglIF431;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)NREVERSE(ctx,1,local+17); /*nreverse*/
	local[17]= w;
	goto irtglIF432;
irtglIF431:
	if (T==NIL) goto irtglIF433;
	local[17]= NIL;
	goto irtglIF434;
irtglIF433:
	local[17]= NIL;
irtglIF434:
irtglIF432:
irtglIF429:
	w = local[17];
	local[14] = w;
	local[16]= loadglobal(fqv[192]);
	ctx->vsp=local+17;
	w=(pointer)INSTANTIATE(ctx,1,local+16); /*instantiate*/
	local[16]= w;
	local[17]= local[16];
	local[18]= fqv[95];
	local[19]= fqv[62];
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	w = local[16];
	local[16]= w;
	goto irtglCON435;
irtglCON436:
	local[16]= NIL;
irtglCON435:
	w = local[11];
	ctx->vsp=local+17;
	local[11] = cons(ctx,local[16],w);
	w = local[11];
	local[14]= local[12];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	local[15]= local[13];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[15]= w;
	local[12] = local[14];
	local[13] = local[15];
	w = NIL;
	ctx->vsp=local+14;
	goto irtglTAG420;
	w = NIL;
	local[12]= w;
irtglBLK419:
	goto irtglCON417;
irtglCON418:
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
irtglTAG439:
	local[14]= local[13];
	local[15]= local[5];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(*ftab[57])(ctx,2,local+15,&ftab[57],fqv[162]); /*array-dimension*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)GREQP(ctx,2,local+14); /*>=*/
	if (w==NIL) goto irtglIF440;
	w = NIL;
	ctx->vsp=local+14;
	local[12]=w;
	goto irtglBLK438;
	goto irtglIF441;
irtglIF440:
	local[14]= NIL;
irtglIF441:
	local[14]= NIL;
	local[15]= NIL;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[10];
irtglWHL442:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtglWHX443;
	local[18]= local[5];
	local[19]= local[13];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[58])(ctx,2,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= w;
	w = local[14];
	ctx->vsp=local+19;
	local[14] = cons(ctx,local[18],w);
	if (local[6]==NIL) goto irtglIF445;
	local[18]= local[6];
	local[19]= local[13];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[58])(ctx,2,local+18,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[18]= w;
	w = local[15];
	ctx->vsp=local+19;
	local[15] = cons(ctx,local[18],w);
	local[18]= local[15];
	goto irtglIF446;
irtglIF445:
	local[18]= NIL;
irtglIF446:
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtglWHL442;
irtglWHX443:
	local[18]= NIL;
irtglBLK444:
	w = NIL;
	local[16]= local[1];
	local[17]= local[16];
	if (fqv[191]!=local[17]) goto irtglIF447;
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtglCLO449,env,argv,local);
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)NREVERSE(ctx,1,local+18); /*nreverse*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	local[17]= w;
	goto irtglIF448;
irtglIF447:
	local[17]= local[16];
	if (fqv[189]!=local[17]) goto irtglIF450;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)NREVERSE(ctx,1,local+17); /*nreverse*/
	local[17]= w;
	goto irtglIF451;
irtglIF450:
	if (T==NIL) goto irtglIF452;
	local[17]= NIL;
	goto irtglIF453;
irtglIF452:
	local[17]= NIL;
irtglIF453:
irtglIF451:
irtglIF448:
	w = local[17];
	local[14] = w;
	local[16]= loadglobal(fqv[192]);
	ctx->vsp=local+17;
	w=(pointer)INSTANTIATE(ctx,1,local+16); /*instantiate*/
	local[16]= w;
	local[17]= local[16];
	local[18]= fqv[95];
	local[19]= fqv[62];
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	w = local[16];
	local[16]= w;
	goto irtglCON454;
irtglCON455:
	local[16]= NIL;
irtglCON454:
	w = local[11];
	ctx->vsp=local+17;
	local[11] = cons(ctx,local[16],w);
	w = local[11];
	local[14]= local[12];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	local[15]= local[13];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[15]= w;
	local[12] = local[14];
	local[13] = local[15];
	w = NIL;
	ctx->vsp=local+14;
	goto irtglTAG439;
	w = NIL;
	local[12]= w;
irtglBLK438:
	goto irtglCON417;
irtglCON437:
	local[12]= NIL;
irtglCON417:
	local[12]= local[11];
	ctx->vsp=local+13;
	w=(pointer)NREVERSE(ctx,1,local+12); /*nreverse*/
	local[12]= w;
	w = local[2];
	ctx->vsp=local+13;
	local[2] = cons(ctx,local[12],w);
	w = local[2];
	goto irtglWHL408;
irtglWHX409:
	local[5]= NIL;
irtglBLK410:
	w = NIL;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[0]= w;
irtglBLK405:
	ctx->vsp=local; return(local[0]);}

/*:faces*/
static pointer irtglM456glvertices_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[193];
	local[2]= fqv[194];
	local[3]= fqv[191];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[61])(ctx,1,local+0,&ftab[61],fqv[195]); /*flatten*/
	local[0]= w;
irtglBLK457:
	ctx->vsp=local; return(local[0]);}

/*:convert-to-faceset*/
static pointer irtglM458glvertices_convert_to_faceset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST460:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[40]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[95];
	local[4]= fqv[61];
	local[5]= (pointer)get_sym_func(fqv[196]);
	local[6]= argv[0];
	local[7]= fqv[193];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,4,local+5); /*apply*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[61])(ctx,1,local+5,&ftab[61],fqv[195]); /*flatten*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[197];
	local[4]= argv[0];
	local[5]= fqv[49];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w = local[1];
	local[0]= w;
irtglBLK459:
	ctx->vsp=local; return(local[0]);}

/*:set-offset*/
static pointer irtglM461glvertices_set_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[198], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtglKEY463;
	local[0] = NIL;
irtglKEY463:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[146];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= fqv[68];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	if (local[0]==NIL) goto irtglIF464;
	local[5]= loadglobal(fqv[187]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[95];
	local[8]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+9;
	w=(pointer)COPYOBJ(ctx,1,local+8); /*copy-object*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = local[5];
	local[4] = w;
	local[5]= local[4];
	goto irtglIF465;
irtglIF464:
	local[4] = argv[0];
	local[5]= local[4];
irtglIF465:
	local[5]= NIL;
	local[6]= *(ovafptr(local[4],fqv[199]));
irtglWHL466:
	if (local[6]==NIL) goto irtglWHX467;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= fqv[62];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[55])(ctx,2,local+7,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[174];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[55])(ctx,2,local+8,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[7];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(*ftab[62])(ctx,4,local+9,&ftab[62],fqv[200]); /*user::c-coords-transform-vector*/
	if (local[8]==NIL) goto irtglIF469;
	local[9]= local[1];
	local[10]= local[3];
	local[11]= local[8];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(*ftab[62])(ctx,4,local+9,&ftab[62],fqv[200]); /*user::c-coords-transform-vector*/
	local[9]= w;
	goto irtglIF470;
irtglIF469:
	local[9]= NIL;
irtglIF470:
	w = local[9];
	goto irtglWHL466;
irtglWHX467:
	local[7]= NIL;
irtglBLK468:
	w = NIL;
	w = local[4];
	local[0]= w;
irtglBLK462:
	ctx->vsp=local; return(local[0]);}

/*:convert-to-world*/
static pointer irtglM471glvertices_convert_to_world(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[201], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY473;
	local[0] = NIL;
irtglKEY473:
	local[1]= argv[0];
	local[2]= fqv[169];
	local[3]= argv[0];
	local[4]= fqv[49];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[202];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[170];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[49];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	local[0]= w;
irtglBLK472:
	ctx->vsp=local; return(local[0]);}

/*:glvertices*/
static pointer irtglM474glvertices_glvertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT478;}
	local[0]= NIL;
irtglENT478:
	if (n>=4) { local[1]=(argv[3]); goto irtglENT477;}
	local[1]= (pointer)get_sym_func(fqv[203]);
irtglENT477:
irtglENT476:
	if (n>4) maerror();
	local[2]= NIL;
	if (local[0]==NIL) goto irtglCON480;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtglCLO481,env,argv,local);
	local[4]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+5;
	w=(*ftab[48])(ctx,2,local+3,&ftab[48],fqv[116]); /*find-if*/
	local[3]= w;
	if (local[3]==NIL) goto irtglIF482;
	local[4]= loadglobal(fqv[187]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[95];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	goto irtglIF483;
irtglIF482:
	local[4]= NIL;
irtglIF483:
	w = local[4];
	local[3]= w;
	goto irtglCON479;
irtglCON480:
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[8];
irtglWHL485:
	if (local[4]==NIL) goto irtglWHX486;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= loadglobal(fqv[187]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[95];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = local[5];
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	goto irtglWHL485;
irtglWHX486:
	local[5]= NIL;
irtglBLK487:
	w = NIL;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[2] = w;
	local[3]= local[2];
	goto irtglCON479;
irtglCON484:
	local[3]= NIL;
irtglCON479:
	w = local[2];
	local[0]= w;
irtglBLK475:
	ctx->vsp=local; return(local[0]);}

/*:append-glvertices*/
static pointer irtglM488glvertices_append_glvertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!!iscons(w)) goto irtglIF490;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	argv[2] = w;
	local[0]= argv[2];
	goto irtglIF491;
irtglIF490:
	local[0]= NIL;
irtglIF491:
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[49];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= argv[2];
irtglWHL492:
	if (local[3]==NIL) goto irtglWHX493;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= *(ovafptr(local[2],fqv[199]));
	ctx->vsp=local+5;
	w=(pointer)COPYOBJ(ctx,1,local+4); /*copy-object*/
	local[4]= w;
	local[5]= local[1];
	local[6]= fqv[204];
	local[7]= local[2];
	local[8]= fqv[49];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= loadglobal(fqv[187]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[95];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	w = local[6];
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[169];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[0];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[0] = w;
	w = local[0];
	goto irtglWHL492;
irtglWHX493:
	local[4]= NIL;
irtglBLK494:
	w = NIL;
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	argv[0]->c.obj.iv[8] = w;
	local[2]= argv[0];
	local[3]= fqv[166];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = argv[0];
	local[0]= w;
irtglBLK489:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM495glvertices_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[205], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY497;
	local[0] = loadglobal(fqv[122]);
irtglKEY497:
	w = NIL;
	local[0]= w;
irtglBLK496:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer irtglM498glvertices_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtglRST500:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[49];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[50];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[156];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	local[4]= NIL;
	local[5]= argv[2];
	local[6]= fqv[8];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= *(ovafptr(w,fqv[13]));
	local[6]= argv[2];
	local[7]= fqv[8];
	local[8]= fqv[9];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= makeint((eusinteger_t)4294967295L);
	ctx->vsp=local+7;
	w=(*ftab[20])(ctx,1,local+6,&ftab[20],fqv[58]); /*glpushattrib*/
	ctx->vsp=local+6;
	w=(*ftab[14])(ctx,0,local+6,&ftab[14],fqv[51]); /*glpushmatrix*/
	local[6]= local[2];
	local[7]= loadglobal(fqv[52]);
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,2,local+6); /*transpose*/
	local[6]= w->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(*ftab[15])(ctx,1,local+6,&ftab[15],fqv[53]); /*glmultmatrixf*/
	local[6]= makeint((eusinteger_t)2898L);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[63])(ctx,2,local+6,&ftab[63],fqv[206]); /*gllightmodeli*/
	local[6]= local[5];
	local[7]= argv[0];
	local[8]= fqv[46];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ASSQ(ctx,2,local+6); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	if (local[1]==NIL) goto irtglCON502;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[16])(ctx,1,local+6,&ftab[16],fqv[54]); /*glcalllist*/
	local[6]= w;
	goto irtglCON501;
irtglCON502:
	local[6]= argv[0];
	local[7]= fqv[48];
	ctx->vsp=local+8;
	w=(pointer)GETPROP(ctx,2,local+6); /*get*/
	local[4] = w;
	if (local[4]==NIL) goto irtglIF504;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VECTORP(ctx,1,local+6); /*vectorp*/
	if (w!=NIL) goto irtglIF504;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)irtglF7find_color(ctx,1,local+6); /*find-color*/
	local[4] = w;
	local[6]= argv[0];
	local[7]= local[4];
	local[8]= fqv[48];
	ctx->vsp=local+9;
	w=(pointer)PUTPROP(ctx,3,local+6); /*putprop*/
	local[6]= w;
	goto irtglIF505;
irtglIF504:
	local[6]= NIL;
irtglIF505:
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[18])(ctx,1,local+6,&ftab[18],fqv[56]); /*glgenlists*/
	local[1] = w;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)4864L);
	ctx->vsp=local+8;
	w=(*ftab[19])(ctx,2,local+6,&ftab[19],fqv[57]); /*glnewlist*/
	if (local[3]==NIL) goto irtglIF506;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[64])(ctx,1,local+6,&ftab[64],fqv[207]); /*gldepthmask*/
	local[6]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+7;
	w=(*ftab[11])(ctx,1,local+6,&ftab[11],fqv[37]); /*glenable*/
	local[6]= makeint((eusinteger_t)770L);
	local[7]= makeint((eusinteger_t)771L);
	ctx->vsp=local+8;
	w=(*ftab[28])(ctx,2,local+6,&ftab[28],fqv[77]); /*glblendfunc*/
	local[6]= w;
	goto irtglIF507;
irtglIF506:
	local[6]= NIL;
irtglIF507:
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[8];
irtglWHL508:
	if (local[7]==NIL) goto irtglWHX509;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= fqv[176];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[55])(ctx,2,local+8,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[160];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[55])(ctx,2,local+9,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[62];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(*ftab[55])(ctx,2,local+10,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[174];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(*ftab[55])(ctx,2,local+11,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[172];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[55])(ctx,2,local+12,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[208];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(*ftab[55])(ctx,2,local+13,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[175];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(*ftab[55])(ctx,2,local+14,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= NIL;
	if (local[14]==NIL) goto irtglIF511;
	local[16]= makeint((eusinteger_t)7424L);
	ctx->vsp=local+17;
	w=(*ftab[11])(ctx,1,local+16,&ftab[11],fqv[37]); /*glenable*/
	local[16]= makeint((eusinteger_t)7424L);
	ctx->vsp=local+17;
	w=(*ftab[65])(ctx,1,local+16,&ftab[65],fqv[209]); /*glshademodel*/
	local[16]= w;
	goto irtglIF512;
irtglIF511:
	local[16]= NIL;
irtglIF512:
	if (local[4]==NIL) goto irtglCON514;
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(*ftab[8])(ctx,1,local+16,&ftab[8],fqv[29]); /*glcolor3fv*/
	if (local[3]==NIL) goto irtglCON516;
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)5634L);
	local[18]= loadglobal(fqv[119]);
	local[19]= local[4];
	local[20]= local[3];
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,1,local+20); /*float-vector*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)CONCATENATE(ctx,3,local+18); /*concatenate*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)5634L);
	local[18]= makeint((eusinteger_t)0L);
	local[19]= makeint((eusinteger_t)0L);
	local[20]= makeint((eusinteger_t)0L);
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= w;
	goto irtglCON515;
irtglCON516:
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)5634L);
	local[18]= local[4];
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)5634L);
	local[18]= makeflt(7.9999999999999982236432e-01);
	local[19]= makeflt(0.0000000000000000000000e+00);
	local[20]= makeflt(5.4000000000000003552714e-01);
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,3,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= w;
	goto irtglCON515;
irtglCON517:
	local[16]= NIL;
irtglCON515:
	goto irtglCON513;
irtglCON514:
	if (local[9]==NIL) goto irtglCON518;
	local[16]= fqv[25];
	local[17]= local[9];
	ctx->vsp=local+18;
	w=(*ftab[55])(ctx,2,local+16,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[210];
	local[18]= local[9];
	ctx->vsp=local+19;
	w=(*ftab[55])(ctx,2,local+17,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= fqv[114];
	local[19]= local[9];
	ctx->vsp=local+20;
	w=(*ftab[55])(ctx,2,local+18,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	local[19]= fqv[211];
	local[20]= local[9];
	ctx->vsp=local+21;
	w=(*ftab[55])(ctx,2,local+19,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	local[20]= fqv[212];
	local[21]= local[9];
	ctx->vsp=local+22;
	w=(*ftab[55])(ctx,2,local+20,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[213];
	local[22]= local[9];
	ctx->vsp=local+23;
	w=(*ftab[55])(ctx,2,local+21,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	local[22]= fqv[214];
	local[23]= local[9];
	ctx->vsp=local+24;
	w=(*ftab[55])(ctx,2,local+22,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	local[23]= fqv[215];
	local[24]= local[9];
	ctx->vsp=local+25;
	w=(*ftab[55])(ctx,2,local+23,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.car;
	if (local[16]==NIL) goto irtglIF519;
	local[23]= local[16];
	ctx->vsp=local+24;
	w=(*ftab[8])(ctx,1,local+23,&ftab[8],fqv[29]); /*glcolor3fv*/
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)5634L);
	if (local[3]==NIL) goto irtglIF521;
	local[25]= loadglobal(fqv[119]);
	local[26]= local[16];
	local[27]= local[3];
	ctx->vsp=local+28;
	w=(pointer)MKFLTVEC(ctx,1,local+27); /*float-vector*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)CONCATENATE(ctx,3,local+25); /*concatenate*/
	local[25]= w;
	goto irtglIF522;
irtglIF521:
	local[25]= local[16];
irtglIF522:
	ctx->vsp=local+26;
	w=(*ftab[29])(ctx,3,local+23,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF520;
irtglIF519:
	local[23]= NIL;
irtglIF520:
	if (local[17]==NIL) goto irtglIF523;
	if (local[3]==NIL) goto irtglIF525;
	local[23]= local[17];
	local[24]= makeint((eusinteger_t)3L);
	local[25]= local[3];
	ctx->vsp=local+26;
	w=(pointer)SETELT(ctx,3,local+23); /*setelt*/
	local[23]= w;
	goto irtglIF526;
irtglIF525:
	local[23]= NIL;
irtglIF526:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)4608L);
	local[25]= local[17];
	ctx->vsp=local+26;
	w=(*ftab[29])(ctx,3,local+23,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF524;
irtglIF523:
	local[23]= NIL;
irtglIF524:
	if (local[18]==NIL) goto irtglIF527;
	if (local[3]==NIL) goto irtglIF529;
	local[23]= local[18];
	local[24]= makeint((eusinteger_t)3L);
	local[25]= local[3];
	ctx->vsp=local+26;
	w=(pointer)SETELT(ctx,3,local+23); /*setelt*/
	local[23]= w;
	goto irtglIF530;
irtglIF529:
	local[23]= NIL;
irtglIF530:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)4609L);
	local[25]= local[18];
	ctx->vsp=local+26;
	w=(*ftab[29])(ctx,3,local+23,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF528;
irtglIF527:
	local[23]= NIL;
irtglIF528:
	if (local[19]==NIL) goto irtglIF531;
	if (local[3]==NIL) goto irtglIF533;
	local[23]= local[19];
	local[24]= makeint((eusinteger_t)3L);
	local[25]= local[3];
	ctx->vsp=local+26;
	w=(pointer)SETELT(ctx,3,local+23); /*setelt*/
	local[23]= w;
	goto irtglIF534;
irtglIF533:
	local[23]= NIL;
irtglIF534:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)4610L);
	local[25]= local[19];
	ctx->vsp=local+26;
	w=(*ftab[29])(ctx,3,local+23,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF532;
irtglIF531:
	local[23]= NIL;
irtglIF532:
	if (local[20]==NIL) goto irtglIF535;
	if (local[3]==NIL) goto irtglIF537;
	local[23]= local[20];
	local[24]= makeint((eusinteger_t)3L);
	local[25]= local[3];
	ctx->vsp=local+26;
	w=(pointer)SETELT(ctx,3,local+23); /*setelt*/
	local[23]= w;
	goto irtglIF538;
irtglIF537:
	local[23]= NIL;
irtglIF538:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)5632L);
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(*ftab[29])(ctx,3,local+23,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF536;
irtglIF535:
	local[23]= NIL;
irtglIF536:
	if (local[21]==NIL) goto irtglCON540;
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)5633L);
	local[25]= local[21];
	ctx->vsp=local+26;
	w=(*ftab[66])(ctx,3,local+23,&ftab[66],fqv[216]); /*glmaterialf*/
	local[23]= w;
	goto irtglCON539;
irtglCON540:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)5633L);
	local[25]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+26;
	w=(*ftab[66])(ctx,3,local+23,&ftab[66],fqv[216]); /*glmaterialf*/
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)4610L);
	local[25]= makeint((eusinteger_t)0L);
	local[26]= makeint((eusinteger_t)0L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)0L);
	ctx->vsp=local+29;
	w=(pointer)MKFLTVEC(ctx,4,local+25); /*float-vector*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[29])(ctx,3,local+23,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[23]= w;
	goto irtglCON539;
irtglCON541:
	local[23]= NIL;
irtglCON539:
	if (local[15]==NIL) goto irtglIF542;
	if (local[13]==NIL) goto irtglIF542;
	local[23]= local[15];
	local[24]= fqv[15];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,2,local+23); /*send*/
	local[23]= w;
	local[24]= local[15];
	local[25]= fqv[14];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[24]= w;
	local[25]= local[15];
	local[26]= fqv[17];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)3317L);
	local[27]= makeint((eusinteger_t)1L);
	ctx->vsp=local+28;
	w=(*ftab[36])(ctx,2,local+26,&ftab[36],fqv[98]); /*glpixelstorei*/
	local[26]= local[15];
	local[27]= loadglobal(fqv[84]);
	ctx->vsp=local+28;
	w=(pointer)DERIVEDP(ctx,2,local+26); /*derivedp*/
	if (w==NIL) goto irtglCON545;
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)6407L);
	local[29]= local[23];
	local[30]= local[24];
	local[31]= makeint((eusinteger_t)0L);
	local[32]= makeint((eusinteger_t)6409L);
	local[33]= makeint((eusinteger_t)5121L);
	local[34]= local[25];
	ctx->vsp=local+35;
	w=(*ftab[35])(ctx,9,local+26,&ftab[35],fqv[97]); /*glteximage2d*/
	local[26]= w;
	goto irtglCON544;
irtglCON545:
	local[26]= local[15];
	local[27]= loadglobal(fqv[83]);
	ctx->vsp=local+28;
	w=(pointer)DERIVEDP(ctx,2,local+26); /*derivedp*/
	if (w==NIL) goto irtglCON546;
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)6407L);
	local[29]= local[23];
	local[30]= local[24];
	local[31]= makeint((eusinteger_t)0L);
	local[32]= makeint((eusinteger_t)6407L);
	local[33]= makeint((eusinteger_t)5121L);
	local[34]= local[25];
	ctx->vsp=local+35;
	w=(*ftab[35])(ctx,9,local+26,&ftab[35],fqv[97]); /*glteximage2d*/
	local[26]= w;
	goto irtglCON544;
irtglCON546:
	local[26]= local[15];
	local[27]= loadglobal(fqv[217]);
	ctx->vsp=local+28;
	w=(pointer)DERIVEDP(ctx,2,local+26); /*derivedp*/
	if (w==NIL) goto irtglCON547;
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)6408L);
	local[29]= local[23];
	local[30]= local[24];
	local[31]= makeint((eusinteger_t)0L);
	local[32]= makeint((eusinteger_t)6408L);
	local[33]= makeint((eusinteger_t)5121L);
	local[34]= local[25];
	ctx->vsp=local+35;
	w=(*ftab[35])(ctx,9,local+26,&ftab[35],fqv[97]); /*glteximage2d*/
	local[26]= w;
	goto irtglCON544;
irtglCON547:
	local[26]= NIL;
irtglCON544:
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)10242L);
	local[28]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+29;
	w=(*ftab[37])(ctx,3,local+26,&ftab[37],fqv[99]); /*gltexparameteri*/
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)10243L);
	local[28]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+29;
	w=(*ftab[37])(ctx,3,local+26,&ftab[37],fqv[99]); /*gltexparameteri*/
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)10241L);
	local[28]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+29;
	w=(*ftab[37])(ctx,3,local+26,&ftab[37],fqv[99]); /*gltexparameteri*/
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)10240L);
	local[28]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+29;
	w=(*ftab[37])(ctx,3,local+26,&ftab[37],fqv[99]); /*gltexparameteri*/
	local[26]= makeint((eusinteger_t)8960L);
	local[27]= makeint((eusinteger_t)8704L);
	local[28]= makeint((eusinteger_t)8448L);
	ctx->vsp=local+29;
	w=(*ftab[38])(ctx,3,local+26,&ftab[38],fqv[100]); /*gltexenvi*/
	local[26]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+27;
	w=(*ftab[11])(ctx,1,local+26,&ftab[11],fqv[37]); /*glenable*/
	local[23]= w;
	goto irtglIF543;
irtglIF542:
	local[23]= NIL;
irtglIF543:
	if (local[3]==NIL) goto irtglIF548;
	local[23]= makeint((eusinteger_t)1028L);
	local[24]= makeint((eusinteger_t)5634L);
	local[25]= makeint((eusinteger_t)0L);
	local[26]= makeint((eusinteger_t)0L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)0L);
	ctx->vsp=local+29;
	w=(pointer)MKFLTVEC(ctx,4,local+25); /*float-vector*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[29])(ctx,3,local+23,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF549;
irtglIF548:
	local[23]= NIL;
irtglIF549:
	w = local[23];
	local[16]= w;
	goto irtglCON513;
irtglCON518:
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)4608L);
	local[18]= makeflt(1.9999999999999995559108e-01);
	local[19]= makeflt(1.9999999999999995559108e-01);
	local[20]= makeflt(1.9999999999999995559108e-01);
	local[21]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)4609L);
	local[18]= makeint((eusinteger_t)1L);
	local[19]= makeint((eusinteger_t)1L);
	local[20]= makeint((eusinteger_t)1L);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)4610L);
	local[18]= makeflt(1.9999999999999995559108e-01);
	local[19]= makeflt(1.9999999999999995559108e-01);
	local[20]= makeflt(1.9999999999999995559108e-01);
	local[21]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)5632L);
	local[18]= makeflt(9.9999999999999977795540e-02);
	local[19]= makeflt(9.9999999999999977795540e-02);
	local[20]= makeflt(9.9999999999999977795540e-02);
	local[21]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)4608L);
	local[18]= makeflt(7.9999999999999982236432e-01);
	local[19]= makeflt(0.0000000000000000000000e+00);
	local[20]= makeflt(5.4000000000000003552714e-01);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)4609L);
	local[18]= makeflt(7.9999999999999982236432e-01);
	local[19]= makeflt(0.0000000000000000000000e+00);
	local[20]= makeflt(5.4000000000000003552714e-01);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)4610L);
	local[18]= makeflt(1.9999999999999995559108e-01);
	local[19]= makeflt(1.9999999999999995559108e-01);
	local[20]= makeflt(1.9999999999999995559108e-01);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)5632L);
	local[18]= makeflt(9.9999999999999977795540e-02);
	local[19]= makeflt(9.9999999999999977795540e-02);
	local[20]= makeflt(9.9999999999999977795540e-02);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[29])(ctx,3,local+16,&ftab[29],fqv[78]); /*glmaterialfv*/
	local[16]= w;
	goto irtglCON513;
irtglCON550:
	local[16]= NIL;
irtglCON513:
	if (local[15]==NIL) goto irtglAND553;
	if (local[13]==NIL) goto irtglAND553;
	goto irtglIF551;
irtglAND553:
	local[13] = NIL;
	local[16]= local[13];
	goto irtglIF552;
irtglIF551:
	local[16]= NIL;
irtglIF552:
	local[16]= makeint((eusinteger_t)32884L);
	ctx->vsp=local+17;
	w=(*ftab[67])(ctx,1,local+16,&ftab[67],fqv[218]); /*glenableclientstate*/
	local[16]= makeint((eusinteger_t)3L);
	local[17]= makeint((eusinteger_t)5130L);
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[10]->c.obj.iv[1];
	ctx->vsp=local+20;
	w=(*ftab[68])(ctx,4,local+16,&ftab[68],fqv[219]); /*glvertexpointer*/
	if (local[11]==NIL) goto irtglIF554;
	local[16]= makeint((eusinteger_t)32885L);
	ctx->vsp=local+17;
	w=(*ftab[67])(ctx,1,local+16,&ftab[67],fqv[218]); /*glenableclientstate*/
	local[16]= makeint((eusinteger_t)5130L);
	local[17]= makeint((eusinteger_t)0L);
	local[18]= local[11]->c.obj.iv[1];
	ctx->vsp=local+19;
	w=(*ftab[69])(ctx,3,local+16,&ftab[69],fqv[220]); /*glnormalpointer*/
	local[16]= w;
	goto irtglIF555;
irtglIF554:
	local[16]= NIL;
irtglIF555:
	if (local[13]==NIL) goto irtglIF556;
	local[16]= makeint((eusinteger_t)32888L);
	ctx->vsp=local+17;
	w=(*ftab[67])(ctx,1,local+16,&ftab[67],fqv[218]); /*glenableclientstate*/
	local[16]= makeint((eusinteger_t)2L);
	local[17]= makeint((eusinteger_t)5130L);
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(*ftab[70])(ctx,4,local+16,&ftab[70],fqv[221]); /*gltexcoordpointer*/
	local[16]= w;
	goto irtglIF557;
irtglIF556:
	local[16]= NIL;
irtglIF557:
	local[16]= NIL;
	local[17]= local[8];
	local[18]= local[17];
	if (fqv[177]!=local[18]) goto irtglIF558;
	local[16] = makeint((eusinteger_t)4L);
	local[18]= local[16];
	goto irtglIF559;
irtglIF558:
	local[18]= local[17];
	if (fqv[178]!=local[18]) goto irtglIF560;
	local[16] = makeint((eusinteger_t)7L);
	local[18]= local[16];
	goto irtglIF561;
irtglIF560:
	local[18]= local[17];
	if (fqv[179]!=local[18]) goto irtglIF562;
	local[16] = makeint((eusinteger_t)1L);
	local[18]= local[16];
	goto irtglIF563;
irtglIF562:
	local[18]= local[17];
	if (fqv[180]!=local[18]) goto irtglIF564;
	local[16] = makeint((eusinteger_t)4L);
	local[18]= fqv[222];
	ctx->vsp=local+19;
	w=(*ftab[13])(ctx,1,local+18,&ftab[13],fqv[44]); /*warn*/
	local[18]= w;
	goto irtglIF565;
irtglIF564:
	if (T==NIL) goto irtglIF566;
	local[18]= fqv[223];
	ctx->vsp=local+19;
	w=(*ftab[13])(ctx,1,local+18,&ftab[13],fqv[44]); /*warn*/
	local[18]= local[8];
	goto irtglIF567;
irtglIF566:
	local[18]= NIL;
irtglIF567:
irtglIF565:
irtglIF563:
irtglIF561:
irtglIF559:
	w = local[18];
	if (local[16]==NIL) goto irtglIF568;
	if (local[12]==NIL) goto irtglCON571;
	local[17]= local[16];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)LENGTH(ctx,1,local+18); /*length*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)5125L);
	local[20]= local[12];
	ctx->vsp=local+21;
	w=(*ftab[71])(ctx,1,local+20,&ftab[71],fqv[224]); /*user::lvector2integer-bytestring*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(*ftab[72])(ctx,4,local+17,&ftab[72],fqv[225]); /*gldrawelements*/
	local[17]= w;
	goto irtglCON570;
irtglCON571:
	local[17]= local[16];
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[10];
	local[20]= makeint((eusinteger_t)0L);
	ctx->vsp=local+21;
	w=(*ftab[57])(ctx,2,local+19,&ftab[57],fqv[162]); /*array-dimension*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[73])(ctx,3,local+17,&ftab[73],fqv[226]); /*gldrawarrays*/
	local[17]= w;
	goto irtglCON570;
irtglCON572:
	local[17]= NIL;
irtglCON570:
	goto irtglIF569;
irtglIF568:
	local[17]= NIL;
irtglIF569:
	w = local[17];
	if (local[13]==NIL) goto irtglIF573;
	local[16]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+17;
	w=(*ftab[6])(ctx,1,local+16,&ftab[6],fqv[26]); /*gldisable*/
	local[16]= makeint((eusinteger_t)32888L);
	ctx->vsp=local+17;
	w=(*ftab[74])(ctx,1,local+16,&ftab[74],fqv[227]); /*gldisableclientstate*/
	local[16]= w;
	goto irtglIF574;
irtglIF573:
	local[16]= NIL;
irtglIF574:
	if (local[11]==NIL) goto irtglIF575;
	local[16]= makeint((eusinteger_t)32885L);
	ctx->vsp=local+17;
	w=(*ftab[74])(ctx,1,local+16,&ftab[74],fqv[227]); /*gldisableclientstate*/
	local[16]= w;
	goto irtglIF576;
irtglIF575:
	local[16]= NIL;
irtglIF576:
	local[16]= makeint((eusinteger_t)32884L);
	ctx->vsp=local+17;
	w=(*ftab[74])(ctx,1,local+16,&ftab[74],fqv[227]); /*gldisableclientstate*/
	if (local[14]==NIL) goto irtglIF577;
	local[16]= makeint((eusinteger_t)7425L);
	ctx->vsp=local+17;
	w=(*ftab[11])(ctx,1,local+16,&ftab[11],fqv[37]); /*glenable*/
	local[16]= makeint((eusinteger_t)7425L);
	ctx->vsp=local+17;
	w=(*ftab[65])(ctx,1,local+16,&ftab[65],fqv[209]); /*glshademodel*/
	local[16]= w;
	goto irtglIF578;
irtglIF577:
	local[16]= NIL;
irtglIF578:
	w = local[16];
	goto irtglWHL508;
irtglWHX509:
	local[8]= NIL;
irtglBLK510:
	w = NIL;
	if (local[3]==NIL) goto irtglIF579;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[64])(ctx,1,local+6,&ftab[64],fqv[207]); /*gldepthmask*/
	local[6]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,1,local+6,&ftab[6],fqv[26]); /*gldisable*/
	local[6]= w;
	goto irtglIF580;
irtglIF579:
	local[6]= NIL;
irtglIF580:
	ctx->vsp=local+6;
	w=(*ftab[27])(ctx,0,local+6,&ftab[27],fqv[74]); /*glendlist*/
	local[6]= argv[0];
	local[7]= local[5];
	w = local[1];
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= argv[0];
	local[9]= fqv[46];
	ctx->vsp=local+10;
	w=(pointer)GETPROP(ctx,2,local+8); /*get*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[46];
	ctx->vsp=local+9;
	w=(pointer)PUTPROP(ctx,3,local+6); /*putprop*/
	local[1] = NIL;
	local[6]= local[1];
	goto irtglCON501;
irtglCON503:
	local[6]= NIL;
irtglCON501:
	local[6]= makeint((eusinteger_t)2898L);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[63])(ctx,2,local+6,&ftab[63],fqv[206]); /*gllightmodeli*/
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,0,local+6,&ftab[17],fqv[55]); /*glpopmatrix*/
	ctx->vsp=local+6;
	w=(*ftab[26])(ctx,0,local+6,&ftab[26],fqv[73]); /*glpopattrib*/
	if (local[1]!=NIL) goto irtglIF581;
	local[6]= argv[0];
	local[7]= fqv[38];
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtglIF582;
irtglIF581:
	local[6]= NIL;
irtglIF582:
	w = local[6];
	local[0]= w;
irtglBLK499:
	ctx->vsp=local; return(local[0]);}

/*:collision-check-objects*/
static pointer irtglM583glvertices_collision_check_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST585:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w = NIL;
	local[0]= w;
irtglBLK584:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer irtglM586glvertices_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[10]!=NIL) goto irtglIF588;
	local[0]= argv[0];
	local[1]= fqv[166];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtglIF589;
irtglIF588:
	local[0]= NIL;
irtglIF589:
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtglBLK587:
	ctx->vsp=local; return(local[0]);}

/*:make-pqpmodel*/
static pointer irtglM590glvertices_make_pqpmodel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[228], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY592;
	local[0] = makeint((eusinteger_t)0L);
irtglKEY592:
	ctx->vsp=local+1;
	w=(*ftab[75])(ctx,0,local+1,&ftab[75],fqv[229]); /*geometry::pqpmakemodel*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[8];
irtglWHL593:
	if (local[7]==NIL) goto irtglWHX594;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= fqv[176];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[55])(ctx,2,local+8,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[8];
	if (fqv[177]==local[9]) goto irtglIF596;
	local[9]= fqv[230];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(*ftab[13])(ctx,2,local+9,&ftab[13],fqv[44]); /*warn*/
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(*ftab[76])(ctx,1,local+9,&ftab[76],fqv[231]); /*geometry::pqpdeletemodel*/
	w = NIL;
	ctx->vsp=local+9;
	local[0]=w;
	goto irtglBLK591;
	goto irtglIF597;
irtglIF596:
	local[9]= NIL;
irtglIF597:
	w = local[9];
	goto irtglWHL593;
irtglWHX594:
	local[8]= NIL;
irtglBLK595:
	w = NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[2] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[3] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[4] = w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[77])(ctx,1,local+6,&ftab[77],fqv[232]); /*geometry::pqpbeginmodel*/
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[8];
irtglWHL598:
	if (local[7]==NIL) goto irtglWHX599;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= fqv[62];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[55])(ctx,2,local+8,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[172];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[55])(ctx,2,local+9,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[9];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	if (local[9]==NIL) goto irtglCON602;
	local[11]= makeint((eusinteger_t)0L);
irtglTAG604:
	local[12]= local[11];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)GREQP(ctx,2,local+12); /*>=*/
	if (w==NIL) goto irtglIF605;
	w = NIL;
	ctx->vsp=local+12;
	local[11]=w;
	goto irtglBLK603;
	goto irtglIF606;
irtglIF605:
	local[12]= NIL;
irtglIF606:
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(*ftab[58])(ctx,3,local+12,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[11];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(*ftab[58])(ctx,3,local+12,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[11];
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[58])(ctx,3,local+12,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[12]= local[0];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)NUMEQUAL(ctx,2,local+12); /*=*/
	if (w!=NIL) goto irtglIF607;
	local[12]= local[2];
	local[13]= local[0];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= local[3];
	local[13]= local[0];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= local[4];
	local[13]= local[0];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= w;
	goto irtglIF608;
irtglIF607:
	local[12]= NIL;
irtglIF608:
	local[12]= local[1];
	local[13]= local[2];
	local[14]= local[3];
	local[15]= local[4];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[78])(ctx,5,local+12,&ftab[78],fqv[233]); /*geometry::pqpaddtri*/
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[5] = w;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[11] = local[12];
	w = NIL;
	ctx->vsp=local+12;
	goto irtglTAG604;
	w = NIL;
	local[11]= w;
irtglBLK603:
	goto irtglCON601;
irtglCON602:
	local[11]= makeint((eusinteger_t)0L);
irtglTAG611:
	local[12]= local[11];
	local[13]= local[8];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[57])(ctx,2,local+13,&ftab[57],fqv[162]); /*array-dimension*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)GREQP(ctx,2,local+12); /*>=*/
	if (w==NIL) goto irtglIF612;
	w = NIL;
	ctx->vsp=local+12;
	local[11]=w;
	goto irtglBLK610;
	goto irtglIF613;
irtglIF612:
	local[12]= NIL;
irtglIF613:
	local[12]= local[8];
	local[13]= local[11];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(*ftab[58])(ctx,3,local+12,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[12]= local[8];
	local[13]= local[11];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(*ftab[58])(ctx,3,local+12,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[12]= local[8];
	local[13]= local[11];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[58])(ctx,3,local+12,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[12]= local[0];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)NUMEQUAL(ctx,2,local+12); /*=*/
	if (w!=NIL) goto irtglIF614;
	local[12]= local[2];
	local[13]= local[0];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= local[3];
	local[13]= local[0];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= local[4];
	local[13]= local[0];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= w;
	goto irtglIF615;
irtglIF614:
	local[12]= NIL;
irtglIF615:
	local[12]= local[1];
	local[13]= local[2];
	local[14]= local[3];
	local[15]= local[4];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[78])(ctx,5,local+12,&ftab[78],fqv[233]); /*geometry::pqpaddtri*/
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[5] = w;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[11] = local[12];
	w = NIL;
	ctx->vsp=local+12;
	goto irtglTAG611;
	w = NIL;
	local[11]= w;
irtglBLK610:
	goto irtglCON601;
irtglCON609:
	local[11]= NIL;
irtglCON601:
	w = local[11];
	goto irtglWHL598;
irtglWHX599:
	local[8]= NIL;
irtglBLK600:
	w = NIL;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[79])(ctx,1,local+6,&ftab[79],fqv[234]); /*geometry::pqpendmodel*/
	w = local[1];
	local[0]= w;
irtglBLK591:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO281(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[2];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[55])(ctx,2,local+0,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO430(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[150];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO449(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[150];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO481(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[1];
	local[1]= env->c.clo.env2[0];
	local[2]= fqv[89];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[55])(ctx,2,local+2,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,3,local+0); /*funcall*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:glvertices*/
static pointer irtglM616glbody_glvertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST618:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[16];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[80])(ctx,2,local+1,&ftab[80],fqv[235]); /*user::forward-message-to*/
	local[0]= w;
irtglBLK617:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer irtglM619glbody_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[16]==NIL) goto irtglIF621;
	local[0]= argv[0]->c.obj.iv[16];
	local[1]= fqv[38];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtglIF622;
irtglIF621:
	local[0]= NIL;
irtglIF622:
	w = local[0];
	local[0]= w;
irtglBLK620:
	ctx->vsp=local; return(local[0]);}

/*:set-color*/
static pointer irtglM623glbody_set_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST625:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[154]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[155]));
	local[4]= fqv[236];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	if (argv[0]->c.obj.iv[16]==NIL) goto irtglIF626;
	local[1]= (pointer)get_sym_func(fqv[196]);
	local[2]= argv[0]->c.obj.iv[16];
	local[3]= fqv[236];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtglIF627;
irtglIF626:
	local[1]= NIL;
irtglIF627:
	w = local[1];
	local[0]= w;
irtglBLK624:
	ctx->vsp=local; return(local[0]);}

/*make-glvertices-from-faceset*/
static pointer irtglF9make_glvertices_from_faceset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[237], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtglKEY629;
	local[0] = NIL;
irtglKEY629:
	local[1]= NIL;
	if (local[0]==NIL) goto irtglCON631;
	local[1] = local[0];
	local[2]= local[1];
	goto irtglCON630;
irtglCON631:
	local[2]= argv[0];
	local[3]= fqv[48];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	if (w==NIL) goto irtglCON632;
	local[2]= argv[0];
	local[3]= fqv[48];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)VECTORP(ctx,1,local+3); /*vectorp*/
	if (w!=NIL) goto irtglIF633;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)irtglF7find_color(ctx,1,local+3); /*find-color*/
	local[2] = w;
	local[3]= local[2];
	goto irtglIF634;
irtglIF633:
	local[3]= NIL;
irtglIF634:
	local[3]= fqv[210];
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[114];
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[1] = w;
	w = local[1];
	local[2]= w;
	goto irtglCON630;
irtglCON632:
	local[2]= fqv[210];
	local[3]= makeflt(6.4999999999999991118216e-01);
	local[4]= makeflt(6.4999999999999991118216e-01);
	local[5]= makeflt(6.4999999999999991118216e-01);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	local[3]= fqv[114];
	local[4]= makeflt(6.4999999999999991118216e-01);
	local[5]= makeflt(6.4999999999999991118216e-01);
	local[6]= makeflt(6.4999999999999991118216e-01);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[1] = w;
	local[2]= local[1];
	goto irtglCON630;
irtglCON635:
	local[2]= NIL;
irtglCON630:
	local[2]= argv[0];
	local[3]= fqv[61];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[160];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)irtglF10make_glvertices_from_faces(ctx,3,local+2); /*make-glvertices-from-faces*/
	local[0]= w;
irtglBLK628:
	ctx->vsp=local; return(local[0]);}

/*make-glvertices-from-faces*/
static pointer irtglF10make_glvertices_from_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[238], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtglKEY637;
	local[0] = NIL;
irtglKEY637:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtglCLO638,env,argv,local);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,1,local+1,&ftab[61],fqv[195]); /*flatten*/
	argv[0] = w;
	local[1]= makeint((eusinteger_t)3L);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[1]);
		local[1]=(makeint(i * j));}
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[60])(ctx,2,local+1,&ftab[60],fqv[173]); /*make-matrix*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(*ftab[60])(ctx,2,local+2,&ftab[60],fqv[173]); /*make-matrix*/
	local[2]= w;
	local[3]= loadglobal(fqv[76]);
	local[4]= makeint((eusinteger_t)3L);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[4]);
		local[4]=(makeint(i * j));}
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,2,local+3); /*instantiate*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= argv[0];
irtglWHL639:
	if (local[6]==NIL) goto irtglWHX640;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[69];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VNORMALIZE(ctx,1,local+7); /*normalize-vector*/
	local[7]= w;
	local[8]= local[5];
	local[9]= fqv[62];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[1];
	local[10]= local[4];
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[58])(ctx,4,local+9,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[9]= local[2];
	local[10]= local[4];
	local[11]= local[7];
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[58])(ctx,4,local+9,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[4] = w;
	local[9]= local[1];
	local[10]= local[4];
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[58])(ctx,4,local+9,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[9]= local[2];
	local[10]= local[4];
	local[11]= local[7];
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[58])(ctx,4,local+9,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[4] = w;
	local[9]= local[1];
	local[10]= local[4];
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[58])(ctx,4,local+9,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[9]= local[2];
	local[10]= local[4];
	local[11]= local[7];
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[58])(ctx,4,local+9,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[4] = w;
	w = local[4];
	goto irtglWHL639;
irtglWHX640:
	local[7]= NIL;
irtglBLK641:
	w = NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtglWHL642:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtglWHX643;
	local[7]= local[3];
	local[8]= local[5];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtglWHL642;
irtglWHX643:
	local[7]= NIL;
irtglBLK644:
	w = NIL;
	local[5]= fqv[176];
	local[6]= fqv[177];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[62];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	local[7]= fqv[174];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	local[8]= fqv[172];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,4,local+5); /*list*/
	local[5]= w;
	if (local[0]==NIL) goto irtglIF645;
	local[6]= fqv[160];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	w = local[5];
	ctx->vsp=local+7;
	local[5] = cons(ctx,local[6],w);
	local[6]= local[5];
	goto irtglIF646;
irtglIF645:
	local[6]= NIL;
irtglIF646:
	local[6]= loadglobal(fqv[187]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[95];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	w = local[6];
	local[0]= w;
irtglBLK636:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO638(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[81])(ctx,1,local+0,&ftab[81],fqv[239]); /*geometry::face-to-triangle-aux*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*_dump-wrl-shape*/
static pointer irtglF11_dump_wrl_shape(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[240], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto irtglKEY648;
	local[0] = makeflt(1.0000000000000000000000e+00);
irtglKEY648:
	if (n & (1<<1)) goto irtglKEY649;
	local[1] = NIL;
irtglKEY649:
	if (n & (1<<2)) goto irtglKEY650;
	local[2] = NIL;
irtglKEY650:
	if (n & (1<<3)) goto irtglKEY651;
	local[3] = NIL;
irtglKEY651:
	local[4]= fqv[176];
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(*ftab[55])(ctx,2,local+4,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[172];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(*ftab[55])(ctx,2,local+5,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[62];
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(*ftab[55])(ctx,2,local+6,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[160];
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(*ftab[55])(ctx,2,local+7,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[208];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(*ftab[55])(ctx,2,local+8,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[174];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(*ftab[55])(ctx,2,local+9,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[6]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[241];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= fqv[25];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(*ftab[55])(ctx,2,local+11,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[210];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(*ftab[55])(ctx,2,local+12,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[114];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(*ftab[55])(ctx,2,local+13,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[211];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(*ftab[55])(ctx,2,local+14,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= fqv[212];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(*ftab[55])(ctx,2,local+15,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	local[16]= fqv[213];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(*ftab[55])(ctx,2,local+16,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[214];
	local[18]= local[7];
	ctx->vsp=local+19;
	w=(*ftab[55])(ctx,2,local+17,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= fqv[242];
	local[19]= local[7];
	ctx->vsp=local+20;
	w=(*ftab[55])(ctx,2,local+18,&ftab[55],fqv[157]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	local[19]= argv[0];
	local[20]= fqv[243];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	if (local[13]==NIL) goto irtglIF652;
	local[19]= argv[0];
	local[20]= fqv[244];
	local[21]= local[13];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[13];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= local[13];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,5,local+19); /*format*/
	local[19]= w;
	goto irtglIF653;
irtglIF652:
	local[19]= NIL;
irtglIF653:
	if (local[1]==NIL) goto irtglIF654;
	if (local[12]==NIL) goto irtglIF654;
	local[19]= argv[0];
	local[20]= fqv[245];
	local[21]= local[12];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[12];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= local[12];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,5,local+19); /*format*/
	local[19]= w;
	goto irtglIF655;
irtglIF654:
	local[19]= NIL;
irtglIF655:
	if (local[14]==NIL) goto irtglIF656;
	local[19]= argv[0];
	local[20]= fqv[246];
	local[21]= local[14];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[14];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= local[14];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,5,local+19); /*format*/
	local[19]= w;
	goto irtglIF657;
irtglIF656:
	local[19]= NIL;
irtglIF657:
	if (local[15]==NIL) goto irtglIF658;
	local[19]= argv[0];
	local[20]= fqv[247];
	local[21]= local[15];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[15];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= local[15];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,5,local+19); /*format*/
	local[19]= w;
	goto irtglIF659;
irtglIF658:
	local[19]= NIL;
irtglIF659:
	if (local[16]==NIL) goto irtglIF660;
	local[19]= argv[0];
	local[20]= fqv[248];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,3,local+19); /*format*/
	local[19]= w;
	goto irtglIF661;
irtglIF660:
	local[19]= NIL;
irtglIF661:
	if (local[17]==NIL) goto irtglIF662;
	local[19]= argv[0];
	local[20]= fqv[249];
	local[21]= local[17];
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,3,local+19); /*format*/
	local[19]= w;
	goto irtglIF663;
irtglIF662:
	local[19]= NIL;
irtglIF663:
	local[19]= argv[0];
	local[20]= fqv[250];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	local[19]= argv[0];
	local[20]= fqv[251];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	local[19]= argv[0];
	local[20]= fqv[252];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	local[11]= argv[0];
	local[12]= fqv[253];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[10];
irtglWHL664:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtglWHX665;
	local[14]= local[6];
	local[15]= local[12];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(*ftab[58])(ctx,3,local+14,&ftab[58],fqv[163]); /*user::c-matrix-row*/
	local[14]= argv[0];
	local[15]= fqv[254];
	local[16]= local[0];
	local[17]= local[11];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	local[17]= local[0];
	local[18]= local[11];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	local[18]= local[0];
	local[19]= local[11];
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,5,local+14); /*format*/
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtglWHL664;
irtglWHX665:
	local[14]= NIL;
irtglBLK666:
	w = NIL;
	local[11]= argv[0];
	local[12]= fqv[255];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	if (local[2]==NIL) goto irtglIF667;
	if (local[9]==NIL) goto irtglIF667;
	local[11]= NIL;
	goto irtglIF668;
irtglIF667:
	local[11]= NIL;
irtglIF668:
	if (local[3]==NIL) goto irtglIF669;
	if (local[8]==NIL) goto irtglIF669;
	local[11]= NIL;
	goto irtglIF670;
irtglIF669:
	local[11]= NIL;
irtglIF670:
	local[11]= argv[0];
	local[12]= fqv[256];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
irtglWHL671:
	local[13]= local[11];
	w = local[12];
	if ((eusinteger_t)local[13] >= (eusinteger_t)w) goto irtglWHX672;
	local[13]= argv[0];
	local[14]= fqv[257];
	local[15]= local[5];
	local[16]= local[11];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[16]);
		local[16]=(makeint(i * j));}
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[5];
	local[17]= local[11];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[5];
	local[18]= local[11];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[18]);
		local[18]=(makeint(i * j));}
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[18]= (pointer)((eusinteger_t)local[18] + (eusinteger_t)w);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[11] = w;
	goto irtglWHL671;
irtglWHX672:
	local[13]= NIL;
irtglBLK673:
	w = NIL;
	local[11]= argv[0];
	local[12]= fqv[258];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[0]= w;
irtglBLK647:
	ctx->vsp=local; return(local[0]);}

/*write-wrl-from-glvertices*/
static pointer irtglF12write_wrl_from_glvertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST675:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= *(ovafptr(argv[1],fqv[199]));
	local[2]= argv[0];
	local[3]= fqv[259];
	local[4]= fqv[260];
	ctx->vsp=local+5;
	w=(*ftab[82])(ctx,3,local+2,&ftab[82],fqv[261]); /*open*/
	local[2]= w;
	ctx->vsp=local+3;
	w = makeclosure(codevec,quotevec,irtglUWP676,env,argv,local);
	local[3]=(pointer)(ctx->protfp); local[4]=w;
	ctx->protfp=(struct protectframe *)(local+3);
	local[5]= local[2];
	local[6]= fqv[262];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= local[2];
	local[6]= fqv[263];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= NIL;
	local[6]= local[1];
irtglWHL677:
	if (local[6]==NIL) goto irtglWHX678;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= (pointer)get_sym_func(fqv[264]);
	local[8]= local[2];
	local[9]= local[5];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,4,local+7); /*apply*/
	goto irtglWHL677;
irtglWHX678:
	local[7]= NIL;
irtglBLK679:
	w = NIL;
	local[5]= local[2];
	local[6]= fqv[265];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= local[2];
	local[6]= fqv[266];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	ctx->vsp=local+5;
	irtglUWP676(ctx,0,local+5,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
irtglBLK674:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglUWP676(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[2];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtgl(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[267];
	ctx->vsp=local+1;
	w=(*ftab[83])(ctx,1,local+0,&ftab[83],fqv[268]); /*require*/
	local[0]= fqv[269];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtglIF680;
	local[0]= fqv[270];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[271],w);
	goto irtglIF681;
irtglIF680:
	local[0]= fqv[272];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtglIF681:
	local[0]= NIL;
	ctx->vsp=local+1;
	w=(*ftab[84])(ctx,0,local+1,&ftab[84],fqv[273]); /*system::sysmod*/
	local[0] = w;
	local[1]= fqv[65];
	local[2]= fqv[274];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[276];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)10752L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[278];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)10753L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[279];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)10754L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[280];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32823L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[281];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32824L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[282];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32823L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[283];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32824L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[284];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32825L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[218];
	local[2]= fqv[285];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[227];
	local[2]= fqv[286];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[219];
	local[2]= fqv[287];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[288];
	local[2]= fqv[289];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[220];
	local[2]= fqv[290];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[221];
	local[2]= fqv[291];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[225];
	local[2]= fqv[292];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[293];
	local[2]= fqv[294];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[226];
	local[2]= fqv[295];
	local[3]= fqv[180];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[85])(ctx,4,local+2,&ftab[85],fqv[275]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[296];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32884L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[297];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32885L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[298];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32888L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[299];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32889L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[300];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32886L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[301];
	local[2]= fqv[277];
	local[3]= makeint((eusinteger_t)32887L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[302],module,irtglF1set_stereo_gl_attribute,fqv[303]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[304],module,irtglF2reset_gl_attribute,fqv[305]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[306],module,irtglF3delete_displaylist_id,fqv[307]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[308],module,irtglF4transpose_image_rows,fqv[309]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[310],module,irtglF5draw_globjects,fqv[311]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[312],module,irtglF6draw_glbody,fqv[313]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[314],module,irtglF7find_color,fqv[315]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[316],module,irtglF8transparent,fqv[317]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM163polygon_draw_on,fqv[41],fqv[318],fqv[319]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM173line_draw_on,fqv[41],fqv[320],fqv[321]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM183faceset_set_color,fqv[236],fqv[40],fqv[322]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM190faceset_draw_on,fqv[41],fqv[40],fqv[323]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM203faceset_paste_texture_to_face,fqv[324],fqv[40],fqv[325]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM221coordinates_vertices,fqv[62],fqv[326],fqv[327]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM223coordinates_draw_on,fqv[41],fqv[326],fqv[328]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM243float_vector_vertices,fqv[62],fqv[119],fqv[329]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM245float_vector_draw_on,fqv[41],fqv[119],fqv[330]);
	local[0]= fqv[187];
	local[1]= fqv[331];
	local[2]= fqv[187];
	local[3]= fqv[332];
	local[4]= loadglobal(fqv[333]);
	local[5]= fqv[334];
	local[6]= fqv[335];
	local[7]= fqv[336];
	local[8]= NIL;
	local[9]= fqv[1];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[337];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[86])(ctx,13,local+2,&ftab[86],fqv[338]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM259glvertices_init,fqv[95],fqv[187],fqv[339]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM263glvertices_filename,fqv[242],fqv[187],fqv[340]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM269glvertices_set_color,fqv[236],fqv[187],fqv[341]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM275glvertices_get_meshinfo,fqv[159],fqv[187],fqv[342]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM282glvertices_set_meshinfo,fqv[161],fqv[187],fqv[343]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM291glvertices_get_material,fqv[344],fqv[187],fqv[345]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM295glvertices_set_material,fqv[346],fqv[187],fqv[347]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM299glvertices_actual_vertices,fqv[164],fqv[187],fqv[348]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM309glvertices_calc_bounding_box,fqv[166],fqv[187],fqv[349]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM311glvertices_vertices,fqv[62],fqv[187],fqv[350]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM315glvertices_reset_offset_from_parent,fqv[351],fqv[187],fqv[352]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM317glvertices_expand_vertices,fqv[353],fqv[187],fqv[354]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM322glvertices_expand_vertices_info,fqv[171],fqv[187],fqv[355]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM329glvertices_use_flat_shader,fqv[356],fqv[187],fqv[357]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM334glvertices_use_smooth_shader,fqv[358],fqv[187],fqv[359]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM341glvertices_calc_normals,fqv[360],fqv[187],fqv[361]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM378glvertices_mirror_axis,fqv[362],fqv[187],fqv[363]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM404glvertices_convert_to_faces,fqv[193],fqv[187],fqv[364]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM456glvertices_faces,fqv[61],fqv[187],fqv[365]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM458glvertices_convert_to_faceset,fqv[366],fqv[187],fqv[367]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM461glvertices_set_offset,fqv[169],fqv[187],fqv[368]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM471glvertices_convert_to_world,fqv[369],fqv[187],fqv[370]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM474glvertices_glvertices,fqv[371],fqv[187],fqv[372]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM488glvertices_append_glvertices,fqv[373],fqv[187],fqv[374]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM495glvertices_draw_on,fqv[41],fqv[187],fqv[375]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM498glvertices_draw,fqv[38],fqv[187],fqv[376]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM583glvertices_collision_check_objects,fqv[377],fqv[187],fqv[378]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM586glvertices_box,fqv[379],fqv[187],fqv[380]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM590glvertices_make_pqpmodel,fqv[381],fqv[187],fqv[382]);
	local[0]= fqv[383];
	local[1]= fqv[331];
	local[2]= fqv[383];
	local[3]= fqv[332];
	local[4]= loadglobal(fqv[384]);
	local[5]= fqv[334];
	local[6]= fqv[385];
	local[7]= fqv[336];
	local[8]= NIL;
	local[9]= fqv[1];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[337];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[86])(ctx,13,local+2,&ftab[86],fqv[338]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM616glbody_glvertices,fqv[371],fqv[383],fqv[386]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM619glbody_draw,fqv[38],fqv[383],fqv[387]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM623glbody_set_color,fqv[236],fqv[383],fqv[388]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[389],module,irtglF9make_glvertices_from_faceset,fqv[390]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[391],module,irtglF10make_glvertices_from_faces,fqv[392]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[264],module,irtglF11_dump_wrl_shape,fqv[393]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[394],module,irtglF12write_wrl_from_glvertices,fqv[395]);
	local[0]= fqv[396];
	local[1]= fqv[397];
	ctx->vsp=local+2;
	w=(*ftab[87])(ctx,2,local+0,&ftab[87],fqv[398]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<88; i++) ftab[i]=fcallx;
}


"use strict";

let MultipleUpload = require('./MultipleUpload.js')
let Upload = require('./Upload.js')

module.exports = {
  MultipleUpload: MultipleUpload,
  Upload: Upload,
};

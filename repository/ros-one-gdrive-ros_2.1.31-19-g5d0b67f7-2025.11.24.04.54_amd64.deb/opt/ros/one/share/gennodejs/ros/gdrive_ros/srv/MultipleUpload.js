// Auto-generated. Do not edit!

// (in-package gdrive_ros.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class MultipleUploadRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.file_paths = null;
      this.file_titles = null;
      this.parents_path = null;
      this.parents_id = null;
      this.use_timestamp_folder = null;
      this.use_timestamp_file_title = null;
    }
    else {
      if (initObj.hasOwnProperty('file_paths')) {
        this.file_paths = initObj.file_paths
      }
      else {
        this.file_paths = [];
      }
      if (initObj.hasOwnProperty('file_titles')) {
        this.file_titles = initObj.file_titles
      }
      else {
        this.file_titles = [];
      }
      if (initObj.hasOwnProperty('parents_path')) {
        this.parents_path = initObj.parents_path
      }
      else {
        this.parents_path = '';
      }
      if (initObj.hasOwnProperty('parents_id')) {
        this.parents_id = initObj.parents_id
      }
      else {
        this.parents_id = '';
      }
      if (initObj.hasOwnProperty('use_timestamp_folder')) {
        this.use_timestamp_folder = initObj.use_timestamp_folder
      }
      else {
        this.use_timestamp_folder = false;
      }
      if (initObj.hasOwnProperty('use_timestamp_file_title')) {
        this.use_timestamp_file_title = initObj.use_timestamp_file_title
      }
      else {
        this.use_timestamp_file_title = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MultipleUploadRequest
    // Serialize message field [file_paths]
    bufferOffset = _arraySerializer.string(obj.file_paths, buffer, bufferOffset, null);
    // Serialize message field [file_titles]
    bufferOffset = _arraySerializer.string(obj.file_titles, buffer, bufferOffset, null);
    // Serialize message field [parents_path]
    bufferOffset = _serializer.string(obj.parents_path, buffer, bufferOffset);
    // Serialize message field [parents_id]
    bufferOffset = _serializer.string(obj.parents_id, buffer, bufferOffset);
    // Serialize message field [use_timestamp_folder]
    bufferOffset = _serializer.bool(obj.use_timestamp_folder, buffer, bufferOffset);
    // Serialize message field [use_timestamp_file_title]
    bufferOffset = _serializer.bool(obj.use_timestamp_file_title, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MultipleUploadRequest
    let len;
    let data = new MultipleUploadRequest(null);
    // Deserialize message field [file_paths]
    data.file_paths = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [file_titles]
    data.file_titles = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [parents_path]
    data.parents_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parents_id]
    data.parents_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [use_timestamp_folder]
    data.use_timestamp_folder = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [use_timestamp_file_title]
    data.use_timestamp_file_title = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.file_paths.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.file_titles.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.parents_path);
    length += _getByteLength(object.parents_id);
    return length + 18;
  }

  static datatype() {
    // Returns string type for a service object
    return 'gdrive_ros/MultipleUploadRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '122e5b4128de0fb81389f9b17153330d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] file_paths
    string[] file_titles
    string parents_path
    string parents_id
    bool use_timestamp_folder
    bool use_timestamp_file_title
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MultipleUploadRequest(null);
    if (msg.file_paths !== undefined) {
      resolved.file_paths = msg.file_paths;
    }
    else {
      resolved.file_paths = []
    }

    if (msg.file_titles !== undefined) {
      resolved.file_titles = msg.file_titles;
    }
    else {
      resolved.file_titles = []
    }

    if (msg.parents_path !== undefined) {
      resolved.parents_path = msg.parents_path;
    }
    else {
      resolved.parents_path = ''
    }

    if (msg.parents_id !== undefined) {
      resolved.parents_id = msg.parents_id;
    }
    else {
      resolved.parents_id = ''
    }

    if (msg.use_timestamp_folder !== undefined) {
      resolved.use_timestamp_folder = msg.use_timestamp_folder;
    }
    else {
      resolved.use_timestamp_folder = false
    }

    if (msg.use_timestamp_file_title !== undefined) {
      resolved.use_timestamp_file_title = msg.use_timestamp_file_title;
    }
    else {
      resolved.use_timestamp_file_title = false
    }

    return resolved;
    }
};

class MultipleUploadResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.successes = null;
      this.file_ids = null;
      this.file_urls = null;
      this.parents_id = null;
      this.parents_url = null;
    }
    else {
      if (initObj.hasOwnProperty('successes')) {
        this.successes = initObj.successes
      }
      else {
        this.successes = [];
      }
      if (initObj.hasOwnProperty('file_ids')) {
        this.file_ids = initObj.file_ids
      }
      else {
        this.file_ids = [];
      }
      if (initObj.hasOwnProperty('file_urls')) {
        this.file_urls = initObj.file_urls
      }
      else {
        this.file_urls = [];
      }
      if (initObj.hasOwnProperty('parents_id')) {
        this.parents_id = initObj.parents_id
      }
      else {
        this.parents_id = '';
      }
      if (initObj.hasOwnProperty('parents_url')) {
        this.parents_url = initObj.parents_url
      }
      else {
        this.parents_url = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MultipleUploadResponse
    // Serialize message field [successes]
    bufferOffset = _arraySerializer.bool(obj.successes, buffer, bufferOffset, null);
    // Serialize message field [file_ids]
    bufferOffset = _arraySerializer.string(obj.file_ids, buffer, bufferOffset, null);
    // Serialize message field [file_urls]
    bufferOffset = _arraySerializer.string(obj.file_urls, buffer, bufferOffset, null);
    // Serialize message field [parents_id]
    bufferOffset = _serializer.string(obj.parents_id, buffer, bufferOffset);
    // Serialize message field [parents_url]
    bufferOffset = _serializer.string(obj.parents_url, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MultipleUploadResponse
    let len;
    let data = new MultipleUploadResponse(null);
    // Deserialize message field [successes]
    data.successes = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [file_ids]
    data.file_ids = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [file_urls]
    data.file_urls = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [parents_id]
    data.parents_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parents_url]
    data.parents_url = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.successes.length;
    object.file_ids.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.file_urls.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.parents_id);
    length += _getByteLength(object.parents_url);
    return length + 20;
  }

  static datatype() {
    // Returns string type for a service object
    return 'gdrive_ros/MultipleUploadResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '060c3b54ca60104d86730aba3a3da16c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool[] successes
    string[] file_ids
    string[] file_urls
    string parents_id
    string parents_url
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MultipleUploadResponse(null);
    if (msg.successes !== undefined) {
      resolved.successes = msg.successes;
    }
    else {
      resolved.successes = []
    }

    if (msg.file_ids !== undefined) {
      resolved.file_ids = msg.file_ids;
    }
    else {
      resolved.file_ids = []
    }

    if (msg.file_urls !== undefined) {
      resolved.file_urls = msg.file_urls;
    }
    else {
      resolved.file_urls = []
    }

    if (msg.parents_id !== undefined) {
      resolved.parents_id = msg.parents_id;
    }
    else {
      resolved.parents_id = ''
    }

    if (msg.parents_url !== undefined) {
      resolved.parents_url = msg.parents_url;
    }
    else {
      resolved.parents_url = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: MultipleUploadRequest,
  Response: MultipleUploadResponse,
  md5sum() { return '6ce04b4ad1fd58ceadb6d132fb43ce42'; },
  datatype() { return 'gdrive_ros/MultipleUpload'; }
};

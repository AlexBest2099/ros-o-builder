
(cl:in-package :asdf)

(defsystem "gdrive_ros-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "MultipleUpload" :depends-on ("_package_MultipleUpload"))
    (:file "_package_MultipleUpload" :depends-on ("_package"))
    (:file "Upload" :depends-on ("_package_Upload"))
    (:file "_package_Upload" :depends-on ("_package"))
  ))
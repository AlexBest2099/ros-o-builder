; Auto-generated. Do not edit!


(cl:in-package gdrive_ros-srv)


;//! \htmlinclude Upload-request.msg.html

(cl:defclass <Upload-request> (roslisp-msg-protocol:ros-message)
  ((file_path
    :reader file_path
    :initarg :file_path
    :type cl:string
    :initform "")
   (file_title
    :reader file_title
    :initarg :file_title
    :type cl:string
    :initform "")
   (parents_path
    :reader parents_path
    :initarg :parents_path
    :type cl:string
    :initform "")
   (parents_id
    :reader parents_id
    :initarg :parents_id
    :type cl:string
    :initform "")
   (use_timestamp_folder
    :reader use_timestamp_folder
    :initarg :use_timestamp_folder
    :type cl:boolean
    :initform cl:nil)
   (use_timestamp_file_title
    :reader use_timestamp_file_title
    :initarg :use_timestamp_file_title
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass Upload-request (<Upload-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Upload-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Upload-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name gdrive_ros-srv:<Upload-request> is deprecated: use gdrive_ros-srv:Upload-request instead.")))

(cl:ensure-generic-function 'file_path-val :lambda-list '(m))
(cl:defmethod file_path-val ((m <Upload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:file_path-val is deprecated.  Use gdrive_ros-srv:file_path instead.")
  (file_path m))

(cl:ensure-generic-function 'file_title-val :lambda-list '(m))
(cl:defmethod file_title-val ((m <Upload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:file_title-val is deprecated.  Use gdrive_ros-srv:file_title instead.")
  (file_title m))

(cl:ensure-generic-function 'parents_path-val :lambda-list '(m))
(cl:defmethod parents_path-val ((m <Upload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:parents_path-val is deprecated.  Use gdrive_ros-srv:parents_path instead.")
  (parents_path m))

(cl:ensure-generic-function 'parents_id-val :lambda-list '(m))
(cl:defmethod parents_id-val ((m <Upload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:parents_id-val is deprecated.  Use gdrive_ros-srv:parents_id instead.")
  (parents_id m))

(cl:ensure-generic-function 'use_timestamp_folder-val :lambda-list '(m))
(cl:defmethod use_timestamp_folder-val ((m <Upload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:use_timestamp_folder-val is deprecated.  Use gdrive_ros-srv:use_timestamp_folder instead.")
  (use_timestamp_folder m))

(cl:ensure-generic-function 'use_timestamp_file_title-val :lambda-list '(m))
(cl:defmethod use_timestamp_file_title-val ((m <Upload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:use_timestamp_file_title-val is deprecated.  Use gdrive_ros-srv:use_timestamp_file_title instead.")
  (use_timestamp_file_title m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Upload-request>) ostream)
  "Serializes a message object of type '<Upload-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'file_path))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'file_path))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'file_title))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'file_title))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parents_path))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parents_path))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parents_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parents_id))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'use_timestamp_folder) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'use_timestamp_file_title) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Upload-request>) istream)
  "Deserializes a message object of type '<Upload-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'file_path) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'file_path) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'file_title) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'file_title) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parents_path) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parents_path) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parents_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parents_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'use_timestamp_folder) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'use_timestamp_file_title) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Upload-request>)))
  "Returns string type for a service object of type '<Upload-request>"
  "gdrive_ros/UploadRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Upload-request)))
  "Returns string type for a service object of type 'Upload-request"
  "gdrive_ros/UploadRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Upload-request>)))
  "Returns md5sum for a message object of type '<Upload-request>"
  "27634bfec9309170d00ba7c592dae289")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Upload-request)))
  "Returns md5sum for a message object of type 'Upload-request"
  "27634bfec9309170d00ba7c592dae289")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Upload-request>)))
  "Returns full string definition for message of type '<Upload-request>"
  (cl:format cl:nil "string file_path~%string file_title~%string parents_path~%string parents_id~%bool use_timestamp_folder~%bool use_timestamp_file_title~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Upload-request)))
  "Returns full string definition for message of type 'Upload-request"
  (cl:format cl:nil "string file_path~%string file_title~%string parents_path~%string parents_id~%bool use_timestamp_folder~%bool use_timestamp_file_title~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Upload-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'file_path))
     4 (cl:length (cl:slot-value msg 'file_title))
     4 (cl:length (cl:slot-value msg 'parents_path))
     4 (cl:length (cl:slot-value msg 'parents_id))
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Upload-request>))
  "Converts a ROS message object to a list"
  (cl:list 'Upload-request
    (cl:cons ':file_path (file_path msg))
    (cl:cons ':file_title (file_title msg))
    (cl:cons ':parents_path (parents_path msg))
    (cl:cons ':parents_id (parents_id msg))
    (cl:cons ':use_timestamp_folder (use_timestamp_folder msg))
    (cl:cons ':use_timestamp_file_title (use_timestamp_file_title msg))
))
;//! \htmlinclude Upload-response.msg.html

(cl:defclass <Upload-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (file_id
    :reader file_id
    :initarg :file_id
    :type cl:string
    :initform "")
   (file_url
    :reader file_url
    :initarg :file_url
    :type cl:string
    :initform "")
   (parents_id
    :reader parents_id
    :initarg :parents_id
    :type cl:string
    :initform "")
   (parents_url
    :reader parents_url
    :initarg :parents_url
    :type cl:string
    :initform ""))
)

(cl:defclass Upload-response (<Upload-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Upload-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Upload-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name gdrive_ros-srv:<Upload-response> is deprecated: use gdrive_ros-srv:Upload-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <Upload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:success-val is deprecated.  Use gdrive_ros-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'file_id-val :lambda-list '(m))
(cl:defmethod file_id-val ((m <Upload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:file_id-val is deprecated.  Use gdrive_ros-srv:file_id instead.")
  (file_id m))

(cl:ensure-generic-function 'file_url-val :lambda-list '(m))
(cl:defmethod file_url-val ((m <Upload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:file_url-val is deprecated.  Use gdrive_ros-srv:file_url instead.")
  (file_url m))

(cl:ensure-generic-function 'parents_id-val :lambda-list '(m))
(cl:defmethod parents_id-val ((m <Upload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:parents_id-val is deprecated.  Use gdrive_ros-srv:parents_id instead.")
  (parents_id m))

(cl:ensure-generic-function 'parents_url-val :lambda-list '(m))
(cl:defmethod parents_url-val ((m <Upload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:parents_url-val is deprecated.  Use gdrive_ros-srv:parents_url instead.")
  (parents_url m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Upload-response>) ostream)
  "Serializes a message object of type '<Upload-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'file_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'file_id))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'file_url))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'file_url))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parents_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parents_id))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parents_url))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parents_url))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Upload-response>) istream)
  "Deserializes a message object of type '<Upload-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'file_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'file_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'file_url) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'file_url) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parents_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parents_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parents_url) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parents_url) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Upload-response>)))
  "Returns string type for a service object of type '<Upload-response>"
  "gdrive_ros/UploadResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Upload-response)))
  "Returns string type for a service object of type 'Upload-response"
  "gdrive_ros/UploadResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Upload-response>)))
  "Returns md5sum for a message object of type '<Upload-response>"
  "27634bfec9309170d00ba7c592dae289")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Upload-response)))
  "Returns md5sum for a message object of type 'Upload-response"
  "27634bfec9309170d00ba7c592dae289")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Upload-response>)))
  "Returns full string definition for message of type '<Upload-response>"
  (cl:format cl:nil "bool success~%string file_id~%string file_url~%string parents_id~%string parents_url~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Upload-response)))
  "Returns full string definition for message of type 'Upload-response"
  (cl:format cl:nil "bool success~%string file_id~%string file_url~%string parents_id~%string parents_url~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Upload-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'file_id))
     4 (cl:length (cl:slot-value msg 'file_url))
     4 (cl:length (cl:slot-value msg 'parents_id))
     4 (cl:length (cl:slot-value msg 'parents_url))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Upload-response>))
  "Converts a ROS message object to a list"
  (cl:list 'Upload-response
    (cl:cons ':success (success msg))
    (cl:cons ':file_id (file_id msg))
    (cl:cons ':file_url (file_url msg))
    (cl:cons ':parents_id (parents_id msg))
    (cl:cons ':parents_url (parents_url msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'Upload)))
  'Upload-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'Upload)))
  'Upload-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Upload)))
  "Returns string type for a service object of type '<Upload>"
  "gdrive_ros/Upload")
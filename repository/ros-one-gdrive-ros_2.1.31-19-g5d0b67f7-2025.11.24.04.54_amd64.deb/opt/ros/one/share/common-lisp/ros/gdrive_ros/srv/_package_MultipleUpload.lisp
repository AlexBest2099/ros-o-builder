(cl:in-package gdrive_ros-srv)
(cl:export '(FILE_PATHS-VAL
          FILE_PATHS
          FILE_TITLES-VAL
          FILE_TITLES
          PARENTS_PATH-VAL
          PARENTS_PATH
          PARENTS_ID-VAL
          PARENTS_ID
          USE_TIMESTAMP_FOLDER-VAL
          USE_TIMESTAMP_FOLDER
          USE_TIMESTAMP_FILE_TITLE-VAL
          USE_TIMESTAMP_FILE_TITLE
          SUCCESSES-VAL
          SUCCESSES
          FILE_IDS-VAL
          FILE_IDS
          FILE_URLS-VAL
          FILE_URLS
          PARENTS_ID-VAL
          PARENTS_ID
          PARENTS_URL-VAL
          PARENTS_URL
))
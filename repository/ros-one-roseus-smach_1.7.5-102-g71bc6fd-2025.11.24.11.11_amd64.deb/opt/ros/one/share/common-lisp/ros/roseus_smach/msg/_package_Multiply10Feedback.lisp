(cl:in-package roseus_smach-msg)
(cl:export '(VALUE-VAL
          VALUE
))
(cl:in-package image_view2-msg)
(cl:export '(HEADER-VAL
          HEADER
          TYPE-VAL
          TYPE
          KEY-VAL
          KEY
          X-VAL
          X
          Y-VAL
          Y
          WIDTH-VAL
          WIDTH
          HEIGHT-VAL
          HEIGHT
))
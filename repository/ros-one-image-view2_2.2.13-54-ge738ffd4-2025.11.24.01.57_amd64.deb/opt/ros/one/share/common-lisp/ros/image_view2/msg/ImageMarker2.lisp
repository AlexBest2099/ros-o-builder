; Auto-generated. Do not edit!


(cl:in-package image_view2-msg)


;//! \htmlinclude ImageMarker2.msg.html

(cl:defclass <ImageMarker2> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (ns
    :reader ns
    :initarg :ns
    :type cl:string
    :initform "")
   (id
    :reader id
    :initarg :id
    :type cl:integer
    :initform 0)
   (type
    :reader type
    :initarg :type
    :type cl:integer
    :initform 0)
   (action
    :reader action
    :initarg :action
    :type cl:integer
    :initform 0)
   (position
    :reader position
    :initarg :position
    :type geometry_msgs-msg:Point
    :initform (cl:make-instance 'geometry_msgs-msg:Point))
   (position3D
    :reader position3D
    :initarg :position3D
    :type geometry_msgs-msg:PointStamped
    :initform (cl:make-instance 'geometry_msgs-msg:PointStamped))
   (pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:PoseStamped
    :initform (cl:make-instance 'geometry_msgs-msg:PoseStamped))
   (scale
    :reader scale
    :initarg :scale
    :type cl:float
    :initform 0.0)
   (width
    :reader width
    :initarg :width
    :type cl:float
    :initform 0.0)
   (outline_color
    :reader outline_color
    :initarg :outline_color
    :type std_msgs-msg:ColorRGBA
    :initform (cl:make-instance 'std_msgs-msg:ColorRGBA))
   (filled
    :reader filled
    :initarg :filled
    :type cl:integer
    :initform 0)
   (fill_color
    :reader fill_color
    :initarg :fill_color
    :type std_msgs-msg:ColorRGBA
    :initform (cl:make-instance 'std_msgs-msg:ColorRGBA))
   (lifetime
    :reader lifetime
    :initarg :lifetime
    :type cl:real
    :initform 0)
   (arc
    :reader arc
    :initarg :arc
    :type cl:integer
    :initform 0)
   (angle
    :reader angle
    :initarg :angle
    :type cl:float
    :initform 0.0)
   (points
    :reader points
    :initarg :points
    :type (cl:vector geometry_msgs-msg:Point)
   :initform (cl:make-array 0 :element-type 'geometry_msgs-msg:Point :initial-element (cl:make-instance 'geometry_msgs-msg:Point)))
   (points3D
    :reader points3D
    :initarg :points3D
    :type image_view2-msg:PointArrayStamped
    :initform (cl:make-instance 'image_view2-msg:PointArrayStamped))
   (outline_colors
    :reader outline_colors
    :initarg :outline_colors
    :type (cl:vector std_msgs-msg:ColorRGBA)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:ColorRGBA :initial-element (cl:make-instance 'std_msgs-msg:ColorRGBA)))
   (frames
    :reader frames
    :initarg :frames
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (text
    :reader text
    :initarg :text
    :type cl:string
    :initform "")
   (left_up_origin
    :reader left_up_origin
    :initarg :left_up_origin
    :type cl:boolean
    :initform cl:nil)
   (ratio_scale
    :reader ratio_scale
    :initarg :ratio_scale
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass ImageMarker2 (<ImageMarker2>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ImageMarker2>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ImageMarker2)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name image_view2-msg:<ImageMarker2> is deprecated: use image_view2-msg:ImageMarker2 instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:header-val is deprecated.  Use image_view2-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'ns-val :lambda-list '(m))
(cl:defmethod ns-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:ns-val is deprecated.  Use image_view2-msg:ns instead.")
  (ns m))

(cl:ensure-generic-function 'id-val :lambda-list '(m))
(cl:defmethod id-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:id-val is deprecated.  Use image_view2-msg:id instead.")
  (id m))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:type-val is deprecated.  Use image_view2-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'action-val :lambda-list '(m))
(cl:defmethod action-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:action-val is deprecated.  Use image_view2-msg:action instead.")
  (action m))

(cl:ensure-generic-function 'position-val :lambda-list '(m))
(cl:defmethod position-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:position-val is deprecated.  Use image_view2-msg:position instead.")
  (position m))

(cl:ensure-generic-function 'position3D-val :lambda-list '(m))
(cl:defmethod position3D-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:position3D-val is deprecated.  Use image_view2-msg:position3D instead.")
  (position3D m))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:pose-val is deprecated.  Use image_view2-msg:pose instead.")
  (pose m))

(cl:ensure-generic-function 'scale-val :lambda-list '(m))
(cl:defmethod scale-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:scale-val is deprecated.  Use image_view2-msg:scale instead.")
  (scale m))

(cl:ensure-generic-function 'width-val :lambda-list '(m))
(cl:defmethod width-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:width-val is deprecated.  Use image_view2-msg:width instead.")
  (width m))

(cl:ensure-generic-function 'outline_color-val :lambda-list '(m))
(cl:defmethod outline_color-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:outline_color-val is deprecated.  Use image_view2-msg:outline_color instead.")
  (outline_color m))

(cl:ensure-generic-function 'filled-val :lambda-list '(m))
(cl:defmethod filled-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:filled-val is deprecated.  Use image_view2-msg:filled instead.")
  (filled m))

(cl:ensure-generic-function 'fill_color-val :lambda-list '(m))
(cl:defmethod fill_color-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:fill_color-val is deprecated.  Use image_view2-msg:fill_color instead.")
  (fill_color m))

(cl:ensure-generic-function 'lifetime-val :lambda-list '(m))
(cl:defmethod lifetime-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:lifetime-val is deprecated.  Use image_view2-msg:lifetime instead.")
  (lifetime m))

(cl:ensure-generic-function 'arc-val :lambda-list '(m))
(cl:defmethod arc-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:arc-val is deprecated.  Use image_view2-msg:arc instead.")
  (arc m))

(cl:ensure-generic-function 'angle-val :lambda-list '(m))
(cl:defmethod angle-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:angle-val is deprecated.  Use image_view2-msg:angle instead.")
  (angle m))

(cl:ensure-generic-function 'points-val :lambda-list '(m))
(cl:defmethod points-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:points-val is deprecated.  Use image_view2-msg:points instead.")
  (points m))

(cl:ensure-generic-function 'points3D-val :lambda-list '(m))
(cl:defmethod points3D-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:points3D-val is deprecated.  Use image_view2-msg:points3D instead.")
  (points3D m))

(cl:ensure-generic-function 'outline_colors-val :lambda-list '(m))
(cl:defmethod outline_colors-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:outline_colors-val is deprecated.  Use image_view2-msg:outline_colors instead.")
  (outline_colors m))

(cl:ensure-generic-function 'frames-val :lambda-list '(m))
(cl:defmethod frames-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:frames-val is deprecated.  Use image_view2-msg:frames instead.")
  (frames m))

(cl:ensure-generic-function 'text-val :lambda-list '(m))
(cl:defmethod text-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:text-val is deprecated.  Use image_view2-msg:text instead.")
  (text m))

(cl:ensure-generic-function 'left_up_origin-val :lambda-list '(m))
(cl:defmethod left_up_origin-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:left_up_origin-val is deprecated.  Use image_view2-msg:left_up_origin instead.")
  (left_up_origin m))

(cl:ensure-generic-function 'ratio_scale-val :lambda-list '(m))
(cl:defmethod ratio_scale-val ((m <ImageMarker2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader image_view2-msg:ratio_scale-val is deprecated.  Use image_view2-msg:ratio_scale instead.")
  (ratio_scale m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<ImageMarker2>)))
    "Constants for message type '<ImageMarker2>"
  '((:CIRCLE . 0)
    (:LINE_STRIP . 1)
    (:LINE_LIST . 2)
    (:POLYGON . 3)
    (:POINTS . 4)
    (:FRAMES . 5)
    (:TEXT . 6)
    (:LINE_STRIP3D . 7)
    (:LINE_LIST3D . 8)
    (:POLYGON3D . 9)
    (:POINTS3D . 10)
    (:TEXT3D . 11)
    (:CIRCLE3D . 12)
    (:ADD . 0)
    (:REMOVE . 1))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'ImageMarker2)))
    "Constants for message type 'ImageMarker2"
  '((:CIRCLE . 0)
    (:LINE_STRIP . 1)
    (:LINE_LIST . 2)
    (:POLYGON . 3)
    (:POINTS . 4)
    (:FRAMES . 5)
    (:TEXT . 6)
    (:LINE_STRIP3D . 7)
    (:LINE_LIST3D . 8)
    (:POLYGON3D . 9)
    (:POINTS3D . 10)
    (:TEXT3D . 11)
    (:CIRCLE3D . 12)
    (:ADD . 0)
    (:REMOVE . 1))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ImageMarker2>) ostream)
  "Serializes a message object of type '<ImageMarker2>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'ns))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'ns))
  (cl:let* ((signed (cl:slot-value msg 'id)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'type)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'action)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'position) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'position3D) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'scale))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'width))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'outline_color) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'filled)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'fill_color) ostream)
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'lifetime)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'lifetime) (cl:floor (cl:slot-value msg 'lifetime)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'arc)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'angle))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'points))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'points))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'points3D) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'outline_colors))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'outline_colors))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'frames))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'frames))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'text))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'text))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'left_up_origin) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'ratio_scale) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ImageMarker2>) istream)
  "Deserializes a message object of type '<ImageMarker2>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'ns) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'ns) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'id) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'type) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'action) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'position) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'position3D) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'scale) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'width) (roslisp-utils:decode-single-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'outline_color) istream)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'filled)) (cl:read-byte istream))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'fill_color) istream)
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'lifetime) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'arc)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'angle) (roslisp-utils:decode-single-float-bits bits)))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'points) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'points)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'geometry_msgs-msg:Point))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'points3D) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'outline_colors) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'outline_colors)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:ColorRGBA))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'frames) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'frames)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'text) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'text) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'left_up_origin) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'ratio_scale) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ImageMarker2>)))
  "Returns string type for a message object of type '<ImageMarker2>"
  "image_view2/ImageMarker2")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ImageMarker2)))
  "Returns string type for a message object of type 'ImageMarker2"
  "image_view2/ImageMarker2")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ImageMarker2>)))
  "Returns md5sum for a message object of type '<ImageMarker2>"
  "8efc23e411f94f2c04288719c078c291")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ImageMarker2)))
  "Returns md5sum for a message object of type 'ImageMarker2"
  "8efc23e411f94f2c04288719c078c291")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ImageMarker2>)))
  "Returns full string definition for message of type '<ImageMarker2>"
  (cl:format cl:nil "byte CIRCLE=0~%byte LINE_STRIP=1~%byte LINE_LIST=2~%byte POLYGON=3~%byte POINTS=4~%byte FRAMES=5~%byte TEXT=6~%~%byte LINE_STRIP3D=7~%byte LINE_LIST3D=8~%byte POLYGON3D=9~%byte POINTS3D=10~%byte TEXT3D=11~%byte CIRCLE3D=12~%~%byte ADD=0~%byte REMOVE=1~%~%Header header~%string ns		# namespace, used with id to form a unique id~%int32 id          	# unique id within the namespace~%int32 type        	# CIRCLE/LINE_STRIP/etc.~%int32 action      	# ADD/REMOVE~%geometry_msgs/Point position # used for CIRCLE/TEXT, 2D in pixel-coords~%geometry_msgs/PointStamped position3D # used for 3DTEXT~%geometry_msgs/PoseStamped pose # used for CIRCLE3D~%float32 scale	 	# the diameter for a circle, etc.~%float32 width	 	# the width for a line, etc.~%std_msgs/ColorRGBA outline_color~%byte filled		# whether to fill in the shape with color~%std_msgs/ColorRGBA fill_color # color [0.0-1.0]~%duration lifetime       # How long the object should last before being automatically deleted.  0 means forever~%byte arc # used for CIRCLE3D~%float32 angle # used for CIRCLE3D~%~%~%geometry_msgs/Point[] points # used for LINE_STRIP/LINE_LIST/POLYGON/POINTS., 2D in pixel coords~%PointArrayStamped points3D # used for 3DLINE_STRIP/3DLINE_LIST/3DPOLYGON/3DPOINTS~%std_msgs/ColorRGBA[] outline_colors # a color for each line, point, etc.~%~%string[] frames # used for FRAMES, tf names~%string text             # used for TEXT, draw size of text is scale~%bool left_up_origin     # draw text from left up origin~%bool ratio_scale        #Use ratio respected to original image to specify scale and position~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/PointStamped~%# This represents a Point with reference coordinate frame and timestamp~%Header header~%Point point~%~%================================================================================~%MSG: geometry_msgs/PoseStamped~%# A Pose with reference coordinate frame and timestamp~%Header header~%Pose pose~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: std_msgs/ColorRGBA~%float32 r~%float32 g~%float32 b~%float32 a~%~%================================================================================~%MSG: image_view2/PointArrayStamped~%Header header~%~%geometry_msgs/Point[] points~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ImageMarker2)))
  "Returns full string definition for message of type 'ImageMarker2"
  (cl:format cl:nil "byte CIRCLE=0~%byte LINE_STRIP=1~%byte LINE_LIST=2~%byte POLYGON=3~%byte POINTS=4~%byte FRAMES=5~%byte TEXT=6~%~%byte LINE_STRIP3D=7~%byte LINE_LIST3D=8~%byte POLYGON3D=9~%byte POINTS3D=10~%byte TEXT3D=11~%byte CIRCLE3D=12~%~%byte ADD=0~%byte REMOVE=1~%~%Header header~%string ns		# namespace, used with id to form a unique id~%int32 id          	# unique id within the namespace~%int32 type        	# CIRCLE/LINE_STRIP/etc.~%int32 action      	# ADD/REMOVE~%geometry_msgs/Point position # used for CIRCLE/TEXT, 2D in pixel-coords~%geometry_msgs/PointStamped position3D # used for 3DTEXT~%geometry_msgs/PoseStamped pose # used for CIRCLE3D~%float32 scale	 	# the diameter for a circle, etc.~%float32 width	 	# the width for a line, etc.~%std_msgs/ColorRGBA outline_color~%byte filled		# whether to fill in the shape with color~%std_msgs/ColorRGBA fill_color # color [0.0-1.0]~%duration lifetime       # How long the object should last before being automatically deleted.  0 means forever~%byte arc # used for CIRCLE3D~%float32 angle # used for CIRCLE3D~%~%~%geometry_msgs/Point[] points # used for LINE_STRIP/LINE_LIST/POLYGON/POINTS., 2D in pixel coords~%PointArrayStamped points3D # used for 3DLINE_STRIP/3DLINE_LIST/3DPOLYGON/3DPOINTS~%std_msgs/ColorRGBA[] outline_colors # a color for each line, point, etc.~%~%string[] frames # used for FRAMES, tf names~%string text             # used for TEXT, draw size of text is scale~%bool left_up_origin     # draw text from left up origin~%bool ratio_scale        #Use ratio respected to original image to specify scale and position~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/PointStamped~%# This represents a Point with reference coordinate frame and timestamp~%Header header~%Point point~%~%================================================================================~%MSG: geometry_msgs/PoseStamped~%# A Pose with reference coordinate frame and timestamp~%Header header~%Pose pose~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: std_msgs/ColorRGBA~%float32 r~%float32 g~%float32 b~%float32 a~%~%================================================================================~%MSG: image_view2/PointArrayStamped~%Header header~%~%geometry_msgs/Point[] points~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ImageMarker2>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'ns))
     4
     4
     4
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'position))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'position3D))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     4
     4
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'outline_color))
     1
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'fill_color))
     8
     1
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'points) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'points3D))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'outline_colors) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'frames) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:length (cl:slot-value msg 'text))
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ImageMarker2>))
  "Converts a ROS message object to a list"
  (cl:list 'ImageMarker2
    (cl:cons ':header (header msg))
    (cl:cons ':ns (ns msg))
    (cl:cons ':id (id msg))
    (cl:cons ':type (type msg))
    (cl:cons ':action (action msg))
    (cl:cons ':position (position msg))
    (cl:cons ':position3D (position3D msg))
    (cl:cons ':pose (pose msg))
    (cl:cons ':scale (scale msg))
    (cl:cons ':width (width msg))
    (cl:cons ':outline_color (outline_color msg))
    (cl:cons ':filled (filled msg))
    (cl:cons ':fill_color (fill_color msg))
    (cl:cons ':lifetime (lifetime msg))
    (cl:cons ':arc (arc msg))
    (cl:cons ':angle (angle msg))
    (cl:cons ':points (points msg))
    (cl:cons ':points3D (points3D msg))
    (cl:cons ':outline_colors (outline_colors msg))
    (cl:cons ':frames (frames msg))
    (cl:cons ':text (text msg))
    (cl:cons ':left_up_origin (left_up_origin msg))
    (cl:cons ':ratio_scale (ratio_scale msg))
))

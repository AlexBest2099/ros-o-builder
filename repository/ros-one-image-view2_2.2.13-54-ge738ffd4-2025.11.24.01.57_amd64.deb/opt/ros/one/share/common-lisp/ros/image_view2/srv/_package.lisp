(cl:defpackage image_view2-srv
  (:use )
  (:export
   "CHANGEMODE"
   "<CHANGEMODE-REQUEST>"
   "CHANGEMODE-REQUEST"
   "<CHANGEMODE-RESPONSE>"
   "CHANGEMODE-RESPONSE"
  ))


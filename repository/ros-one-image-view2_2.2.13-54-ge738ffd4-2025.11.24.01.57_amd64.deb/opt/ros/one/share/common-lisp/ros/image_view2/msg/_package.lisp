(cl:defpackage image_view2-msg
  (:use )
  (:export
   "<IMAGEMARKER2>"
   "IMAGEMARKER2"
   "<MOUSEEVENT>"
   "MOUSEEVENT"
   "<POINTARRAYSTAMPED>"
   "POINTARRAYSTAMPED"
  ))


(cl:in-package image_view2-srv)
(cl:export '(MODE-VAL
          MODE
))
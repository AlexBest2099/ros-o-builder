(cl:in-package rosbag_snapshot_msgs-srv)
(cl:export '(FILENAME-VAL
          FILENAME
          TOPICS-VAL
          TOPICS
          START_TIME-VAL
          START_TIME
          STOP_TIME-VAL
          STOP_TIME
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))
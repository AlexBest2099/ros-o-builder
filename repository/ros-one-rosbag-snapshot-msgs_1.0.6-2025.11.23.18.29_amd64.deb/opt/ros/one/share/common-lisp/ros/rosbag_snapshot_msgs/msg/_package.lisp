(cl:defpackage rosbag_snapshot_msgs-msg
  (:use )
  (:export
   "<SNAPSHOTSTATUS>"
   "SNAPSHOTSTATUS"
  ))


; Auto-generated. Do not edit!


(cl:in-package rosbag_snapshot_msgs-srv)


;//! \htmlinclude TriggerSnapshot-request.msg.html

(cl:defclass <TriggerSnapshot-request> (roslisp-msg-protocol:ros-message)
  ((filename
    :reader filename
    :initarg :filename
    :type cl:string
    :initform "")
   (topics
    :reader topics
    :initarg :topics
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (start_time
    :reader start_time
    :initarg :start_time
    :type cl:real
    :initform 0)
   (stop_time
    :reader stop_time
    :initarg :stop_time
    :type cl:real
    :initform 0))
)

(cl:defclass TriggerSnapshot-request (<TriggerSnapshot-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TriggerSnapshot-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TriggerSnapshot-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name rosbag_snapshot_msgs-srv:<TriggerSnapshot-request> is deprecated: use rosbag_snapshot_msgs-srv:TriggerSnapshot-request instead.")))

(cl:ensure-generic-function 'filename-val :lambda-list '(m))
(cl:defmethod filename-val ((m <TriggerSnapshot-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rosbag_snapshot_msgs-srv:filename-val is deprecated.  Use rosbag_snapshot_msgs-srv:filename instead.")
  (filename m))

(cl:ensure-generic-function 'topics-val :lambda-list '(m))
(cl:defmethod topics-val ((m <TriggerSnapshot-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rosbag_snapshot_msgs-srv:topics-val is deprecated.  Use rosbag_snapshot_msgs-srv:topics instead.")
  (topics m))

(cl:ensure-generic-function 'start_time-val :lambda-list '(m))
(cl:defmethod start_time-val ((m <TriggerSnapshot-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rosbag_snapshot_msgs-srv:start_time-val is deprecated.  Use rosbag_snapshot_msgs-srv:start_time instead.")
  (start_time m))

(cl:ensure-generic-function 'stop_time-val :lambda-list '(m))
(cl:defmethod stop_time-val ((m <TriggerSnapshot-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rosbag_snapshot_msgs-srv:stop_time-val is deprecated.  Use rosbag_snapshot_msgs-srv:stop_time instead.")
  (stop_time m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TriggerSnapshot-request>) ostream)
  "Serializes a message object of type '<TriggerSnapshot-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'filename))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'filename))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'topics))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'topics))
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'start_time)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'start_time) (cl:floor (cl:slot-value msg 'start_time)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stop_time)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stop_time) (cl:floor (cl:slot-value msg 'stop_time)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TriggerSnapshot-request>) istream)
  "Deserializes a message object of type '<TriggerSnapshot-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'filename) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'filename) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'topics) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'topics)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'start_time) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stop_time) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TriggerSnapshot-request>)))
  "Returns string type for a service object of type '<TriggerSnapshot-request>"
  "rosbag_snapshot_msgs/TriggerSnapshotRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TriggerSnapshot-request)))
  "Returns string type for a service object of type 'TriggerSnapshot-request"
  "rosbag_snapshot_msgs/TriggerSnapshotRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TriggerSnapshot-request>)))
  "Returns md5sum for a message object of type '<TriggerSnapshot-request>"
  "d5f2b150730729bd0435527e829e65e2")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TriggerSnapshot-request)))
  "Returns md5sum for a message object of type 'TriggerSnapshot-request"
  "d5f2b150730729bd0435527e829e65e2")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TriggerSnapshot-request>)))
  "Returns full string definition for message of type '<TriggerSnapshot-request>"
  (cl:format cl:nil "string filename   # Name of bag file to save snapshot to.~%                  # if it ends in .bag, this exact filename will be saved.~%                  # otherwise, the current datetime and .bag will be appended to the name~%                  #   example: \"test\" -> test2018-05-23-10-04-20.bag~%                  #   example: \"test.bag\" -> test.bag~%string[] topics   # List of topics to include in snapshot.~%                  # If empty, all buffered topics will be written~%time start_time   # Earliest timestamp for a message to be included in written bag~%                  # If time(0), start at the earliest message in each topic's buffer~%time stop_time    # Latest timestamp for a message to be included in written bag~%                  # If time(0), stop at the most recent message in each topic's buffer~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TriggerSnapshot-request)))
  "Returns full string definition for message of type 'TriggerSnapshot-request"
  (cl:format cl:nil "string filename   # Name of bag file to save snapshot to.~%                  # if it ends in .bag, this exact filename will be saved.~%                  # otherwise, the current datetime and .bag will be appended to the name~%                  #   example: \"test\" -> test2018-05-23-10-04-20.bag~%                  #   example: \"test.bag\" -> test.bag~%string[] topics   # List of topics to include in snapshot.~%                  # If empty, all buffered topics will be written~%time start_time   # Earliest timestamp for a message to be included in written bag~%                  # If time(0), start at the earliest message in each topic's buffer~%time stop_time    # Latest timestamp for a message to be included in written bag~%                  # If time(0), stop at the most recent message in each topic's buffer~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TriggerSnapshot-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'filename))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'topics) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     8
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TriggerSnapshot-request>))
  "Converts a ROS message object to a list"
  (cl:list 'TriggerSnapshot-request
    (cl:cons ':filename (filename msg))
    (cl:cons ':topics (topics msg))
    (cl:cons ':start_time (start_time msg))
    (cl:cons ':stop_time (stop_time msg))
))
;//! \htmlinclude TriggerSnapshot-response.msg.html

(cl:defclass <TriggerSnapshot-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass TriggerSnapshot-response (<TriggerSnapshot-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TriggerSnapshot-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TriggerSnapshot-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name rosbag_snapshot_msgs-srv:<TriggerSnapshot-response> is deprecated: use rosbag_snapshot_msgs-srv:TriggerSnapshot-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <TriggerSnapshot-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rosbag_snapshot_msgs-srv:success-val is deprecated.  Use rosbag_snapshot_msgs-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <TriggerSnapshot-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rosbag_snapshot_msgs-srv:message-val is deprecated.  Use rosbag_snapshot_msgs-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<TriggerSnapshot-response>)))
    "Constants for message type '<TriggerSnapshot-response>"
  '((:NO_DATA_MESSAGE . "no messages buffered on selected topics"))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'TriggerSnapshot-response)))
    "Constants for message type 'TriggerSnapshot-response"
  '((:NO_DATA_MESSAGE . "no messages buffered on selected topics"))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TriggerSnapshot-response>) ostream)
  "Serializes a message object of type '<TriggerSnapshot-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TriggerSnapshot-response>) istream)
  "Deserializes a message object of type '<TriggerSnapshot-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TriggerSnapshot-response>)))
  "Returns string type for a service object of type '<TriggerSnapshot-response>"
  "rosbag_snapshot_msgs/TriggerSnapshotResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TriggerSnapshot-response)))
  "Returns string type for a service object of type 'TriggerSnapshot-response"
  "rosbag_snapshot_msgs/TriggerSnapshotResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TriggerSnapshot-response>)))
  "Returns md5sum for a message object of type '<TriggerSnapshot-response>"
  "d5f2b150730729bd0435527e829e65e2")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TriggerSnapshot-response)))
  "Returns md5sum for a message object of type 'TriggerSnapshot-response"
  "d5f2b150730729bd0435527e829e65e2")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TriggerSnapshot-response>)))
  "Returns full string definition for message of type '<TriggerSnapshot-response>"
  (cl:format cl:nil "~%bool success    # True if snapshot successfully written to disk~%~%string NO_DATA_MESSAGE=no messages buffered on selected topics~%string message  # Error description if failed~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TriggerSnapshot-response)))
  "Returns full string definition for message of type 'TriggerSnapshot-response"
  (cl:format cl:nil "~%bool success    # True if snapshot successfully written to disk~%~%string NO_DATA_MESSAGE=no messages buffered on selected topics~%string message  # Error description if failed~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TriggerSnapshot-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TriggerSnapshot-response>))
  "Converts a ROS message object to a list"
  (cl:list 'TriggerSnapshot-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'TriggerSnapshot)))
  'TriggerSnapshot-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'TriggerSnapshot)))
  'TriggerSnapshot-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TriggerSnapshot)))
  "Returns string type for a service object of type '<TriggerSnapshot>"
  "rosbag_snapshot_msgs/TriggerSnapshot")
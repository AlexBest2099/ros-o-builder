set(rosbag_snapshot_msgs_MESSAGE_FILES "msg/SnapshotStatus.msg")
set(rosbag_snapshot_msgs_SERVICE_FILES "srv/TriggerSnapshot.srv")


"use strict";

let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let Table = require('./Table.js');
let RecognizedObject = require('./RecognizedObject.js');
let TableArray = require('./TableArray.js');
let ObjectType = require('./ObjectType.js');
let ObjectInformation = require('./ObjectInformation.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');

module.exports = {
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  Table: Table,
  RecognizedObject: RecognizedObject,
  TableArray: TableArray,
  ObjectType: ObjectType,
  ObjectInformation: ObjectInformation,
  RecognizedObjectArray: RecognizedObjectArray,
};


(cl:in-package :asdf)

(defsystem "axis_msgs-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "Axis" :depends-on ("_package_Axis"))
    (:file "_package_Axis" :depends-on ("_package"))
    (:file "Ptz" :depends-on ("_package_Ptz"))
    (:file "_package_Ptz" :depends-on ("_package"))
  ))
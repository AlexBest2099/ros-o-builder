(cl:defpackage axis_msgs-msg
  (:use )
  (:export
   "<AXIS>"
   "AXIS"
   "<PTZ>"
   "PTZ"
  ))


set(axis_msgs_MESSAGE_FILES "msg/Axis.msg;msg/Ptz.msg")
set(axis_msgs_SERVICE_FILES "srv/SetInt.srv")


"use strict";

let MagneticField = require('./MagneticField.js');
let TimeReference = require('./TimeReference.js');
let Imu = require('./Imu.js');
let RegionOfInterest = require('./RegionOfInterest.js');
let RelativeHumidity = require('./RelativeHumidity.js');
let Illuminance = require('./Illuminance.js');
let NavSatFix = require('./NavSatFix.js');
let JoyFeedback = require('./JoyFeedback.js');
let NavSatStatus = require('./NavSatStatus.js');
let FluidPressure = require('./FluidPressure.js');
let Temperature = require('./Temperature.js');
let PointCloud2 = require('./PointCloud2.js');
let LaserEcho = require('./LaserEcho.js');
let PointField = require('./PointField.js');
let CameraInfo = require('./CameraInfo.js');
let BatteryState = require('./BatteryState.js');
let LaserScan = require('./LaserScan.js');
let MultiDOFJointState = require('./MultiDOFJointState.js');
let MultiEchoLaserScan = require('./MultiEchoLaserScan.js');
let JoyFeedbackArray = require('./JoyFeedbackArray.js');
let JointState = require('./JointState.js');
let Range = require('./Range.js');
let Image = require('./Image.js');
let ChannelFloat32 = require('./ChannelFloat32.js');
let CompressedImage = require('./CompressedImage.js');
let PointCloud = require('./PointCloud.js');
let Joy = require('./Joy.js');

module.exports = {
  MagneticField: MagneticField,
  TimeReference: TimeReference,
  Imu: Imu,
  RegionOfInterest: RegionOfInterest,
  RelativeHumidity: RelativeHumidity,
  Illuminance: Illuminance,
  NavSatFix: NavSatFix,
  JoyFeedback: JoyFeedback,
  NavSatStatus: NavSatStatus,
  FluidPressure: FluidPressure,
  Temperature: Temperature,
  PointCloud2: PointCloud2,
  LaserEcho: LaserEcho,
  PointField: PointField,
  CameraInfo: CameraInfo,
  BatteryState: BatteryState,
  LaserScan: LaserScan,
  MultiDOFJointState: MultiDOFJointState,
  MultiEchoLaserScan: MultiEchoLaserScan,
  JoyFeedbackArray: JoyFeedbackArray,
  JointState: JointState,
  Range: Range,
  Image: Image,
  ChannelFloat32: ChannelFloat32,
  CompressedImage: CompressedImage,
  PointCloud: PointCloud,
  Joy: Joy,
};

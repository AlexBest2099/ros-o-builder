
"use strict";

let SoftProcessorReset = require('./SoftProcessorReset.js')
let SoftProcessorFirmwareWrite = require('./SoftProcessorFirmwareWrite.js')
let SoftProcessorFirmwareRead = require('./SoftProcessorFirmwareRead.js')

module.exports = {
  SoftProcessorReset: SoftProcessorReset,
  SoftProcessorFirmwareWrite: SoftProcessorFirmwareWrite,
  SoftProcessorFirmwareRead: SoftProcessorFirmwareRead,
};

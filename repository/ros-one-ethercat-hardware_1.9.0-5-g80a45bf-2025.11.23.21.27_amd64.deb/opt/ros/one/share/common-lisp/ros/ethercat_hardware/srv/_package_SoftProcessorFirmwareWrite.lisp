(cl:in-package ethercat_hardware-srv)
(cl:export '(ACTUATOR_NAME-VAL
          ACTUATOR_NAME
          PROCESSOR_NAME-VAL
          PROCESSOR_NAME
          INSTRUCTIONS-VAL
          INSTRUCTIONS
          SUCCESS-VAL
          SUCCESS
          ERROR_MSG-VAL
          ERROR_MSG
))
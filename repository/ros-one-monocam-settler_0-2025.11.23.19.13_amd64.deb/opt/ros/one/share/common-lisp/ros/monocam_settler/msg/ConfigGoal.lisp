; Auto-generated. Do not edit!


(cl:in-package monocam_settler-msg)


;//! \htmlinclude ConfigGoal.msg.html

(cl:defclass <ConfigGoal> (roslisp-msg-protocol:ros-message)
  ((tolerance
    :reader tolerance
    :initarg :tolerance
    :type cl:float
    :initform 0.0)
   (ignore_failures
    :reader ignore_failures
    :initarg :ignore_failures
    :type cl:fixnum
    :initform 0)
   (max_step
    :reader max_step
    :initarg :max_step
    :type cl:real
    :initform 0)
   (cache_size
    :reader cache_size
    :initarg :cache_size
    :type cl:integer
    :initform 0))
)

(cl:defclass ConfigGoal (<ConfigGoal>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ConfigGoal>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ConfigGoal)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name monocam_settler-msg:<ConfigGoal> is deprecated: use monocam_settler-msg:ConfigGoal instead.")))

(cl:ensure-generic-function 'tolerance-val :lambda-list '(m))
(cl:defmethod tolerance-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader monocam_settler-msg:tolerance-val is deprecated.  Use monocam_settler-msg:tolerance instead.")
  (tolerance m))

(cl:ensure-generic-function 'ignore_failures-val :lambda-list '(m))
(cl:defmethod ignore_failures-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader monocam_settler-msg:ignore_failures-val is deprecated.  Use monocam_settler-msg:ignore_failures instead.")
  (ignore_failures m))

(cl:ensure-generic-function 'max_step-val :lambda-list '(m))
(cl:defmethod max_step-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader monocam_settler-msg:max_step-val is deprecated.  Use monocam_settler-msg:max_step instead.")
  (max_step m))

(cl:ensure-generic-function 'cache_size-val :lambda-list '(m))
(cl:defmethod cache_size-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader monocam_settler-msg:cache_size-val is deprecated.  Use monocam_settler-msg:cache_size instead.")
  (cache_size m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ConfigGoal>) ostream)
  "Serializes a message object of type '<ConfigGoal>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'tolerance))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ignore_failures)) ostream)
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'max_step)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'max_step) (cl:floor (cl:slot-value msg 'max_step)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'cache_size)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'cache_size)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'cache_size)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'cache_size)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ConfigGoal>) istream)
  "Deserializes a message object of type '<ConfigGoal>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'tolerance) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ignore_failures)) (cl:read-byte istream))
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'max_step) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'cache_size)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'cache_size)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'cache_size)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'cache_size)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ConfigGoal>)))
  "Returns string type for a message object of type '<ConfigGoal>"
  "monocam_settler/ConfigGoal")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ConfigGoal)))
  "Returns string type for a message object of type 'ConfigGoal"
  "monocam_settler/ConfigGoal")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ConfigGoal>)))
  "Returns md5sum for a message object of type '<ConfigGoal>"
  "f2b47726560448f0dada94e01ba65594")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ConfigGoal)))
  "Returns md5sum for a message object of type 'ConfigGoal"
  "f2b47726560448f0dada94e01ba65594")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ConfigGoal>)))
  "Returns full string definition for message of type '<ConfigGoal>"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%float64 tolerance      # Tolerance on each of the features~%uint8 ignore_failures  # True if we discard~%duration max_step      # The maximum timestep between two elements in an interval~%uint32 cache_size      # The size of our cache when searching for an interval~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ConfigGoal)))
  "Returns full string definition for message of type 'ConfigGoal"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%float64 tolerance      # Tolerance on each of the features~%uint8 ignore_failures  # True if we discard~%duration max_step      # The maximum timestep between two elements in an interval~%uint32 cache_size      # The size of our cache when searching for an interval~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ConfigGoal>))
  (cl:+ 0
     8
     1
     8
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ConfigGoal>))
  "Converts a ROS message object to a list"
  (cl:list 'ConfigGoal
    (cl:cons ':tolerance (tolerance msg))
    (cl:cons ':ignore_failures (ignore_failures msg))
    (cl:cons ':max_step (max_step msg))
    (cl:cons ':cache_size (cache_size msg))
))

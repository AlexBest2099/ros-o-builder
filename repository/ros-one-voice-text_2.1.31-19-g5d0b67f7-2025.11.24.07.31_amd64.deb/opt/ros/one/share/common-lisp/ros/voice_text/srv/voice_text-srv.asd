
(cl:in-package :asdf)

(defsystem "voice_text-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "TextToSpeech" :depends-on ("_package_TextToSpeech"))
    (:file "_package_TextToSpeech" :depends-on ("_package"))
  ))
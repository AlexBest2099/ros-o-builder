; Auto-generated. Do not edit!


(cl:in-package voice_text-srv)


;//! \htmlinclude TextToSpeech-request.msg.html

(cl:defclass <TextToSpeech-request> (roslisp-msg-protocol:ros-message)
  ((text_path
    :reader text_path
    :initarg :text_path
    :type cl:string
    :initform "")
   (wave_path
    :reader wave_path
    :initarg :wave_path
    :type cl:string
    :initform ""))
)

(cl:defclass TextToSpeech-request (<TextToSpeech-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TextToSpeech-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TextToSpeech-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name voice_text-srv:<TextToSpeech-request> is deprecated: use voice_text-srv:TextToSpeech-request instead.")))

(cl:ensure-generic-function 'text_path-val :lambda-list '(m))
(cl:defmethod text_path-val ((m <TextToSpeech-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader voice_text-srv:text_path-val is deprecated.  Use voice_text-srv:text_path instead.")
  (text_path m))

(cl:ensure-generic-function 'wave_path-val :lambda-list '(m))
(cl:defmethod wave_path-val ((m <TextToSpeech-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader voice_text-srv:wave_path-val is deprecated.  Use voice_text-srv:wave_path instead.")
  (wave_path m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TextToSpeech-request>) ostream)
  "Serializes a message object of type '<TextToSpeech-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'text_path))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'text_path))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'wave_path))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'wave_path))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TextToSpeech-request>) istream)
  "Deserializes a message object of type '<TextToSpeech-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'text_path) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'text_path) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'wave_path) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'wave_path) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TextToSpeech-request>)))
  "Returns string type for a service object of type '<TextToSpeech-request>"
  "voice_text/TextToSpeechRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TextToSpeech-request)))
  "Returns string type for a service object of type 'TextToSpeech-request"
  "voice_text/TextToSpeechRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TextToSpeech-request>)))
  "Returns md5sum for a message object of type '<TextToSpeech-request>"
  "cb72e53809c765fb76bd396201ead5a4")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TextToSpeech-request)))
  "Returns md5sum for a message object of type 'TextToSpeech-request"
  "cb72e53809c765fb76bd396201ead5a4")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TextToSpeech-request>)))
  "Returns full string definition for message of type '<TextToSpeech-request>"
  (cl:format cl:nil "string text_path~%string wave_path~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TextToSpeech-request)))
  "Returns full string definition for message of type 'TextToSpeech-request"
  (cl:format cl:nil "string text_path~%string wave_path~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TextToSpeech-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'text_path))
     4 (cl:length (cl:slot-value msg 'wave_path))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TextToSpeech-request>))
  "Converts a ROS message object to a list"
  (cl:list 'TextToSpeech-request
    (cl:cons ':text_path (text_path msg))
    (cl:cons ':wave_path (wave_path msg))
))
;//! \htmlinclude TextToSpeech-response.msg.html

(cl:defclass <TextToSpeech-response> (roslisp-msg-protocol:ros-message)
  ((ok
    :reader ok
    :initarg :ok
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass TextToSpeech-response (<TextToSpeech-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TextToSpeech-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TextToSpeech-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name voice_text-srv:<TextToSpeech-response> is deprecated: use voice_text-srv:TextToSpeech-response instead.")))

(cl:ensure-generic-function 'ok-val :lambda-list '(m))
(cl:defmethod ok-val ((m <TextToSpeech-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader voice_text-srv:ok-val is deprecated.  Use voice_text-srv:ok instead.")
  (ok m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TextToSpeech-response>) ostream)
  "Serializes a message object of type '<TextToSpeech-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'ok) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TextToSpeech-response>) istream)
  "Deserializes a message object of type '<TextToSpeech-response>"
    (cl:setf (cl:slot-value msg 'ok) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TextToSpeech-response>)))
  "Returns string type for a service object of type '<TextToSpeech-response>"
  "voice_text/TextToSpeechResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TextToSpeech-response)))
  "Returns string type for a service object of type 'TextToSpeech-response"
  "voice_text/TextToSpeechResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TextToSpeech-response>)))
  "Returns md5sum for a message object of type '<TextToSpeech-response>"
  "cb72e53809c765fb76bd396201ead5a4")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TextToSpeech-response)))
  "Returns md5sum for a message object of type 'TextToSpeech-response"
  "cb72e53809c765fb76bd396201ead5a4")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TextToSpeech-response>)))
  "Returns full string definition for message of type '<TextToSpeech-response>"
  (cl:format cl:nil "bool ok~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TextToSpeech-response)))
  "Returns full string definition for message of type 'TextToSpeech-response"
  (cl:format cl:nil "bool ok~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TextToSpeech-response>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TextToSpeech-response>))
  "Converts a ROS message object to a list"
  (cl:list 'TextToSpeech-response
    (cl:cons ':ok (ok msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'TextToSpeech)))
  'TextToSpeech-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'TextToSpeech)))
  'TextToSpeech-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TextToSpeech)))
  "Returns string type for a service object of type '<TextToSpeech>"
  "voice_text/TextToSpeech")
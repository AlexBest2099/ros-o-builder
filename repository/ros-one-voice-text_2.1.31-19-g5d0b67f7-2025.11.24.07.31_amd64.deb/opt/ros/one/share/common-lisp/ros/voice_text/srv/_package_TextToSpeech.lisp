(cl:in-package voice_text-srv)
(cl:export '(TEXT_PATH-VAL
          TEXT_PATH
          WAVE_PATH-VAL
          WAVE_PATH
          OK-VAL
          OK
))

"use strict";

let Velocity = require('./Velocity.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeFeedback = require('./ShapeFeedback.js');

module.exports = {
  Velocity: Velocity,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeResult: ShapeResult,
  ShapeAction: ShapeAction,
  ShapeActionGoal: ShapeActionGoal,
  ShapeActionResult: ShapeActionResult,
  ShapeGoal: ShapeGoal,
  ShapeFeedback: ShapeFeedback,
};

/* ./tty.c :  entry=tty */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sun Nov 23 17:09:44 UTC 2025) */
#include "eus.h"
#include "tty.h"
#pragma init (register_tty)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___tty();
extern pointer build_quote_vector();
static int register_tty()
  { add_module_initializer("___tty", ___tty);}

static pointer ttyF4137tty_raw();
static pointer ttyF4138tty_cooked();
static pointer ttyF4139backspace();
static pointer ttyF4140cursor_up();
static pointer ttyF4141cursor_down();
static pointer ttyF4142cursor_forward();
static pointer ttyF4143cursor_backward();
static pointer ttyF4144cursor_return();
static pointer ttyF4145cursor_pos();
static pointer ttyF4146erase_eol();

/*tty-raw*/
static pointer ttyF4137tty_raw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto ttyENT4149;}
	local[0]= makeint((eusinteger_t)0L);
ttyENT4149:
ttyENT4148:
	if (n>1) maerror();
	local[1]= loadglobal(fqv[0]);
	ctx->vsp=local+2;
	w=(pointer)COPYSEQ(ctx,1,local+1); /*copy-seq*/
	local[1]= w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)7L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)12L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)13L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)14L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)15L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)21L);
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)22L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,2,local+2,&ftab[0],fqv[1]); /*unix:tcsets*/
	local[0]= w;
ttyBLK4147:
	ctx->vsp=local; return(local[0]);}

/*tty-cooked*/
static pointer ttyF4138tty_cooked(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto ttyENT4152;}
	local[0]= makeint((eusinteger_t)0L);
ttyENT4152:
ttyENT4151:
	if (n>1) maerror();
	local[1]= local[0];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*unix:tcsets*/
	local[0]= w;
ttyBLK4150:
	ctx->vsp=local; return(local[0]);}

/*backspace*/
static pointer ttyF4139backspace(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto ttyENT4155;}
	local[0]= makeint((eusinteger_t)1L);
ttyENT4155:
ttyENT4154:
	if (n>1) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= local[0];
ttyWHL4156:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto ttyWHX4157;
	local[3]= makeint((eusinteger_t)8L);
	local[4]= loadglobal(fqv[2]);
	ctx->vsp=local+5;
	w=(pointer)WRTBYTE(ctx,2,local+3); /*write-byte*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto ttyWHL4156;
ttyWHX4157:
	local[3]= NIL;
ttyBLK4158:
	w = NIL;
	local[1]= loadglobal(fqv[2]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[0]= w;
ttyBLK4153:
	ctx->vsp=local; return(local[0]);}

/*cursor-up*/
static pointer ttyF4140cursor_up(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto ttyENT4161;}
	local[0]= makeint((eusinteger_t)1L);
ttyENT4161:
ttyENT4160:
	if (n>1) maerror();
	local[1]= loadglobal(fqv[2]);
	local[2]= fqv[3];
	local[3]= makeint((eusinteger_t)27L);
	local[4]= makeint((eusinteger_t)91L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,5,local+1); /*format*/
	local[1]= loadglobal(fqv[2]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[0]= w;
ttyBLK4159:
	ctx->vsp=local; return(local[0]);}

/*cursor-down*/
static pointer ttyF4141cursor_down(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto ttyENT4164;}
	local[0]= makeint((eusinteger_t)1L);
ttyENT4164:
ttyENT4163:
	if (n>1) maerror();
	local[1]= loadglobal(fqv[2]);
	local[2]= fqv[4];
	local[3]= makeint((eusinteger_t)27L);
	local[4]= makeint((eusinteger_t)91L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,5,local+1); /*format*/
	local[1]= loadglobal(fqv[2]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[0]= w;
ttyBLK4162:
	ctx->vsp=local; return(local[0]);}

/*cursor-forward*/
static pointer ttyF4142cursor_forward(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto ttyENT4167;}
	local[0]= makeint((eusinteger_t)1L);
ttyENT4167:
ttyENT4166:
	if (n>1) maerror();
	local[1]= loadglobal(fqv[2]);
	local[2]= fqv[5];
	local[3]= makeint((eusinteger_t)27L);
	local[4]= makeint((eusinteger_t)91L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,5,local+1); /*format*/
	local[1]= loadglobal(fqv[2]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[0]= w;
ttyBLK4165:
	ctx->vsp=local; return(local[0]);}

/*cursor-backward*/
static pointer ttyF4143cursor_backward(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto ttyENT4170;}
	local[0]= makeint((eusinteger_t)1L);
ttyENT4170:
ttyENT4169:
	if (n>1) maerror();
	local[1]= loadglobal(fqv[2]);
	local[2]= fqv[6];
	local[3]= makeint((eusinteger_t)27L);
	local[4]= makeint((eusinteger_t)91L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,5,local+1); /*format*/
	local[1]= loadglobal(fqv[2]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[0]= w;
ttyBLK4168:
	ctx->vsp=local; return(local[0]);}

/*cursor-return*/
static pointer ttyF4144cursor_return(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[2]);
	local[1]= fqv[7];
	local[2]= makeint((eusinteger_t)13L);
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= loadglobal(fqv[2]);
	ctx->vsp=local+1;
	w=(pointer)FINOUT(ctx,1,local+0); /*finish-output*/
	local[0]= w;
ttyBLK4171:
	ctx->vsp=local; return(local[0]);}

/*cursor-pos*/
static pointer ttyF4145cursor_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto ttyIF4173;
	ctx->vsp=local+0;
	w=(pointer)ttyF4144cursor_return(ctx,0,local+0); /*cursor-return*/
	local[0]= w;
	goto ttyIF4174;
ttyIF4173:
	local[0]= loadglobal(fqv[2]);
	local[1]= fqv[8];
	local[2]= makeint((eusinteger_t)13L);
	local[3]= makeint((eusinteger_t)27L);
	local[4]= makeint((eusinteger_t)91L);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,6,local+0); /*format*/
	local[0]= w;
ttyIF4174:
	local[0]= loadglobal(fqv[2]);
	ctx->vsp=local+1;
	w=(pointer)FINOUT(ctx,1,local+0); /*finish-output*/
	local[0]= w;
ttyBLK4172:
	ctx->vsp=local; return(local[0]);}

/*erase-eol*/
static pointer ttyF4146erase_eol(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[2]);
	local[1]= fqv[9];
	local[2]= makeint((eusinteger_t)27L);
	local[3]= makeint((eusinteger_t)91L);
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= loadglobal(fqv[2]);
	ctx->vsp=local+1;
	w=(pointer)FINOUT(ctx,1,local+0); /*finish-output*/
	local[0]= w;
ttyBLK4175:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___tty(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[10];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[11],module,ttyF4137tty_raw,fqv[12]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[13],module,ttyF4138tty_cooked,fqv[14]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[15],module,ttyF4139backspace,fqv[16]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[17],module,ttyF4140cursor_up,fqv[18]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[19],module,ttyF4141cursor_down,fqv[20]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[21],module,ttyF4142cursor_forward,fqv[22]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[23],module,ttyF4143cursor_backward,fqv[24]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[25],module,ttyF4144cursor_return,fqv[26]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[27],module,ttyF4145cursor_pos,fqv[28]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[29],module,ttyF4146erase_eol,fqv[30]);
	local[0]= fqv[31];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[33]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<2; i++) ftab[i]=fcallx;
}

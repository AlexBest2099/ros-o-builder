/* ./toplevel.c :  entry=toplevel */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sun Nov 23 17:09:44 UTC 2025) */
#include "eus.h"
#include "toplevel.h"
#pragma init (register_toplevel)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___toplevel();
extern pointer build_quote_vector();
static int register_toplevel()
  { add_module_initializer("___toplevel", ___toplevel);}

static pointer toplevelF3853count_up_timer();
static pointer toplevelF3854skip_blank();
static pointer toplevelF3855read_list_from_line();
static pointer toplevelF3856sigint_handler();
static pointer toplevelF3857eussig();
static pointer toplevelF3858evaluate_stream();
static pointer toplevelF3859toplevel_prompt();
static pointer toplevelF3860rep1();
static pointer toplevelF3861prompt();
static pointer toplevelF3862reploop_non_select();
static pointer toplevelF3863repsel();
static pointer toplevelF3864reploop_select();
static pointer toplevelF3865reploop();
static pointer toplevelF3866euserror();
static pointer toplevelF3867eustop();
static pointer toplevelF3868reset();

/*count-up-timer*/
static pointer toplevelF3853count_up_timer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[0]);
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	local[0]= w;
	storeglobal(fqv[0],w);
	w = local[0];
	local[0]= w;
toplevelBLK3869:
	ctx->vsp=local; return(local[0]);}

/*skip-blank*/
static pointer toplevelF3854skip_blank(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto toplevelENT3872;}
	ctx->vsp=local+0;
	w=(pointer)GENSYM(ctx,0,local+0); /*gensym*/
	local[0]= w;
toplevelENT3872:
toplevelENT3871:
	if (n>2) maerror();
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)READCH(ctx,3,local+1); /*read-char*/
	local[1]= w;
	local[2]= local[1];
	if (local[0]!=local[2]) goto toplevelIF3873;
	w = local[0];
	ctx->vsp=local+2;
	local[0]=w;
	goto toplevelBLK3870;
	goto toplevelIF3874;
toplevelIF3873:
	local[2]= NIL;
toplevelIF3874:
toplevelWHL3875:
	local[2]= local[1];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,2,local+2,&ftab[0],fqv[2]); /*position*/
	if (w==NIL) goto toplevelWHX3876;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)READCH(ctx,1,local+2); /*read-char*/
	local[1] = w;
	goto toplevelWHL3875;
toplevelWHX3876:
	local[2]= NIL;
toplevelBLK3877:
	local[2]= local[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)UNREADCH(ctx,2,local+2); /*unread-char*/
	w = local[1];
	local[0]= w;
toplevelBLK3870:
	ctx->vsp=local; return(local[0]);}

/*read-list-from-line*/
static pointer toplevelF3855read_list_from_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto toplevelENT3881;}
	local[0]= loadglobal(fqv[3]);
toplevelENT3881:
	if (n>=2) { local[1]=(argv[1]); goto toplevelENT3880;}
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
toplevelENT3880:
toplevelENT3879:
	if (n>2) maerror();
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)toplevelF3854skip_blank(ctx,2,local+6); /*skip-blank*/
	local[2] = w;
	local[6]= NIL;
	storeglobal(fqv[4],local[6]);
	local[6]= local[2];
	if (local[1]!=local[6]) goto toplevelCON3883;
	local[6]= local[1];
	goto toplevelCON3882;
toplevelCON3883:
	local[6]= local[2];
	if (makeint((eusinteger_t)40L)!=local[6]) goto toplevelCON3884;
	local[6]= local[0];
	local[7]= NIL;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)READ(ctx,3,local+6); /*read*/
	local[4] = w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)READCH(ctx,1,local+6); /*read-char*/
	local[2] = w;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)10L);
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w!=NIL) goto toplevelIF3885;
	local[6]= local[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)UNREADCH(ctx,2,local+6); /*unread-char*/
	local[6]= w;
	goto toplevelIF3886;
toplevelIF3885:
	local[6]= NIL;
toplevelIF3886:
	local[6]= local[4];
	goto toplevelCON3882;
toplevelCON3884:
	local[6]= local[2];
	if (makeint((eusinteger_t)44L)!=local[6]) goto toplevelCON3887;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)READCH(ctx,1,local+6); /*read-char*/
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)READ(ctx,1,local+6); /*read*/
	local[4] = w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)READCH(ctx,1,local+6); /*read-char*/
	local[6]= local[4];
	goto toplevelCON3882;
toplevelCON3887:
	local[6]= local[0];
	local[7]= NIL;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)READLINE(ctx,3,local+6); /*read-line*/
	local[6]= w;
	storeglobal(fqv[4],w);
	local[6]= loadglobal(fqv[4]);
	if (local[1]!=local[6]) goto toplevelIF3889;
	w = local[1];
	ctx->vsp=local+6;
	local[0]=w;
	goto toplevelBLK3878;
	goto toplevelIF3890;
toplevelIF3889:
	local[6]= NIL;
toplevelIF3890:
	local[6]= loadglobal(fqv[4]);
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,1,local+6,&ftab[1],fqv[5]); /*make-string-input-stream*/
	local[6]= w;
	goto toplevelCON3882;
toplevelCON3888:
	local[6]= NIL;
toplevelCON3882:
	w = local[6];
	local[0]= w;
toplevelBLK3878:
	ctx->vsp=local; return(local[0]);}

/*sigint-handler*/
static pointer toplevelF3856sigint_handler(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)1L);
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[7]); /*warning-message*/
	local[0]= fqv[8];
	ctx->vsp=local+1;
	w=(pointer)FBOUNDP(ctx,1,local+0); /*fboundp*/
	if (w==NIL) goto toplevelIF3892;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[8]); /*unix:ualarm*/
	local[0]= w;
	goto toplevelIF3893;
toplevelIF3892:
	local[0]= makeint((eusinteger_t)0L);
	ctx->vsp=local+1;
	w=(pointer)ALARM(ctx,1,local+0); /*unix:alarm*/
	local[0]= w;
toplevelIF3893:
	local[0]= loadglobal(fqv[9]);
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	local[0]= w;
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[9],w);
	local[3]= fqv[10];
	w = local[3];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[11],w);
	{jmp_buf jb;
	w = loadglobal(fqv[9]);
	ctx->vsp=local+6;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto toplevelCAT3894;}
	local[12]= (pointer)get_sym_func(fqv[12]);
	ctx->vsp=local+13;
	w=(pointer)toplevelF3865reploop(ctx,1,local+12); /*reploop*/
toplevelCAT3894:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[6]= w;
	ctx->vsp=local+7;
	unbindx(ctx,2);
	w = local[6];
	local[0]= w;
toplevelBLK3891:
	ctx->vsp=local; return(local[0]);}

/*eussig*/
static pointer toplevelF3857eussig(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
toplevelRST3896:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= NIL;
	local[2]= loadglobal(fqv[13]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	if (local[2]==NIL) goto toplevelCON3898;
	local[3]= local[2];
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,3,local+3); /*funcall*/
	local[3]= w;
	goto toplevelCON3897;
toplevelCON3898:
	local[3]= fqv[8];
	ctx->vsp=local+4;
	w=(pointer)FBOUNDP(ctx,1,local+3); /*fboundp*/
	if (w==NIL) goto toplevelIF3900;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(*ftab[3])(ctx,2,local+3,&ftab[3],fqv[8]); /*unix:ualarm*/
	local[3]= w;
	goto toplevelIF3901;
toplevelIF3900:
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ALARM(ctx,1,local+3); /*unix:alarm*/
	local[3]= w;
toplevelIF3901:
	local[3]= makeint((eusinteger_t)1L);
	local[4]= fqv[14];
	local[5]= argv[0];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,4,local+3,&ftab[2],fqv[7]); /*warning-message*/
	local[3]= loadglobal(fqv[9]);
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	w = local[3];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[9],w);
	local[6]= fqv[15];
	w = local[6];
	ctx->vsp=local+6;
	bindspecial(ctx,fqv[11],w);
	{jmp_buf jb;
	w = loadglobal(fqv[9]);
	ctx->vsp=local+9;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto toplevelCAT3902;}
	local[15]= (pointer)get_sym_func(fqv[12]);
	ctx->vsp=local+16;
	w=(pointer)toplevelF3865reploop(ctx,1,local+15); /*reploop*/
toplevelCAT3902:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[9]= w;
	ctx->vsp=local+10;
	unbindx(ctx,2);
	w = local[9];
	local[3]= w;
	goto toplevelCON3897;
toplevelCON3899:
	local[3]= NIL;
toplevelCON3897:
	w = local[3];
	local[0]= w;
toplevelBLK3895:
	ctx->vsp=local; return(local[0]);}

/*evaluate-stream*/
static pointer toplevelF3858evaluate_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	w = NIL;
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)READ(ctx,3,local+1); /*read*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= local[1];
	local[5]= ((local[0])==(local[5])?T:NIL);
	if (local[5]!=NIL) goto toplevelCON3904;
toplevelCON3905:
	w = local[1];
	if (!issymbol(w)) goto toplevelCON3906;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)FBOUNDP(ctx,1,local+5); /*fboundp*/
	if (w==NIL) goto toplevelCON3908;
	local[2] = NIL;
toplevelWHL3909:
	local[5]= argv[0];
	local[6]= NIL;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)READ(ctx,3,local+5); /*read*/
	local[3] = w;
	local[5]= local[3];
	if (local[0]==local[5]) goto toplevelWHX3910;
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	goto toplevelWHL3909;
toplevelWHX3910:
	local[5]= NIL;
toplevelBLK3911:
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	storeglobal(fqv[16],local[5]);
	local[5]= loadglobal(fqv[16]);
	ctx->vsp=local+6;
	w=(pointer)EVAL(ctx,1,local+5); /*eval*/
	local[4] = w;
	local[5]= local[4];
	goto toplevelCON3907;
toplevelCON3908:
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)BOUNDP(ctx,1,local+5); /*boundp*/
	if (w==NIL) goto toplevelCON3912;
	local[5]= argv[0];
	local[6]= NIL;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)READ(ctx,3,local+5); /*read*/
	local[5]= w;
	if (local[0]!=local[5]) goto toplevelCON3912;
	local[5]= local[1];
	storeglobal(fqv[16],local[5]);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)EVAL(ctx,1,local+5); /*eval*/
	local[4] = w;
	local[5]= local[4];
	goto toplevelCON3907;
toplevelCON3912:
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[17]); /*string*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)FINDPACKAGE(ctx,1,local+5); /*find-package*/
	if (w==NIL) goto toplevelCON3913;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[17]); /*string*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)FINDPACKAGE(ctx,1,local+5); /*find-package*/
	if (w==NIL) goto toplevelIF3914;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[17]); /*string*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)FINDPACKAGE(ctx,1,local+5); /*find-package*/
	local[5]= w;
	storeglobal(fqv[18],w);
	goto toplevelIF3915;
toplevelIF3914:
	local[5]= fqv[19];
	ctx->vsp=local+6;
	w=(pointer)SIGERROR(ctx,1,local+5); /*error*/
	local[5]= w;
toplevelIF3915:
	goto toplevelCON3907;
toplevelCON3913:
	if (loadglobal(fqv[20])==NIL) goto toplevelCON3916;
	local[5]= fqv[21];
	local[6]= *(ovafptr(argv[0],fqv[22]));
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[5]= w;
	storeglobal(fqv[16],w);
	local[5]= *(ovafptr(argv[0],fqv[22]));
	ctx->vsp=local+6;
	w=(pointer)SYSTEM(ctx,1,local+5); /*unix:system*/
	local[4] = w;
	local[5]= local[4];
	goto toplevelCON3907;
toplevelCON3916:
	local[5]= fqv[23];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,1,local+5,&ftab[5],fqv[24]); /*warn*/
	local[5]= w;
	goto toplevelCON3907;
toplevelCON3917:
	local[5]= NIL;
toplevelCON3907:
	goto toplevelCON3904;
toplevelCON3906:
	local[5]= local[1];
	storeglobal(fqv[16],local[5]);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)EVAL(ctx,1,local+5); /*eval*/
	local[4] = w;
	local[5]= local[4];
	goto toplevelCON3904;
toplevelCON3918:
	local[5]= NIL;
toplevelCON3904:
	w = local[4];
	local[0]= w;
toplevelBLK3903:
	ctx->vsp=local; return(local[0]);}

/*toplevel-prompt*/
static pointer toplevelF3859toplevel_prompt(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	if (loadglobal(fqv[25])==NIL) goto toplevelIF3920;
	local[0]= argv[0];
	local[1]= fqv[26];
	local[2]= loadglobal(fqv[27]);
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto toplevelIF3921;
toplevelIF3920:
	local[0]= NIL;
toplevelIF3921:
	local[0]= loadglobal(fqv[9]);
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto toplevelIF3922;
	local[0]= argv[0];
	local[1]= fqv[28];
	local[2]= loadglobal(fqv[11]);
	local[3]= loadglobal(fqv[9]);
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	goto toplevelIF3923;
toplevelIF3922:
	local[0]= NIL;
toplevelIF3923:
	local[0]= loadglobal(fqv[18]);
	local[1]= loadglobal(fqv[29]);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w!=NIL) goto toplevelIF3924;
	local[0]= argv[0];
	local[1]= fqv[30];
	local[2]= loadglobal(fqv[18]);
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,1,local+2,&ftab[6],fqv[31]); /*package-name*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto toplevelIF3925;
toplevelIF3924:
	local[0]= NIL;
toplevelIF3925:
	local[0]= argv[0];
	local[1]= fqv[32];
	local[2]= loadglobal(fqv[33]);
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
toplevelBLK3919:
	ctx->vsp=local; return(local[0]);}

/*rep1*/
static pointer toplevelF3860rep1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto toplevelENT3928;}
	local[0]= T;
toplevelENT3928:
toplevelENT3927:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)toplevelF3855read_list_from_line(ctx,2,local+1); /*read-list-from-line*/
	local[1]= w;
	local[2]= NIL;
	local[3]= local[1];
	if (argv[1]!=local[3]) goto toplevelIF3929;
	w = argv[1];
	ctx->vsp=local+3;
	local[0]=w;
	goto toplevelBLK3926;
	goto toplevelIF3930;
toplevelIF3929:
	local[3]= NIL;
toplevelIF3930:
	if (local[1]==NIL) goto toplevelIF3931;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)STREAMP(ctx,1,local+3); /*streamp*/
	if (w==NIL) goto toplevelOR3933;
	local[3]= local[1];
	local[4]= fqv[34];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[3] > (eusinteger_t)w) goto toplevelOR3933;
	goto toplevelIF3931;
toplevelOR3933:
	if (loadglobal(fqv[25])==NIL) goto toplevelIF3934;
	w = local[1];
	if (!iscons(w)) goto toplevelCON3937;
	local[3]= NIL;
	local[4]= fqv[35];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	goto toplevelCON3936;
toplevelCON3937:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)STREAMP(ctx,1,local+3); /*streamp*/
	if (w==NIL) goto toplevelCON3938;
	local[3]= local[1];
	local[4]= fqv[34];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	goto toplevelCON3936;
toplevelCON3938:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,1,local+3,&ftab[4],fqv[17]); /*string*/
	local[3]= w;
	goto toplevelCON3936;
toplevelCON3939:
	local[3]= NIL;
toplevelCON3936:
	ctx->vsp=local+4;
	w=(*ftab[7])(ctx,1,local+3,&ftab[7],fqv[36]); /*add-history*/
	local[3]= w;
	goto toplevelIF3935;
toplevelIF3934:
	local[3]= NIL;
toplevelIF3935:
	if (loadglobal(fqv[37])==NIL) goto toplevelIF3940;
	local[3]= loadglobal(fqv[37]);
	ctx->vsp=local+4;
	w=(pointer)FUNCALL(ctx,1,local+3); /*funcall*/
	local[3]= w;
	goto toplevelIF3941;
toplevelIF3940:
	local[3]= NIL;
toplevelIF3941:
	goto toplevelIF3932;
toplevelIF3931:
	local[3]= NIL;
toplevelIF3932:
	if (local[1]!=NIL) goto toplevelCON3943;
	local[3]= NIL;
	goto toplevelCON3942;
toplevelCON3943:
	w = local[1];
	if (!issymbol(w)) goto toplevelCON3944;
	storeglobal(fqv[16],local[1]);
	local[3]= loadglobal(fqv[9]);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto toplevelCON3946;
	local[3]= local[1];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,2,local+3,&ftab[8],fqv[38]); /*eval-dynamic*/
	local[3]= w;
	goto toplevelCON3945;
toplevelCON3946:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)BOUNDP(ctx,1,local+3); /*boundp*/
	if (w==NIL) goto toplevelCON3947;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)EVAL(ctx,1,local+3); /*eval*/
	local[3]= w;
	goto toplevelCON3945;
toplevelCON3947:
	local[3]= fqv[39];
	goto toplevelCON3945;
toplevelCON3948:
	local[3]= NIL;
toplevelCON3945:
	local[2] = local[3];
	local[3]= local[2];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)PRINT(ctx,2,local+3); /*print*/
	local[3]= w;
	goto toplevelCON3942;
toplevelCON3944:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)STREAMP(ctx,1,local+3); /*streamp*/
	if (w==NIL) goto toplevelOR3950;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LISTP(ctx,1,local+3); /*listp*/
	if (w!=NIL) goto toplevelOR3950;
	goto toplevelCON3949;
toplevelOR3950:
	local[3]= local[1];
	storeglobal(fqv[16],local[3]);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)EVAL(ctx,1,local+3); /*eval*/
	local[2] = w;
	local[3]= local[2];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)PRINT(ctx,2,local+3); /*print*/
	local[3]= w;
	goto toplevelCON3942;
toplevelCON3949:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)STREAMP(ctx,1,local+3); /*streamp*/
	if (w==NIL) goto toplevelCON3951;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)toplevelF3858evaluate_stream(ctx,1,local+3); /*evaluate-stream*/
	local[2] = w;
	local[3]= local[2];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)PRINT(ctx,2,local+3); /*print*/
	local[3]= w;
	goto toplevelCON3942;
toplevelCON3951:
	local[3]= fqv[40];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)PRINT(ctx,2,local+3); /*print*/
	local[3]= w;
	goto toplevelCON3942;
toplevelCON3952:
	local[3]= NIL;
toplevelCON3942:
	storeglobal(fqv[42],loadglobal(fqv[41]));
	storeglobal(fqv[41],loadglobal(fqv[43]));
	local[3]= loadglobal(fqv[16]);
	storeglobal(fqv[43],local[3]);
	storeglobal(fqv[45],loadglobal(fqv[44]));
	storeglobal(fqv[44],loadglobal(fqv[46]));
	local[3]= local[2];
	storeglobal(fqv[46],local[3]);
	w = local[3];
	local[0]= w;
toplevelBLK3926:
	ctx->vsp=local; return(local[0]);}

/*prompt*/
static pointer toplevelF3861prompt(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = loadglobal(fqv[47]);
	if (!isstring(w)) goto toplevelCON3955;
	local[0]= loadglobal(fqv[47]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)PRINC(ctx,2,local+0); /*princ*/
	local[0]= w;
	goto toplevelCON3954;
toplevelCON3955:
	local[0]= loadglobal(fqv[47]);
	ctx->vsp=local+1;
	w=(*ftab[9])(ctx,1,local+0,&ftab[9],fqv[48]); /*functionp*/
	if (w==NIL) goto toplevelCON3956;
	local[0]= loadglobal(fqv[47]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	goto toplevelCON3954;
toplevelCON3956:
	local[0]= argv[0];
	local[1]= fqv[49];
	local[2]= loadglobal(fqv[33]);
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto toplevelCON3954;
toplevelCON3957:
	local[0]= NIL;
toplevelCON3954:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FINOUT(ctx,1,local+0); /*finish-output*/
	local[0]= w;
toplevelBLK3953:
	ctx->vsp=local; return(local[0]);}

/*reploop-non-select*/
static pointer toplevelF3862reploop_non_select(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto toplevelENT3961;}
	local[0]= loadglobal(fqv[50]);
toplevelENT3961:
	if (n>=2) { local[1]=(argv[1]); goto toplevelENT3960;}
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)ISATTY(ctx,1,local+1); /*unix:isatty*/
	local[1]= w;
toplevelENT3960:
toplevelENT3959:
	if (n>2) maerror();
	local[2]= fqv[51];
	w = local[2];
	ctx->vsp=local+2;
	bindspecial(ctx,fqv[52],w);
	ctx->vsp=local+5;
	w=(pointer)GENSYM(ctx,0,local+5); /*gensym*/
	local[5]= w;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= loadglobal(fqv[9]);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)GREATERP(ctx,2,local+9); /*>*/
	if (w==NIL) goto toplevelIF3962;
	ctx->vsp=local+9;
	w=(pointer)LISTBINDINGS(ctx,0,local+9); /*system:list-all-bindings*/
	local[7] = w;
	local[9]= local[7];
	goto toplevelIF3963;
toplevelIF3962:
	local[9]= NIL;
toplevelIF3963:
toplevelWHL3964:
	if (T==NIL) goto toplevelWHX3965;
	{jmp_buf jb;
	w = fqv[53];
	ctx->vsp=local+9;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto toplevelCAT3967;}
	if (local[1]==NIL) goto toplevelIF3968;
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)toplevelF3861prompt(ctx,1,local+15); /*prompt*/
	local[15]= w;
	goto toplevelIF3969;
toplevelIF3968:
	local[15]= NIL;
toplevelIF3969:
	local[15]= local[0];
	local[16]= local[5];
	local[17]= local[7];
	local[18]= local[1];
	ctx->vsp=local+19;
	w=(pointer)toplevelF3860rep1(ctx,4,local+15); /*rep1*/
	local[15]= w;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)EQ(ctx,2,local+15); /*eql*/
	if (w==NIL) goto toplevelIF3970;
	w = NIL;
	ctx->vsp=local+15;
	unwind(ctx,local+0);
	local[0]=w;
	goto toplevelBLK3958;
	goto toplevelIF3971;
toplevelIF3970:
	local[15]= NIL;
toplevelIF3971:
	w = local[15];
toplevelCAT3967:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	goto toplevelWHL3964;
toplevelWHX3965:
	local[9]= NIL;
toplevelBLK3966:
	ctx->vsp=local+10;
	unbindx(ctx,1);
	w = local[9];
	local[0]= w;
toplevelBLK3958:
	ctx->vsp=local; return(local[0]);}

/*repsel*/
static pointer toplevelF3863repsel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[3];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)toplevelF3860rep1(ctx,4,local+0); /*rep1*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF3973;
	local[0]= fqv[54];
	w = NIL;
	ctx->vsp=local+1;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto toplevelIF3974;
toplevelIF3973:
	local[0]= NIL;
toplevelIF3974:
	if (argv[2]==NIL) goto toplevelIF3975;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)toplevelF3861prompt(ctx,1,local+0); /*prompt*/
	local[0]= w;
	goto toplevelIF3976;
toplevelIF3975:
	local[0]= NIL;
toplevelIF3976:
	w = local[0];
	local[0]= w;
toplevelBLK3972:
	ctx->vsp=local; return(local[0]);}

/*reploop-select*/
static pointer toplevelF3864reploop_select(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto toplevelENT3980;}
	local[0]= loadglobal(fqv[50]);
toplevelENT3980:
	if (n>=2) { local[1]=(argv[1]); goto toplevelENT3979;}
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)ISATTY(ctx,1,local+1); /*unix:isatty*/
	local[1]= w;
toplevelENT3979:
toplevelENT3978:
	if (n>2) maerror();
	local[2]= fqv[51];
	w = local[2];
	ctx->vsp=local+2;
	bindspecial(ctx,fqv[52],w);
	ctx->vsp=local+5;
	w=(pointer)GENSYM(ctx,0,local+5); /*gensym*/
	local[5]= w;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	if (local[1]==NIL) goto toplevelIF3981;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)toplevelF3861prompt(ctx,1,local+9); /*prompt*/
	local[9]= w;
	goto toplevelIF3982;
toplevelIF3981:
	local[9]= NIL;
toplevelIF3982:
	local[9]= loadglobal(fqv[9]);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)GREATERP(ctx,2,local+9); /*>*/
	if (w==NIL) goto toplevelIF3983;
	ctx->vsp=local+9;
	w=(pointer)LISTBINDINGS(ctx,0,local+9); /*system:list-all-bindings*/
	local[7] = w;
	local[9]= local[7];
	goto toplevelIF3984;
toplevelIF3983:
	local[9]= NIL;
toplevelIF3984:
	local[9]= loadglobal(fqv[55]);
	local[10]= fqv[56];
	local[11]= local[0];
	local[12]= fqv[57];
	local[13]= local[0];
	local[14]= local[5];
	local[15]= local[1];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,8,local+9); /*send*/
	{jmp_buf jb;
	w = fqv[54];
	ctx->vsp=local+9;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto toplevelCAT3985;}
toplevelWHL3986:
	if (T==NIL) goto toplevelWHX3987;
	local[15]= loadglobal(fqv[55]);
	local[16]= fqv[58];
	local[17]= loadglobal(fqv[59]);
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	if (w!=NIL) goto toplevelIF3989;
	local[15]= loadglobal(fqv[60]);
	ctx->vsp=local+16;
	w=(*ftab[9])(ctx,1,local+15,&ftab[9],fqv[48]); /*functionp*/
	if (w==NIL) goto toplevelIF3991;
	local[15]= loadglobal(fqv[60]);
	ctx->vsp=local+16;
	w=(pointer)FUNCALL(ctx,1,local+15); /*funcall*/
	local[15]= w;
	goto toplevelIF3992;
toplevelIF3991:
	local[15]= NIL;
	local[16]= loadglobal(fqv[60]);
toplevelWHL3993:
	if (local[16]==NIL) goto toplevelWHX3994;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16] = (w)->c.cons.cdr;
	w = local[17];
	local[15] = w;
	local[17]= local[15];
	ctx->vsp=local+18;
	w=(*ftab[9])(ctx,1,local+17,&ftab[9],fqv[48]); /*functionp*/
	if (w==NIL) goto toplevelIF3996;
	local[17]= local[15];
	ctx->vsp=local+18;
	w=(pointer)FUNCALL(ctx,1,local+17); /*funcall*/
	local[17]= w;
	goto toplevelIF3997;
toplevelIF3996:
	local[17]= NIL;
toplevelIF3997:
	goto toplevelWHL3993;
toplevelWHX3994:
	local[17]= NIL;
toplevelBLK3995:
	w = NIL;
	local[15]= w;
toplevelIF3992:
	goto toplevelIF3990;
toplevelIF3989:
	local[15]= NIL;
toplevelIF3990:
	goto toplevelWHL3986;
toplevelWHX3987:
	local[15]= NIL;
toplevelBLK3988:
	w = local[15];
toplevelCAT3985:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[9]= w;
	ctx->vsp=local+10;
	unbindx(ctx,1);
	w = local[9];
	local[0]= w;
toplevelBLK3977:
	ctx->vsp=local; return(local[0]);}

/*reploop*/
static pointer toplevelF3865reploop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto toplevelENT4001;}
	local[0]= loadglobal(fqv[50]);
toplevelENT4001:
	if (n>=3) { local[1]=(argv[2]); goto toplevelENT4000;}
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)ISATTY(ctx,1,local+1); /*unix:isatty*/
	local[1]= w;
toplevelENT4000:
toplevelENT3999:
	if (n>3) maerror();
	local[2]= argv[0];
	w = local[2];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[47],w);
	if (loadglobal(fqv[61])==NIL) goto toplevelIF4002;
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)toplevelF3864reploop_select(ctx,2,local+6); /*reploop-select*/
	local[6]= w;
	goto toplevelIF4003;
toplevelIF4002:
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)toplevelF3862reploop_non_select(ctx,2,local+6); /*reploop-non-select*/
	local[6]= w;
toplevelIF4003:
	ctx->vsp=local+7;
	unbindx(ctx,1);
	w = local[6];
	local[0]= w;
toplevelBLK3998:
	ctx->vsp=local; return(local[0]);}

/*euserror*/
static pointer toplevelF3866euserror(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto toplevelENT4006;}
	local[0]= NIL;
toplevelENT4006:
toplevelENT4005:
	if (n>4) maerror();
	if (local[0]==NIL) goto toplevelIF4007;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[10])(ctx,1,local+1,&ftab[10],fqv[62]); /*zerop*/
	if (w==NIL) goto toplevelIF4007;
	argv[1] = local[0];
	local[0] = NIL;
	local[1]= local[0];
	goto toplevelIF4008;
toplevelIF4007:
	local[1]= NIL;
toplevelIF4008:
	local[1]= loadglobal(fqv[63]);
	local[2]= fqv[64];
	local[3]= makeint((eusinteger_t)27L);
	local[4]= makeint((eusinteger_t)1L);
	w = makeint((eusinteger_t)48L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[4]= (pointer)((eusinteger_t)local[4] + (eusinteger_t)w);
	local[5]= loadglobal(fqv[65]);
	ctx->vsp=local+6;
	w=(pointer)THR_SELF(ctx,0,local+6); /*unix:thr-self*/
	local[6]= w;
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,7,local+1); /*format*/
	if (local[0]==NIL) goto toplevelIF4009;
	local[1]= loadglobal(fqv[63]);
	local[2]= fqv[66];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	goto toplevelIF4010;
toplevelIF4009:
	local[1]= NIL;
toplevelIF4010:
	if (argv[2]==NIL) goto toplevelIF4011;
	local[1]= loadglobal(fqv[63]);
	local[2]= fqv[67];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	goto toplevelIF4012;
toplevelIF4011:
	local[1]= NIL;
toplevelIF4012:
	local[1]= loadglobal(fqv[63]);
	local[2]= fqv[68];
	local[3]= makeint((eusinteger_t)27L);
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= loadglobal(fqv[9]);
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[1]= w;
	local[2]= fqv[69];
	w = local[2];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[11],w);
	w = local[1];
	ctx->vsp=local+6;
	bindspecial(ctx,fqv[9],w);
	{jmp_buf jb;
	w = loadglobal(fqv[9]);
	ctx->vsp=local+9;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto toplevelCAT4013;}
	local[15]= (pointer)get_sym_func(fqv[12]);
	ctx->vsp=local+16;
	w=(pointer)toplevelF3865reploop(ctx,1,local+15); /*reploop*/
toplevelCAT4013:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[9]= w;
	ctx->vsp=local+10;
	unbindx(ctx,2);
	w = local[9];
	local[1]= loadglobal(fqv[9]);
	w = NIL;
	ctx->vsp=local+2;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	w = local[1];
	local[0]= w;
toplevelBLK4004:
	ctx->vsp=local; return(local[0]);}

/*eustop*/
static pointer toplevelF3867eustop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
toplevelRST4015:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= loadglobal(fqv[3]);
	ctx->vsp=local+2;
	w=(pointer)ISATTY(ctx,1,local+1); /*unix:isatty*/
	if (w==NIL) goto toplevelIF4016;
	local[1]= makeint((eusinteger_t)4L);
	local[2]= fqv[70];
	ctx->vsp=local+3;
	w=(*ftab[11])(ctx,0,local+3,&ftab[11],fqv[71]); /*lisp-implementation-version*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,3,local+1,&ftab[2],fqv[7]); /*warning-message*/
	local[1]= loadglobal(fqv[63]);
	ctx->vsp=local+2;
	w=(pointer)TERPRI(ctx,1,local+1); /*terpri*/
	local[1]= makeint((eusinteger_t)2L);
	local[2]= fqv[72];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)SIGNAL(ctx,3,local+1); /*unix:signal*/
	local[1]= makeint((eusinteger_t)13L);
	local[2]= fqv[73];
	ctx->vsp=local+3;
	w=(pointer)SIGNAL(ctx,2,local+1); /*unix:signal*/
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)FBOUNDP(ctx,1,local+1); /*fboundp*/
	if (w==NIL) goto toplevelIF4018;
	local[1]= loadglobal(fqv[3]);
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,1,local+1,&ftab[12],fqv[74]); /*unix:tcgets*/
	local[1]= w;
	storeglobal(fqv[75],w);
	local[1]= loadglobal(fqv[76]);
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,1,local+1,&ftab[13],fqv[77]); /*new-history*/
	local[1]= w;
	goto toplevelIF4019;
toplevelIF4018:
	local[1]= NIL;
toplevelIF4019:
	goto toplevelIF4017;
toplevelIF4016:
	local[1]= NIL;
toplevelIF4017:
	if (local[0]==NIL) goto toplevelIF4020;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,1,local+1,&ftab[14],fqv[78]); /*find-executable*/
	local[1]= w;
	storeglobal(fqv[79],w);
	goto toplevelIF4021;
toplevelIF4020:
	local[1]= NIL;
toplevelIF4021:
	local[1]= fqv[80];
	ctx->vsp=local+2;
	w=(pointer)GETENV(ctx,1,local+1); /*unix:getenv*/
	local[1]= w;
	storeglobal(fqv[81],w);
	local[1]= local[0];
	storeglobal(fqv[82],local[1]);
	local[1]= loadglobal(fqv[65]);
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,1,local+1,&ftab[15],fqv[83]); /*pathname-name*/
	local[1]= w;
	storeglobal(fqv[33],w);
	local[1]= fqv[84];
	ctx->vsp=local+2;
	w=(pointer)GETENV(ctx,1,local+1); /*unix:getenv*/
	local[1]= w;
	if (local[1]!=NIL) goto toplevelIF4022;
	local[2]= loadglobal(fqv[17]);
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)GETENV(ctx,1,local+3); /*unix:getenv*/
	local[3]= w;
	local[4]= fqv[86];
	ctx->vsp=local+5;
	w=(pointer)CONCATENATE(ctx,3,local+2); /*concatenate*/
	local[1] = w;
	local[2]= local[1];
	goto toplevelIF4023;
toplevelIF4022:
	local[2]= NIL;
toplevelIF4023:
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[16])(ctx,1,local+2,&ftab[16],fqv[87]); /*probe-file*/
	if (w==NIL) goto toplevelIF4024;
	local[2]= local[1];
	local[3]= fqv[88];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,3,local+2,&ftab[17],fqv[89]); /*load*/
	local[2]= w;
	goto toplevelIF4025;
toplevelIF4024:
	local[2]= NIL;
toplevelIF4025:
	w = local[2];
	local[1]= fqv[90];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,1,local+1,&ftab[16],fqv[87]); /*probe-file*/
	if (w==NIL) goto toplevelIF4026;
	local[1]= fqv[91];
	local[2]= fqv[88];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(*ftab[17])(ctx,3,local+1,&ftab[17],fqv[89]); /*load*/
	local[1]= w;
	goto toplevelIF4027;
toplevelIF4026:
	local[1]= NIL;
toplevelIF4027:
	if (local[0]==NIL) goto toplevelIF4028;
	local[1]= loadglobal(fqv[65]);
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,1,local+1,&ftab[15],fqv[83]); /*pathname-name*/
	local[1]= w;
	local[2]= fqv[92];
	ctx->vsp=local+3;
	w=(pointer)EQUAL(ctx,2,local+1); /*equal*/
	if (w==NIL) goto toplevelIF4028;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	w = makeint((eusinteger_t)2L);
	if ((eusinteger_t)local[1] < (eusinteger_t)w) goto toplevelIF4028;
	local[1]= (pointer)get_sym_func(fqv[93]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,1,local+1,&ftab[18],fqv[94]); /*exit*/
	local[1]= w;
	goto toplevelIF4029;
toplevelIF4028:
	local[1]= NIL;
toplevelIF4029:
	if (loadglobal(fqv[95])==NIL) goto toplevelIF4030;
	local[1]= loadglobal(fqv[95]);
	local[2]= loadglobal(fqv[82]);
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,2,local+1); /*funcall*/
	local[1]= w;
	goto toplevelIF4031;
toplevelIF4030:
	local[1]= NIL;
toplevelIF4031:
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= loadglobal(fqv[82]);
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
toplevelWHL4032:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto toplevelWHX4033;
	local[4]= loadglobal(fqv[82]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[1] = w;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	if (makeint((eusinteger_t)40L)!=local[4]) goto toplevelCON4036;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[19])(ctx,1,local+4,&ftab[19],fqv[96]); /*read-from-string*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)EVAL(ctx,1,local+4); /*eval*/
	local[4]= w;
	goto toplevelCON4035;
toplevelCON4036:
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[4]= ((makeint((eusinteger_t)45L))==(local[4])?T:NIL);
	if (local[4]!=NIL) goto toplevelCON4035;
toplevelCON4037:
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,1,local+4,&ftab[17],fqv[89]); /*load*/
	local[4]= w;
	goto toplevelCON4035;
toplevelCON4038:
	local[4]= NIL;
toplevelCON4035:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto toplevelWHL4032;
toplevelWHX4033:
	local[4]= NIL;
toplevelBLK4034:
	w = NIL;
	{jmp_buf jb;
	w = fqv[97];
	ctx->vsp=local+1;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto toplevelCAT4039;}
toplevelWHL4040:
	if (T==NIL) goto toplevelWHX4041;
	{jmp_buf jb;
	w = makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto toplevelCAT4043;}
	local[13]= makeint((eusinteger_t)0L);
	local[14]= fqv[98];
	w = local[14];
	ctx->vsp=local+15;
	bindspecial(ctx,fqv[11],w);
	w = local[13];
	ctx->vsp=local+18;
	bindspecial(ctx,fqv[9],w);
	local[21]= (pointer)get_sym_func(fqv[12]);
	ctx->vsp=local+22;
	w=(pointer)toplevelF3865reploop(ctx,1,local+21); /*reploop*/
	local[21]= w;
	ctx->vsp=local+22;
	unbindx(ctx,2);
	w = local[21];
	local[13]= fqv[97];
	w = NIL;
	ctx->vsp=local+14;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	w = local[13];
toplevelCAT4043:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	goto toplevelWHL4040;
toplevelWHX4041:
	local[7]= NIL;
toplevelBLK4042:
	w = local[7];
toplevelCAT4039:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[0]= w;
toplevelBLK4014:
	ctx->vsp=local; return(local[0]);}

/*reset*/
static pointer toplevelF3868reset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto toplevelENT4046;}
	local[0]= makeint((eusinteger_t)0L);
toplevelENT4046:
toplevelENT4045:
	if (n>1) maerror();
	local[1]= local[0];
	w = NIL;
	ctx->vsp=local+2;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	w = local[1];
	local[0]= w;
toplevelBLK4044:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___toplevel(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[99];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto toplevelIF4047;
	local[0]= fqv[100];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[18],w);
	goto toplevelIF4048;
toplevelIF4047:
	local[0]= fqv[101];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
toplevelIF4048:
	local[0]= fqv[102];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[16];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4049;
	local[0]= fqv[16];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[16];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4051;
	local[0]= fqv[16];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4052;
toplevelIF4051:
	local[0]= NIL;
toplevelIF4052:
	local[0]= fqv[16];
	goto toplevelIF4050;
toplevelIF4049:
	local[0]= NIL;
toplevelIF4050:
	local[0]= fqv[46];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4053;
	local[0]= fqv[46];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[46];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4055;
	local[0]= fqv[46];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4056;
toplevelIF4055:
	local[0]= NIL;
toplevelIF4056:
	local[0]= fqv[46];
	goto toplevelIF4054;
toplevelIF4053:
	local[0]= NIL;
toplevelIF4054:
	local[0]= fqv[44];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4057;
	local[0]= fqv[44];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[44];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4059;
	local[0]= fqv[44];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4060;
toplevelIF4059:
	local[0]= NIL;
toplevelIF4060:
	local[0]= fqv[44];
	goto toplevelIF4058;
toplevelIF4057:
	local[0]= NIL;
toplevelIF4058:
	local[0]= fqv[45];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4061;
	local[0]= fqv[45];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[45];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4063;
	local[0]= fqv[45];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4064;
toplevelIF4063:
	local[0]= NIL;
toplevelIF4064:
	local[0]= fqv[45];
	goto toplevelIF4062;
toplevelIF4061:
	local[0]= NIL;
toplevelIF4062:
	local[0]= fqv[43];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4065;
	local[0]= fqv[43];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[43];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4067;
	local[0]= fqv[43];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4068;
toplevelIF4067:
	local[0]= NIL;
toplevelIF4068:
	local[0]= fqv[43];
	goto toplevelIF4066;
toplevelIF4065:
	local[0]= NIL;
toplevelIF4066:
	local[0]= fqv[41];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4069;
	local[0]= fqv[41];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[41];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4071;
	local[0]= fqv[41];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4072;
toplevelIF4071:
	local[0]= NIL;
toplevelIF4072:
	local[0]= fqv[41];
	goto toplevelIF4070;
toplevelIF4069:
	local[0]= NIL;
toplevelIF4070:
	local[0]= fqv[42];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4073;
	local[0]= fqv[42];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[42];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4075;
	local[0]= fqv[42];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4076;
toplevelIF4075:
	local[0]= NIL;
toplevelIF4076:
	local[0]= fqv[42];
	goto toplevelIF4074;
toplevelIF4073:
	local[0]= NIL;
toplevelIF4074:
	local[0]= fqv[105];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4077;
	local[0]= fqv[105];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[105];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4079;
	local[0]= fqv[105];
	local[1]= fqv[104];
	local[2]= loadglobal(fqv[3]);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4080;
toplevelIF4079:
	local[0]= NIL;
toplevelIF4080:
	local[0]= fqv[105];
	goto toplevelIF4078;
toplevelIF4077:
	local[0]= NIL;
toplevelIF4078:
	local[0]= fqv[106];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4081;
	local[0]= fqv[106];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[106];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4083;
	local[0]= fqv[106];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4084;
toplevelIF4083:
	local[0]= NIL;
toplevelIF4084:
	local[0]= fqv[106];
	goto toplevelIF4082;
toplevelIF4081:
	local[0]= NIL;
toplevelIF4082:
	local[0]= fqv[95];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4085;
	local[0]= fqv[95];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[95];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4087;
	local[0]= fqv[95];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4088;
toplevelIF4087:
	local[0]= NIL;
toplevelIF4088:
	local[0]= fqv[95];
	goto toplevelIF4086;
toplevelIF4085:
	local[0]= NIL;
toplevelIF4086:
	local[0]= fqv[47];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4089;
	local[0]= fqv[47];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[47];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4091;
	local[0]= fqv[47];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4092;
toplevelIF4091:
	local[0]= NIL;
toplevelIF4092:
	local[0]= fqv[47];
	goto toplevelIF4090;
toplevelIF4089:
	local[0]= NIL;
toplevelIF4090:
	local[0]= fqv[37];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4093;
	local[0]= fqv[37];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[37];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4095;
	local[0]= fqv[37];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4096;
toplevelIF4095:
	local[0]= NIL;
toplevelIF4096:
	local[0]= fqv[37];
	goto toplevelIF4094;
toplevelIF4093:
	local[0]= NIL;
toplevelIF4094:
	local[0]= fqv[9];
	local[1]= fqv[107];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[11];
	local[1]= fqv[107];
	local[2]= fqv[108];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[4];
	local[1]= fqv[107];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[33];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4097;
	local[0]= fqv[33];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[33];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4099;
	local[0]= fqv[33];
	local[1]= fqv[104];
	local[2]= fqv[109];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4100;
toplevelIF4099:
	local[0]= NIL;
toplevelIF4100:
	local[0]= fqv[33];
	goto toplevelIF4098;
toplevelIF4097:
	local[0]= NIL;
toplevelIF4098:
	local[0]= fqv[25];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4101;
	local[0]= fqv[25];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[25];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4103;
	local[0]= fqv[25];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4104;
toplevelIF4103:
	local[0]= NIL;
toplevelIF4104:
	local[0]= fqv[25];
	goto toplevelIF4102;
toplevelIF4101:
	local[0]= NIL;
toplevelIF4102:
	local[0]= fqv[75];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4105;
	local[0]= fqv[75];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[75];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4107;
	local[0]= fqv[75];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4108;
toplevelIF4107:
	local[0]= NIL;
toplevelIF4108:
	local[0]= fqv[75];
	goto toplevelIF4106;
toplevelIF4105:
	local[0]= NIL;
toplevelIF4106:
	local[0]= fqv[82];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4109;
	local[0]= fqv[82];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[82];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4111;
	local[0]= fqv[82];
	local[1]= fqv[104];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4112;
toplevelIF4111:
	local[0]= NIL;
toplevelIF4112:
	local[0]= fqv[82];
	goto toplevelIF4110;
toplevelIF4109:
	local[0]= NIL;
toplevelIF4110:
	local[0]= fqv[55];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4113;
	local[0]= fqv[55];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[55];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4115;
	local[0]= fqv[55];
	local[1]= fqv[104];
	local[2]= loadglobal(fqv[110]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[111];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	w = local[2];
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4116;
toplevelIF4115:
	local[0]= NIL;
toplevelIF4116:
	local[0]= fqv[55];
	goto toplevelIF4114;
toplevelIF4113:
	local[0]= NIL;
toplevelIF4114:
	local[0]= fqv[60];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4117;
	local[0]= fqv[60];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[60];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4119;
	local[0]= fqv[60];
	local[1]= fqv[104];
	local[2]= fqv[112];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4120;
toplevelIF4119:
	local[0]= NIL;
toplevelIF4120:
	local[0]= fqv[60];
	goto toplevelIF4118;
toplevelIF4117:
	local[0]= NIL;
toplevelIF4118:
	local[0]= fqv[0];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4121;
	local[0]= fqv[0];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[0];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4123;
	local[0]= fqv[0];
	local[1]= fqv[104];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4124;
toplevelIF4123:
	local[0]= NIL;
toplevelIF4124:
	local[0]= fqv[0];
	goto toplevelIF4122;
toplevelIF4121:
	local[0]= NIL;
toplevelIF4122:
	local[0]= fqv[59];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4125;
	local[0]= fqv[59];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[59];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4127;
	local[0]= fqv[59];
	local[1]= fqv[104];
	local[2]= makeflt(1.0000000000000000000000e+01);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4128;
toplevelIF4127:
	local[0]= NIL;
toplevelIF4128:
	local[0]= fqv[59];
	goto toplevelIF4126;
toplevelIF4125:
	local[0]= NIL;
toplevelIF4126:
	local[0]= fqv[61];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4129;
	local[0]= fqv[61];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[61];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4131;
	local[0]= fqv[61];
	local[1]= fqv[104];
	local[2]= fqv[113];
	ctx->vsp=local+3;
	w=(pointer)GETENV(ctx,1,local+2); /*unix:getenv*/
	local[2]= ((w)==NIL?T:NIL);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4132;
toplevelIF4131:
	local[0]= NIL;
toplevelIF4132:
	local[0]= fqv[61];
	goto toplevelIF4130;
toplevelIF4129:
	local[0]= NIL;
toplevelIF4130:
	local[0]= fqv[20];
	local[1]= fqv[104];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[112],module,toplevelF3853count_up_timer,fqv[114]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[115],module,toplevelF3854skip_blank,fqv[116]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[117],module,toplevelF3855read_list_from_line,fqv[118]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[72],module,toplevelF3856sigint_handler,fqv[119]);
	local[0]= fqv[13];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto toplevelIF4133;
	local[0]= fqv[13];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[13];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto toplevelIF4135;
	local[0]= fqv[13];
	local[1]= fqv[104];
	local[2]= loadglobal(fqv[120]);
	local[3]= makeint((eusinteger_t)32L);
	ctx->vsp=local+4;
	w=(*ftab[20])(ctx,2,local+2,&ftab[20],fqv[121]); /*make-sequence*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto toplevelIF4136;
toplevelIF4135:
	local[0]= NIL;
toplevelIF4136:
	local[0]= fqv[13];
	goto toplevelIF4134;
toplevelIF4133:
	local[0]= NIL;
toplevelIF4134:
	ctx->vsp=local+0;
	compfun(ctx,fqv[73],module,toplevelF3857eussig,fqv[122]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[123],module,toplevelF3858evaluate_stream,fqv[124]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[12],module,toplevelF3859toplevel_prompt,fqv[125]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[126],module,toplevelF3860rep1,fqv[127]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[128],module,toplevelF3861prompt,fqv[129]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[130],module,toplevelF3862reploop_non_select,fqv[131]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[57],module,toplevelF3863repsel,fqv[132]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[133],module,toplevelF3864reploop_select,fqv[134]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[135],module,toplevelF3865reploop,fqv[136]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[51],module,toplevelF3866euserror,fqv[137]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[138],module,toplevelF3867eustop,fqv[139]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[140],module,toplevelF3868reset,fqv[141]);
	local[0]= fqv[142];
	local[1]= fqv[143];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[144]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<22; i++) ftab[i]=fcallx;
}

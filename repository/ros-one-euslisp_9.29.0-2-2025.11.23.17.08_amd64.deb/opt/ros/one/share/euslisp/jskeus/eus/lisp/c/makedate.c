char *makedate="Sun Nov 23 17:09:44 UTC 2025";
#if Linux
char *gitrevision="6db5aab3";
#else
char *gitrevision="";
#endif
char *compilehost="sbuild";

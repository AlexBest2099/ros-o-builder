/* ./trans.c :  entry=trans */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sun Nov 23 17:09:44 UTC 2025) */
#include "eus.h"
#include "trans.h"
#pragma init (register_trans)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___trans();
extern pointer build_quote_vector();
static int register_trans()
  { add_module_initializer("___trans", ___trans);}

static pointer transF1c_stringize();
static pointer transF2ftab_index();

/*c-stringize*/
static pointer transF1c_stringize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*prin1-to-string*/
	local[0]= w;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)10L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,2,local+2,&ftab[1],fqv[1]); /*position*/
	if (w==NIL) goto transCON5;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
transWHL6:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto transWHX7;
	local[4]= local[0];
	{ register eusinteger_t i=intval(local[2]);
	  w=makeint(local[4]->c.str.chars[i]);}
	local[4]= w;
	local[5]= makeint((eusinteger_t)10L);
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w==NIL) goto transIF9;
	local[4]= makeint((eusinteger_t)92L);
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= makeint((eusinteger_t)110L);
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[1];
	goto transIF10;
transIF9:
	local[4]= local[0];
	{ register eusinteger_t i=intval(local[2]);
	  w=makeint(local[4]->c.str.chars[i]);}
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[1];
transIF10:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto transWHL6;
transWHX7:
	local[4]= NIL;
transBLK8:
	w = NIL;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[2]= w;
	local[3]= loadglobal(fqv[2]);
	ctx->vsp=local+4;
	w=(pointer)COERCE(ctx,2,local+2); /*coerce*/
	local[2]= w;
	goto transCON4;
transCON5:
	local[2]= local[0];
	goto transCON4;
transCON11:
	local[2]= NIL;
transCON4:
	w = local[2];
	local[0]= w;
transBLK3:
	ctx->vsp=local; return(local[0]);}

/*ftab-index*/
static pointer transF2ftab_index(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	local[0]= w;
	if (local[0]!=NIL) goto transIF13;
	local[1]= argv[0];
	local[2]= loadglobal(fqv[4]);
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	local[2]= argv[0];
	w = loadglobal(fqv[5]);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	storeglobal(fqv[5],local[2]);
	local[2]= loadglobal(fqv[4]);
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	storeglobal(fqv[4],w);
	w = local[1];
	local[1]= w;
	goto transIF14;
transIF13:
	local[1]= local[0];
transIF14:
	w = local[1];
	local[0]= w;
transBLK12:
	ctx->vsp=local; return(local[0]);}

/*:label*/
static pointer transM15translator_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[7];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transBLK16:
	ctx->vsp=local; return(local[0]);}

/*:comment*/
static pointer transM17translator_comment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
transRST19:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[8];
	local[2]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
transWHL20:
	if (local[0]==NIL) goto transWHX21;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	goto transWHL20;
transWHX21:
	local[1]= NIL;
transBLK22:
	local[1]= fqv[9];
	local[2]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)TERPRI(ctx,1,local+1); /*terpri*/
	local[0]= w;
transBLK18:
	ctx->vsp=local; return(local[0]);}

/*:pop*/
static pointer transM23translator_pop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[2]==NIL) goto transIF25;
	local[0]= argv[0]->c.obj.iv[2];
	argv[0]->c.obj.iv[2] = NIL;
	w = local[0];
	local[0]= w;
	goto transIF26;
transIF25:
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= NIL;
	local[1]= fqv[10];
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transIF26:
	w = local[0];
	local[0]= w;
transBLK24:
	ctx->vsp=local; return(local[0]);}

/*:store*/
static pointer transM27translator_store(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[2]==NIL) goto transOR31;
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	if (w==NIL) goto transOR31;
	goto transIF29;
transOR31:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[11];
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	goto transIF30;
transIF29:
	argv[0]->c.obj.iv[2] = NIL;
	local[0]= argv[0]->c.obj.iv[2];
transIF30:
	w = local[0];
	local[0]= w;
transBLK28:
	ctx->vsp=local; return(local[0]);}

/*:push*/
static pointer transM32translator_push(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[2] = argv[2];
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
transBLK33:
	ctx->vsp=local; return(local[0]);}

/*:clearpush*/
static pointer transM34translator_clearpush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[2]==NIL) goto transIF36;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[13];
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= argv[0]->c.obj.iv[3];
	goto transIF37;
transIF36:
	local[0]= NIL;
transIF37:
	argv[0]->c.obj.iv[2] = NIL;
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
transBLK35:
	ctx->vsp=local; return(local[0]);}

/*:quote-entry*/
static pointer transM38translator_quote_entry(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	w = argv[2];
	if (!issymbol(w)) goto transCON41;
	local[1]= argv[2];
	w = argv[0]->c.obj.iv[4];
	local[0] = memq(local[1],w);
	if (local[0]==NIL) goto transCON41;
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[0] = (pointer)((eusinteger_t)local[1] - (eusinteger_t)w);
	local[1]= local[0];
	goto transCON40;
transCON41:
	local[1]= argv[0]->c.obj.iv[4];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)NCONC(ctx,2,local+1); /*nconc*/
	argv[0]->c.obj.iv[4] = w;
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[0] = w;
	local[1]= local[0];
	goto transCON40;
transCON42:
	local[1]= NIL;
transCON40:
	w = local[0];
	local[0]= w;
transBLK39:
	ctx->vsp=local; return(local[0]);}

/*:dupe*/
static pointer transM43translator_dupe(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= fqv[14];
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	if (w==NIL) goto transCON46;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[16];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON45;
transCON46:
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[17];
	local[4]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+5;
	w=(pointer)SUB1(ctx,1,local+4); /*1-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON45;
transCON47:
	local[0]= NIL;
transCON45:
	w = local[0];
	local[0]= w;
transBLK44:
	ctx->vsp=local; return(local[0]);}

/*:discard*/
static pointer transM48translator_discard(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[2]==NIL) goto transIF50;
	argv[0]->c.obj.iv[2] = NIL;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[2] = w;
	local[0]= argv[2];
	goto transIF51;
transIF50:
	local[0]= NIL;
transIF51:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto transIF52;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= argv[0]->c.obj.iv[3];
	goto transIF53;
transIF52:
	local[0]= NIL;
transIF53:
	w = local[0];
	local[0]= w;
transBLK49:
	ctx->vsp=local; return(local[0]);}

/*:adjust*/
static pointer transM54translator_adjust(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK55:
	ctx->vsp=local; return(local[0]);}

/*:setpushcount*/
static pointer transM56translator_setpushcount(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[3] = argv[2];
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK57:
	ctx->vsp=local; return(local[0]);}

/*:offset-from-fp*/
static pointer transM58translator_offset_from_fp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK59:
	ctx->vsp=local; return(local[0]);}

/*:reset-vsp*/
static pointer transM60translator_reset_vsp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[18];
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transBLK61:
	ctx->vsp=local; return(local[0]);}

/*:bind-special*/
static pointer transM62translator_bind_special(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[20];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[22];
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)3L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK63:
	ctx->vsp=local; return(local[0]);}

/*:unbind-special*/
static pointer transM64translator_unbind_special(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[24];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transBLK65:
	ctx->vsp=local; return(local[0]);}

/*:pushenv*/
static pointer transM66translator_pushenv(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[25];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
transBLK67:
	ctx->vsp=local; return(local[0]);}

/*:enter*/
static pointer transM68translator_enter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+1;
	w=(pointer)TERPRI(ctx,1,local+0); /*terpri*/
	local[0]= argv[0];
	local[1]= fqv[26];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[0]->c.obj.iv[3] = makeint((eusinteger_t)0L);
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[27];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[28];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[29];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[30];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[31];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
transBLK69:
	ctx->vsp=local; return(local[0]);}

/*:check-req-arg*/
static pointer transM70translator_check_req_arg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto transIF72;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
	goto transIF73;
transIF72:
	local[0]= NIL;
transIF73:
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto transIF74;
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto transIF76;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[34];
	local[2]= argv[3];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)NUMEQUAL(ctx,2,local+2); /*=*/
	if (w==NIL) goto transIF78;
	local[2]= fqv[35];
	goto transIF79;
transIF78:
	local[2]= fqv[36];
transIF79:
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	goto transIF77;
transIF76:
	local[0]= NIL;
transIF77:
	goto transIF75;
transIF74:
	local[0]= NIL;
transIF75:
	w = local[0];
	local[0]= w;
transBLK71:
	ctx->vsp=local; return(local[0]);}

/*:check-opt-arg*/
static pointer transM80translator_check_opt_arg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[37];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[3];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,6,local+0); /*format*/
	local[0]= w;
transBLK81:
	ctx->vsp=local; return(local[0]);}

/*:check-rest-arg*/
static pointer transM82translator_check_rest_arg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto transIF84;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[38];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto transIF85;
transIF84:
	local[0]= NIL;
transIF85:
	w = local[0];
	local[0]= w;
transBLK83:
	ctx->vsp=local; return(local[0]);}

/*:rest*/
static pointer transM86translator_rest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[39];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK87:
	ctx->vsp=local; return(local[0]);}

/*:parse-key-params*/
static pointer transM88translator_parse_key_params(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[40];
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[3];
	local[5]= argv[0]->c.obj.iv[3];
	if (argv[5]==NIL) goto transIF90;
	local[6]= makeint((eusinteger_t)1L);
	goto transIF91;
transIF90:
	local[6]= makeint((eusinteger_t)0L);
transIF91:
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,7,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK89:
	ctx->vsp=local; return(local[0]);}

/*:check-key-arg*/
static pointer transM92translator_check_key_arg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[41];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
transBLK93:
	ctx->vsp=local; return(local[0]);}

/*:getbase*/
static pointer transM94translator_getbase(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto transCON97;
	if (argv[3]==NIL) goto transIF98;
	local[0]= fqv[42];
	goto transIF99;
transIF98:
	local[0]= fqv[43];
transIF99:
	goto transCON96;
transCON97:
	local[0]= fqv[44];
transWHL101:
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	if (w==NIL) goto transWHX102;
	local[1]= loadglobal(fqv[2]);
	local[2]= local[0];
	local[3]= fqv[45];
	ctx->vsp=local+4;
	w=(pointer)CONCATENATE(ctx,3,local+1); /*concatenate*/
	local[0] = w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	argv[2] = w;
	goto transWHL101;
transWHX102:
	local[1]= NIL;
transBLK103:
	local[1]= loadglobal(fqv[2]);
	local[2]= local[0];
	if (argv[3]==NIL) goto transIF104;
	local[3]= fqv[46];
	goto transIF105;
transIF104:
	local[3]= fqv[47];
transIF105:
	ctx->vsp=local+4;
	w=(pointer)CONCATENATE(ctx,3,local+1); /*concatenate*/
	local[0] = w;
	w = local[0];
	local[0]= w;
	goto transCON96;
transCON100:
	local[0]= NIL;
transCON96:
	w = local[0];
	local[0]= w;
transBLK95:
	ctx->vsp=local; return(local[0]);}

/*:load-t*/
static pointer transM106translator_load_t(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[48];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK107:
	ctx->vsp=local; return(local[0]);}

/*:load-nil*/
static pointer transM108translator_load_nil(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[49];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK109:
	ctx->vsp=local; return(local[0]);}

/*:load-int*/
static pointer transM110translator_load_int(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[50];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK111:
	ctx->vsp=local; return(local[0]);}

/*:load-float*/
static pointer transM112translator_load_float(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[51];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK113:
	ctx->vsp=local; return(local[0]);}

/*:load-quote*/
static pointer transM114translator_load_quote(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[52];
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK115:
	ctx->vsp=local; return(local[0]);}

/*:load-arg*/
static pointer transM116translator_load_arg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[53];
	local[4]= argv[0];
	local[5]= fqv[54];
	local[6]= argv[3];
	local[7]= fqv[55];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK117:
	ctx->vsp=local; return(local[0]);}

/*:load-local*/
static pointer transM118translator_load_local(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[56];
	local[4]= argv[0];
	local[5]= fqv[54];
	local[6]= argv[3];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK119:
	ctx->vsp=local; return(local[0]);}

/*:load-obj*/
static pointer transM120translator_load_obj(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[57];
	local[4]= argv[0];
	local[5]= fqv[54];
	local[6]= argv[3];
	local[7]= fqv[55];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK121:
	ctx->vsp=local; return(local[0]);}

/*:load-global*/
static pointer transM122translator_load_global(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[58];
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK123:
	ctx->vsp=local; return(local[0]);}

/*:store-arg*/
static pointer transM124translator_store_arg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= NIL;
	local[3]= fqv[59];
	local[4]= argv[0];
	local[5]= fqv[54];
	local[6]= argv[3];
	local[7]= fqv[55];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK125:
	ctx->vsp=local; return(local[0]);}

/*:store-local*/
static pointer transM126translator_store_local(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= NIL;
	local[3]= fqv[60];
	local[4]= argv[0];
	local[5]= fqv[54];
	local[6]= argv[3];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK127:
	ctx->vsp=local; return(local[0]);}

/*:store-obj*/
static pointer transM128translator_store_obj(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= NIL;
	local[3]= fqv[61];
	local[4]= argv[0];
	local[5]= fqv[54];
	local[6]= argv[3];
	local[7]= fqv[55];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK129:
	ctx->vsp=local; return(local[0]);}

/*:store-global*/
static pointer transM130translator_store_global(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[62];
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
transBLK131:
	ctx->vsp=local; return(local[0]);}

/*:load-ovaf*/
static pointer transM132translator_load_ovaf(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[63];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[23];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK133:
	ctx->vsp=local; return(local[0]);}

/*:load-indexed-ov*/
static pointer transM134translator_load_indexed_ov(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[64];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK135:
	ctx->vsp=local; return(local[0]);}

/*:store-ovaf*/
static pointer transM136translator_store_ovaf(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= NIL;
	local[3]= fqv[65];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[23];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK137:
	ctx->vsp=local; return(local[0]);}

/*:store-indexed-ov*/
static pointer transM138translator_store_indexed_ov(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[66];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= NIL;
	local[3]= fqv[67];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK139:
	ctx->vsp=local; return(local[0]);}

/*:call*/
static pointer transM140translator_call(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= argv[2];
	local[2]= fqv[68];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0] = w;
	if (local[0]!=NIL) goto transIF142;
	local[1]= argv[2];
	local[2]= fqv[69];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0] = w;
	local[1]= local[0];
	goto transIF143;
transIF142:
	local[1]= NIL;
transIF143:
	local[1]= argv[0];
	local[2]= fqv[6];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[21];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,1,local+1,&ftab[2],fqv[70]); /*functionp*/
	if (w!=NIL) goto transIF144;
	local[1]= loadglobal(fqv[71]);
	local[2]= fqv[72];
	local[3]= makeint((eusinteger_t)27L);
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)27L);
	local[6]= makeint((eusinteger_t)27L);
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,6,local+1); /*format*/
	local[1]= w;
	goto transIF145;
transIF144:
	local[1]= NIL;
transIF145:
	if (local[0]==NIL) goto transIF146;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[73];
	local[3]= local[0];
	local[4]= argv[3];
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,6,local+1); /*format*/
	local[1]= w;
	goto transIF147;
transIF146:
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[74];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)transF2ftab_index(ctx,1,local+3); /*ftab-index*/
	local[3]= w;
	local[4]= argv[3];
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)transF2ftab_index(ctx,1,local+6); /*ftab-index*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[23];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,8,local+1); /*format*/
	local[1]= w;
transIF147:
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[15];
	local[3]= fqv[76];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
transBLK141:
	ctx->vsp=local; return(local[0]);}

/*:call-closure*/
static pointer transM148translator_call_closure(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[77];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[78];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[75];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[79];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK149:
	ctx->vsp=local; return(local[0]);}

/*:getfunc*/
static pointer transM150translator_getfunc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[80];
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK151:
	ctx->vsp=local; return(local[0]);}

/*:1-*/
static pointer transM152translator_1_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[81];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK153:
	ctx->vsp=local; return(local[0]);}

/*:1+*/
static pointer transM154translator_1_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[82];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK155:
	ctx->vsp=local; return(local[0]);}

/*:check-cons-nil*/
static pointer transM156translator_check_cons_nil(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= fqv[83];
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	if (w==NIL) goto transIF158;
	local[0]= argv[0];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto transIF159;
transIF158:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[84];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transIF159:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[86];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK157:
	ctx->vsp=local; return(local[0]);}

/*:car*/
static pointer transM160translator_car(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[87]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto transIF162;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[88];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transIF163;
transIF162:
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto transIF164;
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto transIF165;
transIF164:
	local[0]= NIL;
transIF165:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[90];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transIF163:
	w = local[0];
	local[0]= w;
transBLK161:
	ctx->vsp=local; return(local[0]);}

/*:cdr*/
static pointer transM166translator_cdr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[87]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto transIF168;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[91];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transIF169;
transIF168:
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto transIF170;
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto transIF171;
transIF170:
	local[0]= NIL;
transIF171:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[92];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transIF169:
	w = local[0];
	local[0]= w;
transBLK167:
	ctx->vsp=local; return(local[0]);}

/*:caar*/
static pointer transM172translator_caar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[87]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto transCON175;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[93];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON174;
transCON175:
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto transCON176;
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[94];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[95];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON174;
transCON176:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[96];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON174;
transCON177:
	local[0]= NIL;
transCON174:
	w = local[0];
	local[0]= w;
transBLK173:
	ctx->vsp=local; return(local[0]);}

/*:cddr*/
static pointer transM178translator_cddr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[87]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto transCON181;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[97];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON180;
transCON181:
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto transCON182;
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[98];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[99];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON180;
transCON182:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[100];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON180;
transCON183:
	local[0]= NIL;
transCON180:
	w = local[0];
	local[0]= w;
transBLK179:
	ctx->vsp=local; return(local[0]);}

/*:cdar*/
static pointer transM184translator_cdar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[87]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto transCON187;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[101];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON186;
transCON187:
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto transCON188;
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[102];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[103];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON186;
transCON188:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[104];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON186;
transCON189:
	local[0]= NIL;
transCON186:
	w = local[0];
	local[0]= w;
transBLK185:
	ctx->vsp=local; return(local[0]);}

/*:cadr*/
static pointer transM190translator_cadr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[87]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto transCON193;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[105];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON192;
transCON193:
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto transCON194;
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[106];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[107];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON192;
transCON194:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[108];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON192;
transCON195:
	local[0]= NIL;
transCON192:
	w = local[0];
	local[0]= w;
transBLK191:
	ctx->vsp=local; return(local[0]);}

/*:caddr*/
static pointer transM196translator_caddr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[87]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto transCON199;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[109];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON198;
transCON199:
	local[0]= loadglobal(fqv[32]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto transCON200;
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[110];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[111];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[89];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[112];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON198;
transCON200:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[113];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON198;
transCON201:
	local[0]= NIL;
transCON198:
	w = local[0];
	local[0]= w;
transBLK197:
	ctx->vsp=local; return(local[0]);}

/*:cons*/
static pointer transM202translator_cons(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[114];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[115];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK203:
	ctx->vsp=local; return(local[0]);}

/*:svref*/
static pointer transM204translator_svref(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[116];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[117];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[118];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK205:
	ctx->vsp=local; return(local[0]);}

/*:svset*/
static pointer transM206translator_svset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[119];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[121];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[122];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK207:
	ctx->vsp=local; return(local[0]);}

/*:char*/
static pointer transM208translator_char(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[124];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[125];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[126];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK209:
	ctx->vsp=local; return(local[0]);}

/*:setchar*/
static pointer transM210translator_setchar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[128];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[129];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[130];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[131];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK211:
	ctx->vsp=local; return(local[0]);}

/*:bit*/
static pointer transM212translator_bit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[132];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[133];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[134];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK213:
	ctx->vsp=local; return(local[0]);}

/*:setbit*/
static pointer transM214translator_setbit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[135];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[136];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[137];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[138];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[139];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[140];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK215:
	ctx->vsp=local; return(local[0]);}

/*:vref*/
static pointer transM216translator_vref(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[141];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= local[1];
	if (fqv[142]!=local[2]) goto transIF218;
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= fqv[143];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	goto transIF219;
transIF218:
	local[2]= local[1];
	if (fqv[144]!=local[2]) goto transIF220;
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= fqv[145];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	goto transIF221;
transIF220:
	local[2]= local[1];
	if (fqv[146]!=local[2]) goto transIF222;
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= fqv[147];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	goto transIF223;
transIF222:
	local[2]= local[1];
	if (fqv[148]!=local[2]) goto transIF224;
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= fqv[149];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	goto transIF225;
transIF224:
	if (T==NIL) goto transIF226;
	local[2]= argv[0];
	local[3]= fqv[150];
	local[4]= fqv[151];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto transIF227;
transIF226:
	local[2]= NIL;
transIF227:
transIF225:
transIF223:
transIF221:
transIF219:
	w = local[2];
	local[1]= argv[0];
	local[2]= fqv[15];
	local[3]= fqv[152];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
transBLK217:
	ctx->vsp=local; return(local[0]);}

/*:vset*/
static pointer transM228translator_vset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[153];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[154];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[155];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[2];
	local[1]= local[0];
	if (fqv[142]!=local[1]) goto transIF230;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[156];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= w;
	goto transIF231;
transIF230:
	local[1]= local[0];
	if (fqv[144]!=local[1]) goto transIF232;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[157];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= w;
	goto transIF233;
transIF232:
	local[1]= local[0];
	if (fqv[146]!=local[1]) goto transIF234;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[158];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= w;
	goto transIF235;
transIF234:
	local[1]= local[0];
	if (fqv[148]!=local[1]) goto transIF236;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[159];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= w;
	goto transIF237;
transIF236:
	if (T==NIL) goto transIF238;
	local[1]= argv[0];
	local[2]= fqv[150];
	local[3]= fqv[160];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto transIF239;
transIF238:
	local[1]= NIL;
transIF239:
transIF237:
transIF235:
transIF233:
transIF231:
	w = local[1];
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[161];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK229:
	ctx->vsp=local; return(local[0]);}

/*:nullx*/
static pointer transM240translator_nullx(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[162];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK241:
	ctx->vsp=local; return(local[0]);}

/*:eqx*/
static pointer transM242translator_eqx(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[163];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[12];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK243:
	ctx->vsp=local; return(local[0]);}

/*:memqx*/
static pointer transM244translator_memqx(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[164];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[165];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK245:
	ctx->vsp=local; return(local[0]);}

/*:type-check-predicate*/
static pointer transM246translator_type_check_predicate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[166];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[167];
	local[4]= argv[2];
	local[5]= fqv[168];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,2,local+4,&ftab[3],fqv[169]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK247:
	ctx->vsp=local; return(local[0]);}

/*:if-nil*/
static pointer transM248translator_if_nil(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[170];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
transBLK249:
	ctx->vsp=local; return(local[0]);}

/*:if-t*/
static pointer transM250translator_if_t(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[171];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
transBLK251:
	ctx->vsp=local; return(local[0]);}

/*:if-eq*/
static pointer transM252translator_if_eq(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[172];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= w;
transBLK253:
	ctx->vsp=local; return(local[0]);}

/*:if-neq*/
static pointer transM254translator_if_neq(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[173];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= w;
transBLK255:
	ctx->vsp=local; return(local[0]);}

/*:int-op2*/
static pointer transM256translator_int_op2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = fqv[174];
	if (memq(local[0],w)==NIL) goto transCON259;
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[175];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[2];
	w = fqv[176];
	if (memq(local[0],w)==NIL) goto transIF260;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
	goto transIF261;
transIF260:
	local[0]= NIL;
transIF261:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[178];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= fqv[179];
	ctx->vsp=local+7;
	w=(pointer)ASSQ(ctx,2,local+5); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON258;
transCON259:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[180];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[181];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[182];
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= argv[2];
	local[4]= fqv[183];
	ctx->vsp=local+5;
	w=(pointer)ASSQ(ctx,2,local+3); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= argv[0]->c.obj.iv[3];
	goto transCON258;
transCON262:
	local[0]= NIL;
transCON258:
	w = local[0];
	local[0]= w;
transBLK257:
	ctx->vsp=local; return(local[0]);}

/*:int-neg*/
static pointer transM263translator_int_neg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[184];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK264:
	ctx->vsp=local; return(local[0]);}

/*:int-abs*/
static pointer transM265translator_int_abs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[185];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK266:
	ctx->vsp=local; return(local[0]);}

/*:flt-abs*/
static pointer transM267translator_flt_abs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[186];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK268:
	ctx->vsp=local; return(local[0]);}

/*:compare*/
static pointer transM269translator_compare(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[3];
	if (fqv[187]!=local[0]) goto transCON272;
	local[0]= argv[0];
	local[1]= fqv[188];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON271;
transCON272:
	local[0]= argv[3];
	if (fqv[189]!=local[0]) goto transCON273;
	local[0]= argv[0];
	local[1]= fqv[190];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON271;
transCON273:
	local[0]= argv[2];
	if (fqv[191]!=local[0]) goto transCON274;
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[192];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[193];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= w;
	goto transCON271;
transCON274:
	local[0]= argv[2];
	if (fqv[146]!=local[0]) goto transCON275;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[194];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[195];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[196];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	goto transCON271;
transCON275:
	local[0]= argv[0];
	local[1]= fqv[150];
	local[2]= fqv[197];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto transCON271;
transCON276:
	local[0]= NIL;
transCON271:
	w = local[0];
	local[0]= w;
transBLK270:
	ctx->vsp=local; return(local[0]);}

/*:flt-op2*/
static pointer transM277translator_flt_op2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[198];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[199];
	local[2]= argv[0];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[200];
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= argv[2];
	local[4]= fqv[201];
	ctx->vsp=local+5;
	w=(pointer)ASSQ(ctx,2,local+3); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK278:
	ctx->vsp=local; return(local[0]);}

/*:flt-neg*/
static pointer transM279translator_flt_neg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[202];
	local[4]= argv[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK280:
	ctx->vsp=local; return(local[0]);}

/*:type-checker*/
static pointer transM281translator_type_checker(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[203];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
transBLK282:
	ctx->vsp=local; return(local[0]);}

/*:if-type*/
static pointer transM283translator_if_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[204];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[205];
	local[2]= argv[0];
	local[3]= fqv[206];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
transBLK284:
	ctx->vsp=local; return(local[0]);}

/*:if-not-type*/
static pointer transM285translator_if_not_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[207];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[208];
	local[2]= argv[0];
	local[3]= fqv[206];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
transBLK286:
	ctx->vsp=local; return(local[0]);}

/*:jump*/
static pointer transM287translator_jump(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[209];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transBLK288:
	ctx->vsp=local; return(local[0]);}

/*:return*/
static pointer transM289translator_return(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[210];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w!=NIL) goto transIF291;
	local[0]= fqv[211];
	local[1]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[212]); /*warn*/
	local[0]= w;
	goto transIF292;
transIF291:
	local[0]= NIL;
transIF292:
	w = local[0];
	local[0]= w;
transBLK290:
	ctx->vsp=local; return(local[0]);}

/*:del-frame*/
static pointer transM293translator_del_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[213];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[75];
	local[2]= makeint((eusinteger_t)3L);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[214];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK294:
	ctx->vsp=local; return(local[0]);}

/*:entercatch*/
static pointer transM295translator_entercatch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[217];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[218];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)6L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK296:
	ctx->vsp=local; return(local[0]);}

/*:exitcatch*/
static pointer transM297translator_exitcatch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[219];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[220];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[221];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[222];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)6L);
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[223];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK298:
	ctx->vsp=local; return(local[0]);}

/*:throw*/
static pointer transM299translator_throw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[224];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[225];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[226];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
transBLK300:
	ctx->vsp=local; return(local[0]);}

/*:bind-cleaner*/
static pointer transM301translator_bind_cleaner(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[227];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[228];
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK302:
	ctx->vsp=local; return(local[0]);}

/*:call-cleaner*/
static pointer transM303translator_call_cleaner(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[229];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[230];
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[231];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[232];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK304:
	ctx->vsp=local; return(local[0]);}

/*:return-from*/
static pointer transM305translator_return_from(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= fqv[233];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (argv[3]==NIL) goto transIF307;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[234];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto transIF308;
transIF307:
	local[0]= NIL;
transIF308:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[235];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK306:
	ctx->vsp=local; return(local[0]);}

/*:go-tag*/
static pointer transM309translator_go_tag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (argv[3]==NIL) goto transIF311;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[236];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto transIF312;
transIF311:
	local[0]= NIL;
transIF312:
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK310:
	ctx->vsp=local; return(local[0]);}

/*:closure*/
static pointer transM313translator_closure(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	local[3]= fqv[237];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
transBLK314:
	ctx->vsp=local; return(local[0]);}

/*:defun*/
static pointer transM315translator_defun(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[238];
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= w;
transBLK316:
	ctx->vsp=local; return(local[0]);}

/*:defmacro*/
static pointer transM317translator_defmacro(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[239];
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= w;
transBLK318:
	ctx->vsp=local; return(local[0]);}

/*:quote-fqv-entry*/
static pointer transM319translator_quote_fqv_entry(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[2]!=NIL) goto transIF321;
	local[0]= fqv[240];
	goto transIF322;
transIF321:
	local[0]= NIL;
	local[1]= fqv[241];
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transIF322:
	w = local[0];
	local[0]= w;
transBLK320:
	ctx->vsp=local; return(local[0]);}

/*:defmethod*/
static pointer transM323translator_defmethod(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[242];
	local[2]= argv[4];
	local[3]= argv[0];
	local[4]= fqv[23];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[243];
	local[7]= argv[5];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,6,local+0); /*format*/
	local[0]= w;
transBLK324:
	ctx->vsp=local; return(local[0]);}

/*:declare-forward-function*/
static pointer transM325translator_declare_forward_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[244];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transBLK326:
	ctx->vsp=local; return(local[0]);}

/*:quote*/
static pointer transM327translator_quote(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
transBLK328:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer transM329translator_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[2] = NIL;
	argv[0]->c.obj.iv[3] = makeint((eusinteger_t)0L);
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
transBLK330:
	ctx->vsp=local; return(local[0]);}

/*:init-file*/
static pointer transM331translator_init_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[3];
	local[1]= fqv[245];
	local[2]= fqv[246];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,3,local+0,&ftab[5],fqv[247]); /*open*/
	argv[0]->c.obj.iv[0] = w;
	local[0]= argv[4];
	local[1]= fqv[245];
	local[2]= fqv[246];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,3,local+0,&ftab[5],fqv[247]); /*open*/
	argv[0]->c.obj.iv[1] = w;
	argv[0]->c.obj.iv[4] = NIL;
	storeglobal(fqv[5],NIL);
	local[0]= makeint((eusinteger_t)0L);
	storeglobal(fqv[4],local[0]);
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[248];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,1,local+2,&ftab[6],fqv[249]); /*namestring*/
	local[2]= w;
	local[3]= argv[5];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[250];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,0,local+2,&ftab[7],fqv[251]); /*lisp-implementation-version*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[252];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[253];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[254]); /*pathname-name*/
	local[2]= w;
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[255]); /*pathname-type*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[256];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[257];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[258];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[259];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= loadglobal(fqv[87]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto transCON334;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[260];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[261];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
	goto transCON333;
transCON334:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[262];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
	goto transCON333;
transCON335:
	local[0]= NIL;
transCON333:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[263];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= fqv[264];
	w = loadglobal(fqv[265]);
	if (memq(local[0],w)==NIL) goto transIF336;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[266];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto transIF337;
transIF336:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[267];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
transIF337:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[268];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[269];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[270];
	local[2]= loadglobal(fqv[2]);
	local[3]= fqv[271];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[254]); /*pathname-name*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)CONCATENATE(ctx,3,local+2); /*concatenate*/
	local[2]= w;
	local[3]= argv[5];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= NIL;
	local[1]= loadglobal(fqv[272]);
transWHL338:
	if (local[1]==NIL) goto transWHX339;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= fqv[273];
	local[4]= local[0];
	local[5]= fqv[68];
	ctx->vsp=local+6;
	w=(pointer)GETPROP(ctx,2,local+4); /*get*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	goto transWHL338;
transWHX339:
	local[2]= NIL;
transBLK340:
	w = NIL;
	local[0]= w;
transBLK332:
	ctx->vsp=local; return(local[0]);}

/*:eusmain*/
static pointer transM341translator_eusmain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[274];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[275];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[276];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[277];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[278];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[279];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[280];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[281];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[282];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
transBLK342:
	ctx->vsp=local; return(local[0]);}

/*:write-quote-vector*/
static pointer transM343translator_write_quote_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[283];
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[284];
	local[2]= fqv[285];
	w = loadglobal(fqv[265]);
	if (memq(local[2],w)==NIL) goto transIF345;
	local[2]= fqv[286];
	goto transIF346;
transIF345:
	local[2]= fqv[287];
transIF346:
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[4];
transWHL347:
	if (local[1]==NIL) goto transWHX348;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,1,local+2,&ftab[0],fqv[0]); /*prin1-to-string*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= fqv[288];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
transWHL350:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto transWHX351;
	local[7]= local[2];
	{ register eusinteger_t i=intval(local[5]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	local[8]= makeint((eusinteger_t)92L);
	ctx->vsp=local+9;
	w=(pointer)EQ(ctx,2,local+7); /*eql*/
	if (w==NIL) goto transCON354;
	local[7]= makeint((eusinteger_t)92L);
	local[8]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+9;
	w=(pointer)WRTBYTE(ctx,2,local+7); /*write-byte*/
	local[7]= makeint((eusinteger_t)92L);
	local[8]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+9;
	w=(pointer)WRTBYTE(ctx,2,local+7); /*write-byte*/
	local[7]= w;
	goto transCON353;
transCON354:
	local[7]= local[2];
	{ register eusinteger_t i=intval(local[5]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	local[8]= makeint((eusinteger_t)34L);
	ctx->vsp=local+9;
	w=(pointer)EQ(ctx,2,local+7); /*eql*/
	if (w==NIL) goto transCON355;
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= fqv[289];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= w;
	goto transCON353;
transCON355:
	local[7]= local[2];
	{ register eusinteger_t i=intval(local[5]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	local[8]= makeint((eusinteger_t)10L);
	ctx->vsp=local+9;
	w=(pointer)EQ(ctx,2,local+7); /*eql*/
	if (w==NIL) goto transCON356;
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= fqv[290];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= w;
	goto transCON353;
transCON356:
	local[7]= local[2];
	{ register eusinteger_t i=intval(local[5]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+9;
	w=(pointer)WRTBYTE(ctx,2,local+7); /*write-byte*/
	local[7]= w;
	goto transCON353;
transCON357:
	local[7]= NIL;
transCON353:
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto transWHL350;
transWHX351:
	local[7]= NIL;
transBLK352:
	w = NIL;
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= fqv[291];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	goto transWHL347;
transWHX348:
	local[2]= NIL;
transBLK349:
	w = NIL;
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[292];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
transBLK344:
	ctx->vsp=local; return(local[0]);}

/*:declare-ftab*/
static pointer transM358translator_declare_ftab(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[4]);
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto transIF360;
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[293];
	local[2]= loadglobal(fqv[4]);
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto transIF361;
transIF360:
	local[0]= NIL;
transIF361:
	w = local[0];
	local[0]= w;
transBLK359:
	ctx->vsp=local; return(local[0]);}

/*:ftab-initializer*/
static pointer transM362translator_ftab_initializer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[294];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= loadglobal(fqv[4]);
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto transIF364;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[295];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[296];
	local[2]= loadglobal(fqv[4]);
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto transIF365;
transIF364:
	local[0]= NIL;
transIF365:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[297];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= NIL;
	local[1]= loadglobal(fqv[5]);
transWHL366:
	if (local[1]==NIL) goto transWHX367;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,2,local+2,&ftab[10],fqv[298]); /*remprop*/
	goto transWHL366;
transWHX367:
	local[2]= NIL;
transBLK368:
	w = NIL;
	local[0]= w;
transBLK363:
	ctx->vsp=local; return(local[0]);}

/*:close*/
static pointer transM369translator_close(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
transBLK370:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___trans(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[299];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto transIF371;
	local[0]= fqv[300];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[301],w);
	goto transIF372;
transIF371:
	local[0]= fqv[302];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
transIF372:
	local[0]= fqv[303];
	local[1]= fqv[304];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto transIF373;
	local[0]= fqv[303];
	local[1]= fqv[304];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[303];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto transIF375;
	local[0]= fqv[303];
	local[1]= fqv[305];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto transIF376;
transIF375:
	local[0]= NIL;
transIF376:
	local[0]= fqv[303];
	goto transIF374;
transIF373:
	local[0]= NIL;
transIF374:
	ctx->vsp=local+0;
	compfun(ctx,fqv[306],module,transF1c_stringize,fqv[307]);
	local[0]= fqv[308];
	local[1]= fqv[305];
	local[2]= fqv[308];
	local[3]= fqv[309];
	local[4]= loadglobal(fqv[310]);
	local[5]= fqv[311];
	local[6]= fqv[312];
	local[7]= fqv[313];
	local[8]= NIL;
	local[9]= fqv[314];
	local[10]= NIL;
	local[11]= fqv[315];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[316];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[11])(ctx,13,local+2,&ftab[11],fqv[317]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[4];
	local[1]= fqv[305];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[5];
	local[1]= fqv[305];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[318],module,transF2ftab_index,fqv[319]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM15translator_label,fqv[220],fqv[308],fqv[320]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM17translator_comment,fqv[26],fqv[308],fqv[321]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM23translator_pop,fqv[12],fqv[308],fqv[322]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM27translator_store,fqv[19],fqv[308],fqv[323]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM32translator_push,fqv[15],fqv[308],fqv[324]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM34translator_clearpush,fqv[6],fqv[308],fqv[325]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM38translator_quote_entry,fqv[23],fqv[308],fqv[326]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM43translator_dupe,fqv[327],fqv[308],fqv[328]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM48translator_discard,fqv[75],fqv[308],fqv[329]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM54translator_adjust,fqv[330],fqv[308],fqv[331]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM56translator_setpushcount,fqv[332],fqv[308],fqv[333]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM58translator_offset_from_fp,fqv[334],fqv[308],fqv[335]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM60translator_reset_vsp,fqv[21],fqv[308],fqv[336]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM62translator_bind_special,fqv[337],fqv[308],fqv[338]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM64translator_unbind_special,fqv[339],fqv[308],fqv[340]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM66translator_pushenv,fqv[341],fqv[308],fqv[342]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM68translator_enter,fqv[343],fqv[308],fqv[344]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM70translator_check_req_arg,fqv[345],fqv[308],fqv[346]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM80translator_check_opt_arg,fqv[347],fqv[308],fqv[348]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM82translator_check_rest_arg,fqv[349],fqv[308],fqv[350]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM86translator_rest,fqv[351],fqv[308],fqv[352]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM88translator_parse_key_params,fqv[353],fqv[308],fqv[354]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM92translator_check_key_arg,fqv[355],fqv[308],fqv[356]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM94translator_getbase,fqv[54],fqv[308],fqv[357]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM106translator_load_t,fqv[358],fqv[308],fqv[359]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM108translator_load_nil,fqv[360],fqv[308],fqv[361]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM110translator_load_int,fqv[362],fqv[308],fqv[363]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM112translator_load_float,fqv[364],fqv[308],fqv[365]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM114translator_load_quote,fqv[366],fqv[308],fqv[367]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM116translator_load_arg,fqv[368],fqv[308],fqv[369]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM118translator_load_local,fqv[370],fqv[308],fqv[371]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM120translator_load_obj,fqv[372],fqv[308],fqv[373]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM122translator_load_global,fqv[374],fqv[308],fqv[375]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM124translator_store_arg,fqv[376],fqv[308],fqv[377]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM126translator_store_local,fqv[378],fqv[308],fqv[379]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM128translator_store_obj,fqv[380],fqv[308],fqv[381]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM130translator_store_global,fqv[382],fqv[308],fqv[383]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM132translator_load_ovaf,fqv[384],fqv[308],fqv[385]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM134translator_load_indexed_ov,fqv[386],fqv[308],fqv[387]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM136translator_store_ovaf,fqv[388],fqv[308],fqv[389]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM138translator_store_indexed_ov,fqv[390],fqv[308],fqv[391]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM140translator_call,fqv[392],fqv[308],fqv[393]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM148translator_call_closure,fqv[394],fqv[308],fqv[395]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM150translator_getfunc,fqv[396],fqv[308],fqv[397]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM152translator_1_,fqv[398],fqv[308],fqv[399]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM154translator_1_,fqv[400],fqv[308],fqv[401]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM156translator_check_cons_nil,fqv[89],fqv[308],fqv[402]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM160translator_car,fqv[403],fqv[308],fqv[404]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM166translator_cdr,fqv[405],fqv[308],fqv[406]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM172translator_caar,fqv[407],fqv[308],fqv[408]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM178translator_cddr,fqv[409],fqv[308],fqv[410]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM184translator_cdar,fqv[411],fqv[308],fqv[412]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM190translator_cadr,fqv[413],fqv[308],fqv[414]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM196translator_caddr,fqv[415],fqv[308],fqv[416]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM202translator_cons,fqv[417],fqv[308],fqv[418]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM204translator_svref,fqv[419],fqv[308],fqv[420]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM206translator_svset,fqv[421],fqv[308],fqv[422]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM208translator_char,fqv[423],fqv[308],fqv[424]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM210translator_setchar,fqv[425],fqv[308],fqv[426]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM212translator_bit,fqv[427],fqv[308],fqv[428]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM214translator_setbit,fqv[429],fqv[308],fqv[430]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM216translator_vref,fqv[431],fqv[308],fqv[432]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM228translator_vset,fqv[433],fqv[308],fqv[434]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM240translator_nullx,fqv[435],fqv[308],fqv[436]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM242translator_eqx,fqv[437],fqv[308],fqv[438]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM244translator_memqx,fqv[439],fqv[308],fqv[440]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM246translator_type_check_predicate,fqv[441],fqv[308],fqv[442]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM248translator_if_nil,fqv[443],fqv[308],fqv[444]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM250translator_if_t,fqv[445],fqv[308],fqv[446]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM252translator_if_eq,fqv[190],fqv[308],fqv[447]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM254translator_if_neq,fqv[188],fqv[308],fqv[448]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM256translator_int_op2,fqv[449],fqv[308],fqv[450]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM263translator_int_neg,fqv[451],fqv[308],fqv[452]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM265translator_int_abs,fqv[453],fqv[308],fqv[454]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM267translator_flt_abs,fqv[455],fqv[308],fqv[456]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM269translator_compare,fqv[457],fqv[308],fqv[458]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM277translator_flt_op2,fqv[459],fqv[308],fqv[460]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM279translator_flt_neg,fqv[461],fqv[308],fqv[462]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM281translator_type_checker,fqv[206],fqv[308],fqv[463]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM283translator_if_type,fqv[464],fqv[308],fqv[465]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM285translator_if_not_type,fqv[466],fqv[308],fqv[467]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM287translator_jump,fqv[468],fqv[308],fqv[469]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM289translator_return,fqv[470],fqv[308],fqv[471]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM293translator_del_frame,fqv[472],fqv[308],fqv[473]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM295translator_entercatch,fqv[474],fqv[308],fqv[475]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM297translator_exitcatch,fqv[476],fqv[308],fqv[477]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM299translator_throw,fqv[478],fqv[308],fqv[479]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM301translator_bind_cleaner,fqv[480],fqv[308],fqv[481]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM303translator_call_cleaner,fqv[482],fqv[308],fqv[483]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM305translator_return_from,fqv[484],fqv[308],fqv[485]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM309translator_go_tag,fqv[486],fqv[308],fqv[487]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM313translator_closure,fqv[488],fqv[308],fqv[489]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM315translator_defun,fqv[490],fqv[308],fqv[491]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM317translator_defmacro,fqv[492],fqv[308],fqv[493]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM319translator_quote_fqv_entry,fqv[243],fqv[308],fqv[494]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM323translator_defmethod,fqv[495],fqv[308],fqv[496]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM325translator_declare_forward_function,fqv[497],fqv[308],fqv[498]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM327translator_quote,fqv[499],fqv[308],fqv[500]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM329translator_init,fqv[501],fqv[308],fqv[502]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM331translator_init_file,fqv[503],fqv[308],fqv[504]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM341translator_eusmain,fqv[505],fqv[308],fqv[506]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM343translator_write_quote_vector,fqv[507],fqv[308],fqv[508]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM358translator_declare_ftab,fqv[509],fqv[308],fqv[510]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM362translator_ftab_initializer,fqv[511],fqv[308],fqv[512]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,transM369translator_close,fqv[513],fqv[308],fqv[514]);
	local[0]= loadglobal(fqv[308]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	storeglobal(fqv[303],w);
	local[0]= fqv[515];
	local[1]= fqv[516];
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,2,local+0,&ftab[12],fqv[517]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<13; i++) ftab[i]=fcallx;
}

(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(QUESTION-VAL
          QUESTION
          ANSWER-VAL
          ANSWER
))
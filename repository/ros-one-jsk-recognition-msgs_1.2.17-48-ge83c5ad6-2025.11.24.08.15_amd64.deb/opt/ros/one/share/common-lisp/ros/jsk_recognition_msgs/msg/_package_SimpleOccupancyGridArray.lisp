(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          GRIDS-VAL
          GRIDS
))
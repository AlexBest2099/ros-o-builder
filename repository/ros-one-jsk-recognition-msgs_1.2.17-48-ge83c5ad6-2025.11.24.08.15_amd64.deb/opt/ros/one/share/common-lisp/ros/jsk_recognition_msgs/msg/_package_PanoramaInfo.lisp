(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          PROJECTION_MODEL-VAL
          PROJECTION_MODEL
          IMAGE_HEIGHT-VAL
          IMAGE_HEIGHT
          IMAGE_WIDTH-VAL
          IMAGE_WIDTH
          THETA_MIN-VAL
          THETA_MIN
          THETA_MAX-VAL
          THETA_MAX
          PHI_MIN-VAL
          PHI_MIN
          PHI_MAX-VAL
          PHI_MAX
))
(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(IMAGE-VAL
          IMAGE
          COMPRESSED_IMAGE-VAL
          COMPRESSED_IMAGE
          QUESTIONS-VAL
          QUESTIONS
))
; Auto-generated. Do not edit!


(cl:in-package jsk_recognition_msgs-msg)


;//! \htmlinclude VQAResult.msg.html

(cl:defclass <VQAResult> (roslisp-msg-protocol:ros-message)
  ((result
    :reader result
    :initarg :result
    :type (cl:vector jsk_recognition_msgs-msg:QuestionAndAnswerText)
   :initform (cl:make-array 0 :element-type 'jsk_recognition_msgs-msg:QuestionAndAnswerText :initial-element (cl:make-instance 'jsk_recognition_msgs-msg:QuestionAndAnswerText))))
)

(cl:defclass VQAResult (<VQAResult>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <VQAResult>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'VQAResult)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_recognition_msgs-msg:<VQAResult> is deprecated: use jsk_recognition_msgs-msg:VQAResult instead.")))

(cl:ensure-generic-function 'result-val :lambda-list '(m))
(cl:defmethod result-val ((m <VQAResult>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:result-val is deprecated.  Use jsk_recognition_msgs-msg:result instead.")
  (result m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <VQAResult>) ostream)
  "Serializes a message object of type '<VQAResult>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'result))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'result))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <VQAResult>) istream)
  "Deserializes a message object of type '<VQAResult>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'result) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'result)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'jsk_recognition_msgs-msg:QuestionAndAnswerText))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<VQAResult>)))
  "Returns string type for a message object of type '<VQAResult>"
  "jsk_recognition_msgs/VQAResult")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'VQAResult)))
  "Returns string type for a message object of type 'VQAResult"
  "jsk_recognition_msgs/VQAResult")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<VQAResult>)))
  "Returns md5sum for a message object of type '<VQAResult>"
  "8899eb6036ebfcfe80ce4291b9c06ac0")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'VQAResult)))
  "Returns md5sum for a message object of type 'VQAResult"
  "8899eb6036ebfcfe80ce4291b9c06ac0")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<VQAResult>)))
  "Returns full string definition for message of type '<VQAResult>"
  (cl:format cl:nil "jsk_recognition_msgs/QuestionAndAnswerText[] result~%~%================================================================================~%MSG: jsk_recognition_msgs/QuestionAndAnswerText~%string question~%string answer~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'VQAResult)))
  "Returns full string definition for message of type 'VQAResult"
  (cl:format cl:nil "jsk_recognition_msgs/QuestionAndAnswerText[] result~%~%================================================================================~%MSG: jsk_recognition_msgs/QuestionAndAnswerText~%string question~%string answer~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <VQAResult>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'result) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <VQAResult>))
  "Converts a ROS message object to a list"
  (cl:list 'VQAResult
    (cl:cons ':result (result msg))
))

(cl:in-package nfc_ros-msg)
(cl:export '(TYPE-VAL
          TYPE
          NAME-VAL
          NAME
          DATA-VAL
          DATA
))
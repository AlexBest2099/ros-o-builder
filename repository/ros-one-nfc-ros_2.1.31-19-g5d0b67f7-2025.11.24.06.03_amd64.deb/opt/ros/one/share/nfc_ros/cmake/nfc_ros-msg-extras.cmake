set(nfc_ros_MESSAGE_FILES "msg/NDEFRecord.msg;msg/Tag.msg")
set(nfc_ros_SERVICE_FILES "")

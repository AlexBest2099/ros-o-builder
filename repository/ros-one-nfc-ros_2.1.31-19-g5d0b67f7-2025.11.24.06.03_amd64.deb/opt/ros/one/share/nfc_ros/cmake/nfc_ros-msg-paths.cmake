# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${nfc_ros_DIR}/.." "msg" nfc_ros_MSG_INCLUDE_DIRS UNIQUE)
set(nfc_ros_MSG_DEPENDENCIES )


"use strict";

let Tag = require('./Tag.js');
let NDEFRecord = require('./NDEFRecord.js');

module.exports = {
  Tag: Tag,
  NDEFRecord: NDEFRecord,
};


"use strict";

let TestTimeArray = require('./TestTimeArray.js');
let TestDurationArray = require('./TestDurationArray.js');
let TestChar = require('./TestChar.js');
let TestUInt8 = require('./TestUInt8.js');
let TestHeaderTwo = require('./TestHeaderTwo.js');
let TestUInt8FixedSizeArray16 = require('./TestUInt8FixedSizeArray16.js');
let Num = require('./Num.js');
let TestHeaderArray = require('./TestHeaderArray.js');
let TestHeader = require('./TestHeader.js');

module.exports = {
  TestTimeArray: TestTimeArray,
  TestDurationArray: TestDurationArray,
  TestChar: TestChar,
  TestUInt8: TestUInt8,
  TestHeaderTwo: TestHeaderTwo,
  TestUInt8FixedSizeArray16: TestUInt8FixedSizeArray16,
  Num: Num,
  TestHeaderArray: TestHeaderArray,
  TestHeader: TestHeader,
};

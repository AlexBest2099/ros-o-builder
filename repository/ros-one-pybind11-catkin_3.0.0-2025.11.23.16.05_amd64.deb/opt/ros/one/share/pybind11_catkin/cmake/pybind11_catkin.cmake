cmake_minimum_required(VERSION 3.12)

set(PYBIND11_PYTHON_VERSION ${PYTHON_VERSION_STRING})
find_package(pybind11  REQUIRED)

list(APPEND pybind11_catkin_LIBRARIES pybind11::pybind11)
list(APPEND pybind11_catkin_INCLUDE_DIRS ${pybind11_INCLUDE_DIRS})

# Augment the pybind11_add_module function to set the output directory
macro(pybind_add_module target_name)
    pybind11_add_module(${ARGV})
    set_target_properties(${target_name} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${CATKIN_DEVEL_PREFIX}/${CATKIN_GLOBAL_PYTHON_DESTINATION})
endmacro(pybind_add_module)

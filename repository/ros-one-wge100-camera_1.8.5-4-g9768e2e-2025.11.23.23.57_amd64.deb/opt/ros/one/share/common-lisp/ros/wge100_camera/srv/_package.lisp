(cl:defpackage wge100_camera-srv
  (:use )
  (:export
   "BOARDCONFIG"
   "<BOARDCONFIG-REQUEST>"
   "BOARDCONFIG-REQUEST"
   "<BOARDCONFIG-RESPONSE>"
   "BOARDCONFIG-RESPONSE"
  ))


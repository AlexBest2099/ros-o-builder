
"use strict";

let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');
let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');
let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');
let FaceDetectorResult = require('./FaceDetectorResult.js');
let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');

module.exports = {
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorActionResult: FaceDetectorActionResult,
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorGoal: FaceDetectorGoal,
  FaceDetectorActionGoal: FaceDetectorActionGoal,
  FaceDetectorResult: FaceDetectorResult,
  FaceDetectorFeedback: FaceDetectorFeedback,
};

(cl:defpackage moveit_by_name-msg
  (:use )
  (:export
   "<COMMAND>"
   "COMMAND"
  ))


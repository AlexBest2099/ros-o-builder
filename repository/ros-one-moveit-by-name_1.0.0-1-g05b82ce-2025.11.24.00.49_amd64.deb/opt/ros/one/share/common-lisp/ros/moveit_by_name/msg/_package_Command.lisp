(cl:in-package moveit_by_name-msg)
(cl:export '(GROUP-VAL
          GROUP
          TARGET-VAL
          TARGET
))
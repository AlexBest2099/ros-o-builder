set(moveit_by_name_MESSAGE_FILES "msg/Command.msg")
set(moveit_by_name_SERVICE_FILES "")

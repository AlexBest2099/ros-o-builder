# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${moveit_by_name_DIR}/.." "msg" moveit_by_name_MSG_INCLUDE_DIRS UNIQUE)
set(moveit_by_name_MSG_DEPENDENCIES )

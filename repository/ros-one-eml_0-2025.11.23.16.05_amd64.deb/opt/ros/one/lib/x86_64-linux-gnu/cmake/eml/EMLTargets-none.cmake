#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "eml::eml-dynamic" for configuration "None"
set_property(TARGET eml::eml-dynamic APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eml::eml-dynamic PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libeml.so"
  IMPORTED_SONAME_NONE "libeml.so"
  )

list(APPEND _cmake_import_check_targets eml::eml-dynamic )
list(APPEND _cmake_import_check_files_for_eml::eml-dynamic "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libeml.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${dynamic_tf_publisher_DIR}/.." "" dynamic_tf_publisher_MSG_INCLUDE_DIRS UNIQUE)
set(dynamic_tf_publisher_MSG_DEPENDENCIES geometry_msgs)

; Auto-generated. Do not edit!


(cl:in-package dynamic_tf_publisher-srv)


;//! \htmlinclude DeleteTF-request.msg.html

(cl:defclass <DeleteTF-request> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header)))
)

(cl:defclass DeleteTF-request (<DeleteTF-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DeleteTF-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DeleteTF-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name dynamic_tf_publisher-srv:<DeleteTF-request> is deprecated: use dynamic_tf_publisher-srv:DeleteTF-request instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <DeleteTF-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader dynamic_tf_publisher-srv:header-val is deprecated.  Use dynamic_tf_publisher-srv:header instead.")
  (header m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DeleteTF-request>) ostream)
  "Serializes a message object of type '<DeleteTF-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DeleteTF-request>) istream)
  "Deserializes a message object of type '<DeleteTF-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DeleteTF-request>)))
  "Returns string type for a service object of type '<DeleteTF-request>"
  "dynamic_tf_publisher/DeleteTFRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DeleteTF-request)))
  "Returns string type for a service object of type 'DeleteTF-request"
  "dynamic_tf_publisher/DeleteTFRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DeleteTF-request>)))
  "Returns md5sum for a message object of type '<DeleteTF-request>"
  "d7be0bb39af8fb9129d5a76e6b63a290")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DeleteTF-request)))
  "Returns md5sum for a message object of type 'DeleteTF-request"
  "d7be0bb39af8fb9129d5a76e6b63a290")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DeleteTF-request>)))
  "Returns full string definition for message of type '<DeleteTF-request>"
  (cl:format cl:nil "Header  header~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DeleteTF-request)))
  "Returns full string definition for message of type 'DeleteTF-request"
  (cl:format cl:nil "Header  header~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DeleteTF-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DeleteTF-request>))
  "Converts a ROS message object to a list"
  (cl:list 'DeleteTF-request
    (cl:cons ':header (header msg))
))
;//! \htmlinclude DeleteTF-response.msg.html

(cl:defclass <DeleteTF-response> (roslisp-msg-protocol:ros-message)
  ()
)

(cl:defclass DeleteTF-response (<DeleteTF-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DeleteTF-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DeleteTF-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name dynamic_tf_publisher-srv:<DeleteTF-response> is deprecated: use dynamic_tf_publisher-srv:DeleteTF-response instead.")))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DeleteTF-response>) ostream)
  "Serializes a message object of type '<DeleteTF-response>"
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DeleteTF-response>) istream)
  "Deserializes a message object of type '<DeleteTF-response>"
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DeleteTF-response>)))
  "Returns string type for a service object of type '<DeleteTF-response>"
  "dynamic_tf_publisher/DeleteTFResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DeleteTF-response)))
  "Returns string type for a service object of type 'DeleteTF-response"
  "dynamic_tf_publisher/DeleteTFResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DeleteTF-response>)))
  "Returns md5sum for a message object of type '<DeleteTF-response>"
  "d7be0bb39af8fb9129d5a76e6b63a290")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DeleteTF-response)))
  "Returns md5sum for a message object of type 'DeleteTF-response"
  "d7be0bb39af8fb9129d5a76e6b63a290")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DeleteTF-response>)))
  "Returns full string definition for message of type '<DeleteTF-response>"
  (cl:format cl:nil "~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DeleteTF-response)))
  "Returns full string definition for message of type 'DeleteTF-response"
  (cl:format cl:nil "~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DeleteTF-response>))
  (cl:+ 0
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DeleteTF-response>))
  "Converts a ROS message object to a list"
  (cl:list 'DeleteTF-response
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'DeleteTF)))
  'DeleteTF-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'DeleteTF)))
  'DeleteTF-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DeleteTF)))
  "Returns string type for a service object of type '<DeleteTF>"
  "dynamic_tf_publisher/DeleteTF")
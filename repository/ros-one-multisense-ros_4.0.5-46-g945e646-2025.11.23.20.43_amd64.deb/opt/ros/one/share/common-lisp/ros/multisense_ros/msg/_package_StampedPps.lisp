(cl:in-package multisense_ros-msg)
(cl:export '(DATA-VAL
          DATA
          HOST_TIME-VAL
          HOST_TIME
))
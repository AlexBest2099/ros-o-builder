; Auto-generated. Do not edit!


(cl:in-package multisense_ros-msg)


;//! \htmlinclude StampedPps.msg.html

(cl:defclass <StampedPps> (roslisp-msg-protocol:ros-message)
  ((data
    :reader data
    :initarg :data
    :type cl:real
    :initform 0)
   (host_time
    :reader host_time
    :initarg :host_time
    :type cl:real
    :initform 0))
)

(cl:defclass StampedPps (<StampedPps>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <StampedPps>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'StampedPps)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name multisense_ros-msg:<StampedPps> is deprecated: use multisense_ros-msg:StampedPps instead.")))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <StampedPps>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:data-val is deprecated.  Use multisense_ros-msg:data instead.")
  (data m))

(cl:ensure-generic-function 'host_time-val :lambda-list '(m))
(cl:defmethod host_time-val ((m <StampedPps>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:host_time-val is deprecated.  Use multisense_ros-msg:host_time instead.")
  (host_time m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <StampedPps>) ostream)
  "Serializes a message object of type '<StampedPps>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'data)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'data) (cl:floor (cl:slot-value msg 'data)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'host_time)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'host_time) (cl:floor (cl:slot-value msg 'host_time)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <StampedPps>) istream)
  "Deserializes a message object of type '<StampedPps>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'data) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'host_time) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<StampedPps>)))
  "Returns string type for a message object of type '<StampedPps>"
  "multisense_ros/StampedPps")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'StampedPps)))
  "Returns string type for a message object of type 'StampedPps"
  "multisense_ros/StampedPps")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<StampedPps>)))
  "Returns md5sum for a message object of type '<StampedPps>"
  "ee2f8d6ea6dc30440398fb554199fa0d")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'StampedPps)))
  "Returns md5sum for a message object of type 'StampedPps"
  "ee2f8d6ea6dc30440398fb554199fa0d")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<StampedPps>)))
  "Returns full string definition for message of type '<StampedPps>"
  (cl:format cl:nil "time     data~%time     host_time~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'StampedPps)))
  "Returns full string definition for message of type 'StampedPps"
  (cl:format cl:nil "time     data~%time     host_time~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <StampedPps>))
  (cl:+ 0
     8
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <StampedPps>))
  "Converts a ROS message object to a list"
  (cl:list 'StampedPps
    (cl:cons ':data (data msg))
    (cl:cons ':host_time (host_time msg))
))

#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ruckig::ruckig" for configuration "None"
set_property(TARGET ruckig::ruckig APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(ruckig::ruckig PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libruckig.so"
  IMPORTED_SONAME_NONE "libruckig.so"
  )

list(APPEND _cmake_import_check_targets ruckig::ruckig )
list(APPEND _cmake_import_check_files_for_ruckig::ruckig "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libruckig.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

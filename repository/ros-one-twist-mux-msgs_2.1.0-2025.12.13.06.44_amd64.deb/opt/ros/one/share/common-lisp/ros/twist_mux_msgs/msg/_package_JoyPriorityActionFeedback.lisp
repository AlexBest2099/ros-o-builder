(cl:in-package twist_mux_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          FEEDBACK-VAL
          FEEDBACK
))
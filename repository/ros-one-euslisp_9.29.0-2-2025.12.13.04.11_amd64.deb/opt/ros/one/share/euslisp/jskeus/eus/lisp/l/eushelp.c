/* ./eushelp.c :  entry=eushelp */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "eushelp.h"
#pragma init (register_eushelp)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___eushelp();
extern pointer build_quote_vector();
static int register_eushelp()
  { add_module_initializer("___eushelp", ___eushelp);}

static pointer eushelpF4383help();
static pointer eushelpF4384print_item();
static pointer eushelpF4385print_item2();
static pointer eushelpF4386print_class();
static pointer eushelpF4387help_method();
static pointer eushelpF4388help_usage();
static pointer eushelpF4389help_method_list();
static pointer eushelpF4390load_help();

/*:init*/
static pointer eushelpM4391help_item_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	if (n>=7) { local[0]=(argv[6]); goto eushelpENT4394;}
	local[0]= NIL;
eushelpENT4394:
eushelpENT4393:
	if (n>7) maerror();
	argv[0]->c.obj.iv[0] = argv[2];
	argv[0]->c.obj.iv[1] = argv[3];
	argv[0]->c.obj.iv[2] = argv[4];
	argv[0]->c.obj.iv[3] = argv[5];
	local[1]= argv[2];
	if (makeint((eusinteger_t)1L)!=local[1]) goto eushelpIF4395;
	argv[0]->c.obj.iv[4] = local[0];
	local[1]= argv[0]->c.obj.iv[4];
	goto eushelpIF4396;
eushelpIF4395:
	local[1]= NIL;
eushelpIF4396:
	local[1]= argv[2];
	if (makeint((eusinteger_t)0L)!=local[1]) goto eushelpIF4397;
	local[1]= fqv[0];
	local[2]= (pointer)get_sym_func(fqv[1]);
	local[3]= fqv[2];
	local[4]= makeflt(1.3999999999999994670929e+00);
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,4,local+1,&ftab[0],fqv[3]); /*make-hash-table*/
	argv[0]->c.obj.iv[5] = w;
	local[1]= argv[0]->c.obj.iv[5];
	w = loadglobal(fqv[4]);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	storeglobal(fqv[4],local[1]);
	goto eushelpIF4398;
eushelpIF4397:
	local[1]= NIL;
eushelpIF4398:
	w = local[1];
	local[0]= w;
eushelpBLK4392:
	ctx->vsp=local; return(local[0]);}

/*:read-help*/
static pointer eushelpM4399help_item_read_help(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[5];
	local[1]= loadglobal(fqv[6]);
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,1,local+1,&ftab[1],fqv[7]); /*pathname*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,1,local+1,&ftab[2],fqv[8]); /*pathname-directory*/
	local[1]= w;
	local[2]= fqv[9];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= fqv[10];
	local[5]= fqv[11];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,6,local+0,&ftab[3],fqv[12]); /*make-pathname*/
	local[0]= w;
	local[1]= fqv[13];
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,3,local+0,&ftab[4],fqv[15]); /*open*/
	local[0]= w;
	local[1]= fqv[16];
	local[2]= fqv[17];
	local[3]= fqv[18];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,eushelpFLET4401,env,argv,local);
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[2];
	w = local[4];
	ctx->vsp=local+7;
	w=eushelpFLET4401(ctx,2,local+5,w);
	local[1] = w;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto eushelpIF4402;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)-1L);
	w = local[4];
	ctx->vsp=local+7;
	w=eushelpFLET4401(ctx,2,local+5,w);
	local[2] = w;
	local[5]= local[2];
	goto eushelpIF4403;
eushelpIF4402:
	local[5]= NIL;
eushelpIF4403:
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto eushelpIF4404;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)-1L);
	w = local[4];
	ctx->vsp=local+7;
	w=eushelpFLET4401(ctx,2,local+5,w);
	local[3] = w;
	local[5]= local[3];
	goto eushelpIF4405;
eushelpIF4404:
	local[5]= NIL;
eushelpIF4405:
	w = local[5];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)CLOSE(ctx,1,local+4); /*close*/
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[0]= w;
eushelpBLK4400:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eushelpFLET4401(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)32L);
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[19]); /*read-tex*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[20]); /*string-trim*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*help*/
static pointer eushelpF4383help(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eushelpENT4410;}
	local[0]= NIL;
eushelpENT4410:
	if (n>=2) { local[1]=(argv[1]); goto eushelpENT4409;}
	local[1]= NIL;
eushelpENT4409:
	if (n>=3) { local[2]=(argv[2]); goto eushelpENT4408;}
	local[2]= T;
eushelpENT4408:
eushelpENT4407:
	if (n>3) maerror();
	if (loadglobal(fqv[21])!=NIL) goto eushelpIF4411;
	local[3]= fqv[0];
	local[4]= (pointer)get_sym_func(fqv[1]);
	local[5]= fqv[22];
	local[6]= makeint((eusinteger_t)1000L);
	local[7]= fqv[2];
	local[8]= makeflt(1.5999999999999996447286e+00);
	ctx->vsp=local+9;
	w=(*ftab[0])(ctx,6,local+3,&ftab[0],fqv[3]); /*make-hash-table*/
	local[3]= w;
	storeglobal(fqv[21],w);
	local[3]= NIL;
	local[4]= fqv[23];
	local[5]= loadglobal(fqv[6]);
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)eushelpF4390load_help(ctx,1,local+3); /*load-help*/
	local[3]= w;
	goto eushelpIF4412;
eushelpIF4411:
	local[3]= NIL;
eushelpIF4412:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= fqv[24];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[0] = w;
	local[6]= local[0];
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,2,local+6,&ftab[7],fqv[1]); /*string-equal*/
	if (w!=NIL) goto eushelpOR4415;
	local[6]= local[0];
	local[7]= fqv[26];
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,2,local+6,&ftab[7],fqv[1]); /*string-equal*/
	if (w!=NIL) goto eushelpOR4415;
	goto eushelpIF4413;
eushelpOR4415:
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)eushelpF4388help_usage(ctx,1,local+6); /*help-usage*/
	local[6]= w;
	goto eushelpIF4414;
eushelpIF4413:
	local[6]= local[1];
	if (NIL!=local[6]) goto eushelpIF4416;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	if (makeint((eusinteger_t)58L)!=local[6]) goto eushelpIF4418;
	local[6]= local[0];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)eushelpF4389help_method_list(ctx,2,local+6); /*help-method-list*/
	local[6]= w;
	goto eushelpIF4419;
eushelpIF4418:
	local[6]= local[0];
	local[7]= loadglobal(fqv[21]);
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,2,local+6,&ftab[8],fqv[27]); /*gethash*/
	local[4] = w;
	local[6]= local[4];
	if (NIL!=local[6]) goto eushelpIF4420;
	local[6]= local[2];
	local[7]= fqv[28];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,1,local+6,&ftab[9],fqv[29]); /*apropos-list*/
	local[6]= w;
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,2,local+6,&ftab[10],fqv[30]); /*pprint*/
	local[6]= w;
	goto eushelpIF4421;
eushelpIF4420:
	local[6]= local[2];
	local[7]= fqv[31];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= local[4];
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[3] = w;
	local[6]= local[4]->c.obj.iv[0];
	local[7]= local[6];
	if (fqv[33]!=local[7]) goto eushelpIF4422;
	local[7]= local[2];
	local[8]= fqv[34];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= local[4];
	local[8]= local[3];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)eushelpF4386print_class(ctx,3,local+7); /*print-class*/
	local[7]= w;
	goto eushelpIF4423;
eushelpIF4422:
	local[7]= local[6];
	if (fqv[35]!=local[7]) goto eushelpIF4424;
	local[7]= local[2];
	local[8]= fqv[36];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= local[0];
	local[8]= local[4];
	local[9]= local[3];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)eushelpF4384print_item(ctx,4,local+7); /*print-item*/
	local[7]= w;
	goto eushelpIF4425;
eushelpIF4424:
	local[7]= local[6];
	if (fqv[37]!=local[7]) goto eushelpIF4426;
	local[7]= local[2];
	local[8]= fqv[38];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= local[0];
	local[8]= local[4];
	local[9]= local[3];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)eushelpF4384print_item(ctx,4,local+7); /*print-item*/
	local[7]= w;
	goto eushelpIF4427;
eushelpIF4426:
	local[7]= local[6];
	if (fqv[39]!=local[7]) goto eushelpIF4428;
	local[7]= local[2];
	local[8]= fqv[40];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= local[0];
	local[8]= local[4];
	local[9]= local[3];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)eushelpF4385print_item2(ctx,4,local+7); /*print-item2*/
	local[7]= w;
	goto eushelpIF4429;
eushelpIF4428:
	local[7]= local[6];
	if (fqv[41]!=local[7]) goto eushelpIF4430;
	local[7]= local[2];
	local[8]= fqv[42];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= local[0];
	local[8]= local[4];
	local[9]= local[3];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)eushelpF4385print_item2(ctx,4,local+7); /*print-item2*/
	local[7]= w;
	goto eushelpIF4431;
eushelpIF4430:
	local[7]= local[6];
	if (fqv[43]!=local[7]) goto eushelpIF4432;
	local[7]= local[2];
	local[8]= fqv[44];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= local[0];
	local[8]= local[4];
	local[9]= local[3];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)eushelpF4384print_item(ctx,4,local+7); /*print-item*/
	local[7]= w;
	goto eushelpIF4433;
eushelpIF4432:
	local[7]= NIL;
eushelpIF4433:
eushelpIF4431:
eushelpIF4429:
eushelpIF4427:
eushelpIF4425:
eushelpIF4423:
	w = local[7];
	local[6]= w;
eushelpIF4421:
eushelpIF4419:
	goto eushelpIF4417;
eushelpIF4416:
	local[6]= NIL;
	local[7]= fqv[45];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= loadglobal(fqv[21]);
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,2,local+6,&ftab[8],fqv[27]); /*gethash*/
	local[5] = w;
	local[6]= local[5];
	if (NIL!=local[6]) goto eushelpIF4434;
	local[6]= local[2];
	local[7]= fqv[46];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	goto eushelpIF4435;
eushelpIF4434:
	local[6]= local[0];
	local[7]= local[5]->c.obj.iv[5];
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,2,local+6,&ftab[8],fqv[27]); /*gethash*/
	local[4] = w;
	local[6]= local[4];
	if (NIL!=local[6]) goto eushelpIF4436;
	local[6]= local[2];
	local[7]= fqv[47];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	goto eushelpIF4437;
eushelpIF4436:
	local[6]= local[2];
	local[7]= fqv[48];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= local[2];
	local[7]= fqv[49];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= local[4];
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[3] = w;
	local[6]= local[0];
	local[7]= local[4];
	local[8]= local[3];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)eushelpF4384print_item(ctx,4,local+6); /*print-item*/
	local[6]= w;
eushelpIF4437:
eushelpIF4435:
eushelpIF4417:
eushelpIF4414:
	w = local[6];
	local[0]= w;
eushelpBLK4406:
	ctx->vsp=local; return(local[0]);}

/*print-item*/
static pointer eushelpF4384print_item(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	local[1]= fqv[50];
	local[2]= argv[0];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[3];
	local[1]= fqv[51];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
eushelpBLK4438:
	ctx->vsp=local; return(local[0]);}

/*print-item2*/
static pointer eushelpF4385print_item2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	local[1]= fqv[52];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
eushelpBLK4439:
	ctx->vsp=local; return(local[0]);}

/*print-class*/
static pointer eushelpF4386print_class(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[53];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[2];
	local[1]= fqv[54];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[2];
	local[1]= fqv[55];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
eushelpBLK4440:
	ctx->vsp=local; return(local[0]);}

/*help-method*/
static pointer eushelpF4387help_method(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= fqv[56];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= loadglobal(fqv[21]);
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,2,local+6,&ftab[8],fqv[27]); /*gethash*/
	local[1] = w;
	local[6]= local[1];
	if (NIL!=local[6]) goto eushelpIF4442;
	local[6]= argv[1];
	local[7]= fqv[57];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	goto eushelpIF4443;
eushelpIF4442:
	local[6]= local[1]->c.obj.iv[0];
	if (makeint((eusinteger_t)0L)!=local[6]) goto eushelpIF4444;
	local[6]= argv[1];
	local[7]= fqv[58];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[2] = local[1]->c.obj.iv[5]->c.obj.iv[0];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
eushelpWHL4446:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto eushelpWHX4447;
	local[8]= local[2];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[3] = w;
	w = local[3];
	if (!isstring(w)) goto eushelpIF4449;
	local[8]= T;
	local[9]= fqv[59];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	goto eushelpIF4450;
eushelpIF4449:
	local[8]= NIL;
eushelpIF4450:
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto eushelpWHL4446;
eushelpWHX4447:
	local[8]= NIL;
eushelpBLK4448:
	w = NIL;
	local[6]= w;
	goto eushelpIF4445;
eushelpIF4444:
	local[6]= argv[1];
	local[7]= fqv[60];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
eushelpIF4445:
eushelpIF4443:
	w = local[6];
	local[0]= w;
eushelpBLK4441:
	ctx->vsp=local; return(local[0]);}

/*help-usage*/
static pointer eushelpF4388help_usage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[61];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
eushelpBLK4451:
	ctx->vsp=local; return(local[0]);}

/*help-method-list*/
static pointer eushelpF4389help_method_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[1];
	local[2]= fqv[63];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= makeint((eusinteger_t)0L);
	local[2]= loadglobal(fqv[4]);
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
eushelpWHL4453:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto eushelpWHX4454;
	local[3]= argv[0];
	local[4]= local[1];
	local[5]= loadglobal(fqv[4]);
	ctx->vsp=local+6;
	w=(pointer)NTH(ctx,2,local+4); /*nth*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,2,local+3,&ftab[8],fqv[27]); /*gethash*/
	local[0] = w;
	local[3]= local[0];
	if (NIL==local[3]) goto eushelpIF4456;
	local[3]= argv[1];
	local[4]= fqv[64];
	local[5]= local[0]->c.obj.iv[4];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= w;
	goto eushelpIF4457;
eushelpIF4456:
	local[3]= NIL;
eushelpIF4457:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto eushelpWHL4453;
eushelpWHX4454:
	local[3]= NIL;
eushelpBLK4455:
	w = NIL;
	local[0]= w;
eushelpBLK4452:
	ctx->vsp=local; return(local[0]);}

/*load-help*/
static pointer eushelpF4390load_help(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	if (loadglobal(fqv[21])!=NIL) goto eushelpIF4459;
	local[7]= fqv[0];
	local[8]= (pointer)get_sym_func(fqv[1]);
	local[9]= fqv[22];
	local[10]= makeint((eusinteger_t)1000L);
	local[11]= fqv[2];
	local[12]= makeflt(1.5999999999999996447286e+00);
	ctx->vsp=local+13;
	w=(*ftab[0])(ctx,6,local+7,&ftab[0],fqv[3]); /*make-hash-table*/
	local[7]= w;
	storeglobal(fqv[21],w);
	goto eushelpIF4460;
eushelpIF4459:
	local[7]= NIL;
eushelpIF4460:
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,1,local+7,&ftab[4],fqv[15]); /*open*/
	local[0] = w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)READ(ctx,1,local+7); /*read*/
eushelpTAG4462:
	local[7]= local[0];
	local[8]= NIL;
	ctx->vsp=local+9;
	w=(pointer)READ(ctx,2,local+7); /*read*/
	local[1] = w;
	local[7]= local[1];
	if (NIL!=local[7]) goto eushelpIF4463;
	w = NIL;
	ctx->vsp=local+7;
	local[7]=w;
	goto eushelpBLK4461;
	goto eushelpIF4464;
eushelpIF4463:
	local[7]= NIL;
eushelpIF4464:
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)READ(ctx,1,local+7); /*read*/
	local[2] = w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)READ(ctx,1,local+7); /*read*/
	local[3] = w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)READ(ctx,1,local+7); /*read*/
	local[4] = w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)READ(ctx,1,local+7); /*read*/
	local[5] = w;
	local[7]= local[2];
	if (makeint((eusinteger_t)0L)!=local[7]) goto eushelpIF4465;
	local[6] = local[1];
	local[7]= local[6];
	goto eushelpIF4466;
eushelpIF4465:
	local[7]= NIL;
eushelpIF4466:
	local[7]= local[2];
	if (makeint((eusinteger_t)1L)!=local[7]) goto eushelpIF4467;
	local[7]= local[1];
	local[8]= local[6];
	local[9]= loadglobal(fqv[21]);
	ctx->vsp=local+10;
	w=(*ftab[8])(ctx,2,local+8,&ftab[8],fqv[27]); /*gethash*/
	local[8]= w->c.obj.iv[5];
	local[9]= loadglobal(fqv[65]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[66];
	local[12]= local[2];
	local[13]= local[3];
	local[14]= local[4];
	local[15]= local[5];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,7,local+10); /*send*/
	w = local[9];
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,3,local+7,&ftab[11],fqv[67]); /*sethash*/
	local[7]= w;
	goto eushelpIF4468;
eushelpIF4467:
	local[7]= local[1];
	local[8]= loadglobal(fqv[21]);
	local[9]= loadglobal(fqv[65]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[66];
	local[12]= local[2];
	local[13]= local[3];
	local[14]= local[4];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,6,local+10); /*send*/
	w = local[9];
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,3,local+7,&ftab[11],fqv[67]); /*sethash*/
	local[7]= w;
eushelpIF4468:
	ctx->vsp=local+7;
	goto eushelpTAG4462;
	local[7]= NIL;
eushelpBLK4461:
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)CLOSE(ctx,1,local+7); /*close*/
	local[0]= w;
eushelpBLK4458:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___eushelp(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[68];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto eushelpIF4469;
	local[0]= fqv[69];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[70],w);
	goto eushelpIF4470;
eushelpIF4469:
	local[0]= fqv[71];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
eushelpIF4470:
	local[0]= fqv[72];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[73];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[75];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[76];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[77];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)3L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[78];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)4L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[79];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)5L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[80];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)6L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[21];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eushelpIF4471;
	local[0]= fqv[21];
	local[1]= fqv[81];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[21];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eushelpIF4473;
	local[0]= fqv[21];
	local[1]= fqv[82];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eushelpIF4474;
eushelpIF4473:
	local[0]= NIL;
eushelpIF4474:
	local[0]= fqv[21];
	goto eushelpIF4472;
eushelpIF4471:
	local[0]= NIL;
eushelpIF4472:
	local[0]= fqv[83];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eushelpIF4475;
	local[0]= fqv[83];
	local[1]= fqv[81];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[83];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eushelpIF4477;
	local[0]= fqv[83];
	local[1]= fqv[82];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eushelpIF4478;
eushelpIF4477:
	local[0]= NIL;
eushelpIF4478:
	local[0]= fqv[83];
	goto eushelpIF4476;
eushelpIF4475:
	local[0]= NIL;
eushelpIF4476:
	local[0]= fqv[6];
	local[1]= fqv[82];
	local[2]= NIL;
	local[3]= fqv[84];
	local[4]= loadglobal(fqv[85]);
	local[5]= fqv[86];
	local[6]= fqv[87];
	ctx->vsp=local+7;
	w=(pointer)GETENV(ctx,1,local+6); /*unix:getenv*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[12])(ctx,2,local+5,&ftab[12],fqv[88]); /*substringp*/
	if (w!=NIL) goto eushelpOR4481;
	local[5]= fqv[89];
	local[6]= fqv[90];
	ctx->vsp=local+7;
	w=(pointer)GETENV(ctx,1,local+6); /*unix:getenv*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[12])(ctx,2,local+5,&ftab[12],fqv[88]); /*substringp*/
	if (w!=NIL) goto eushelpOR4481;
	goto eushelpIF4479;
eushelpOR4481:
	local[5]= fqv[91];
	goto eushelpIF4480;
eushelpIF4479:
	local[5]= fqv[92];
eushelpIF4480:
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[4];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eushelpIF4482;
	local[0]= fqv[4];
	local[1]= fqv[81];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[4];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eushelpIF4484;
	local[0]= fqv[4];
	local[1]= fqv[82];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eushelpIF4485;
eushelpIF4484:
	local[0]= NIL;
eushelpIF4485:
	local[0]= fqv[4];
	goto eushelpIF4483;
eushelpIF4482:
	local[0]= NIL;
eushelpIF4483:
	local[0]= fqv[65];
	local[1]= fqv[82];
	local[2]= fqv[65];
	local[3]= fqv[93];
	local[4]= loadglobal(fqv[94]);
	local[5]= fqv[95];
	local[6]= fqv[96];
	local[7]= fqv[97];
	local[8]= NIL;
	local[9]= fqv[98];
	local[10]= NIL;
	local[11]= fqv[22];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[99];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[13])(ctx,13,local+2,&ftab[13],fqv[100]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,eushelpM4391help_item_init,fqv[66],fqv[65],fqv[101]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,eushelpM4399help_item_read_help,fqv[32],fqv[65],fqv[102]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[103],module,eushelpF4383help,fqv[104]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[105],module,eushelpF4384print_item,fqv[106]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[107],module,eushelpF4385print_item2,fqv[108]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[109],module,eushelpF4386print_class,fqv[110]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[111],module,eushelpF4387help_method,fqv[112]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[113],module,eushelpF4388help_usage,fqv[114]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[115],module,eushelpF4389help_method_list,fqv[116]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[117],module,eushelpF4390load_help,fqv[118]);
	local[0]= fqv[119];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto eushelpIF4486;
	local[0]= fqv[120];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[70],w);
	goto eushelpIF4487;
eushelpIF4486:
	local[0]= fqv[121];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
eushelpIF4487:
	local[0]= fqv[122];
	ctx->vsp=local+1;
	w=(*ftab[14])(ctx,1,local+0,&ftab[14],fqv[123]); /*use-package*/
	local[0]= fqv[124];
	local[1]= fqv[125];
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,2,local+0,&ftab[15],fqv[126]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<16; i++) ftab[i]=fcallx;
}

/* ./loader.c :  entry=loader */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "loader.h"
#pragma init (register_loader)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___loader();
extern pointer build_quote_vector();
static int register_loader()
  { add_module_initializer("___loader", ___loader);}

static pointer loaderF1519file_write_date();
static pointer loaderF1520file_newer();
static pointer loaderF1521open();
static pointer loaderF1522probe_file();
static pointer loaderF1523object_file_p();
static pointer loaderF1524path_list();
static pointer loaderF1525find_executable();
static pointer loaderF1526system__txtload();
static pointer loaderF1527load_module_file_name();
static pointer loaderF1528gencname_tail();
static pointer loaderF1529load();
static pointer loaderF1530load_files();
static pointer loaderF1531read_file();
static pointer loaderF1532read_strings();
static pointer loaderF1533read_lines();
static pointer loaderF1534read_lists();
static pointer loaderF1535read_binary_file();
static pointer loaderF1536read_lines_till_eof();
static pointer loaderF1537load_library();
static pointer loaderF1538dump_object();
static pointer loaderF1539dump_structure();
static pointer loaderF1540file_size();
static pointer loaderF1541directory_p();
static pointer loaderF1542map_file();
static pointer loaderF1543provide();
static pointer loaderF1544require();

/*file-write-date*/
static pointer loaderF1519file_write_date(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)9L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[0]); /*namestring*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)STAT(ctx,1,local+1); /*unix:stat*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
loaderBLK1545:
	ctx->vsp=local; return(local[0]);}

/*file-newer*/
static pointer loaderF1520file_newer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)loaderF1522probe_file(ctx,1,local+0); /*probe-file*/
	local[0]= ((w)==NIL?T:NIL);
	if (local[0]!=NIL) goto loaderOR1547;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)loaderF1522probe_file(ctx,1,local+0); /*probe-file*/
	local[0]= ((w)==NIL?T:NIL);
	if (local[0]!=NIL) goto loaderOR1547;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)loaderF1519file_write_date(ctx,1,local+0); /*file-write-date*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)loaderF1519file_write_date(ctx,1,local+1); /*file-write-date*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	local[0]= w;
loaderOR1547:
	w = local[0];
	local[0]= w;
loaderBLK1546:
	ctx->vsp=local; return(local[0]);}

/*open*/
static pointer loaderF1521open(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[1], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto loaderKEY1549;
	local[0] = fqv[2];
loaderKEY1549:
	if (n & (1<<1)) goto loaderKEY1550;
	local[1] = fqv[3];
loaderKEY1550:
	if (n & (1<<2)) goto loaderKEY1551;
	local[2] = fqv[4];
loaderKEY1551:
	if (n & (1<<3)) goto loaderKEY1552;
	local[3] = makeint((eusinteger_t)420L);
loaderKEY1552:
	if (n & (1<<4)) goto loaderKEY1553;
	local[4] = makeint((eusinteger_t)512L);
loaderKEY1553:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= NIL;
	local[7]= NIL;
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)STREAMP(ctx,1,local+8); /*streamp*/
	if (w==NIL) goto loaderIF1554;
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[1])(ctx,1,local+8,&ftab[1],fqv[5]); /*io-stream-p*/
	if (w==NIL) goto loaderIF1556;
	local[7] = *(ovafptr(*(ovafptr(argv[0],fqv[6])),fqv[7]));
	local[8]= local[7];
	goto loaderIF1557;
loaderIF1556:
	local[7] = *(ovafptr(argv[0],fqv[7]));
	local[8]= local[7];
loaderIF1557:
	goto loaderIF1555;
loaderIF1554:
	local[7] = argv[0];
	local[8]= local[7];
loaderIF1555:
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(*ftab[0])(ctx,1,local+8,&ftab[0],fqv[0]); /*namestring*/
	local[7] = w;
	local[8]= local[0];
	local[9]= local[8];
	if (fqv[2]!=local[9]) goto loaderIF1558;
	local[5] = makeint((eusinteger_t)0L);
	local[9]= local[2];
	if (fqv[4]!=local[9]) goto loaderIF1560;
	local[2] = fqv[8];
	local[9]= local[2];
	goto loaderIF1561;
loaderIF1560:
	local[9]= NIL;
loaderIF1561:
	local[9]= local[2];
	if (fqv[9]!=local[9]) goto loaderIF1562;
	local[9]= local[5];
	local[10]= makeint((eusinteger_t)64L);
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[5] = w;
	local[9]= local[5];
	goto loaderIF1563;
loaderIF1562:
	local[9]= NIL;
loaderIF1563:
	local[9]= local[7];
	local[10]= local[5];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[2])(ctx,4,local+9,&ftab[2],fqv[10]); /*system:openfile*/
	local[6] = w;
	local[9]= local[6];
	goto loaderIF1559;
loaderIF1558:
	local[9]= local[8];
	w = fqv[11];
	if (memq(local[9],w)==NIL) goto loaderIF1564;
	local[9]= local[0];
	if (fqv[12]!=local[9]) goto loaderIF1566;
	local[5] = makeint((eusinteger_t)2L);
	local[9]= local[5];
	goto loaderIF1567;
loaderIF1566:
	local[5] = makeint((eusinteger_t)1L);
	local[9]= local[5];
loaderIF1567:
	local[9]= local[1];
	local[10]= local[9];
	if (fqv[13]!=local[10]) goto loaderIF1568;
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)1024L);
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[5] = w;
	local[10]= local[5];
	goto loaderIF1569;
loaderIF1568:
	local[10]= local[9];
	w = fqv[14];
	if (memq(local[10],w)==NIL) goto loaderIF1570;
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)64L);
	local[12]= makeint((eusinteger_t)512L);
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,3,local+10); /*+*/
	local[5] = w;
	local[10]= local[5];
	goto loaderIF1571;
loaderIF1570:
	local[10]= local[9];
	if (fqv[15]!=local[10]) goto loaderIF1572;
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)64L);
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[5] = w;
	local[10]= local[5];
	goto loaderIF1573;
loaderIF1572:
	local[10]= local[9];
	w = fqv[16];
	if (memq(local[10],w)==NIL) goto loaderIF1574;
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)64L);
	local[12]= makeint((eusinteger_t)128L);
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,3,local+10); /*+*/
	local[5] = w;
	local[10]= local[5];
	goto loaderIF1575;
loaderIF1574:
	if (T==NIL) goto loaderIF1576;
	local[10]= fqv[17];
	ctx->vsp=local+11;
	w=(pointer)SIGERROR(ctx,1,local+10); /*error*/
	local[10]= w;
	goto loaderIF1577;
loaderIF1576:
	local[10]= NIL;
loaderIF1577:
loaderIF1575:
loaderIF1573:
loaderIF1571:
loaderIF1569:
	w = local[10];
	local[9]= local[2];
	local[10]= local[9];
	if (fqv[8]!=local[10]) goto loaderIF1578;
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)64L);
	ctx->vsp=local+12;
	w=(pointer)LOGNOT(ctx,1,local+11); /*lognot*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LOGAND(ctx,2,local+10); /*logand*/
	local[5] = w;
	local[10]= local[5];
	goto loaderIF1579;
loaderIF1578:
	local[10]= local[9];
	if (fqv[9]!=local[10]) goto loaderIF1580;
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)64L);
	ctx->vsp=local+12;
	w=(pointer)LOGIOR(ctx,2,local+10); /*logior*/
	local[5] = w;
	local[10]= local[5];
	goto loaderIF1581;
loaderIF1580:
	local[10]= local[9];
	if (fqv[4]!=local[10]) goto loaderIF1582;
	local[10]= local[1];
	w = fqv[18];
	if (memq(local[10],w)!=NIL) goto loaderIF1584;
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)64L);
	ctx->vsp=local+12;
	w=(pointer)LOGIOR(ctx,2,local+10); /*logior*/
	local[5] = w;
	local[10]= local[5];
	goto loaderIF1585;
loaderIF1584:
	local[10]= NIL;
loaderIF1585:
	goto loaderIF1583;
loaderIF1582:
	local[10]= local[9];
	if (fqv[19]!=local[10]) goto loaderIF1586;
	local[10]= NIL;
	goto loaderIF1587;
loaderIF1586:
	if (T==NIL) goto loaderIF1588;
	local[10]= fqv[20];
	ctx->vsp=local+11;
	w=(pointer)SIGERROR(ctx,1,local+10); /*error*/
	local[10]= w;
	goto loaderIF1589;
loaderIF1588:
	local[10]= NIL;
loaderIF1589:
loaderIF1587:
loaderIF1583:
loaderIF1581:
loaderIF1579:
	w = local[10];
	local[9]= local[7];
	local[10]= local[5];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[2])(ctx,4,local+9,&ftab[2],fqv[10]); /*system:openfile*/
	local[6] = w;
	local[9]= local[6];
	goto loaderIF1565;
loaderIF1564:
	if (T==NIL) goto loaderIF1590;
	local[9]= fqv[21];
	ctx->vsp=local+10;
	w=(pointer)SIGERROR(ctx,1,local+9); /*error*/
	local[9]= w;
	goto loaderIF1591;
loaderIF1590:
	local[9]= NIL;
loaderIF1591:
loaderIF1565:
loaderIF1559:
	w = local[9];
	w = local[6];
	if (!numberp(w)) goto loaderIF1592;
	if (local[2]!=NIL) goto loaderIF1594;
	w = NIL;
	ctx->vsp=local+8;
	local[0]=w;
	goto loaderBLK1548;
	goto loaderIF1595;
loaderIF1594:
	local[8]= loadglobal(fqv[22]);
	local[9]= fqv[23];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)CONCATENATE(ctx,3,local+8); /*concatenate*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SIGERROR(ctx,1,local+8); /*error*/
	local[8]= w;
loaderIF1595:
	goto loaderIF1593;
loaderIF1592:
	local[8]= NIL;
loaderIF1593:
	w = local[6];
	local[0]= w;
loaderBLK1548:
	ctx->vsp=local; return(local[0]);}

/*with-open-file*/
static pointer loaderF1596(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
loaderRST1598:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[24];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[25];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	local[3]= fqv[26];
	local[4]= fqv[27];
	local[5]= local[0];
	local[6]= NIL;
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[28];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
loaderBLK1597:
	ctx->vsp=local; return(local[0]);}

/*probe-file*/
static pointer loaderF1522probe_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*namestring*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)STAT(ctx,1,local+1); /*unix:stat*/
	local[1]= w;
	w = local[1];
	if (!iscons(w)) goto loaderIF1600;
	local[2]= makeint((eusinteger_t)61440L);
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)LOGAND(ctx,2,local+2); /*logand*/
	local[2]= w;
	local[3]= local[2];
	if (fqv[29]!=local[3]) goto loaderIF1602;
	local[3]= fqv[30];
	goto loaderIF1603;
loaderIF1602:
	local[3]= local[2];
	if (fqv[31]!=local[3]) goto loaderIF1604;
	local[3]= fqv[32];
	goto loaderIF1605;
loaderIF1604:
	local[3]= local[2];
	if (fqv[33]!=local[3]) goto loaderIF1606;
	local[3]= fqv[34];
	goto loaderIF1607;
loaderIF1606:
	local[3]= local[2];
	if (fqv[35]!=local[3]) goto loaderIF1608;
	local[3]= fqv[36];
	goto loaderIF1609;
loaderIF1608:
	local[3]= local[2];
	if (fqv[37]!=local[3]) goto loaderIF1610;
	local[3]= fqv[38];
	goto loaderIF1611;
loaderIF1610:
	local[3]= local[2];
	if (fqv[39]!=local[3]) goto loaderIF1612;
	local[3]= fqv[40];
	goto loaderIF1613;
loaderIF1612:
	local[3]= local[2];
	if (fqv[41]!=local[3]) goto loaderIF1614;
	local[3]= fqv[42];
	goto loaderIF1615;
loaderIF1614:
	local[3]= NIL;
loaderIF1615:
loaderIF1613:
loaderIF1611:
loaderIF1609:
loaderIF1607:
loaderIF1605:
loaderIF1603:
	w = local[3];
	local[2]= w;
	goto loaderIF1601;
loaderIF1600:
	local[2]= NIL;
loaderIF1601:
	w = local[2];
	local[0]= w;
loaderBLK1599:
	ctx->vsp=local; return(local[0]);}

/*object-file-p*/
static pointer loaderF1523object_file_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,loaderFLET1617,env,argv,local);
	local[1]= argv[0];
	w = local[0];
	ctx->vsp=local+2;
	w=loaderFLET1617(ctx,1,local+1,w);
	local[1]= w;
	local[2]= loadglobal(fqv[43]);
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[6];
	local[6]= w;
	local[7]= T;
	local[8]= NIL;
loaderTAG1619:
	if (local[2]==NIL) goto loaderOR1622;
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)GREQP(ctx,2,local+9); /*>=*/
	if (w!=NIL) goto loaderOR1622;
	if (local[8]!=NIL) goto loaderOR1622;
	goto loaderIF1620;
loaderOR1622:
	w = local[7];
	ctx->vsp=local+9;
	local[3]=w;
	goto loaderBLK1618;
	goto loaderIF1621;
loaderIF1620:
	local[9]= NIL;
loaderIF1621:
	if (local[6]==NIL) goto loaderIF1623;
	local[9]= local[3];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)EQ(ctx,2,local+9); /*eql*/
	if (w!=NIL) goto loaderIF1623;
	local[9]= local[3];
	w = local[6];
	if (memq(local[9],w)!=NIL) goto loaderIF1623;
	local[7] = NIL;
	local[8] = T;
	local[9]= local[8];
	goto loaderIF1624;
loaderIF1623:
	local[9]= NIL;
loaderIF1624:
	local[9]= local[1];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[10]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[11];
	local[11]= w;
	local[3] = local[9];
	local[4] = local[10];
	local[6] = local[11];
	w = NIL;
	ctx->vsp=local+9;
	goto loaderTAG1619;
	w = NIL;
	local[3]= w;
loaderBLK1618:
	w = local[3];
	local[0]= w;
loaderBLK1616:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderFLET1617(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)4L);
	ctx->vsp=local+1;
	w=(*ftab[3])(ctx,1,local+0,&ftab[3],fqv[44]); /*make-string*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)loaderF1521open(ctx,1,local+1); /*open*/
	local[1]= w;
	ctx->vsp=local+2;
	w = makeclosure(codevec,quotevec,loaderUWP1625,env,argv,local);
	local[2]=(pointer)(ctx->protfp); local[3]=w;
	ctx->protfp=(struct protectframe *)(local+2);
	local[4]= local[1]->c.obj.iv[5];
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)UNIXREAD(ctx,3,local+4); /*unix:uread*/
	ctx->vsp=local+4;
	loaderUWP1625(ctx,0,local+4,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1625(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*path-list*/
static pointer loaderF1524path_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto loaderENT1628;}
	local[0]= fqv[45];
	ctx->vsp=local+1;
	w=(pointer)GETENV(ctx,1,local+0); /*unix:getenv*/
	local[0]= w;
loaderENT1628:
loaderENT1627:
	if (n>1) maerror();
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= NIL;
loaderWHL1629:
	local[5]= makeint((eusinteger_t)58L);
	local[6]= local[0];
	local[7]= fqv[46];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,4,local+5,&ftab[4],fqv[47]); /*position*/
	local[3] = w;
	if (local[3]==NIL) goto loaderWHX1630;
	local[5]= local[0];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[4] = w;
	local[5]= loadglobal(fqv[22]);
	local[6]= local[4];
	local[7]= fqv[48];
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,3,local+5); /*concatenate*/
	local[5]= w;
	w = local[1];
	ctx->vsp=local+6;
	local[1] = cons(ctx,local[5],w);
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[2] = w;
	goto loaderWHL1629;
loaderWHX1630:
	local[5]= NIL;
loaderBLK1631:
	local[5]= loadglobal(fqv[22]);
	local[6]= local[0];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,2,local+6); /*subseq*/
	local[6]= w;
	local[7]= fqv[49];
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,3,local+5); /*concatenate*/
	local[5]= w;
	w = local[1];
	ctx->vsp=local+6;
	local[1] = cons(ctx,local[5],w);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)NREVERSE(ctx,1,local+5); /*nreverse*/
	local[0]= w;
loaderBLK1626:
	ctx->vsp=local; return(local[0]);}

/*find-executable*/
static pointer loaderF1525find_executable(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)loaderF1522probe_file(ctx,1,local+0); /*probe-file*/
	if (w==NIL) goto loaderIF1633;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[5])(ctx,1,local+0,&ftab[5],fqv[50]); /*truename*/
	local[0]= w;
	goto loaderIF1634;
loaderIF1633:
	ctx->vsp=local+0;
	w=(pointer)loaderF1524path_list(ctx,0,local+0); /*path-list*/
	local[0]= w;
	local[1]= NIL;
loaderWHL1635:
	if (local[0]==NIL) goto loaderWHX1636;
	local[2]= argv[0];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,2,local+2,&ftab[6],fqv[51]); /*merge-pathnames*/
	local[1] = w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,1,local+2,&ftab[0],fqv[0]); /*namestring*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)loaderF1522probe_file(ctx,1,local+2); /*probe-file*/
	if (w==NIL) goto loaderIF1638;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,1,local+2,&ftab[5],fqv[50]); /*truename*/
	ctx->vsp=local+2;
	local[0]=w;
	goto loaderBLK1632;
	goto loaderIF1639;
loaderIF1638:
	local[2]= NIL;
loaderIF1639:
	goto loaderWHL1635;
loaderWHX1636:
	local[2]= NIL;
loaderBLK1637:
	w = NIL;
	local[0]= w;
loaderIF1634:
	w = local[0];
	local[0]= w;
loaderBLK1632:
	ctx->vsp=local; return(local[0]);}

/*system::txtload*/
static pointer loaderF1526system__txtload(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto loaderENT1642;}
	local[0]= NIL;
loaderENT1642:
loaderENT1641:
	if (n>2) maerror();
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)loaderF1521open(ctx,1,local+4); /*open*/
	local[4]= w;
	ctx->vsp=local+5;
	w = makeclosure(codevec,quotevec,loaderUWP1643,env,argv,local);
	local[5]=(pointer)(ctx->protfp); local[6]=w;
	ctx->protfp=(struct protectframe *)(local+5);
loaderWHL1644:
	local[7]= local[4];
	local[8]= NIL;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)READ(ctx,3,local+7); /*read*/
	local[2] = w;
	local[7]= local[2];
	if (local[1]==local[7]) goto loaderWHX1645;
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)EVAL(ctx,1,local+7); /*eval*/
	local[3] = w;
	if (local[0]==NIL) goto loaderIF1647;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)PRINT(ctx,1,local+7); /*print*/
	local[7]= w;
	goto loaderIF1648;
loaderIF1647:
	local[7]= NIL;
loaderIF1648:
	goto loaderWHL1644;
loaderWHX1645:
	local[7]= NIL;
loaderBLK1646:
	w = local[7];
	ctx->vsp=local+7;
	loaderUWP1643(ctx,0,local+7,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
loaderBLK1640:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1643(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[4];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*load-module-file-name*/
static pointer loaderF1527load_module_file_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(*ftab[7])(ctx,1,local+0,&ftab[7],fqv[52]); /*pathname-name*/
	local[0]= w;
loaderBLK1649:
	ctx->vsp=local; return(local[0]);}

/*gencname-tail*/
static pointer loaderF1528gencname_tail(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
loaderRST1651:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,loaderFLET1652,env,argv,local);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,loaderFLET1653,env,argv,local);
	local[3]= local[0];
	w = local[2];
	ctx->vsp=local+4;
	w=loaderFLET1653(ctx,1,local+3,w);
	local[0]= w;
loaderBLK1650:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderFLET1652(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)97L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LSEQP(ctx,2,local+0); /*<=*/
	local[0]= w;
	if (w==NIL) goto loaderAND1655;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)122L);
	ctx->vsp=local+2;
	w=(pointer)LSEQP(ctx,2,local+0); /*<=*/
	local[0]= w;
loaderAND1655:
	if (local[0]!=NIL) goto loaderOR1654;
	local[0]= makeint((eusinteger_t)65L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LSEQP(ctx,2,local+0); /*<=*/
	local[0]= w;
	if (w==NIL) goto loaderAND1656;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)90L);
	ctx->vsp=local+2;
	w=(pointer)LSEQP(ctx,2,local+0); /*<=*/
	local[0]= w;
loaderAND1656:
	if (local[0]!=NIL) goto loaderOR1654;
	local[0]= makeint((eusinteger_t)48L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LSEQP(ctx,2,local+0); /*<=*/
	local[0]= w;
	if (w==NIL) goto loaderAND1657;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)57L);
	ctx->vsp=local+2;
	w=(pointer)LSEQP(ctx,2,local+0); /*<=*/
	local[0]= w;
loaderAND1657:
	if (local[0]!=NIL) goto loaderOR1654;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)95L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	local[0]= w;
loaderOR1654:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderFLET1653(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,loaderCLO1658,env,argv,local);
	local[1]= argv[0];
	local[2]= fqv[53];
	local[3]= fqv[54];
	ctx->vsp=local+4;
	w=(*ftab[8])(ctx,4,local+0,&ftab[8],fqv[55]); /*reduce*/
	local[0]= w;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,loaderCLO1659,env,argv,local);
	local[2]= local[0];
	local[3]= loadglobal(fqv[56]);
	ctx->vsp=local+4;
	w=(pointer)COERCE(ctx,2,local+2); /*coerce*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	local[2]= loadglobal(fqv[22]);
	ctx->vsp=local+3;
	w=(pointer)COERCE(ctx,2,local+1); /*coerce*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderCLO1658(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= fqv[57];
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderCLO1659(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env0->c.clo.env2[1];
	ctx->vsp=local+1;
	w=loaderFLET1652(ctx,1,local+0,w);
	if (w==NIL) goto loaderIF1660;
	local[0]= argv[0];
	goto loaderIF1661;
loaderIF1660:
	local[0]= makeint((eusinteger_t)95L);
loaderIF1661:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*load*/
static pointer loaderF1529load(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[58], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto loaderKEY1663;
	local[0] = NIL;
loaderKEY1663:
	if (n & (1<<1)) goto loaderKEY1664;
	local[8]= loadglobal(fqv[22]);
	local[9]= fqv[59];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[7])(ctx,1,local+10,&ftab[7],fqv[52]); /*pathname-name*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)CONCATENATE(ctx,3,local+8); /*concatenate*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)loaderF1528gencname_tail(ctx,1,local+8); /*gencname-tail*/
	local[1] = w;
loaderKEY1664:
	if (n & (1<<2)) goto loaderKEY1665;
	local[2] = NIL;
loaderKEY1665:
	if (n & (1<<3)) goto loaderKEY1666;
	local[3] = fqv[60];
loaderKEY1666:
	if (n & (1<<4)) goto loaderKEY1667;
	local[4] = fqv[61];
loaderKEY1667:
	if (n & (1<<5)) goto loaderKEY1668;
	local[5] = loadglobal(fqv[62]);
loaderKEY1668:
	if (n & (1<<6)) goto loaderKEY1669;
	local[6] = NIL;
loaderKEY1669:
	if (n & (1<<7)) goto loaderKEY1670;
	local[7] = loadglobal(fqv[63]);
loaderKEY1670:
	local[8]= loadglobal(fqv[63]);
	w = local[8];
	ctx->vsp=local+8;
	bindspecial(ctx,fqv[63],w);
	local[11]= NIL;
	local[12]= NIL;
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,loaderFLET1671,env,argv,local);
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,loaderFLET1672,env,argv,local);
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,loaderFLET1673,env,argv,local);
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(*ftab[9])(ctx,1,local+16,&ftab[9],fqv[64]); /*pathname*/
	argv[0] = w;
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)FINDPACKAGE(ctx,1,local+16); /*find-package*/
	local[16]= w;
	storeglobal(fqv[63],w);
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,1,local+16,&ftab[10],fqv[65]); /*pathname-directory*/
	if (w==NIL) goto loaderIF1674;
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,1,local+16,&ftab[10],fqv[65]); /*pathname-directory*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[66];
	ctx->vsp=local+18;
	w=(pointer)EQ(ctx,2,local+16); /*eql*/
	if (w==NIL) goto loaderIF1674;
	local[16]= argv[0];
	w = local[15];
	ctx->vsp=local+17;
	w=loaderFLET1673(ctx,1,local+16,w);
	local[12] = w;
	if (local[12]!=NIL) goto loaderIF1676;
	local[16]= fqv[67];
	local[17]= argv[0];
	ctx->vsp=local+18;
	w=(pointer)SIGERROR(ctx,2,local+16); /*error*/
	local[16]= w;
	goto loaderIF1677;
loaderIF1676:
	local[16]= local[12];
loaderIF1677:
	goto loaderIF1675;
loaderIF1674:
	local[16]= NIL;
	local[17]= loadglobal(fqv[68]);
	local[18]= loadglobal(fqv[69]);
	local[19]= fqv[70];
	local[20]= (pointer)get_sym_func(fqv[71]);
	ctx->vsp=local+21;
	w=(*ftab[11])(ctx,4,local+17,&ftab[11],fqv[72]); /*union*/
	local[17]= w;
loaderWHL1678:
	if (local[17]==NIL) goto loaderWHX1679;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	local[18]= local[16];
	local[19]= argv[0];
	ctx->vsp=local+20;
	w=(*ftab[12])(ctx,2,local+18,&ftab[12],fqv[73]); /*concatenate-pathnames*/
	local[11] = w;
	local[18]= local[11];
	w = local[15];
	ctx->vsp=local+19;
	w=loaderFLET1673(ctx,1,local+18,w);
	local[12] = w;
	if (local[12]==NIL) goto loaderIF1681;
	w = local[12];
	ctx->vsp=local+18;
	unwind(ctx,local+0);
	local[0]=w;
	goto loaderBLK1662;
	goto loaderIF1682;
loaderIF1681:
	local[18]= NIL;
loaderIF1682:
	goto loaderWHL1678;
loaderWHX1679:
	local[18]= NIL;
loaderBLK1680:
	w = NIL;
	local[16]= fqv[74];
	local[17]= argv[0];
	ctx->vsp=local+18;
	w=(pointer)SIGERROR(ctx,2,local+16); /*error*/
	local[16]= w;
loaderIF1675:
	w = local[16];
	local[13]= w;
	ctx->vsp=local+14;
	unbindx(ctx,1);
	w = local[13];
	local[0]= w;
loaderBLK1662:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderFLET1671(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (env->c.clo.env2[5]==NIL) goto loaderIF1683;
	local[0]= T;
	local[1]= fqv[75];
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,1,local+3,&ftab[0],fqv[0]); /*namestring*/
	local[3]= w;
	local[4]= loadglobal(fqv[63]);
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= w;
	goto loaderIF1684;
loaderIF1683:
	local[0]= NIL;
loaderIF1684:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderFLET1672(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[13])(ctx,1,local+0,&ftab[13],fqv[76]); /*directory-namestring*/
	local[0]= w;
	w = loadglobal(fqv[68]);
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	local[1]= NIL;
	local[2]= NIL;
	w = local[0];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[68],w);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,1,local+6,&ftab[0],fqv[0]); /*namestring*/
	argv[0] = w;
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)loaderF1523object_file_p(ctx,1,local+6); /*object-file-p*/
	if (w==NIL) goto loaderCON1686;
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[7])(ctx,1,local+6,&ftab[7],fqv[52]); /*pathname-name*/
	local[6]= w;
	local[7]= loadglobal(fqv[77]);
	local[8]= fqv[78];
	local[9]= (pointer)get_sym_func(fqv[79]);
	local[10]= fqv[70];
	local[11]= (pointer)get_sym_func(fqv[80]);
	ctx->vsp=local+12;
	w=(*ftab[14])(ctx,6,local+6,&ftab[14],fqv[81]); /*find*/
	local[1] = w;
	if (local[1]==NIL) goto loaderIF1687;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[15])(ctx,1,local+6,&ftab[15],fqv[82]); /*system::unbinload*/
	local[6]= T;
	local[7]= fqv[83];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	goto loaderIF1688;
loaderIF1687:
	local[6]= NIL;
loaderIF1688:
	local[6]= fqv[84];
	local[7]= argv[0];
	w = env->c.clo.env2[13];
	ctx->vsp=local+8;
	w=loaderFLET1671(ctx,2,local+6,w);
	local[6]= argv[0];
	local[7]= env->c.clo.env2[1];
	ctx->vsp=local+8;
	w=(pointer)BINLOAD(ctx,2,local+6); /*system:binload*/
	local[2] = w;
	if (local[2]==NIL) goto loaderIF1689;
	local[6]= local[2];
	w = loadglobal(fqv[77]);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	storeglobal(fqv[77],local[6]);
	goto loaderIF1690;
loaderIF1689:
	local[6]= NIL;
loaderIF1690:
	local[6]= local[2];
	goto loaderCON1685;
loaderCON1686:
	local[6]= fqv[85];
	local[7]= argv[0];
	w = env->c.clo.env2[13];
	ctx->vsp=local+8;
	w=loaderFLET1671(ctx,2,local+6,w);
	local[6]= argv[0];
	local[7]= env->c.clo.env2[6];
	ctx->vsp=local+8;
	w=(pointer)loaderF1526system__txtload(ctx,2,local+6); /*system::txtload*/
	local[6]= T;
	goto loaderCON1685;
loaderCON1691:
	local[6]= NIL;
loaderCON1685:
	ctx->vsp=local+7;
	unbindx(ctx,1);
	w = local[6];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderFLET1673(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)loaderF1522probe_file(ctx,1,local+2); /*probe-file*/
	local[2]= w;
	local[3]= fqv[86];
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1693;
	local[2]= argv[0];
	w = env->c.clo.env2[14];
	ctx->vsp=local+3;
	w=loaderFLET1672(ctx,1,local+2,w);
	local[2]= w;
	goto loaderCON1692;
loaderCON1693:
	local[2]= fqv[88];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,2,local+2,&ftab[6],fqv[51]); /*merge-pathnames*/
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)loaderF1522probe_file(ctx,1,local+2); /*probe-file*/
	if (w==NIL) goto loaderCON1694;
	local[2]= local[0];
	w = env->c.clo.env2[14];
	ctx->vsp=local+3;
	w=loaderFLET1672(ctx,1,local+2,w);
	local[2]= w;
	goto loaderCON1692;
loaderCON1694:
	local[2]= fqv[89];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,2,local+2,&ftab[6],fqv[51]); /*merge-pathnames*/
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)loaderF1522probe_file(ctx,1,local+2); /*probe-file*/
	if (w==NIL) goto loaderCON1695;
	local[2]= local[0];
	w = env->c.clo.env2[14];
	ctx->vsp=local+3;
	w=loaderFLET1672(ctx,1,local+2,w);
	local[2]= w;
	goto loaderCON1692;
loaderCON1695:
	local[2]= fqv[90];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,2,local+2,&ftab[6],fqv[51]); /*merge-pathnames*/
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)loaderF1522probe_file(ctx,1,local+2); /*probe-file*/
	if (w==NIL) goto loaderCON1696;
	local[2]= local[0];
	w = env->c.clo.env2[14];
	ctx->vsp=local+3;
	w=loaderFLET1672(ctx,1,local+2,w);
	local[2]= w;
	goto loaderCON1692;
loaderCON1696:
	local[2]= fqv[91];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,2,local+2,&ftab[6],fqv[51]); /*merge-pathnames*/
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)loaderF1522probe_file(ctx,1,local+2); /*probe-file*/
	if (w==NIL) goto loaderCON1697;
	local[2]= local[0];
	w = env->c.clo.env2[14];
	ctx->vsp=local+3;
	w=loaderFLET1672(ctx,1,local+2,w);
	local[2]= w;
	goto loaderCON1692;
loaderCON1697:
	local[2]= fqv[92];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,2,local+2,&ftab[6],fqv[51]); /*merge-pathnames*/
	local[1] = w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)loaderF1522probe_file(ctx,1,local+2); /*probe-file*/
	if (w==NIL) goto loaderCON1698;
	local[2]= local[1];
	w = env->c.clo.env2[14];
	ctx->vsp=local+3;
	w=loaderFLET1672(ctx,1,local+2,w);
	local[2]= w;
	goto loaderCON1692;
loaderCON1698:
	local[2]= NIL;
loaderCON1692:
	w = local[2];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*load-files*/
static pointer loaderF1530load_files(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
loaderRST1700:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= local[0];
loaderWHL1701:
	if (local[2]==NIL) goto loaderWHX1702;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= fqv[93];
	local[5]= T;
	ctx->vsp=local+6;
	w=(pointer)loaderF1529load(ctx,3,local+3); /*load*/
	goto loaderWHL1701;
loaderWHX1702:
	local[3]= NIL;
loaderBLK1703:
	w = NIL;
	w = T;
	local[0]= w;
loaderBLK1699:
	ctx->vsp=local; return(local[0]);}

/*read-file*/
static pointer loaderF1531read_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)loaderF1521open(ctx,1,local+0); /*open*/
	local[0]= w;
	ctx->vsp=local+1;
	w = makeclosure(codevec,quotevec,loaderUWP1705,env,argv,local);
	local[1]=(pointer)(ctx->protfp); local[2]=w;
	ctx->protfp=(struct protectframe *)(local+1);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)READ(ctx,1,local+3); /*read*/
	ctx->vsp=local+3;
	loaderUWP1705(ctx,0,local+3,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
loaderBLK1704:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1705(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*read-strings*/
static pointer loaderF1532read_strings(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)loaderF1521open(ctx,1,local+0); /*open*/
	local[0]= w;
	ctx->vsp=local+1;
	w = makeclosure(codevec,quotevec,loaderUWP1707,env,argv,local);
	local[1]=(pointer)(ctx->protfp); local[2]=w;
	ctx->protfp=(struct protectframe *)(local+1);
	local[3]= NIL;
	local[4]= NIL;
	w = NIL;
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= NIL;
loaderWHL1708:
	local[6]= local[0];
	local[7]= NIL;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)READLINE(ctx,3,local+6); /*read-line*/
	local[3] = w;
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w!=NIL) goto loaderWHX1709;
	local[6]= local[3];
	w = local[5];
	ctx->vsp=local+7;
	local[5] = cons(ctx,local[6],w);
	local[6]= fqv[94];
	w = local[5];
	ctx->vsp=local+7;
	local[5] = cons(ctx,local[6],w);
	goto loaderWHL1708;
loaderWHX1709:
	local[6]= NIL;
loaderBLK1710:
	local[6]= (pointer)get_sym_func(fqv[95]);
	local[7]= loadglobal(fqv[22]);
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)NREVERSE(ctx,1,local+8); /*nreverse*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,3,local+6); /*apply*/
	ctx->vsp=local+3;
	loaderUWP1707(ctx,0,local+3,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
loaderBLK1706:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1707(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*read-lines*/
static pointer loaderF1533read_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)loaderF1521open(ctx,1,local+0); /*open*/
	local[0]= w;
	ctx->vsp=local+1;
	w = makeclosure(codevec,quotevec,loaderUWP1712,env,argv,local);
	local[1]=(pointer)(ctx->protfp); local[2]=w;
	ctx->protfp=(struct protectframe *)(local+1);
	local[3]= NIL;
	local[4]= NIL;
	w = NIL;
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= NIL;
loaderWHL1713:
	local[6]= local[0];
	local[7]= NIL;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)READLINE(ctx,3,local+6); /*read-line*/
	local[3] = w;
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w!=NIL) goto loaderWHX1714;
	local[6]= local[3];
	w = local[5];
	ctx->vsp=local+7;
	local[5] = cons(ctx,local[6],w);
	goto loaderWHL1713;
loaderWHX1714:
	local[6]= NIL;
loaderBLK1715:
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	ctx->vsp=local+3;
	loaderUWP1712(ctx,0,local+3,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
loaderBLK1711:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1712(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*read-lists*/
static pointer loaderF1534read_lists(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	w = NIL;
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)loaderF1521open(ctx,1,local+3); /*open*/
	local[3]= w;
	ctx->vsp=local+4;
	w = makeclosure(codevec,quotevec,loaderUWP1717,env,argv,local);
	local[4]=(pointer)(ctx->protfp); local[5]=w;
	ctx->protfp=(struct protectframe *)(local+4);
loaderWHL1718:
	local[6]= local[3];
	local[7]= NIL;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)READ(ctx,3,local+6); /*read*/
	local[1] = w;
	local[6]= local[1];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w!=NIL) goto loaderWHX1719;
	local[6]= local[1];
	w = local[2];
	ctx->vsp=local+7;
	local[2] = cons(ctx,local[6],w);
	goto loaderWHL1718;
loaderWHX1719:
	local[6]= NIL;
loaderBLK1720:
	w = local[6];
	ctx->vsp=local+6;
	loaderUWP1717(ctx,0,local+6,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[0]= w;
loaderBLK1716:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1717(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*read-binary-file*/
static pointer loaderF1535read_binary_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*namestring*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)loaderF1540file_size(ctx,1,local+0); /*file-size*/
	local[0]= w;
	local[1]= NIL;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[44]); /*make-string*/
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)loaderF1521open(ctx,1,local+3); /*open*/
	local[3]= w;
	ctx->vsp=local+4;
	w = makeclosure(codevec,quotevec,loaderUWP1722,env,argv,local);
	local[4]=(pointer)(ctx->protfp); local[5]=w;
	ctx->protfp=(struct protectframe *)(local+4);
	local[6]= local[3];
	local[7]= fqv[96];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[2];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)UNIXREAD(ctx,3,local+6); /*unix:uread*/
	local[1] = w;
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,2,local+6,&ftab[17],fqv[97]); /*/=*/
	if (w==NIL) goto loaderIF1723;
	local[6]= fqv[98];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto loaderIF1724;
loaderIF1723:
	local[6]= NIL;
loaderIF1724:
	w = local[6];
	ctx->vsp=local+6;
	loaderUWP1722(ctx,0,local+6,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	w = local[2];
	local[0]= w;
loaderBLK1721:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1722(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*read-lines-till-eof*/
static pointer loaderF1536read_lines_till_eof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	w = NIL;
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
loaderWHL1726:
	local[3]= argv[0];
	local[4]= NIL;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)READLINE(ctx,3,local+3); /*read-line*/
	local[1] = w;
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)EQ(ctx,2,local+3); /*eql*/
	if (w!=NIL) goto loaderWHX1727;
	local[3]= local[1];
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	goto loaderWHL1726;
loaderWHX1727:
	local[3]= NIL;
loaderBLK1728:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[0]= w;
loaderBLK1725:
	ctx->vsp=local; return(local[0]);}

/*do-file-line*/
static pointer loaderF1729(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
loaderRST1731:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	w = local[1];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[99],w);
	local[6]= fqv[100];
	local[7]= loadglobal(fqv[99]);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[24];
	local[9]= local[2];
	local[10]= fqv[56];
	local[11]= fqv[19];
	local[12]= fqv[19];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[101];
	local[11]= fqv[102];
	local[12]= fqv[103];
	local[13]= local[2];
	local[14]= fqv[104];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	local[16]= fqv[105];
	local[17]= loadglobal(fqv[99]);
	local[18]= fqv[19];
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	w = local[0];
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	unbindx(ctx,1);
	w = local[6];
	local[0]= w;
loaderBLK1730:
	ctx->vsp=local; return(local[0]);}

/*do-file-form*/
static pointer loaderF1732(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
loaderRST1734:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	w = local[1];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[99],w);
	local[6]= fqv[100];
	local[7]= loadglobal(fqv[99]);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[24];
	local[9]= local[2];
	local[10]= fqv[56];
	local[11]= fqv[19];
	local[12]= fqv[19];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[101];
	local[11]= fqv[102];
	local[12]= fqv[103];
	local[13]= local[2];
	local[14]= fqv[104];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	local[16]= fqv[106];
	local[17]= loadglobal(fqv[99]);
	local[18]= fqv[19];
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	w = local[0];
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	unbindx(ctx,1);
	w = local[6];
	local[0]= w;
loaderBLK1733:
	ctx->vsp=local; return(local[0]);}

/*load-library*/
static pointer loaderF1537load_library(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
loaderRST1736:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[107]);
	local[2]= argv[0];
	local[3]= fqv[108];
	local[4]= NIL;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[1]= w;
	local[2]= local[1];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(*ftab[18])(ctx,2,local+2,&ftab[18],fqv[109]); /*system::list-module-initializers*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= local[2];
loaderWHL1737:
	if (local[5]==NIL) goto loaderWHX1738;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= loadglobal(fqv[110]);
	ctx->vsp=local+7;
	w=(pointer)ISATTY(ctx,1,local+6); /*unix:isatty*/
	if (w==NIL) goto loaderIF1740;
	local[6]= loadglobal(fqv[111]);
	local[7]= fqv[112];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= loadglobal(fqv[111]);
	ctx->vsp=local+7;
	w=(pointer)FINOUT(ctx,1,local+6); /*finish-output*/
	local[6]= w;
	goto loaderIF1741;
loaderIF1740:
	local[6]= NIL;
loaderIF1741:
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,2,local+6); /*funcall*/
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+7;
	local[3] = cons(ctx,local[6],w);
	goto loaderWHL1737;
loaderWHX1738:
	local[6]= NIL;
loaderBLK1739:
	w = NIL;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)NREVERSE(ctx,1,local+4); /*nreverse*/
	local[0]= w;
loaderBLK1735:
	ctx->vsp=local; return(local[0]);}

/*dump-object*/
static pointer loaderF1538dump_object(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
loaderRST1743:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= T;
	local[2]= T;
	local[3]= NIL;
	local[4]= NIL;
	w = local[4];
	ctx->vsp=local+5;
	bindspecial(ctx,fqv[113],w);
	w = local[3];
	ctx->vsp=local+8;
	bindspecial(ctx,fqv[114],w);
	w = local[2];
	ctx->vsp=local+11;
	bindspecial(ctx,fqv[115],w);
	w = local[1];
	ctx->vsp=local+14;
	bindspecial(ctx,fqv[116],w);
	local[17]= argv[0];
	ctx->vsp=local+18;
	w=(pointer)STREAMP(ctx,1,local+17); /*streamp*/
	if (w==NIL) goto loaderIF1744;
	local[17]= NIL;
	local[18]= local[0];
loaderWHL1746:
	if (local[18]==NIL) goto loaderWHX1747;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18] = (w)->c.cons.cdr;
	w = local[19];
	local[17] = w;
	local[19]= local[17];
	local[20]= argv[0];
	ctx->vsp=local+21;
	w=(pointer)PRINT(ctx,2,local+19); /*print*/
	goto loaderWHL1746;
loaderWHX1747:
	local[19]= NIL;
loaderBLK1748:
	w = NIL;
	local[17]= w;
	goto loaderIF1745;
loaderIF1744:
	local[17]= argv[0];
	local[18]= fqv[117];
	local[19]= fqv[118];
	ctx->vsp=local+20;
	w=(pointer)loaderF1521open(ctx,3,local+17); /*open*/
	local[17]= w;
	ctx->vsp=local+18;
	w = makeclosure(codevec,quotevec,loaderUWP1749,env,argv,local);
	local[18]=(pointer)(ctx->protfp); local[19]=w;
	ctx->protfp=(struct protectframe *)(local+18);
	local[20]= NIL;
	local[21]= local[0];
loaderWHL1750:
	if (local[21]==NIL) goto loaderWHX1751;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21] = (w)->c.cons.cdr;
	w = local[22];
	local[20] = w;
	local[22]= local[20];
	local[23]= local[17];
	ctx->vsp=local+24;
	w=(pointer)PRINT(ctx,2,local+22); /*print*/
	goto loaderWHL1750;
loaderWHX1751:
	local[22]= NIL;
loaderBLK1752:
	w = NIL;
	ctx->vsp=local+20;
	loaderUWP1749(ctx,0,local+20,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[17]= w;
loaderIF1745:
	ctx->vsp=local+18;
	unbindx(ctx,4);
	w = local[17];
	local[0]= w;
loaderBLK1742:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1749(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[17];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*dump-structure*/
static pointer loaderF1539dump_structure(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
loaderRST1754:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= T;
	local[2]= T;
	local[3]= NIL;
	local[4]= NIL;
	w = local[4];
	ctx->vsp=local+5;
	bindspecial(ctx,fqv[113],w);
	w = local[3];
	ctx->vsp=local+8;
	bindspecial(ctx,fqv[114],w);
	w = local[2];
	ctx->vsp=local+11;
	bindspecial(ctx,fqv[115],w);
	w = local[1];
	ctx->vsp=local+14;
	bindspecial(ctx,fqv[119],w);
	local[17]= argv[0];
	ctx->vsp=local+18;
	w=(pointer)STREAMP(ctx,1,local+17); /*streamp*/
	if (w==NIL) goto loaderIF1755;
	local[17]= NIL;
	local[18]= local[0];
loaderWHL1757:
	if (local[18]==NIL) goto loaderWHX1758;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18] = (w)->c.cons.cdr;
	w = local[19];
	local[17] = w;
	local[19]= local[17];
	local[20]= argv[0];
	ctx->vsp=local+21;
	w=(pointer)PRINT(ctx,2,local+19); /*print*/
	goto loaderWHL1757;
loaderWHX1758:
	local[19]= NIL;
loaderBLK1759:
	w = NIL;
	local[17]= w;
	goto loaderIF1756;
loaderIF1755:
	local[17]= argv[0];
	local[18]= fqv[117];
	local[19]= fqv[118];
	ctx->vsp=local+20;
	w=(pointer)loaderF1521open(ctx,3,local+17); /*open*/
	local[17]= w;
	ctx->vsp=local+18;
	w = makeclosure(codevec,quotevec,loaderUWP1760,env,argv,local);
	local[18]=(pointer)(ctx->protfp); local[19]=w;
	ctx->protfp=(struct protectframe *)(local+18);
	local[20]= NIL;
	local[21]= local[0];
loaderWHL1761:
	if (local[21]==NIL) goto loaderWHX1762;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21] = (w)->c.cons.cdr;
	w = local[22];
	local[20] = w;
	local[22]= local[20];
	local[23]= local[17];
	ctx->vsp=local+24;
	w=(pointer)PRINT(ctx,2,local+22); /*print*/
	goto loaderWHL1761;
loaderWHX1762:
	local[22]= NIL;
loaderBLK1763:
	w = NIL;
	ctx->vsp=local+20;
	loaderUWP1760(ctx,0,local+20,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[17]= w;
loaderIF1756:
	ctx->vsp=local+18;
	unbindx(ctx,4);
	w = local[17];
	local[0]= w;
loaderBLK1753:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer loaderUWP1760(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[17];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*dump-loadable-structure*/
static pointer loaderF1764(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
loaderRST1766:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= local[0];
loaderWHL1767:
	if (local[3]==NIL) goto loaderWHX1768;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= fqv[120];
	local[5]= fqv[104];
	local[6]= local[2];
	local[7]= fqv[120];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SYMVALUE(ctx,1,local+8); /*symbol-value*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,3,local+5); /*list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	goto loaderWHL1767;
loaderWHX1768:
	local[4]= NIL;
loaderBLK1769:
	w = NIL;
	local[2]= fqv[121];
	local[3]= argv[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)REVERSE(ctx,1,local+4); /*reverse*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
loaderBLK1765:
	ctx->vsp=local; return(local[0]);}

/*file-size*/
static pointer loaderF1540file_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*namestring*/
	argv[0] = w;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)loaderF1522probe_file(ctx,1,local+0); /*probe-file*/
	if (w==NIL) goto loaderIF1771;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*namestring*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)STAT(ctx,1,local+0); /*unix:stat*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)7L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	goto loaderIF1772;
loaderIF1771:
	local[0]= fqv[122];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
loaderIF1772:
	w = local[0];
	local[0]= w;
loaderBLK1770:
	ctx->vsp=local; return(local[0]);}

/*directory-p*/
static pointer loaderF1541directory_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)STAT(ctx,1,local+2); /*unix:stat*/
	local[1] = w;
	w = local[1];
	if (!iscons(w)) goto loaderIF1774;
	local[2]= makeint((eusinteger_t)16384L);
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LOGAND(ctx,2,local+2); /*logand*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)16384L);
	ctx->vsp=local+4;
	w=(pointer)NUMEQUAL(ctx,2,local+2); /*=*/
	local[2]= w;
	goto loaderIF1775;
loaderIF1774:
	local[2]= NIL;
loaderIF1775:
	w = local[2];
	local[0]= w;
loaderBLK1773:
	ctx->vsp=local; return(local[0]);}

/*map-file*/
static pointer loaderF1542map_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[123], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto loaderKEY1777;
	local[0] = fqv[2];
loaderKEY1777:
	if (n & (1<<1)) goto loaderKEY1778;
	local[1] = makeint((eusinteger_t)0L);
loaderKEY1778:
	if (n & (1<<2)) goto loaderKEY1779;
	local[2] = NIL;
loaderKEY1779:
	if (n & (1<<3)) goto loaderKEY1780;
	local[3] = NIL;
loaderKEY1780:
	if (n & (1<<4)) goto loaderKEY1781;
	local[4] = T;
loaderKEY1781:
	if (n & (1<<5)) goto loaderKEY1782;
	local[5] = NIL;
loaderKEY1782:
	if (n & (1<<6)) goto loaderKEY1783;
	local[6] = makeint((eusinteger_t)0L);
loaderKEY1783:
	local[7]= NIL;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= NIL;
	local[10]= argv[0];
	local[11]= fqv[117];
	local[12]= local[0];
	local[13]= fqv[124];
	local[14]= fqv[13];
	ctx->vsp=local+15;
	w=(pointer)loaderF1521open(ctx,5,local+10); /*open*/
	local[7] = w;
	if (local[2]!=NIL) goto loaderIF1784;
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)loaderF1540file_size(ctx,1,local+10); /*file-size*/
	local[2] = w;
	local[10]= local[2];
	goto loaderIF1785;
loaderIF1784:
	local[10]= NIL;
loaderIF1785:
	if (local[3]!=NIL) goto loaderIF1786;
	local[10]= local[0];
	local[11]= fqv[125];
	ctx->vsp=local+12;
	w=(pointer)ASSQ(ctx,2,local+10); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	local[10]= local[3];
	goto loaderIF1787;
loaderIF1786:
	local[10]= NIL;
loaderIF1787:
	if (local[4]==NIL) goto loaderIF1788;
	local[8] = makeint((eusinteger_t)1L);
	local[10]= local[8];
	goto loaderIF1789;
loaderIF1788:
	local[10]= NIL;
loaderIF1789:
	if (local[5]==NIL) goto loaderIF1790;
	local[8] = makeint((eusinteger_t)2L);
	local[10]= local[8];
	goto loaderIF1791;
loaderIF1790:
	local[10]= NIL;
loaderIF1791:
	local[10]= local[6];
	local[11]= local[2];
	local[12]= local[3];
	local[13]= local[8];
	local[14]= local[7];
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(*ftab[19])(ctx,6,local+10,&ftab[19],fqv[126]); /*unix:mmap*/
	local[9] = w;
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)CLOSE(ctx,1,local+10); /*close*/
	w = local[9];
	local[0]= w;
loaderBLK1776:
	ctx->vsp=local; return(local[0]);}

/*provide*/
static pointer loaderF1543provide(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
loaderRST1793:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,1,local+1,&ftab[20],fqv[127]); /*keywordp*/
	if (w!=NIL) goto loaderIF1794;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,1,local+1,&ftab[21],fqv[22]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,1,local+1,&ftab[22],fqv[128]); /*string-upcase*/
	local[1]= w;
	local[2]= loadglobal(fqv[129]);
	ctx->vsp=local+3;
	w=(pointer)INTERN(ctx,2,local+1); /*intern*/
	argv[0] = w;
	local[1]= argv[0];
	goto loaderIF1795;
loaderIF1794:
	local[1]= NIL;
loaderIF1795:
	local[1]= argv[0];
	local[2]= loadglobal(fqv[130]);
	ctx->vsp=local+3;
	w=(*ftab[23])(ctx,2,local+1,&ftab[23],fqv[131]); /*assoc*/
	if (w!=NIL) goto loaderIF1796;
	local[1]= loadglobal(fqv[130]);
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST_STAR(ctx,2,local+2); /*list**/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)NCONC(ctx,2,local+1); /*nconc*/
	local[1]= w;
	storeglobal(fqv[130],w);
	goto loaderIF1797;
loaderIF1796:
	local[1]= NIL;
loaderIF1797:
	w = argv[0];
	local[0]= w;
loaderBLK1792:
	ctx->vsp=local; return(local[0]);}

/*require*/
static pointer loaderF1544require(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
loaderRST1799:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,1,local+1,&ftab[20],fqv[127]); /*keywordp*/
	if (w!=NIL) goto loaderIF1800;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,1,local+1,&ftab[21],fqv[22]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,1,local+1,&ftab[22],fqv[128]); /*string-upcase*/
	local[1]= w;
	local[2]= loadglobal(fqv[129]);
	ctx->vsp=local+3;
	w=(pointer)INTERN(ctx,2,local+1); /*intern*/
	argv[0] = w;
	local[1]= argv[0];
	goto loaderIF1801;
loaderIF1800:
	local[1]= NIL;
loaderIF1801:
	local[1]= argv[0];
	local[2]= loadglobal(fqv[130]);
	ctx->vsp=local+3;
	w=(*ftab[23])(ctx,2,local+1,&ftab[23],fqv[131]); /*assoc*/
	if (w!=NIL) goto loaderIF1802;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (isstring(w)) goto loaderIF1804;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,1,local+1,&ftab[21],fqv[22]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[24])(ctx,1,local+1,&ftab[24],fqv[132]); /*string-downcase*/
	local[1]= w;
	w = local[0];
	ctx->vsp=local+2;
	local[0] = cons(ctx,local[1],w);
	local[1]= local[0];
	goto loaderIF1805;
loaderIF1804:
	local[1]= NIL;
loaderIF1805:
	local[1]= (pointer)get_sym_func(fqv[107]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)loaderF1543provide(ctx,1,local+1); /*provide*/
	local[1]= w;
	goto loaderIF1803;
loaderIF1802:
	local[1]= NIL;
loaderIF1803:
	w = local[1];
	local[0]= w;
loaderBLK1798:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___loader(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[133];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= fqv[134];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto loaderIF1806;
	local[0]= fqv[135];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[63],w);
	goto loaderIF1807;
loaderIF1806:
	local[0]= fqv[136];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
loaderIF1807:
	local[0]= fqv[137];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[138],module,loaderF1519file_write_date,fqv[139]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[140],module,loaderF1520file_newer,fqv[141]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[25],module,loaderF1521open,fqv[142]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[100],module,loaderF1596,fqv[143]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[144],module,loaderF1522probe_file,fqv[145]);
	local[0]= fqv[43];
	local[1]= fqv[146];
	local[2]= fqv[147];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1809;
	local[2]= makeint((eusinteger_t)7L);
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1809:
	local[2]= fqv[149];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1810;
	local[2]= makeint((eusinteger_t)127L);
	local[3]= makeint((eusinteger_t)69L);
	local[4]= makeint((eusinteger_t)76L);
	local[5]= makeint((eusinteger_t)70L);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1810:
	local[2]= fqv[150];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1811;
	local[2]= makeint((eusinteger_t)127L);
	local[3]= makeint((eusinteger_t)69L);
	local[4]= makeint((eusinteger_t)76L);
	local[5]= makeint((eusinteger_t)70L);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1811:
	local[2]= fqv[151];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1812;
	local[2]= fqv[152];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w!=NIL) goto loaderCON1812;
	local[2]= makeint((eusinteger_t)98L);
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1812:
	local[2]= fqv[153];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1813;
	local[2]= makeint((eusinteger_t)127L);
	local[3]= makeint((eusinteger_t)69L);
	local[4]= makeint((eusinteger_t)76L);
	local[5]= makeint((eusinteger_t)70L);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1813:
	local[2]= fqv[154];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1814;
	local[2]= fqv[155];
	local[3]= fqv[156];
	local[4]= fqv[157];
	local[5]= fqv[158];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1814:
	local[2]= fqv[152];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1815;
	local[2]= makeint((eusinteger_t)127L);
	local[3]= makeint((eusinteger_t)69L);
	local[4]= makeint((eusinteger_t)76L);
	local[5]= makeint((eusinteger_t)70L);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1815:
	local[2]= fqv[159];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1816;
	local[2]= makeint((eusinteger_t)77L);
	local[3]= makeint((eusinteger_t)90L);
	local[4]= makeint((eusinteger_t)144L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1816:
	local[2]= fqv[160];
	local[3]= loadglobal(fqv[148]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,2,local+2,&ftab[16],fqv[87]); /*member*/
	if (w==NIL) goto loaderCON1817;
	local[2]= makeint((eusinteger_t)131L);
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1817:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= fqv[161];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	goto loaderCON1808;
loaderCON1818:
	local[2]= NIL;
loaderCON1808:
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[162],module,loaderF1523object_file_p,fqv[163]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[164],module,loaderF1524path_list,fqv[165]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[166],module,loaderF1525find_executable,fqv[167]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[168],module,loaderF1526system__txtload,fqv[169]);
	local[0]= fqv[69];
	local[1]= fqv[170];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto loaderIF1819;
	local[0]= fqv[69];
	local[1]= fqv[170];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[69];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto loaderIF1821;
	local[0]= fqv[69];
	local[1]= fqv[171];
	local[2]= fqv[172];
	local[3]= loadglobal(fqv[173]);
	local[4]= NIL;
	local[5]= fqv[174];
	local[6]= loadglobal(fqv[173]);
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	local[5]= NIL;
	local[6]= fqv[175];
	local[7]= loadglobal(fqv[173]);
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	local[6]= NIL;
	local[7]= fqv[176];
	local[8]= loadglobal(fqv[173]);
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,5,local+2); /*list*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto loaderIF1822;
loaderIF1821:
	local[0]= NIL;
loaderIF1822:
	local[0]= fqv[69];
	goto loaderIF1820;
loaderIF1819:
	local[0]= NIL;
loaderIF1820:
	local[0]= fqv[68];
	local[1]= fqv[177];
	local[2]= fqv[178];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[62];
	local[1]= fqv[170];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto loaderIF1823;
	local[0]= fqv[62];
	local[1]= fqv[170];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[62];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto loaderIF1825;
	local[0]= fqv[62];
	local[1]= fqv[171];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto loaderIF1826;
loaderIF1825:
	local[0]= NIL;
loaderIF1826:
	local[0]= fqv[62];
	goto loaderIF1824;
loaderIF1823:
	local[0]= NIL;
loaderIF1824:
	local[0]= fqv[77];
	local[1]= fqv[170];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto loaderIF1827;
	local[0]= fqv[77];
	local[1]= fqv[170];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[77];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto loaderIF1829;
	local[0]= fqv[77];
	local[1]= fqv[171];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto loaderIF1830;
loaderIF1829:
	local[0]= NIL;
loaderIF1830:
	local[0]= fqv[77];
	goto loaderIF1828;
loaderIF1827:
	local[0]= NIL;
loaderIF1828:
	ctx->vsp=local+0;
	compfun(ctx,fqv[79],module,loaderF1527load_module_file_name,fqv[179]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[180],module,loaderF1528gencname_tail,fqv[181]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[107],module,loaderF1529load,fqv[182]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[183],module,loaderF1530load_files,fqv[184]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[185],module,loaderF1531read_file,fqv[186]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[187],module,loaderF1532read_strings,fqv[188]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[189],module,loaderF1533read_lines,fqv[190]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[191],module,loaderF1534read_lists,fqv[192]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[193],module,loaderF1535read_binary_file,fqv[194]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[195],module,loaderF1536read_lines_till_eof,fqv[196]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[197],module,loaderF1729,fqv[198]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[199],module,loaderF1732,fqv[200]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[201],module,loaderF1537load_library,fqv[202]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[203],module,loaderF1538dump_object,fqv[204]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[121],module,loaderF1539dump_structure,fqv[205]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[206],module,loaderF1764,fqv[207]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[208],module,loaderF1540file_size,fqv[209]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[210],module,loaderF1541directory_p,fqv[211]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[212],module,loaderF1542map_file,fqv[213]);
	local[0]= fqv[130];
	local[1]= fqv[170];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto loaderIF1831;
	local[0]= fqv[130];
	local[1]= fqv[170];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[130];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto loaderIF1833;
	local[0]= fqv[130];
	local[1]= fqv[171];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto loaderIF1834;
loaderIF1833:
	local[0]= NIL;
loaderIF1834:
	local[0]= fqv[130];
	goto loaderIF1832;
loaderIF1831:
	local[0]= NIL;
loaderIF1832:
	ctx->vsp=local+0;
	compfun(ctx,fqv[214],module,loaderF1543provide,fqv[215]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[216],module,loaderF1544require,fqv[217]);
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<25; i++) ftab[i]=fcallx;
}

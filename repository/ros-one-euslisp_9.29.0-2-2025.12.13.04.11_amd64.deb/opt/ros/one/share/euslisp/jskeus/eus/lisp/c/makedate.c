char *makedate="Sat Dec 13 04:13:03 UTC 2025";
#if Linux
char *gitrevision="6db5aab3";
#else
char *gitrevision="";
#endif
char *compilehost="sbuild";

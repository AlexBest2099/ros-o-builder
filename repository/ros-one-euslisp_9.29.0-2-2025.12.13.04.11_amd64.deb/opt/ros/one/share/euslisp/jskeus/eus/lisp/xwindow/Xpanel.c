/* ./Xpanel.c :  entry=Xpanel */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "Xpanel.h"
#pragma init (register_Xpanel)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xpanel();
extern pointer build_quote_vector();
static int register_Xpanel()
  { add_module_initializer("___Xpanel", ___Xpanel);}


/*:create*/
static pointer XpanelM1858panel_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XpanelRST1860:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XpanelKEY1861;
	local[1] = makeint((eusinteger_t)28L);
XpanelKEY1861:
	if (n & (1<<1)) goto XpanelKEY1862;
	local[2] = makeint((eusinteger_t)50L);
XpanelKEY1862:
	if (n & (1<<2)) goto XpanelKEY1863;
	local[3] = loadglobal(fqv[1]);
XpanelKEY1863:
	if (n & (1<<3)) goto XpanelKEY1864;
	local[4] = NIL;
XpanelKEY1864:
	if (n & (1<<4)) goto XpanelKEY1865;
	local[5] = NIL;
XpanelKEY1865:
	if (n & (1<<5)) goto XpanelKEY1866;
	local[6] = NIL;
XpanelKEY1866:
	if (local[4]!=NIL) goto XpanelIF1867;
	if (local[5]==NIL) goto XpanelIF1869;
	local[7]= argv[0];
	local[8]= fqv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	goto XpanelIF1870;
XpanelIF1869:
	local[7]= loadglobal(fqv[3]);
XpanelIF1870:
	local[4] = local[7];
	local[7]= local[4];
	goto XpanelIF1868;
XpanelIF1867:
	local[7]= NIL;
XpanelIF1868:
	local[7]= (pointer)get_sym_func(fqv[4]);
	local[8]= argv[0];
	local[9]= *(ovafptr(argv[1],fqv[5]));
	local[10]= fqv[6];
	local[11]= fqv[7];
	local[12]= makeint((eusinteger_t)1L);
	local[13]= fqv[2];
	local[14]= local[4];
	local[15]= fqv[8];
	local[16]= local[5];
	local[17]= fqv[9];
	local[18]= local[6];
	local[19]= local[0];
	ctx->vsp=local+20;
	w=(pointer)APPLY(ctx,13,local+7); /*apply*/
	w = local[3];
	if (!numberp(w)) goto XpanelIF1871;
	local[7]= local[3];
	goto XpanelIF1872;
XpanelIF1871:
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[0])(ctx,1,local+7,&ftab[0],fqv[10]); /*font-id*/
	local[7]= w;
XpanelIF1872:
	argv[0]->c.obj.iv[14] = local[7];
	local[7]= argv[0]->c.obj.iv[3];
	local[8]= fqv[11];
	local[9]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	argv[0]->c.obj.iv[19] = local[2];
	argv[0]->c.obj.iv[20] = local[1];
	local[7]= argv[0];
	local[8]= fqv[12];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	argv[0]->c.obj.iv[15] = w;
	local[7]= argv[0];
	local[8]= fqv[13];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	argv[0]->c.obj.iv[16] = w;
	argv[0]->c.obj.iv[13] = NIL;
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[18] = makeint((eusinteger_t)0L);
	local[7]= argv[0]->c.obj.iv[4];
	local[8]= makeflt(1.3999999999999994670929e+00);
	local[9]= argv[0];
	local[10]= fqv[14];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,3,local+7,&ftab[1],fqv[15]); /*get-lighter-pixel*/
	argv[0]->c.obj.iv[22] = w;
	local[7]= argv[0]->c.obj.iv[4];
	local[8]= makeflt(5.9999999999999964472863e-01);
	local[9]= argv[0];
	local[10]= fqv[14];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,3,local+7,&ftab[1],fqv[15]); /*get-lighter-pixel*/
	argv[0]->c.obj.iv[21] = w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[0]->c.obj.iv[5];
	local[10]= argv[0]->c.obj.iv[6];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(*ftab[2])(ctx,5,local+7,&ftab[2],fqv[16]); /*make-topleft-edge-polygon*/
	argv[0]->c.obj.iv[23] = w;
	local[7]= argv[0];
	local[8]= fqv[17];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	w = argv[0];
	local[0]= w;
XpanelBLK1859:
	ctx->vsp=local; return(local[0]);}

/*:expose*/
static pointer XpanelM1873panel_expose(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[18],w);
	local[3]= argv[0];
	local[4]= fqv[19];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XpanelBLK1874:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XpanelM1875panel_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = NIL;
	local[0]= w;
XpanelBLK1876:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XpanelM1877panel_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[5]));
	local[2]= fqv[20];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,5,local+0,&ftab[2],fqv[16]); /*make-topleft-edge-polygon*/
	argv[0]->c.obj.iv[23] = w;
	w = argv[0];
	local[0]= w;
XpanelBLK1878:
	ctx->vsp=local; return(local[0]);}

/*:items*/
static pointer XpanelM1879panel_items(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
XpanelBLK1880:
	ctx->vsp=local; return(local[0]);}

/*:locate-item*/
static pointer XpanelM1881panel_locate_item(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XpanelENT1885;}
	local[0]= NIL;
XpanelENT1885:
	if (n>=5) { local[1]=(argv[4]); goto XpanelENT1884;}
	local[1]= NIL;
XpanelENT1884:
XpanelENT1883:
	if (n>5) maerror();
	local[2]= argv[0];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= makeint((eusinteger_t)10L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,3,local+2); /*-*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[21];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= local[2];
	local[4]= argv[2];
	local[5]= fqv[13];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto XpanelIF1886;
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[18];
	local[4]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= (pointer)get_sym_func(fqv[22]);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,XpanelCLO1888,env,argv,local);
	local[7]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,3,local+4); /*apply*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAX(ctx,2,local+3); /*max*/
	argv[0]->c.obj.iv[18] = w;
	local[3]= argv[0]->c.obj.iv[18];
	goto XpanelIF1887;
XpanelIF1886:
	local[3]= NIL;
XpanelIF1887:
	if (local[0]!=NIL) goto XpanelIF1889;
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= makeint((eusinteger_t)5L);
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[0] = w;
	local[3]= local[0];
	goto XpanelIF1890;
XpanelIF1889:
	local[3]= NIL;
XpanelIF1890:
	if (local[1]!=NIL) goto XpanelIF1891;
	local[3]= argv[0]->c.obj.iv[18];
	local[4]= makeint((eusinteger_t)5L);
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[1] = w;
	local[3]= local[1];
	goto XpanelIF1892;
XpanelIF1891:
	local[3]= NIL;
XpanelIF1892:
	local[3]= argv[2];
	local[4]= fqv[23];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= argv[2];
	local[6]= fqv[13];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAX(ctx,2,local+4); /*max*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	argv[0]->c.obj.iv[17] = w;
	local[3]= argv[2];
	local[4]= fqv[24];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)5L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	argv[0]->c.obj.iv[18] = w;
	local[3]= argv[2];
	local[4]= fqv[25];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[2];
	w = argv[0]->c.obj.iv[13];
	ctx->vsp=local+4;
	argv[0]->c.obj.iv[13] = cons(ctx,local[3],w);
	w = argv[2];
	local[0]= w;
XpanelBLK1882:
	ctx->vsp=local; return(local[0]);}

/*:create-item*/
static pointer XpanelM1893panel_create_item(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
XpanelRST1895:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-6);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[26], &argv[6], n-6, local+1, 1);
	if (n & (1<<0)) goto XpanelKEY1896;
	local[1] = NIL;
XpanelKEY1896:
	if (n & (1<<1)) goto XpanelKEY1897;
	local[2] = NIL;
XpanelKEY1897:
	if (n & (1<<2)) goto XpanelKEY1898;
	local[3] = argv[0]->c.obj.iv[14];
XpanelKEY1898:
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= (pointer)get_sym_func(fqv[28]);
	local[8]= local[6];
	local[9]= fqv[6];
	local[10]= argv[3];
	local[11]= argv[4];
	local[12]= argv[5];
	local[13]= fqv[11];
	local[14]= local[3];
	local[15]= fqv[8];
	local[16]= argv[0];
	local[17]= fqv[25];
	local[18]= NIL;
	local[19]= local[0];
	ctx->vsp=local+20;
	w=(pointer)APPLY(ctx,13,local+7); /*apply*/
	w = local[6];
	local[6]= w;
	local[7]= local[1];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[0]= w;
XpanelBLK1894:
	ctx->vsp=local; return(local[0]);}

/*:create-menubar*/
static pointer XpanelM1899panel_create_menubar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XpanelRST1901:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[29], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XpanelKEY1902;
	local[1] = makeint((eusinteger_t)0L);
XpanelKEY1902:
	if (n & (1<<1)) goto XpanelKEY1903;
	local[2] = makeint((eusinteger_t)0L);
XpanelKEY1903:
	if (n & (1<<2)) goto XpanelKEY1904;
	local[3] = argv[0]->c.obj.iv[14];
XpanelKEY1904:
	local[4]= NIL;
	local[5]= loadglobal(fqv[30]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= (pointer)get_sym_func(fqv[28]);
	local[7]= local[5];
	local[8]= fqv[6];
	local[9]= fqv[11];
	local[10]= local[3];
	local[11]= fqv[8];
	local[12]= argv[0];
	local[13]= fqv[25];
	local[14]= NIL;
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,10,local+6); /*apply*/
	w = local[5];
	local[4] = w;
	local[5]= local[4];
	local[6]= fqv[12];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	argv[0]->c.obj.iv[18] = w;
	local[5]= argv[0];
	local[6]= fqv[27];
	local[7]= local[4];
	local[8]= local[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[0]= w;
XpanelBLK1900:
	ctx->vsp=local; return(local[0]);}

/*:active-menu*/
static pointer XpanelM1905panel_active_menu(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[24]==NIL) goto XpanelIF1907;
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[24];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w!=NIL) goto XpanelIF1907;
	local[0]= argv[0]->c.obj.iv[24];
	local[1]= fqv[31];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto XpanelIF1908;
XpanelIF1907:
	local[0]= NIL;
XpanelIF1908:
	argv[0]->c.obj.iv[24] = argv[2];
	local[0]= argv[0]->c.obj.iv[24];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XpanelBLK1906:
	ctx->vsp=local; return(local[0]);}

/*:delete-items*/
static pointer XpanelM1909panel_delete_items(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[18] = makeint((eusinteger_t)0L);
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[34]); /*send-all*/
	argv[0]->c.obj.iv[13] = NIL;
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
XpanelBLK1910:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer XpanelCLO1888(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[24];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:quit*/
static pointer XpanelM1911panel_quit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XpanelRST1913:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[35];
	w = NIL;
	ctx->vsp=local+2;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	w = local[1];
	local[0]= w;
XpanelBLK1912:
	ctx->vsp=local; return(local[0]);}

/*:keyenter*/
static pointer XpanelM1914panel_keyenter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XpanelBLK1915:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XpanelM1916panel_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XpanelBLK1917:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XpanelM1918panel_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XpanelBLK1919:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XpanelM1920panel_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XpanelBLK1921:
	ctx->vsp=local; return(local[0]);}

/*:enternotify*/
static pointer XpanelM1922panel_enternotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[18],w);
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XpanelBLK1923:
	ctx->vsp=local; return(local[0]);}

/*:leavenotify*/
static pointer XpanelM1924panel_leavenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XpanelBLK1925:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XpanelM1926menubar_panel_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XpanelRST1928:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[36], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XpanelKEY1929;
	local[1] = loadglobal(fqv[1]);
XpanelKEY1929:
	if (n & (1<<1)) goto XpanelKEY1930;
	local[2] = NIL;
XpanelKEY1930:
	if (n & (1<<2)) goto XpanelKEY1931;
	local[3] = NIL;
XpanelKEY1931:
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= fqv[37];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[38]); /*textdots*/
	local[6] = w;
	if (local[2]!=NIL) goto XpanelIF1932;
	local[7]= makeint((eusinteger_t)60L);
	goto XpanelIF1933;
XpanelIF1932:
	local[7]= local[2];
XpanelIF1933:
	local[4] = local[7];
	if (local[3]==NIL) goto XpanelIF1934;
	local[7]= local[3];
	goto XpanelIF1935;
XpanelIF1934:
	local[7]= local[6];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)6L);
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,3,local+7); /*+*/
	local[7]= w;
XpanelIF1935:
	local[5] = local[7];
	local[7]= (pointer)get_sym_func(fqv[4]);
	local[8]= argv[0];
	local[9]= *(ovafptr(argv[1],fqv[5]));
	local[10]= fqv[6];
	local[11]= fqv[13];
	local[12]= local[4];
	local[13]= fqv[12];
	local[14]= local[5];
	local[15]= fqv[7];
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,11,local+7); /*apply*/
	local[7]= argv[0];
	local[8]= fqv[39];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[2];
	local[12]= local[3];
	local[13]= makeint((eusinteger_t)2L);
	local[14]= argv[0]->c.obj.iv[22];
	local[15]= argv[0]->c.obj.iv[21];
	local[16]= argv[0]->c.obj.iv[4];
	local[17]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,11,local+7); /*send*/
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)3L);
	argv[0]->c.obj.iv[18] = makeint((eusinteger_t)2L);
	local[7]= argv[0];
	local[8]= fqv[17];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	w = argv[0];
	local[0]= w;
XpanelBLK1927:
	ctx->vsp=local; return(local[0]);}

/*:locate-item*/
static pointer XpanelM1936menubar_panel_locate_item(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XpanelENT1940;}
	local[0]= NIL;
XpanelENT1940:
	if (n>=5) { local[1]=(argv[4]); goto XpanelENT1939;}
	local[1]= NIL;
XpanelENT1939:
XpanelENT1938:
	if (n>5) maerror();
	local[2]= argv[0];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= makeint((eusinteger_t)10L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,3,local+2); /*-*/
	local[2]= w;
	local[3]= local[2];
	local[4]= argv[2];
	local[5]= fqv[13];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto XpanelIF1941;
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)3L);
	local[3]= argv[0]->c.obj.iv[18];
	local[4]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	argv[0]->c.obj.iv[18] = w;
	local[3]= argv[0]->c.obj.iv[18];
	goto XpanelIF1942;
XpanelIF1941:
	local[3]= NIL;
XpanelIF1942:
	local[3]= argv[2];
	local[4]= fqv[23];
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= argv[2];
	local[4]= fqv[40];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= fqv[13];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	argv[0]->c.obj.iv[17] = w;
	local[3]= argv[2];
	local[4]= fqv[24];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	argv[0]->c.obj.iv[18] = w;
	local[3]= argv[2];
	local[4]= fqv[25];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[2];
	w = argv[0]->c.obj.iv[13];
	ctx->vsp=local+4;
	argv[0]->c.obj.iv[13] = cons(ctx,local[3],w);
	w = argv[2];
	local[0]= w;
XpanelBLK1937:
	ctx->vsp=local; return(local[0]);}

/*:popup-all-menus*/
static pointer XpanelM1943menubar_panel_popup_all_menus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[34]); /*send-all*/
	local[0]= w;
XpanelBLK1944:
	ctx->vsp=local; return(local[0]);}

/*:unmap-all-menus*/
static pointer XpanelM1945menubar_panel_unmap_all_menus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= fqv[31];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[34]); /*send-all*/
	local[0]= w;
XpanelBLK1946:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xpanel(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[41];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XpanelIF1947;
	local[0]= fqv[42];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[43],w);
	goto XpanelIF1948;
XpanelIF1947:
	local[0]= fqv[44];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XpanelIF1948:
	local[0]= fqv[45];
	local[1]= fqv[46];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[47]); /*require*/
	local[0]= fqv[48];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1858panel_create,fqv[6],fqv[49],fqv[50]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1873panel_expose,fqv[51],fqv[49],fqv[52]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1875panel_redraw,fqv[19],fqv[49],fqv[53]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1877panel_resize,fqv[20],fqv[49],fqv[54]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1879panel_items,fqv[55],fqv[49],fqv[56]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1881panel_locate_item,fqv[27],fqv[49],fqv[57]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1893panel_create_item,fqv[58],fqv[49],fqv[59]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1899panel_create_menubar,fqv[60],fqv[49],fqv[61]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1905panel_active_menu,fqv[62],fqv[49],fqv[63]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1909panel_delete_items,fqv[64],fqv[49],fqv[65]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1911panel_quit,fqv[66],fqv[49],fqv[67]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1914panel_keyenter,fqv[68],fqv[49],fqv[69]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1916panel_buttonpress,fqv[70],fqv[49],fqv[71]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1918panel_buttonrelease,fqv[72],fqv[49],fqv[73]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1920panel_motionnotify,fqv[74],fqv[49],fqv[75]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1922panel_enternotify,fqv[76],fqv[49],fqv[77]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1924panel_leavenotify,fqv[78],fqv[49],fqv[79]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1926menubar_panel_create,fqv[6],fqv[30],fqv[80]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1936menubar_panel_locate_item,fqv[27],fqv[30],fqv[81]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1943menubar_panel_popup_all_menus,fqv[82],fqv[30],fqv[83]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XpanelM1945menubar_panel_unmap_all_menus,fqv[84],fqv[30],fqv[85]);
	local[0]= fqv[86];
	local[1]= fqv[87];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[88]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<7; i++) ftab[i]=fcallx;
}

/* ./packsym.c :  entry=packsym */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "packsym.h"
#pragma init (register_packsym)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___packsym();
extern pointer build_quote_vector();
static int register_packsym()
  { add_module_initializer("___packsym", ___packsym);}

static pointer packsymF2431metaclass_name();
static pointer packsymF2432symbol_plist();
static pointer packsymF2433remprop();
static pointer packsymF2434symbol_package();
static pointer packsymF2435symbol_name();
static pointer packsymF2436make_symbol();
static pointer packsymF2437documentation();
static pointer packsymF2438gentemp();
static pointer packsymF2439package_name();
static pointer packsymF2440package_nicknames();
static pointer packsymF2441package_use_list();
static pointer packsymF2442package_used_by_list();
static pointer packsymF2443packagep();
static pointer packsymF2444use_package();
static pointer packsymF2445unuse_package();
static pointer packsymF2446make_package();
static pointer packsymF2447rename_package();
static pointer packsymF2448shadow();
static pointer packsymF2449import();
static pointer packsymF2450symbol_string();
static pointer packsymF2451unintern();
static pointer packsymF2452package_stats();

/*metaclass-name*/
static pointer packsymF2431metaclass_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = *(ovafptr(argv[0],fqv[0]));
	local[0]= w;
packsymBLK2453:
	ctx->vsp=local; return(local[0]);}

/*:home-package*/
static pointer packsymM2454symbol_home_package(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
packsymBLK2455:
	ctx->vsp=local; return(local[0]);}

/*:pname*/
static pointer packsymM2456symbol_pname(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
packsymBLK2457:
	ctx->vsp=local; return(local[0]);}

/*:func*/
static pointer packsymM2458symbol_func(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
packsymBLK2459:
	ctx->vsp=local; return(local[0]);}

/*:value*/
static pointer packsymM2460symbol_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto packsymIF2462;
	local[0]= makeint((eusinteger_t)11L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
	goto packsymIF2463;
packsymIF2462:
	local[0]= NIL;
packsymIF2463:
	argv[0]->c.obj.iv[1] = argv[2];
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
packsymBLK2461:
	ctx->vsp=local; return(local[0]);}

/*:constant*/
static pointer packsymM2464symbol_constant(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto packsymENT2467;}
	local[0]= NIL;
packsymENT2467:
packsymENT2466:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w==NIL) goto packsymIF2468;
	goto packsymIF2469;
packsymIF2468:
	local[-1]= NIL;
packsymIF2469:
	if (local[0]==NIL) goto packsymIF2470;
	local[-1]= argv[0];
	local[0]= local[0];
	local[1]= fqv[1];
	ctx->vsp=local+2;
	w=(pointer)PUTPROP(ctx,3,local+-1); /*putprop*/
	local[-1]= w;
	goto packsymIF2471;
packsymIF2470:
	local[-1]= NIL;
packsymIF2471:
	argv[0]->c.obj.iv[2] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[1] = argv[2];
	w = argv[0];
	local[-2]= w;
packsymBLK2465:
	ctx->vsp=local; return(local[0]);}

/*:special*/
static pointer packsymM2472symbol_special(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto packsymENT2475;}
	local[0]= NIL;
packsymENT2475:
packsymENT2474:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w==NIL) goto packsymIF2476;
	local[1]= makeint((eusinteger_t)11L);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto packsymIF2477;
packsymIF2476:
	local[1]= NIL;
packsymIF2477:
	if (local[0]==NIL) goto packsymIF2478;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto packsymIF2479;
packsymIF2478:
	local[1]= NIL;
packsymIF2479:
	ctx->vsp=local+1;
	w=(pointer)NEXT_SPECIAL_INDEX(ctx,0,local+1); /*system::next-special-index*/
	argv[0]->c.obj.iv[2] = w;
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SETSPECIAL(ctx,2,local+1); /*set*/
	w = argv[0];
	local[0]= w;
packsymBLK2473:
	ctx->vsp=local; return(local[0]);}

/*:global*/
static pointer packsymM2480symbol_global(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto packsymENT2483;}
	local[0]= NIL;
packsymENT2483:
packsymENT2482:
	if (n>4) maerror();
	argv[0]->c.obj.iv[2] = makeint((eusinteger_t)2L);
	argv[0]->c.obj.iv[1] = argv[2];
	if (local[0]==NIL) goto packsymIF2484;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto packsymIF2485;
packsymIF2484:
	local[1]= NIL;
packsymIF2485:
	w = argv[2];
	local[0]= w;
packsymBLK2481:
	ctx->vsp=local; return(local[0]);}

/*:vtype*/
static pointer packsymM2486symbol_vtype(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto packsymENT2489;}
	local[0]= NIL;
packsymENT2489:
packsymENT2488:
	if (n>3) maerror();
	if (local[0]==NIL) goto packsymIF2490;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto packsymIF2491;
packsymIF2490:
	local[1]= NIL;
packsymIF2491:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
packsymBLK2487:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer packsymM2492symbol_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto packsymENT2495;}
	local[0]= makeint((eusinteger_t)1L);
packsymENT2495:
packsymENT2494:
	if (n>4) maerror();
	argv[0]->c.obj.iv[4] = argv[2];
	argv[0]->c.obj.iv[2] = local[0];
	w = argv[0];
	local[0]= w;
packsymBLK2493:
	ctx->vsp=local; return(local[0]);}

/*symbol-plist*/
static pointer packsymF2432symbol_plist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[2];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
packsymBLK2496:
	ctx->vsp=local; return(local[0]);}

/*remprop*/
static pointer packsymF2433remprop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[3];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
packsymBLK2497:
	ctx->vsp=local; return(local[0]);}

/*symbol-package*/
static pointer packsymF2434symbol_package(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
packsymBLK2498:
	ctx->vsp=local; return(local[0]);}

/*symbol-name*/
static pointer packsymF2435symbol_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!issymbol(w)) goto packsymIF2500;
	local[0]= argv[0]->c.obj.iv[4];
	goto packsymIF2501;
packsymIF2500:
	local[0]= fqv[5];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
packsymIF2501:
	w = local[0];
	local[0]= w;
packsymBLK2499:
	ctx->vsp=local; return(local[0]);}

/*make-symbol*/
static pointer packsymF2436make_symbol(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto packsymENT2504;}
	local[0]= loadglobal(fqv[6]);
packsymENT2504:
packsymENT2503:
	if (n>2) maerror();
	w = argv[0];
	if (isstring(w)) goto packsymIF2505;
	local[1]= fqv[7];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto packsymIF2506;
packsymIF2505:
	local[1]= NIL;
packsymIF2506:
	local[1]= loadglobal(fqv[8]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= argv[0];
	w = local[1];
	w->c.obj.iv[4] = local[2];
	local[2]= makeint((eusinteger_t)1L);
	w = local[1];
	w->c.obj.iv[2] = local[2];
	local[2]= local[0];
	local[3]= local[2];
	w = local[1];
	w->c.obj.iv[5] = local[3];
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)MAKUNBOUND(ctx,1,local+2); /*makunbound*/
	w = local[1];
	local[0]= w;
packsymBLK2502:
	ctx->vsp=local; return(local[0]);}

/*documentation*/
static pointer packsymF2437documentation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto packsymENT2509;}
	local[0]= NIL;
packsymENT2509:
packsymENT2508:
	if (n>2) maerror();
	local[1]= local[0];
	local[2]= local[1];
	w = fqv[9];
	if (memq(local[2],w)==NIL) goto packsymIF2510;
	local[2]= argv[0];
	local[3]= fqv[10];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	goto packsymIF2511;
packsymIF2510:
	local[2]= local[1];
	w = fqv[11];
	if (memq(local[2],w)==NIL) goto packsymIF2512;
	local[2]= argv[0];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	goto packsymIF2513;
packsymIF2512:
	local[2]= local[1];
	w = fqv[12];
	if (memq(local[2],w)==NIL) goto packsymIF2514;
	local[2]= argv[0];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	goto packsymIF2515;
packsymIF2514:
	local[2]= local[1];
	w = fqv[14];
	if (memq(local[2],w)==NIL) goto packsymIF2516;
	local[2]= argv[0];
	local[3]= fqv[15];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	goto packsymIF2517;
packsymIF2516:
	if (T==NIL) goto packsymIF2518;
	local[2]= argv[0];
	local[3]= fqv[10];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	if (w!=NIL) goto packsymCON2520;
packsymCON2521:
	local[2]= argv[0];
	local[3]= fqv[15];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	if (w!=NIL) goto packsymCON2520;
packsymCON2522:
	local[2]= argv[0];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	if (w!=NIL) goto packsymCON2520;
packsymCON2523:
	local[2]= argv[0];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	if (w!=NIL) goto packsymCON2520;
packsymCON2524:
	local[2]= NIL;
packsymCON2520:
	goto packsymIF2519;
packsymIF2518:
	local[2]= NIL;
packsymIF2519:
packsymIF2517:
packsymIF2515:
packsymIF2513:
packsymIF2511:
	w = local[2];
	local[0]= w;
packsymBLK2507:
	ctx->vsp=local; return(local[0]);}

/*gentemp*/
static pointer packsymF2438gentemp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto packsymENT2528;}
	local[0]= fqv[16];
packsymENT2528:
	if (n>=2) { local[1]=(argv[1]); goto packsymENT2527;}
	local[1]= loadglobal(fqv[6]);
packsymENT2527:
packsymENT2526:
	if (n>2) maerror();
	local[2]= NIL;
packsymWHL2529:
	local[3]= loadglobal(fqv[17]);
	local[4]= local[0];
	local[5]= loadglobal(fqv[18]);
	ctx->vsp=local+6;
	w=(*ftab[0])(ctx,1,local+5,&ftab[0],fqv[17]); /*string*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)CONCATENATE(ctx,3,local+3); /*concatenate*/
	local[2] = w;
	local[3]= local[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)FINDSYMBOL(ctx,2,local+3); /*find-symbol*/
	if (w==NIL) goto packsymWHX2530;
	local[3]= loadglobal(fqv[18]);
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	storeglobal(fqv[18],w);
	goto packsymWHL2529;
packsymWHX2530:
	local[3]= NIL;
packsymBLK2531:
	local[3]= local[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)INTERN(ctx,2,local+3); /*intern*/
	local[0]= w;
packsymBLK2525:
	ctx->vsp=local; return(local[0]);}

/*:use-list*/
static pointer packsymM2532package_use_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
packsymBLK2533:
	ctx->vsp=local; return(local[0]);}

/*:used-by-list*/
static pointer packsymM2534package_used_by_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
packsymBLK2535:
	ctx->vsp=local; return(local[0]);}

/*:used-by*/
static pointer packsymM2536package_used_by(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[19]); /*adjoin*/
	argv[0]->c.obj.iv[8] = w;
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
packsymBLK2537:
	ctx->vsp=local; return(local[0]);}

/*:use*/
static pointer packsymM2538package_use(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto packsymIF2540;
packsymWHL2542:
	if (argv[2]==NIL) goto packsymWHX2543;
	local[0]= argv[0];
	local[1]= fqv[20];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	goto packsymWHL2542;
packsymWHX2543:
	local[0]= NIL;
packsymBLK2544:
	local[0]= argv[0]->c.obj.iv[2];
	goto packsymIF2541;
packsymIF2540:
	local[0]= NIL;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)FINDPACKAGE(ctx,1,local+1); /*find-package*/
	argv[2] = w;
	local[1]= argv[2];
	if (argv[0]==local[1]) goto packsymIF2545;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)packsymF2443packagep(ctx,1,local+1); /*packagep*/
	if (w==NIL) goto packsymIF2545;
	local[1]= NIL;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)FINDPACKAGE(ctx,1,local+2); /*find-package*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= *(ovafptr(local[2],fqv[21]));
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
packsymWHL2547:
	local[6]= local[3];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w==NIL) goto packsymWHX2548;
	local[6]= local[4];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[1] = w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[3] = w;
	w = local[1];
	if (!issymbol(w)) goto packsymIF2550;
	local[6]= argv[0];
	local[7]= fqv[22];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto packsymIF2552;
	local[6]= argv[0]->c.obj.iv[5];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[6]->c.vec.v[i]);}
	local[6]= w;
	if (local[1]==local[6]) goto packsymIF2552;
	local[6]= fqv[23];
	local[7]= local[1];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)SIGERROR(ctx,3,local+6); /*error*/
	local[6]= w;
	goto packsymIF2553;
packsymIF2552:
	local[6]= NIL;
packsymIF2553:
	goto packsymIF2551;
packsymIF2550:
	local[6]= NIL;
packsymIF2551:
	goto packsymWHL2547;
packsymWHX2548:
	local[6]= NIL;
packsymBLK2549:
	w = NIL;
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[19]); /*adjoin*/
	argv[0]->c.obj.iv[2] = w;
	local[1]= argv[2];
	local[2]= fqv[24];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto packsymIF2546;
packsymIF2545:
	local[1]= NIL;
packsymIF2546:
	w = local[1];
	local[0]= w;
packsymIF2541:
	w = local[0];
	local[0]= w;
packsymBLK2539:
	ctx->vsp=local; return(local[0]);}

/*:unuse*/
static pointer packsymM2554package_unuse(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	argv[2] = w;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)packsymF2443packagep(ctx,1,local+0); /*packagep*/
	if (w==NIL) goto packsymIF2556;
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[25]); /*delete*/
	argv[0]->c.obj.iv[2] = w;
	local[0]= argv[2];
	local[1]= fqv[26];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto packsymIF2557;
packsymIF2556:
	local[0]= NIL;
packsymIF2557:
	w = local[0];
	local[0]= w;
packsymBLK2555:
	ctx->vsp=local; return(local[0]);}

/*:unused*/
static pointer packsymM2558package_unused(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[25]); /*delete*/
	argv[0]->c.obj.iv[8] = w;
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
packsymBLK2559:
	ctx->vsp=local; return(local[0]);}

/*:name*/
static pointer packsymM2560package_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
packsymBLK2561:
	ctx->vsp=local; return(local[0]);}

/*:rename*/
static pointer packsymM2562package_rename(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[17]); /*string*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
packsymBLK2563:
	ctx->vsp=local; return(local[0]);}

/*:nicknames*/
static pointer packsymM2564package_nicknames(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto packsymENT2567;}
	local[0]= NIL;
packsymENT2567:
packsymENT2566:
	if (n>3) maerror();
	if (local[0]==NIL) goto packsymIF2568;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= (pointer)get_sym_func(fqv[17]);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= fqv[27];
	local[4]= (pointer)get_sym_func(fqv[28]);
	ctx->vsp=local+5;
	w=(*ftab[3])(ctx,4,local+1,&ftab[3],fqv[29]); /*union*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= argv[0]->c.obj.iv[1];
	goto packsymIF2569;
packsymIF2568:
	local[1]= NIL;
packsymIF2569:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
packsymBLK2565:
	ctx->vsp=local; return(local[0]);}

/*:hash*/
static pointer packsymM2570package_hash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[17]); /*string*/
	argv[2] = w;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)SXHASH(ctx,1,local+0); /*sxhash*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MOD(ctx,2,local+0); /*mod*/
	local[0]= w;
packsymBLK2571:
	ctx->vsp=local; return(local[0]);}

/*:enter*/
static pointer packsymM2572package_enter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (issymbol(w)) goto packsymIF2574;
	w = NIL;
	ctx->vsp=local+0;
	local[0]=w;
	goto packsymBLK2573;
	goto packsymIF2575;
packsymIF2574:
	local[0]= NIL;
packsymIF2575:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)SXHASH(ctx,1,local+0); /*sxhash*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MOD(ctx,2,local+0); /*mod*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[6];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)GREQP(ctx,2,local+2); /*>=*/
	if (w==NIL) goto packsymIF2576;
	local[2]= fqv[30];
	local[3]= argv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,3,local+2); /*error*/
	local[2]= w;
	goto packsymIF2577;
packsymIF2576:
	local[2]= NIL;
packsymIF2577:
packsymWHL2578:
	local[2]= argv[0]->c.obj.iv[5];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[2]->c.vec.v[i]);}
	if (!issymbol(w)) goto packsymWHX2579;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)GREQP(ctx,2,local+2); /*>=*/
	if (w==NIL) goto packsymIF2581;
	local[0] = makeint((eusinteger_t)0L);
	local[2]= local[0];
	goto packsymIF2582;
packsymIF2581:
	local[2]= NIL;
packsymIF2582:
	goto packsymWHL2578;
packsymWHX2579:
	local[2]= NIL;
packsymBLK2580:
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= local[0];
	w = argv[2];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[3]); v=local[2];
	  v->c.vec.v[i]=w;}
	local[2]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	argv[0]->c.obj.iv[6] = w;
	w = argv[2];
	local[0]= w;
packsymBLK2573:
	ctx->vsp=local; return(local[0]);}

/*:find*/
static pointer packsymM2583package_find(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (issymbol(w)) goto packsymIF2585;
	local[0]= fqv[31];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto packsymIF2586;
packsymIF2585:
	local[0]= NIL;
packsymIF2586:
	local[0]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)SXHASH(ctx,1,local+1); /*sxhash*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)MOD(ctx,2,local+1); /*mod*/
	local[1]= w;
	local[2]= NIL;
packsymWHL2587:
	if (T==NIL) goto packsymWHX2588;
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MOD(ctx,2,local+4); /*mod*/
	{ register eusinteger_t i=intval(w);
	  w=(local[3]->c.vec.v[i]);}
	local[2] = w;
	local[3]= local[2];
	if (makeint((eusinteger_t)0L)!=local[3]) goto packsymCON2591;
	w = NIL;
	ctx->vsp=local+3;
	local[0]=w;
	goto packsymBLK2584;
	goto packsymCON2590;
packsymCON2591:
	local[3]= local[2];
	local[3]= ((makeint((eusinteger_t)1L))==(local[3])?T:NIL);
	if (local[3]!=NIL) goto packsymCON2590;
packsymCON2592:
	local[3]= local[2]->c.obj.iv[4];
	local[4]= argv[2]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)EQUAL(ctx,2,local+3); /*equal*/
	if (w==NIL) goto packsymCON2593;
	local[3]= local[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MOD(ctx,2,local+3); /*mod*/
	ctx->vsp=local+3;
	local[0]=w;
	goto packsymBLK2584;
	goto packsymCON2590;
packsymCON2593:
	local[3]= NIL;
packsymCON2590:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	if (w==NIL) goto packsymIF2594;
	local[3]= fqv[32];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,2,local+3); /*error*/
	local[3]= w;
	goto packsymIF2595;
packsymIF2594:
	local[3]= NIL;
packsymIF2595:
	goto packsymWHL2587;
packsymWHX2588:
	local[3]= NIL;
packsymBLK2589:
	w = NIL;
	local[0]= w;
packsymBLK2584:
	ctx->vsp=local; return(local[0]);}

/*:shadow*/
static pointer packsymM2596package_shadow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[22];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w!=NIL) goto packsymIF2598;
	local[0]= argv[0];
	local[1]= fqv[33];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,1,local+2,&ftab[0],fqv[17]); /*string*/
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)packsymF2436make_symbol(ctx,2,local+2); /*make-symbol*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto packsymIF2599;
packsymIF2598:
	local[0]= NIL;
packsymIF2599:
	w = local[0];
	local[0]= w;
packsymBLK2597:
	ctx->vsp=local; return(local[0]);}

/*:import*/
static pointer packsymM2600package_import(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[22];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	if (local[0]==NIL) goto packsymIF2602;
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[5];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[2]->c.vec.v[i]);}
	if (w==local[1]) goto packsymIF2602;
	local[1]= fqv[34];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto packsymIF2603;
packsymIF2602:
	local[1]= argv[0];
	local[2]= fqv[33];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
packsymIF2603:
	w = local[1];
	local[0]= w;
packsymBLK2601:
	ctx->vsp=local; return(local[0]);}

/*:unintern*/
static pointer packsymM2604package_unintern(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= *(ovafptr(argv[2],fqv[35]));
	if (argv[0]!=local[1]) goto packsymIF2606;
	local[1]= NIL;
	local[2]= local[1];
	*(ovafptr(argv[2],fqv[35])) = local[2];
	goto packsymIF2607;
packsymIF2606:
	local[1]= NIL;
packsymIF2607:
	local[1]= argv[0];
	local[2]= fqv[22];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto packsymIF2608;
	local[1]= argv[0]->c.obj.iv[5];
	local[2]= local[0];
	w = makeint((eusinteger_t)1L);
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[2]); v=local[1];
	  v->c.vec.v[i]=w;}
	local[1]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	argv[0]->c.obj.iv[6] = w;
	local[1]= argv[0]->c.obj.iv[6];
	goto packsymIF2609;
packsymIF2608:
	local[1]= NIL;
packsymIF2609:
	local[1]= argv[0];
	local[2]= fqv[36];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto packsymIF2610;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= local[0];
	w = makeint((eusinteger_t)1L);
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[2]); v=local[1];
	  v->c.vec.v[i]=w;}
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	argv[0]->c.obj.iv[4] = w;
	local[1]= argv[0]->c.obj.iv[4];
	goto packsymIF2611;
packsymIF2610:
	local[1]= NIL;
packsymIF2611:
	w = local[1];
	local[0]= w;
packsymBLK2605:
	ctx->vsp=local; return(local[0]);}

/*:find-external*/
static pointer packsymM2612package_find_external(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (issymbol(w)) goto packsymIF2614;
	local[0]= fqv[37];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto packsymIF2615;
packsymIF2614:
	local[0]= NIL;
packsymIF2615:
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)SXHASH(ctx,1,local+1); /*sxhash*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)MOD(ctx,2,local+1); /*mod*/
	local[1]= w;
	local[2]= NIL;
packsymWHL2616:
	if (T==NIL) goto packsymWHX2617;
	local[3]= argv[0]->c.obj.iv[3];
	{ register eusinteger_t i=intval(local[1]);
	  w=(local[3]->c.vec.v[i]);}
	local[2] = w;
	local[3]= local[2];
	if (makeint((eusinteger_t)0L)!=local[3]) goto packsymCON2620;
	w = NIL;
	ctx->vsp=local+3;
	local[0]=w;
	goto packsymBLK2613;
	goto packsymCON2619;
packsymCON2620:
	local[3]= local[2];
	local[3]= ((makeint((eusinteger_t)1L))==(local[3])?T:NIL);
	if (local[3]!=NIL) goto packsymCON2619;
packsymCON2621:
	local[3]= local[2]->c.obj.iv[4];
	local[4]= argv[2]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)EQUAL(ctx,2,local+3); /*equal*/
	if (w==NIL) goto packsymCON2622;
	w = local[1];
	ctx->vsp=local+3;
	local[0]=w;
	goto packsymBLK2613;
	goto packsymCON2619;
packsymCON2622:
	local[3]= NIL;
packsymCON2619:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	local[3]= local[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	if (w==NIL) goto packsymIF2623;
	local[1] = makeint((eusinteger_t)0L);
	local[3]= local[1];
	goto packsymIF2624;
packsymIF2623:
	local[3]= NIL;
packsymIF2624:
	goto packsymWHL2616;
packsymWHX2617:
	local[3]= NIL;
packsymBLK2618:
	w = NIL;
	local[0]= w;
packsymBLK2613:
	ctx->vsp=local; return(local[0]);}

/*:unexport*/
static pointer packsymM2625package_unexport(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[36];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	if (local[0]==NIL) goto packsymIF2627;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= local[0];
	w = makeint((eusinteger_t)0L);
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[2]); v=local[1];
	  v->c.vec.v[i]=w;}
	local[1]= w;
	goto packsymIF2628;
packsymIF2627:
	local[1]= NIL;
packsymIF2628:
	w = local[1];
	local[0]= w;
packsymBLK2626:
	ctx->vsp=local; return(local[0]);}

/*package-name*/
static pointer packsymF2439package_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	argv[0] = w;
	local[0]= argv[0];
	local[1]= fqv[38];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
packsymBLK2629:
	ctx->vsp=local; return(local[0]);}

/*package-nicknames*/
static pointer packsymF2440package_nicknames(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	local[1]= fqv[39];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
packsymBLK2630:
	ctx->vsp=local; return(local[0]);}

/*package-use-list*/
static pointer packsymF2441package_use_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	local[1]= fqv[40];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
packsymBLK2631:
	ctx->vsp=local; return(local[0]);}

/*package-used-by-list*/
static pointer packsymF2442package_used_by_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	local[1]= fqv[41];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
packsymBLK2632:
	ctx->vsp=local; return(local[0]);}

/*packagep*/
static pointer packsymF2443packagep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	w = ((loadglobal(fqv[42]))==(local[0])?T:NIL);
	local[0]= w;
packsymBLK2633:
	ctx->vsp=local; return(local[0]);}

/*use-package*/
static pointer packsymF2444use_package(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto packsymENT2636;}
	local[0]= loadglobal(fqv[6]);
packsymENT2636:
packsymENT2635:
	if (n>2) maerror();
	local[1]= local[0];
	local[2]= fqv[20];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = T;
	local[0]= w;
packsymBLK2634:
	ctx->vsp=local; return(local[0]);}

/*unuse-package*/
static pointer packsymF2445unuse_package(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto packsymENT2639;}
	local[0]= loadglobal(fqv[6]);
packsymENT2639:
packsymENT2638:
	if (n>2) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)FINDPACKAGE(ctx,1,local+1); /*find-package*/
	local[1]= w;
	local[2]= fqv[43];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
packsymBLK2637:
	ctx->vsp=local; return(local[0]);}

/*make-package*/
static pointer packsymF2446make_package(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[44], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto packsymKEY2641;
	local[0] = NIL;
packsymKEY2641:
	if (n & (1<<1)) goto packsymKEY2642;
	local[2]= fqv[45];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[1] = w;
packsymKEY2642:
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MAKEPACKAGE(ctx,3,local+2); /*system::makepackage*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[20];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	w = local[2];
	local[0]= w;
packsymBLK2640:
	ctx->vsp=local; return(local[0]);}

/*in-package*/
static pointer packsymF2643(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[46];
	local[1]= fqv[47];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[48];
	local[3]= fqv[6];
	local[4]= fqv[47];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[49];
	local[4]= fqv[50];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
packsymBLK2644:
	ctx->vsp=local; return(local[0]);}

/*rename-package*/
static pointer packsymF2447rename_package(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto packsymENT2647;}
	local[0]= NIL;
packsymENT2647:
packsymENT2646:
	if (n>3) maerror();
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)FINDPACKAGE(ctx,1,local+1); /*find-package*/
	argv[0] = w;
	local[1]= argv[0];
	local[2]= fqv[51];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (local[0]==NIL) goto packsymIF2648;
	local[1]= argv[0];
	local[2]= fqv[39];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto packsymIF2649;
packsymIF2648:
	local[1]= NIL;
packsymIF2649:
	w = local[1];
	local[0]= w;
packsymBLK2645:
	ctx->vsp=local; return(local[0]);}

/*shadow*/
static pointer packsymF2448shadow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto packsymENT2652;}
	local[0]= loadglobal(fqv[6]);
packsymENT2652:
packsymENT2651:
	if (n>2) maerror();
	w = argv[0];
	if (!issymbol(w)) goto packsymIF2653;
	local[1]= local[0];
	local[2]= fqv[52];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto packsymIF2654;
packsymIF2653:
packsymWHL2655:
	if (argv[0]==NIL) goto packsymWHX2656;
	local[1]= local[0];
	local[2]= fqv[52];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	goto packsymWHL2655;
packsymWHX2656:
	local[1]= NIL;
packsymBLK2657:
packsymIF2654:
	w = local[1];
	local[0]= w;
packsymBLK2650:
	ctx->vsp=local; return(local[0]);}

/*import*/
static pointer packsymF2449import(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto packsymENT2660;}
	local[0]= loadglobal(fqv[6]);
packsymENT2660:
packsymENT2659:
	if (n>2) maerror();
	w = argv[0];
	if (!issymbol(w)) goto packsymIF2661;
	local[1]= local[0];
	local[2]= fqv[53];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto packsymIF2662;
packsymIF2661:
packsymWHL2663:
	if (argv[0]==NIL) goto packsymWHX2664;
	local[1]= local[0];
	local[2]= fqv[53];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	goto packsymWHL2663;
packsymWHX2664:
	local[1]= NIL;
packsymBLK2665:
packsymIF2662:
	w = T;
	local[0]= w;
packsymBLK2658:
	ctx->vsp=local; return(local[0]);}

/*symbol-string*/
static pointer packsymF2450symbol_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!issymbol(w)) goto packsymIF2667;
	local[0]= *(ovafptr(argv[0],fqv[54]));
	goto packsymIF2668;
packsymIF2667:
	local[0]= fqv[55];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
packsymIF2668:
	w = local[0];
	local[0]= w;
packsymBLK2666:
	ctx->vsp=local; return(local[0]);}

/*unintern*/
static pointer packsymF2451unintern(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto packsymENT2671;}
	local[0]= loadglobal(fqv[6]);
packsymENT2671:
packsymENT2670:
	if (n>2) maerror();
	w = argv[0];
	if (!issymbol(w)) goto packsymIF2672;
	local[1]= local[0];
	local[2]= fqv[56];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto packsymIF2673;
packsymIF2672:
	local[1]= fqv[57];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
packsymIF2673:
	w = local[1];
	local[0]= w;
packsymBLK2669:
	ctx->vsp=local; return(local[0]);}

/*package-stats*/
static pointer packsymF2452package_stats(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto packsymENT2676;}
	local[0]= T;
packsymENT2676:
packsymENT2675:
	if (n>1) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)ALLPACKAGES(ctx,0,local+5); /*list-all-packages*/
	local[5]= w;
packsymWHL2677:
	if (local[5]==NIL) goto packsymWHX2678;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= (pointer)get_sym_func(fqv[58]);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)packsymF2441package_use_list(ctx,1,local+7); /*package-use-list*/
	local[7]= w;
	local[8]= fqv[39];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[59]); /*send-all*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[2] = w;
	local[6]= (pointer)get_sym_func(fqv[58]);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)packsymF2442package_used_by_list(ctx,1,local+7); /*package-used-by-list*/
	local[7]= w;
	local[8]= fqv[39];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[59]); /*send-all*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[3] = w;
	local[6]= local[0];
	local[7]= fqv[60];
	local[8]= local[4];
	local[9]= fqv[39];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[4];
	local[10]= fqv[39];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto packsymIF2680;
	local[9]= local[4];
	local[10]= fqv[39];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	goto packsymIF2681;
packsymIF2680:
	local[9]= fqv[61];
packsymIF2681:
	local[10]= local[4]->c.obj.iv[4];
	if (local[2]==NIL) goto packsymIF2682;
	local[11]= local[2];
	goto packsymIF2683;
packsymIF2682:
	local[11]= fqv[62];
packsymIF2683:
	if (local[3]==NIL) goto packsymIF2684;
	local[12]= local[3];
	goto packsymIF2685;
packsymIF2684:
	local[12]= fqv[63];
packsymIF2685:
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,7,local+6); /*format*/
	goto packsymWHL2677;
packsymWHX2678:
	local[6]= NIL;
packsymBLK2679:
	w = NIL;
	local[0]= w;
packsymBLK2674:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___packsym(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[64];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= fqv[65];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto packsymIF2686;
	local[0]= fqv[66];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[6],w);
	goto packsymIF2687;
packsymIF2686:
	local[0]= fqv[67];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
packsymIF2687:
	local[0]= fqv[68];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[69],module,packsymF2431metaclass_name,fqv[70]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2454symbol_home_package,fqv[4],fqv[8],fqv[71]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2456symbol_pname,fqv[72],fqv[8],fqv[73]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2458symbol_func,fqv[74],fqv[8],fqv[75]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2460symbol_value,fqv[76],fqv[8],fqv[77]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2464symbol_constant,fqv[78],fqv[8],fqv[79]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2472symbol_special,fqv[80],fqv[8],fqv[81]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2480symbol_global,fqv[82],fqv[8],fqv[83]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2486symbol_vtype,fqv[84],fqv[8],fqv[85]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2492symbol_init,fqv[86],fqv[8],fqv[87]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[88],module,packsymF2432symbol_plist,fqv[89]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[90],module,packsymF2433remprop,fqv[91]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[92],module,packsymF2434symbol_package,fqv[93]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[94],module,packsymF2435symbol_name,fqv[95]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[96],module,packsymF2436make_symbol,fqv[97]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[98],module,packsymF2437documentation,fqv[99]);
	local[0]= makeint((eusinteger_t)0L);
	storeglobal(fqv[18],local[0]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[100],module,packsymF2438gentemp,fqv[101]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2532package_use_list,fqv[40],fqv[42],fqv[102]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2534package_used_by_list,fqv[41],fqv[42],fqv[103]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2536package_used_by,fqv[24],fqv[42],fqv[104]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2538package_use,fqv[20],fqv[42],fqv[105]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2554package_unuse,fqv[43],fqv[42],fqv[106]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2558package_unused,fqv[26],fqv[42],fqv[107]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2560package_name,fqv[38],fqv[42],fqv[108]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2562package_rename,fqv[51],fqv[42],fqv[109]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2564package_nicknames,fqv[39],fqv[42],fqv[110]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2570package_hash,fqv[111],fqv[42],fqv[112]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2572package_enter,fqv[33],fqv[42],fqv[113]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2583package_find,fqv[22],fqv[42],fqv[114]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2596package_shadow,fqv[52],fqv[42],fqv[115]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2600package_import,fqv[53],fqv[42],fqv[116]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2604package_unintern,fqv[56],fqv[42],fqv[117]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2612package_find_external,fqv[36],fqv[42],fqv[118]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,packsymM2625package_unexport,fqv[119],fqv[42],fqv[120]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[121],module,packsymF2439package_name,fqv[122]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[123],module,packsymF2440package_nicknames,fqv[124]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[125],module,packsymF2441package_use_list,fqv[126]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[127],module,packsymF2442package_used_by_list,fqv[128]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[129],module,packsymF2443packagep,fqv[130]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[131],module,packsymF2444use_package,fqv[132]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[133],module,packsymF2445unuse_package,fqv[134]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[135],module,packsymF2446make_package,fqv[136]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[137],module,packsymF2643,fqv[138]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[139],module,packsymF2447rename_package,fqv[140]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[141],module,packsymF2448shadow,fqv[142]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[143],module,packsymF2449import,fqv[144]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[145],module,packsymF2450symbol_string,fqv[146]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[147],module,packsymF2451unintern,fqv[148]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[149],module,packsymF2452package_stats,fqv[150]);
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<5; i++) ftab[i]=fcallx;
}

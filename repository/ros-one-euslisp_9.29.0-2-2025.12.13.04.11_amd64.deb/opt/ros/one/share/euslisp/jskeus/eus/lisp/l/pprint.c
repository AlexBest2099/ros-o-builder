/* ./pprint.c :  entry=pprint */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Dec 13 04:13:03 UTC 2025) */
#include "eus.h"
#include "pprint.h"
#pragma init (register_pprint)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___pprint();
extern pointer build_quote_vector();
static int register_pprint()
  { add_module_initializer("___pprint", ___pprint);}

static pointer pprintF984spaces();
static pointer pprintF985px();
static pointer pprintF986pp_method();
static pointer pprintF987pprint();
static pointer pprintF988pprint_file();
static pointer pprintF989pprint1();
static pointer pprintF990pparg();
static pointer pprintF991pprint_array();
static pointer pprintF992tprint();

/*spaces*/
static pointer pprintF984spaces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto pprintENT995;}
	local[0]= T;
pprintENT995:
pprintENT994:
	if (n>2) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
pprintWHL996:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto pprintWHX997;
	local[3]= fqv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)PRINC(ctx,2,local+3); /*princ*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto pprintWHL996;
pprintWHX997:
	local[3]= NIL;
pprintBLK998:
	w = NIL;
	local[0]= w;
pprintBLK993:
	ctx->vsp=local; return(local[0]);}

/*px*/
static pointer pprintF985px(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto pprintENT1001;}
	local[0]= T;
pprintENT1001:
pprintENT1000:
	if (n>2) maerror();
	local[1]= local[0];
	local[2]= fqv[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[0]= w;
pprintBLK999:
	ctx->vsp=local; return(local[0]);}

/*pf*/
static pointer pprintF1002(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto pprintENT1005;}
	local[0]= loadglobal(fqv[2]);
pprintENT1005:
pprintENT1004:
	if (n>2) maerror();
	local[1]= fqv[3];
	local[2]= fqv[4];
	local[3]= fqv[5];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[6];
	local[4]= fqv[7];
	local[5]= fqv[5];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[5];
	local[5]= fqv[8];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
pprintBLK1003:
	ctx->vsp=local; return(local[0]);}

/*pp-method*/
static pointer pprintF986pp_method(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto pprintENT1008;}
	local[0]= loadglobal(fqv[2]);
pprintENT1008:
pprintENT1007:
	if (n>3) maerror();
	local[1]= argv[1];
	local[2]= *(ovafptr(argv[0],fqv[9]));
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[10]); /*assoc*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)pprintF987pprint(ctx,2,local+1); /*pprint*/
	local[0]= w;
pprintBLK1006:
	ctx->vsp=local; return(local[0]);}

/*pprint*/
static pointer pprintF987pprint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto pprintENT1013;}
	local[0]= loadglobal(fqv[2]);
pprintENT1013:
	if (n>=3) { local[1]=(argv[2]); goto pprintENT1012;}
	local[1]= makeint((eusinteger_t)0L);
pprintENT1012:
	if (n>=4) { local[2]=(argv[3]); goto pprintENT1011;}
	local[2]= makeint((eusinteger_t)75L);
pprintENT1011:
pprintENT1010:
	if (n>4) maerror();
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)pprintF989pprint1(ctx,4,local+3); /*pprint1*/
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TERPRI(ctx,1,local+3); /*terpri*/
	local[0]= w;
pprintBLK1009:
	ctx->vsp=local; return(local[0]);}

/*pprint-file*/
static pointer pprintF988pprint_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= fqv[11];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[13]); /*open*/
	local[0]= w;
	ctx->vsp=local+1;
	w = makeclosure(codevec,quotevec,pprintUWP1015,env,argv,local);
	local[1]=(pointer)(ctx->protfp); local[2]=w;
	ctx->protfp=(struct protectframe *)(local+1);
	local[3]= argv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)pprintF987pprint(ctx,2,local+3); /*pprint*/
	ctx->vsp=local+3;
	pprintUWP1015(ctx,0,local+3,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
pprintBLK1014:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer pprintUWP1015(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*pprint1*/
static pointer pprintF989pprint1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[0];
	if (issymbol(w)) goto pprintOR1019;
	w = argv[0];
	if (numberp(w)) goto pprintOR1019;
	w = argv[0];
	if (isstring(w)) goto pprintOR1019;
	local[0]= argv[0];
	local[1]= argv[3];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PRNTSIZE(ctx,2,local+0); /*print-size*/
	local[0]= w;
	local[1]= argv[3];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w!=NIL) goto pprintOR1019;
	goto pprintCON1018;
pprintOR1019:
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PRIN1(ctx,2,local+0); /*prin1*/
	local[0]= w;
	goto pprintCON1017;
pprintCON1018:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto pprintCON1020;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[5]!=local[0]) goto pprintCON1020;
	local[0]= fqv[14];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PRINC(ctx,2,local+0); /*princ*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)pprintF989pprint1(ctx,4,local+0); /*pprint1*/
	local[0]= w;
	goto pprintCON1017;
pprintCON1020:
	local[0]= argv[0];
	local[1]= loadglobal(fqv[15]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto pprintCON1021;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[2])(ctx,1,local+0,&ftab[2],fqv[16]); /*array-rank*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto pprintCON1021;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[3])(ctx,1,local+0,&ftab[3],fqv[17]); /*array-total-size*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)100L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto pprintCON1021;
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)pprintF991pprint_array(ctx,3,local+0); /*pprint-array*/
	local[0]= w;
	goto pprintCON1017;
pprintCON1021:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)VECTORP(ctx,1,local+0); /*vectorp*/
	if (w==NIL) goto pprintCON1022;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[4])(ctx,1,local+0,&ftab[4],fqv[18]); /*float-vector-p*/
	if (w==NIL) goto pprintCON1024;
	local[0]= fqv[19];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PRINC(ctx,2,local+0); /*princ*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)3L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[2] = w;
	local[0]= argv[2];
	goto pprintCON1023;
pprintCON1024:
	local[0]= fqv[20];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PRINC(ctx,2,local+0); /*princ*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[2] = w;
	local[0]= argv[2];
	goto pprintCON1023;
pprintCON1025:
	local[0]= NIL;
pprintCON1023:
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
pprintWHL1026:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto pprintWHX1027;
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)pprintF989pprint1(ctx,4,local+2); /*pprint1*/
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)TERPRI(ctx,1,local+2); /*terpri*/
	local[2]= argv[2];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)pprintF984spaces(ctx,2,local+2); /*spaces*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto pprintWHL1026;
pprintWHX1027:
	local[2]= NIL;
pprintBLK1028:
	local[2]= fqv[21];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)PRINC(ctx,2,local+2); /*princ*/
	local[0]= w;
	goto pprintCON1017;
pprintCON1022:
	w = argv[0];
	if (!!iscons(w)) goto pprintCON1029;
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PRIN1(ctx,2,local+0); /*prin1*/
	local[0]= w;
	goto pprintCON1017;
pprintCON1029:
	local[0]= fqv[22];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PRINC(ctx,2,local+0); /*princ*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)LISTP(ctx,1,local+2); /*listp*/
	if (w==NIL) goto pprintIF1031;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	goto pprintIF1032;
pprintIF1031:
	local[2]= argv[2];
pprintIF1032:
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)pprintF989pprint1(ctx,4,local+0); /*pprint1*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= local[0];
	w = fqv[23];
	if (memq(local[1],w)==NIL) goto pprintIF1033;
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)pprintF984spaces(ctx,2,local+1); /*spaces*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)pprintF984spaces(ctx,2,local+1); /*spaces*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	argv[2] = w;
	local[2]= argv[2];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)PRNTSIZE(ctx,1,local+3); /*print-size*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)pprintF990pparg(ctx,4,local+1); /*pparg*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[1]= argv[0];
	goto pprintIF1034;
pprintIF1033:
	local[1]= local[0];
	w = fqv[24];
	if (memq(local[1],w)==NIL) goto pprintIF1035;
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)pprintF984spaces(ctx,2,local+1); /*spaces*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	argv[2] = w;
	local[2]= argv[2];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)PRNTSIZE(ctx,1,local+3); /*print-size*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)pprintF990pparg(ctx,4,local+1); /*pparg*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[1]= argv[0];
	goto pprintIF1036;
pprintIF1035:
	local[1]= local[0];
	w = fqv[25];
	if (memq(local[1],w)==NIL) goto pprintIF1037;
pprintWHL1039:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	if (argv[0]==NIL) goto pprintWHX1040;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto pprintWHX1040;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)TERPRI(ctx,1,local+1); /*terpri*/
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)pprintF984spaces(ctx,2,local+1); /*spaces*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)pprintF984spaces(ctx,2,local+1); /*spaces*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[1];
	local[3]= argv[2];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)PRNTSIZE(ctx,1,local+4); /*print-size*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,3,local+3); /*+*/
	local[3]= w;
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)pprintF989pprint1(ctx,4,local+1); /*pprint1*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	goto pprintWHL1039;
pprintWHX1040:
	local[1]= NIL;
pprintBLK1041:
	argv[0] = fqv[26];
	local[1]= argv[0];
	goto pprintIF1038;
pprintIF1037:
	if (T==NIL) goto pprintIF1042;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!issymbol(w)) goto pprintIF1044;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)FBOUNDP(ctx,1,local+1); /*fboundp*/
	if (w==NIL) goto pprintIF1044;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	argv[2] = w;
	local[1]= argv[2];
	goto pprintIF1045;
pprintIF1044:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	argv[2] = w;
	local[1]= argv[2];
pprintIF1045:
	goto pprintIF1043;
pprintIF1042:
	local[1]= NIL;
pprintIF1043:
pprintIF1038:
pprintIF1036:
pprintIF1034:
	w = local[1];
pprintWHL1046:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto pprintWHX1047;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	if (argv[0]==NIL) goto pprintWHX1047;
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)TERPRI(ctx,1,local+0); /*terpri*/
	local[0]= argv[2];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)pprintF984spaces(ctx,2,local+0); /*spaces*/
	w = argv[0];
	if (!!iscons(w)) goto pprintCON1050;
	local[0]= fqv[27];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PRINC(ctx,2,local+0); /*princ*/
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)pprintF989pprint1(ctx,4,local+0); /*pprint1*/
	local[0]= w;
	goto pprintCON1049;
pprintCON1050:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)pprintF989pprint1(ctx,4,local+0); /*pprint1*/
	local[0]= w;
	goto pprintCON1049;
pprintCON1051:
	local[0]= NIL;
pprintCON1049:
	goto pprintWHL1046;
pprintWHX1047:
	local[0]= NIL;
pprintBLK1048:
	local[0]= fqv[28];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PRINC(ctx,2,local+0); /*princ*/
	local[0]= w;
	goto pprintCON1017;
pprintCON1030:
	local[0]= NIL;
pprintCON1017:
	w = local[0];
	local[0]= w;
pprintBLK1016:
	ctx->vsp=local; return(local[0]);}

/*pparg*/
static pointer pprintF990pparg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[0];
	if (!iscons(w)) goto pprintOR1055;
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PRNTSIZE(ctx,2,local+0); /*print-size*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w!=NIL) goto pprintOR1055;
	goto pprintCON1054;
pprintOR1055:
	local[0]= argv[0];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)PRIN1(ctx,2,local+0); /*prin1*/
	local[0]= w;
	goto pprintCON1053;
pprintCON1054:
	local[0]= NIL;
	local[1]= fqv[29];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[0] = argv[1];
pprintWHL1057:
	if (argv[0]==NIL) goto pprintWHX1058;
	local[1]= local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)PRNTSIZE(ctx,1,local+2); /*print-size*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,3,local+1); /*+*/
	local[0] = w;
	local[1]= local[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto pprintCON1061;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)PRIN1(ctx,2,local+1); /*prin1*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[1]= argv[0];
	if (local[1]==NIL) goto pprintAND1062;
	local[1]= fqv[30];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[1]= w;
pprintAND1062:
	goto pprintCON1060;
pprintCON1061:
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)TERPRI(ctx,1,local+1); /*terpri*/
	local[1]= argv[1];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)pprintF984spaces(ctx,2,local+1); /*spaces*/
	local[0] = argv[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[3];
	local[3]= local[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)pprintF989pprint1(ctx,4,local+1); /*pprint1*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[1]= argv[0];
	if (local[1]==NIL) goto pprintAND1064;
	local[1]= fqv[31];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[1]= w;
pprintAND1064:
	goto pprintCON1060;
pprintCON1063:
	local[1]= NIL;
pprintCON1060:
	goto pprintWHL1057;
pprintWHX1058:
	local[1]= NIL;
pprintBLK1059:
	local[1]= fqv[32];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[0]= w;
	goto pprintCON1053;
pprintCON1056:
	local[0]= NIL;
pprintCON1053:
	w = local[0];
	local[0]= w;
pprintBLK1052:
	ctx->vsp=local; return(local[0]);}

/*pprint-array*/
static pointer pprintF991pprint_array(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[10]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[35]); /*array-dimension*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,2,local+2,&ftab[5],fqv[35]); /*array-dimension*/
	local[2]= w;
	if (local[0]!=NIL) goto pprintIF1066;
	local[0] = fqv[36];
	local[3]= local[0];
	goto pprintIF1067;
pprintIF1066:
	local[3]= NIL;
pprintIF1067:
	local[3]= argv[1];
	local[4]= fqv[37];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[1];
pprintWHL1068:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto pprintWHX1069;
	local[5]= argv[1];
	local[6]= fqv[38];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
pprintWHL1071:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto pprintWHX1072;
	local[7]= argv[1];
	local[8]= fqv[39];
	local[9]= argv[0];
	local[10]= local[3];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto pprintCON1075;
	local[7]= argv[1];
	local[8]= fqv[40];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= w;
	goto pprintCON1074;
pprintCON1075:
	local[7]= argv[1];
	local[8]= fqv[41];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= w;
	goto pprintCON1074;
pprintCON1076:
	local[7]= NIL;
pprintCON1074:
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto pprintWHL1071;
pprintWHX1072:
	local[7]= NIL;
pprintBLK1073:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[35]); /*array-dimension*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	if (w==NIL) goto pprintIF1077;
	local[5]= argv[1];
	local[6]= fqv[42];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)pprintF984spaces(ctx,2,local+5); /*spaces*/
	local[5]= w;
	goto pprintIF1078;
pprintIF1077:
	local[5]= NIL;
pprintIF1078:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto pprintWHL1068;
pprintWHX1069:
	local[5]= NIL;
pprintBLK1070:
	w = NIL;
	local[3]= argv[1];
	local[4]= fqv[43];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,2,local+3); /*format*/
	local[0]= w;
pprintBLK1065:
	ctx->vsp=local; return(local[0]);}

/*tprint*/
static pointer pprintF992tprint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto pprintENT1083;}
	local[0]= makeint((eusinteger_t)0L);
pprintENT1083:
	if (n>=4) { local[1]=(argv[3]); goto pprintENT1082;}
	local[1]= makeint((eusinteger_t)79L);
pprintENT1082:
	if (n>=5) { local[2]=(argv[4]); goto pprintENT1081;}
	local[2]= makeint((eusinteger_t)0L);
pprintENT1081:
pprintENT1080:
	if (n>5) maerror();
	local[3]= local[2];
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[1];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[0];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)pprintF984spaces(ctx,1,local+8); /*spaces*/
pprintWHL1084:
	if (argv[0]==NIL) goto pprintWHX1085;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)PRNTSIZE(ctx,1,local+8); /*print-size*/
	local[7] = w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[8]= argv[1];
	local[9]= local[7];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[5] = w;
	local[8]= local[5];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w==NIL) goto pprintCON1088;
	ctx->vsp=local+8;
	w=(pointer)TERPRI(ctx,0,local+8); /*terpri*/
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)pprintF984spaces(ctx,1,local+8); /*spaces*/
	local[3] = local[0];
	local[8]= local[1];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[6] = w;
	local[8]= local[6];
	goto pprintCON1087;
pprintCON1088:
	local[8]= NIL;
pprintCON1087:
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)PRINC(ctx,1,local+8); /*princ*/
	local[8]= local[5];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)pprintF984spaces(ctx,1,local+8); /*spaces*/
	local[8]= local[6];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[6] = w;
	local[8]= local[3];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[3] = w;
	goto pprintWHL1084;
pprintWHX1085:
	local[8]= NIL;
pprintBLK1086:
	w = local[8];
	local[0]= w;
pprintBLK1079:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___pprint(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[44];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto pprintIF1089;
	local[0]= fqv[45];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[46],w);
	goto pprintIF1090;
pprintIF1089:
	local[0]= fqv[47];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
pprintIF1090:
	local[0]= fqv[48];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[49],module,pprintF984spaces,fqv[50]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[51],module,pprintF985px,fqv[52]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[53],module,pprintF1002,fqv[54]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[55],module,pprintF986pp_method,fqv[56]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[6],module,pprintF987pprint,fqv[57]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[58],module,pprintF988pprint_file,fqv[59]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[60],module,pprintF989pprint1,fqv[61]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[62],module,pprintF990pparg,fqv[63]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[64],module,pprintF991pprint_array,fqv[65]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[66],module,pprintF992tprint,fqv[67]);
	local[0]= fqv[68];
	local[1]= fqv[69];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[70]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<7; i++) ftab[i]=fcallx;
}

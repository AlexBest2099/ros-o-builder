# euslisp.cmake
set(EUSDIR /opt/ros/one/share/euslisp/jskeus/eus)
set(ARCHDIR Linux64)
set(euslisp_INCLUDE_DIRS ${EUSDIR}/include)
message("-- set EUSDIR to ${EUSDIR}")
message("-- set ARCHDIR to ${ARCHDIR}")


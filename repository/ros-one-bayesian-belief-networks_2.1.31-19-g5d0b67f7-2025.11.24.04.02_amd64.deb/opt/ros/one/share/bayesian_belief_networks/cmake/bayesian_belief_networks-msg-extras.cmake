set(bayesian_belief_networks_MESSAGE_FILES "msg/Result.msg;msg/Observation.msg")
set(bayesian_belief_networks_SERVICE_FILES "srv/Query.srv")

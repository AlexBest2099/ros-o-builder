; Auto-generated. Do not edit!


(cl:in-package bayesian_belief_networks-srv)


;//! \htmlinclude Query-request.msg.html

(cl:defclass <Query-request> (roslisp-msg-protocol:ros-message)
  ((query
    :reader query
    :initarg :query
    :type (cl:vector bayesian_belief_networks-msg:Observation)
   :initform (cl:make-array 0 :element-type 'bayesian_belief_networks-msg:Observation :initial-element (cl:make-instance 'bayesian_belief_networks-msg:Observation))))
)

(cl:defclass Query-request (<Query-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Query-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Query-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name bayesian_belief_networks-srv:<Query-request> is deprecated: use bayesian_belief_networks-srv:Query-request instead.")))

(cl:ensure-generic-function 'query-val :lambda-list '(m))
(cl:defmethod query-val ((m <Query-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader bayesian_belief_networks-srv:query-val is deprecated.  Use bayesian_belief_networks-srv:query instead.")
  (query m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Query-request>) ostream)
  "Serializes a message object of type '<Query-request>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'query))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'query))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Query-request>) istream)
  "Deserializes a message object of type '<Query-request>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'query) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'query)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'bayesian_belief_networks-msg:Observation))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Query-request>)))
  "Returns string type for a service object of type '<Query-request>"
  "bayesian_belief_networks/QueryRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Query-request)))
  "Returns string type for a service object of type 'Query-request"
  "bayesian_belief_networks/QueryRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Query-request>)))
  "Returns md5sum for a message object of type '<Query-request>"
  "5cc4ca012e1b2c83f69c62071ca032f1")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Query-request)))
  "Returns md5sum for a message object of type 'Query-request"
  "5cc4ca012e1b2c83f69c62071ca032f1")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Query-request>)))
  "Returns full string definition for message of type '<Query-request>"
  (cl:format cl:nil "Observation[] query~%~%================================================================================~%MSG: bayesian_belief_networks/Observation~%string node~%string evidence~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Query-request)))
  "Returns full string definition for message of type 'Query-request"
  (cl:format cl:nil "Observation[] query~%~%================================================================================~%MSG: bayesian_belief_networks/Observation~%string node~%string evidence~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Query-request>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'query) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Query-request>))
  "Converts a ROS message object to a list"
  (cl:list 'Query-request
    (cl:cons ':query (query msg))
))
;//! \htmlinclude Query-response.msg.html

(cl:defclass <Query-response> (roslisp-msg-protocol:ros-message)
  ((results
    :reader results
    :initarg :results
    :type (cl:vector bayesian_belief_networks-msg:Result)
   :initform (cl:make-array 0 :element-type 'bayesian_belief_networks-msg:Result :initial-element (cl:make-instance 'bayesian_belief_networks-msg:Result))))
)

(cl:defclass Query-response (<Query-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Query-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Query-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name bayesian_belief_networks-srv:<Query-response> is deprecated: use bayesian_belief_networks-srv:Query-response instead.")))

(cl:ensure-generic-function 'results-val :lambda-list '(m))
(cl:defmethod results-val ((m <Query-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader bayesian_belief_networks-srv:results-val is deprecated.  Use bayesian_belief_networks-srv:results instead.")
  (results m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Query-response>) ostream)
  "Serializes a message object of type '<Query-response>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'results))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'results))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Query-response>) istream)
  "Deserializes a message object of type '<Query-response>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'results) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'results)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'bayesian_belief_networks-msg:Result))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Query-response>)))
  "Returns string type for a service object of type '<Query-response>"
  "bayesian_belief_networks/QueryResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Query-response)))
  "Returns string type for a service object of type 'Query-response"
  "bayesian_belief_networks/QueryResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Query-response>)))
  "Returns md5sum for a message object of type '<Query-response>"
  "5cc4ca012e1b2c83f69c62071ca032f1")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Query-response)))
  "Returns md5sum for a message object of type 'Query-response"
  "5cc4ca012e1b2c83f69c62071ca032f1")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Query-response>)))
  "Returns full string definition for message of type '<Query-response>"
  (cl:format cl:nil "Result[] results~%~%================================================================================~%MSG: bayesian_belief_networks/Result~%string node~%string Value~%float64 Marginal~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Query-response)))
  "Returns full string definition for message of type 'Query-response"
  (cl:format cl:nil "Result[] results~%~%================================================================================~%MSG: bayesian_belief_networks/Result~%string node~%string Value~%float64 Marginal~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Query-response>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'results) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Query-response>))
  "Converts a ROS message object to a list"
  (cl:list 'Query-response
    (cl:cons ':results (results msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'Query)))
  'Query-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'Query)))
  'Query-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Query)))
  "Returns string type for a service object of type '<Query>"
  "bayesian_belief_networks/Query")
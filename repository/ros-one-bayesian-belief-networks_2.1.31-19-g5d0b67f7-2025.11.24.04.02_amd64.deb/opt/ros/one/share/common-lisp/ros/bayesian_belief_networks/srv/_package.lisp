(cl:defpackage bayesian_belief_networks-srv
  (:use )
  (:export
   "QUERY"
   "<QUERY-REQUEST>"
   "QUERY-REQUEST"
   "<QUERY-RESPONSE>"
   "QUERY-RESPONSE"
  ))


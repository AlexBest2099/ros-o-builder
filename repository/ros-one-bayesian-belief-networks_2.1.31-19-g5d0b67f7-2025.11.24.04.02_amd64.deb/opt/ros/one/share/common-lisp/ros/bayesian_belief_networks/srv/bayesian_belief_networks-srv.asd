
(cl:in-package :asdf)

(defsystem "bayesian_belief_networks-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :bayesian_belief_networks-msg
)
  :components ((:file "_package")
    (:file "Query" :depends-on ("_package_Query"))
    (:file "_package_Query" :depends-on ("_package"))
  ))
// Auto-generated. Do not edit!

// (in-package bayesian_belief_networks.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Result {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node = null;
      this.Value = null;
      this.Marginal = null;
    }
    else {
      if (initObj.hasOwnProperty('node')) {
        this.node = initObj.node
      }
      else {
        this.node = '';
      }
      if (initObj.hasOwnProperty('Value')) {
        this.Value = initObj.Value
      }
      else {
        this.Value = '';
      }
      if (initObj.hasOwnProperty('Marginal')) {
        this.Marginal = initObj.Marginal
      }
      else {
        this.Marginal = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Result
    // Serialize message field [node]
    bufferOffset = _serializer.string(obj.node, buffer, bufferOffset);
    // Serialize message field [Value]
    bufferOffset = _serializer.string(obj.Value, buffer, bufferOffset);
    // Serialize message field [Marginal]
    bufferOffset = _serializer.float64(obj.Marginal, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Result
    let len;
    let data = new Result(null);
    // Deserialize message field [node]
    data.node = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [Value]
    data.Value = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [Marginal]
    data.Marginal = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.node);
    length += _getByteLength(object.Value);
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'bayesian_belief_networks/Result';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c12bc86306f498c9d6b12dcfb4492003';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string node
    string Value
    float64 Marginal
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Result(null);
    if (msg.node !== undefined) {
      resolved.node = msg.node;
    }
    else {
      resolved.node = ''
    }

    if (msg.Value !== undefined) {
      resolved.Value = msg.Value;
    }
    else {
      resolved.Value = ''
    }

    if (msg.Marginal !== undefined) {
      resolved.Marginal = msg.Marginal;
    }
    else {
      resolved.Marginal = 0.0
    }

    return resolved;
    }
};

module.exports = Result;

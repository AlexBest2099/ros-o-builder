(cl:in-package laser_cb_detector-msg)
(cl:export '(NUM_X-VAL
          NUM_X
          NUM_Y-VAL
          NUM_Y
          SPACING_X-VAL
          SPACING_X
          SPACING_Y-VAL
          SPACING_Y
          WIDTH_SCALING-VAL
          WIDTH_SCALING
          HEIGHT_SCALING-VAL
          HEIGHT_SCALING
          MIN_INTENSITY-VAL
          MIN_INTENSITY
          MAX_INTENSITY-VAL
          MAX_INTENSITY
          SUBPIXEL_WINDOW-VAL
          SUBPIXEL_WINDOW
          SUBPIXEL_ZERO_ZONE-VAL
          SUBPIXEL_ZERO_ZONE
          FLIP_HORIZONTAL-VAL
          FLIP_HORIZONTAL
))
(cl:in-package laser_cb_detector-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          RESULT-VAL
          RESULT
))